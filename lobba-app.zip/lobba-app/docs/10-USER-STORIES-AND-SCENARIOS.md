# 10 — User Stories & Scenarios

Written in the standard form **"As a `<role>`, I want `<goal>`, so that `<reason>`"**,
followed by **end-to-end scenarios** (happy paths + edge cases) that double as manual
QA scripts. Three roles: **Player**, **Court Owner**, **Platform Admin**.

---

## App open — animated welcome (all users)

**Story.** *As a user, I want an animated branded welcome when I open the app, so
that it feels premium and I know it's Lobba while it loads.*

**Scenario — cold open**
1. User taps the Lobba icon.
2. **Splash** plays: the "L" logo tile scales in with a glow, a court-ring pulse
   expands behind it, the **"Lobba"** wordmark and **"PADEL, PERFECTED"** tagline
   reveal, a loading shimmer runs at the bottom (~2.4 s).
3. If **not logged in** → **Welcome / role-select** (Player · Owner) → sign in.
4. If **logged in as player** → Home. If **owner** → Owner Dashboard.

*Acceptance:* animation is smooth, never blocks longer than ~2.5 s, and the correct
next screen is chosen from auth state.

---

## PLAYER

### P1 — Discover & book a court
*As a player, I want to find a court and book a free slot, so that I can play.*

**Happy path**
1. Home / Discover → filter (Indoor/Outdoor/Top-rated) → open a court.
2. Court detail shows real name, per-duration price, location, rating.
3. Reserve → pick **day**, **duration (60/90/120)**, a **30-min slot**, then a
   **free court (1..N)** (availability is live).
4. Players step: match is **private by default**; add players / invite (contacts or
   link); 2v2 + subs grid.
5. Payment: wallet / Apple / Google / Cash; optional **split** (each pays their share).
6. Review sheet (fees, VAT, cancellation policy) → **Confirm & pay**.
7. **Booking confirmed** → correct venue, court #, date, time, price → **QR ticket**
   (booker name = profile name; Share works).

**Edge cases**
- **All courts busy at that time** → slot greyed / "No courts free — change the slot
  or duration." Player must change time.
- **Court taken between selecting and confirming** → "That court just got taken —
  pick another time or court." Booking is blocked; no double-booking.
- **End-time is free:** a 90-min booking at 3:00 PM must leave **4:30 PM bookable**.
- **Insufficient wallet** → "Insufficient balance — top up first" → Top up flow.

### P2 — Split a booking with friends
*As a player, I want to split the cost, so that each friend pays their share.*
- Turn on Split → per-player share = total ÷ players. Booker pays their share now;
  invited players show **Pending payment** until they pay; open seats show **Waiting
  for a player**. Non-split → others just **confirm joining** (no per-player charge).

### P3 — Join an open match
*As a player, I want to join a nearby open match at my level, so that I can play with others.*
- Matches → filter (My level / Near me) → a card shows **court number**, venue, time,
  duration, spots → open → **detail reflects that exact match** → Confirm & join →
  "host confirms, you're notified."

### P4 — Book a discounted deal
*As a player, I want last-minute deals, so that I pay less on dead-time slots.*
- Deals → a deal shows **court number** + % off → "Book deal" opens the court with the
  **discounted price applied across durations** → book as normal.

### P5 — Wallet & top-up
*As a player, I want a wallet, so that I can pay quickly and protect my card.*
- Add card (number/expiry/CVV) → only a **masked label** is stored ("Visa •••• 4242");
  full number & CVV never saved. Top up via saved card / Apple Pay / Google Pay.

### P6 — Track my level & ranking
*As a player, I want a skill level and ranking, so that I get fair matches.*
- Take the assessment → get a level band (0–7). See national/city rankings & reliability.

---

## COURT OWNER

### O1 — See bookings in real time
*As an owner, I want every booking at my courts to appear instantly, so that I can run the venue.*
- Dashboard **Recent bookings** and **Court management availability** update the moment
  a player books (they watch the same booking engine). Dashboard period filter:
  **Today / 30 / 60 / 90 days** re-scales the KPIs.

### O2 — Manage courts & availability
*As an owner, I want to manage Court 1..N and see what's free, so that I avoid clashes.*
- Court management lists each court with a **live availability strip** ("Fully
  available" vs "N booked · next 6:00 PM"), status toggle, price/hours edit.

### O3 — Lock a WhatsApp booking
*As an owner, I want to lock a slot booked over WhatsApp, so that the app can't double-book it.*
- WhatsApp screen: court → date (sliding strip) → duration → **30-min time grid** →
  **Lock**. The lock writes to the booking engine, so the **player app can no longer
  book that court/time**. Unlock frees it.

**Edge case:** locking a slot another booking already covers → "That court just got
taken — pick another time or court."

### O4 — Approve / decline booking requests
*As an owner, I want to review incoming bookings, so that I control who plays.*
- Booking requests: approve/decline; cash bookings get a reminder; player names are
  tappable to their **owner-side profile**.

### O5 — Vet a player before approving
*As an owner, I want a player's history, so that I can avoid no-shows.*
- Tap any player name → history at **my courts only**, cancellations, payment method,
  a **risk verdict** (Safe / Risky to approve), and **Suspend from booking**.

### O6 — Run a last-minute deal
*As an owner, I want to discount dead-time slots, so that I fill empty courts.*
- Deals → New deal → court + original price + **% discount** + **30-min dead-time slot**
  + duration → save. Only low-demand slots are selectable.

### O7 — Read my analytics
*As an owner, I want revenue analytics I can filter, so that I understand my venue.*
- Analytics: **date range (from–to)** + **hour range (from–to)** + court + duration →
  every number (revenue bars, total, avg, busiest hour, top court, bookings) recomputes;
  export PDF.

### O8 — Manage my court profile
*As an owner, I want a court profile, so that players see accurate info.*
- Court profile hub: logo, name, location, admin/manager contacts, payout method, all
  settings, dark mode, language.

---

## PLATFORM ADMIN (web portal)

### A1 — Approve new venues (KYC)
*As an admin, I want to review venue applications, so that only legitimate courts go live.*
- KYC Approvals → review docs → **Approve** (venue becomes bookable) or **Reject**
  (with reason). Empty state: "All caught up."

### A2 — Pay owners
*As an admin, I want to pay owners their earnings, so that they get GMV minus commission.*
- Payouts → pending payout per owner = **GMV − 10% commission** → **Confirm transfer**
  (confirm dialog; never mark paid without a real transfer).

### A3 — Moderate users
*As an admin, I want to ban abusive users, so that the platform stays safe.*
- Users → search → **Ban / Unban** (confirm dialog). Every action should be audit-logged.

### A4 — Watch the marketplace
*As an admin, I want a platform overview, so that I can act on problems fast.*
- Dashboard: revenue (7-day), commission earned, bookings, **pending actions** badge
  (KYC + payouts). Sections for Venues, Bookings (all venues), Coaches, Academies,
  Deals, Analytics, Settings (commission rate, support email).

---

## Cross-cutting scenarios (QA checklist)

- **Bilingual:** every screen renders correctly in **Arabic (RTL)** and English.
- **Dark mode:** every screen is legible in both themes.
- **Double-booking is impossible** across the whole system (once the backend lands,
  this must hold across devices — see `docs/06`).
- **Money safety:** card number/CVV never stored; (post-backend) wallet balance is
  server-authoritative; admin payouts are deliberate + logged.
- **No dead ends:** every button navigates or acts (see `docs/03` for the remaining
  Phase-2 orphans that still need wiring).
