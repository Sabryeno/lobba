# 07 — Status & Backlog

The single source of truth for "what's real vs mock" and "what to build next".

## ✅ Done (front-end, on mock data)

- All ~40 screens built, navigable, bilingual (EN/AR + RTL), light/dark themed.
- Player + Owner apps, role-routed.
- Booking flow: 30-min slots, per-court live availability, overlap blocking,
  private-by-default matches, invite (contacts + link), 2v2+subs court grid,
  split payment reflecting player count, review sheet (fees/VAT/cancellation).
- Court identity threaded correctly through booking → confirmed → ticket
  (name/court#/date/time/price), booker name synced to profile, ticket share works.
- Percentage deals applied per duration; court numbers shown in deals & matches.
- Owner: dashboard with Today/30/60/90-day filter, live bookings feed, court
  management with live availability, booking requests, WhatsApp lock that **writes
  to the booking engine** (blocks players), analytics with date-range + hour-range
  filters + PDF export.
- Wallet: balance, add card (masked), top-up (card/Apple/Google) — all on mock money.
- Notifications screen: all types wired to their destinations.
- Full-app button audit done; the only real dead handlers found were fixed.

## 🟡 Mock — works but not real (needs backend)

| Area | Reality today |
|---|---|
| **Cross-device sync** | Device-local only. Two phones share nothing. |
| **Double-booking prevention** | Correct logic, but client-side → not enforced across devices. |
| **Wallet / money** | Local integer. Top-ups fake. No gateway. |
| **Auth** | Firebase packages present, flow is mock (no real sign-in/OTP). |
| **Analytics numbers** | Synthetic scaling factors (backend `venue_revenue()` exists to replace). |
| **Deals, matches rosters, leveling, rankings, tribes, player directory** | Hardcoded sample data. |
| **Push notifications** | Content exists in-app; no FCM delivery. |
| **Bookings/wallet/account persistence** | SharedPreferences (per-device, wiped on uninstall). |

## ❌ Missing entirely

1. **Backend + database** — designed in `backend/`, not executed. *Highest priority.*
2. **Server-side payments** (Paymob/Fawry) + webhooks + server-authoritative wallet.
3. **Real-time across devices** (Supabase Realtime subscription in the app).
4. **Real auth** (players + owners, role claim, phone OTP).
5. **iOS build** — folder exists, never configured/tested (signing, Firebase iOS).
6. **Automated tests** for the Flutter app; CI; crash reporting.
7. **Repository abstraction** in the app (needed to swap the store cleanly).

## ⚠️ Known gaps / bugs

- **Phase-2 screens are orphaned** (no entry point): Teams, Tournaments, Academies,
  Clubs, Chat, Create-match, Book-coach/Coach-detail.
- **Team detail** and **Tournament detail** are literal `"Coming Soon"` stubs
  (tournament one isn't even translated).
- Open-match detail shows a **representative player roster** (matches don't carry a
  real roster yet) — venue/court/date/time/skill/spots are correct, the 3 names are sample.
- `booking_confirmation_screen.dart` is an **older unused** confirmation variant
  (the wired one is `booking_confirmed_screen.dart`) — safe to delete.
- `day` is a **label index**, not a real date — must be mapped when the backend lands.

## Recommended build order (from here)

1. **Install Docker + Supabase CLI, run `backend/` locally, pass the overlap test.**
   (Proves the core guarantee before touching the app.)
2. **App: introduce `BookingRepository`** interface; keep current behaviour behind
   a `LocalBookingRepository`. No UI change.
3. **App: add Supabase, migrate Auth → Venues/Courts → Bookings → Realtime.**
4. **Payments** (own project): Paymob/Fawry + webhooks + server wallet.
5. **Wire or defer Phase-2** (teams/tournaments/etc.) — decide product scope.
6. **iOS pass, tests, CI, crash reporting.**

## Effort framing (rough, not a quote)

- Steps 1–3 (backend live + app on real data, single region) — the meaningful core.
- Step 4 (payments) — separate, gated by gateway onboarding and money-handling rules.
- Step 5+ — product scope decisions, not blockers.
