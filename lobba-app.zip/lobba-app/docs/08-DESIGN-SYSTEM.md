# 08 — Design System

Source of truth: `lib/core/theme/lobba_tokens.dart`. **Never hardcode colours** —
always use `context.t.<token>` so light/dark and RTL keep working.

## Themes

- **Light — "Sage Atelier"** (default): soft sage/green, cream surfaces.
- **Dark — "Ink & Brass"**: dark green/charcoal with brass/gold accent.

Toggle: Settings → Dark mode (player) / Court profile (owner), via `themeModeProvider`.

## Colour tokens

| Token | Light | Dark | Use |
|---|---|---|---|
| `bg` | `#E9EDE7` | `#1A1E1B` | screen background |
| `surface` | `#FFFFFF` | `#242A26` | cards |
| `surface2` | `#EEF2EC` | `#2D332E` | insets, chips |
| `ink` | `#1F2A24` | `#ECE7DC` | primary text |
| `ink2` | `#5E6B62` | `#A8A89D` | secondary text |
| `ink3` | `#9AA89F` | `#73776E` | muted text |
| `line` | `#DCE4DA` | `#343B35` | borders/dividers |
| `accent` | `#2F5446` (green) | `#C9A36B` (brass) | primary actions |
| `accentSoft` | `#E2ECE5` | `#2C2E25` | tinted backgrounds |
| `onAccent` | `#FFFFFF` | `#1A1E1B` | text on accent |
| `sage` | `#5E9B7A` | success / positive |
| `gold` | `#C49A52` | warnings / pending |
| `clay` | `#C2705A` | destructive / risk |
| `slate` | `#5E83A8` | info / map user dot |
| `headBg` / `headFg` | green header / white | — | screen headers |

Semantic status colours: **sage** = confirmed/available, **gold** = pending/locked,
**clay** = cancelled/risk/destructive.

## Typography

- `kSerif` — display / headings / big numbers (font family declared in tokens).
- `kSans` — body / UI.

> ⚠️ **Known nuance:** `lobba_tokens.dart` names the families `'Spectral'` /
> `'HankenGrotesk'`, while `pubspec.yaml` bundles `Tajawal` (Arabic), `Inter`,
> `PlayfairDisplay`. Verify the family names line up (or update one side) so custom
> fonts actually render instead of falling back to the platform default. This is a
> quick, worthwhile cleanup for the new dev.

## Shared widgets — `lib/core/widgets/lobba_widgets.dart`

| Widget | Purpose |
|---|---|
| `PushScaffold(title, child, trailing?, subtitle?, bottomBar?)` | standard pushed screen with circular back arrow |
| `LPill(text, bg, fg)` | rounded status pill |
| `LAvatar(letter, size?, bg?, fg?)` | circular initial avatar |
| `Eyebrow(text)` | small uppercase section label |
| `Display(text, size)` | serif display heading |

Use these for consistency; most screens are built from them.

## Internationalisation

- System: `.tr(context)` extension in `lib/core/i18n/lobba_i18n.dart` (see `docs/02`).
- English string **is** the key; Arabic comes from the `_ar` const map (723 entries).
- Full RTL: layout mirrors automatically when locale is Arabic.
- **Build guard:** duplicate keys in `_ar` break the build — run the dedup grep in
  `docs/05` before every build.

## Iconography & imagery

- Material Icons (rounded variants preferred, e.g. `Icons.sports_tennis_rounded`).
- Court images are gradient placeholders (no real photos yet) — a real image
  pipeline (Supabase Storage) is a backend task.
- Maps use OpenStreetMap tiles via `flutter_map` (no API key).

## Spacing & shape conventions

- Card radius ~14–20; pills fully rounded (99).
- Screen horizontal padding typically 22.
- Accent-bordered selection states (1.5px) for chosen chips/tiles.
