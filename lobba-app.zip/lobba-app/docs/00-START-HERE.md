# Lobba — Developer Handover

**Lobba** is a bilingual (Arabic RTL / English) padel-court booking platform for the
Egyptian market, with **three surfaces**:
1. **Player app** (Flutter mobile)
2. **Court-Owner app** (same Flutter app, routed by login role)
3. **Admin portal** (separate web app — `admin/Lobba-Admin-Portal.html`) — the
   platform operator's control room: KYC approvals, payouts, users, marketplace.

This package is a complete handover for a developer to take it from a **working
front-end prototype** to a **production, backend-connected platform**.

> **Read this first, then the docs in order.** Everything you need is in this folder.

## What's in this package

```
Lobba-Handover/
├── 00-START-HERE.md            ← you are here
├── app/
│   └── Lobba-Native.apk        Installable Android build (the current UI). Sideload to try it.
├── source/
│   └── lobba-mobile/           Full Flutter source (build caches removed). This is the app.
├── admin/
│   └── Lobba-Admin-Portal.html Working web ADMIN portal prototype (open in a browser).
├── backend/                    Postgres/Supabase backend package (SQL migrations + tests).
└── docs/
    ├── 01-PROJECT-OVERVIEW.md  What the product is, roles, features, scope.
    ├── 02-ARCHITECTURE.md      How the code is organised, patterns, state, routing, i18n.
    ├── 03-SCREEN-INVENTORY.md  Every screen, its buttons, and status (works / mock / stub).
    ├── 04-DATA-MODEL.md        Entities, the booking/overlap model, current local storage.
    ├── 05-BUILD-AND-RUN.md     Exact steps to build & run (Windows was the dev machine).
    ├── 06-BACKEND-HANDOVER.md  The backend, why Postgres, and the app-migration plan.
    ├── 07-STATUS-AND-BACKLOG.md Done / mock / missing / known bugs / prioritised backlog.
    ├── 08-DESIGN-SYSTEM.md     Theme tokens, fonts, colours, i18n dictionary (reference).
    ├── 09-ADMIN-PORTAL.md      The web ADMIN portal — all 12 sections, features, what's needed.
    ├── 10-USER-STORIES-AND-SCENARIOS.md  User stories + end-to-end scenarios (doubles as QA scripts).
    ├── Lobba-Design-Guide.html VISUAL design guide (mobile apps) — open in a browser.
    └── Lobba-Admin-Design-Guide.html VISUAL design guide (ADMIN portal) — open in a browser.
```

## The 60-second summary

- **State of the app:** front-end is ~90% complete and polished for both roles.
  All screens exist and navigate. **It is a prototype: there is no server and no
  database.** All data is mock, held in-memory / `SharedPreferences` on the device.
- **The one thing that must be built next:** the **backend** (see `backend/` and
  `docs/06`). Until it exists, two phones share nothing, two players can
  double-book the same court, and the wallet is a fake number.
- **The backend is already designed** — schema, the anti-double-booking database
  constraint, the API functions, and security — as runnable SQL in `backend/`.
  It has **not been executed yet** (needs Docker + Supabase CLI).
- **Do not take real money** until server-side payments (Paymob/Fawry) exist.

## Suggested reading order for the new developer

1. Install `app/Lobba-Native.apk` on an Android phone, log in as a player, then as
   an owner. Play with it for 15 minutes. (Owner login: any email; role is chosen
   at signup / role-select.)
2. `docs/01` → `docs/02` → `docs/04` to understand the shape.
3. `docs/07` to see exactly what's real vs mock and what to build.
4. `docs/06` + `backend/README.md` to start the backend.
5. `docs/05` to build the app yourself.

## Key facts

| | |
|---|---|
| Framework | Flutter (Dart), single codebase |
| Flutter SDK used | 3.44.4 (stable) |
| State management | Riverpod (`NotifierProvider`) |
| Navigation | go_router |
| Package id (Android) | `com.lobba.app` |
| App version | 1.0.1+2 |
| Screens | ~40 user-facing (62 screen files) |
| Languages | English + Arabic (full RTL), 723-entry dictionary |
| Backend (designed) | Postgres via Supabase — see `backend/` |
| Auth (partially wired) | Firebase Auth email/password (`lobba-padel` project) |

## Contact / provenance

Built as an iterative prototype. The source is self-contained and self-documented
(comments explain the non-obvious parts, especially the booking engine). Start
with the booking engine — `source/lobba-mobile/lib/features/booking/providers/bookings_provider.dart`
— it is the heart of the product.
