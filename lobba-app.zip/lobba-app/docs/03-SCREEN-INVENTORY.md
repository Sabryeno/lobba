# 03 — Screen Inventory

Every screen, its purpose, key buttons, and status. Status legend:
- ✅ **works** — navigates and behaves correctly (on mock data)
- 🟡 **mock** — works but data is hardcoded / would need the backend to be real
- 🔴 **stub / orphan** — placeholder, or not reachable from any button

62 screen *files*; ~40 user-facing screens (some files hold several screen classes).

## Auth & onboarding — `features/auth/screens/`
| Screen | Purpose | Status |
|---|---|---|
| splash_screen | Animated splash → welcome | ✅ |
| welcome_screen | Animated intro, "Get started" | ✅ |
| role_select_screen | Choose Player / Owner | ✅ |
| player_signup_screen / organizer_signup_screen | Sign up | 🟡 (no real auth call) |
| email_auth_screen | Email/password login | 🟡 (Firebase wired but flow is mock) |
| otp_verification_screen | 6-digit OTP + resend | 🟡 (no real SMS) |
| player_profile_setup_screen | Name, birth, prefs | ✅ |
| assessment_screen | Find your level (questions) | ✅ |
| coach_validate_screen | Coach-verified level | ✅ |
| organizer_kyc_screen / organizer_pending_screen | Owner onboarding | 🟡 |

## Player — Home & Discovery
| Screen | Key buttons | Status |
|---|---|---|
| home/home_screen | bell→notifications, featured cards→court detail (correct ids), quick actions, playmates, search | ✅ |
| discovery/discovery_screen | Indoor/Outdoor/Top-rated filters, map, court cards | ✅ |
| discovery/map_search_screen | OSM map, pins → correct court detail | ✅ |
| discovery/advanced_search_screen | live search | ✅ |

## Player — Booking
| Screen | Key buttons | Status |
|---|---|---|
| booking/court_detail_screen | pricing (deal-aware), location→maps, call, favourite, **Reserve** | ✅ |
| booking/booking_flow_screen | day/duration/**30-min slot**/**court select (live availability)** → players (invite, 2v2 grid, add by link) → payment (wallet/apple/google/cash, split) → review sheet → confirm | ✅ (mock money) |
| booking/booking_confirmed_screen | reflects real court/date/time/court#/price; View ticket, Add to calendar, Share, Home | ✅ |
| booking/qr_ticket_screen | QR, real court/date/time, **booker name synced to profile**, Share works | ✅ |
| booking/my_bookings_screen | Upcoming/Past tabs, View ticket, **Share (wired)**, Add/Confirm score | ✅ (mock list) |
| booking/booking_confirmation_screen | (older confirmation variant — not the wired one) | 🟡 unused |

## Player — Matches, Level, Social
| Screen | Status |
|---|---|
| matches/matches_screen — open matches, filters, live matches from bookings, court# pills | ✅ |
| matches/match_detail_screen — reflects tapped match (venue/court/date/time/skill/spots); Join | ✅ |
| matches/join_pending_screen — waiting for host | ✅ |
| matches/create_match_screen | 🔴 orphan (no entry point) |
| matches/match_result_screens — record score (5 sets, editable), confirm score | ✅ |
| leaderboard/leaderboard_screen — National/Cairo tabs, standings | ✅ (mock) |
| profile/levelling_screens — level hub, ranges, reliability, lower-level | ✅ |
| social/social_screens — friends (search name/phone), tribes (create/discover/join), add friends | ✅ (mock) |
| social/clubs_screen, club_detail_screen | 🔴 orphan |
| profile/player_detail_screen — a player's public profile | ✅ |

## Player — Profile, Wallet, Settings, Notifications
| Screen | Status |
|---|---|
| profile/profile_screen — stats, menu, dark mode, logout | ✅ |
| profile/settings_screen — account, language, notifications, **My wallet**, delete account | ✅ |
| profile/account_edit_screen — name/birth/email (phone read-only) | ✅ |
| profile/edit_profile_screen — preferences | ✅ |
| profile/wallet_screens — wallet, add card (masked), top-up | ✅ (mock money) |
| notifications/notifications_screen — all types wired (friend, match, score, rating, invite, booking, deal) | ✅ (mock) |

## Owner — `features/organizer/screens/`
| Screen | Key buttons | Status |
|---|---|---|
| organizer_dashboard_screen | **Today/30/60/90-day filter**, KPIs, live bookings feed, court-profile avatar | ✅ |
| organizer_courts_screen | Court 1..N with **live availability**, status toggle, edit, hours | ✅ |
| organizer_court_form_screen | add/edit court (name, format, indoor, price) | ✅ |
| organizer_bookings_screen | approve/decline, **live player bookings**, cash reminder | ✅ |
| organizer_analytics_screen | **date from–to** + **hour from–to** filters, revenue bars, payment split, PDF export | ✅ (mock factors) |
| organizer_deals_screen + organizer_deal_form_screen | create % deal on **30-min** dead-time slots | ✅ |
| organizer_settings_screens | Owner settings, **WhatsApp lock (writes to engine → blocks players)**, Payout method | ✅ |
| organizer_extra_screens | Training, Store, Booking history (players) | ✅ |
| court_profile_screen | logo, name, location, admin/manager, all settings, dark mode, language, logout | ✅ |
| owner_player_screen | player profile: history, cancellations, risk verdict, suspend | ✅ |

## Coaches / Academies / Teams / Tournaments / Chat (Phase-2)
| Screen | Status |
|---|---|
| coaches/coaches_screen — request a coach (snackbar) | ✅ reachable (Home → Learn to play) |
| coaches/coach_detail_screen, book_coach_screen | 🔴 orphan / stub |
| academies/academies_screen, academy_detail_screen | 🔴 orphan |
| teams/teams_screen → team_detail_screen | 🔴 orphan; **detail = "Coming Soon" stub** |
| tournaments/tournaments_screen → tournament_detail_screen | 🔴 orphan; **detail = "Coming Soon" stub** |
| chat/chats_screen, chat_detail_screen (send/attach work) | 🔴 orphan (no entry point) |

## Button audit summary (from the full-app audit)
- Only **real dead handlers** found app-wide were fixed: a dead `_PaymentMethodsScreen`
  (removed), the My-Bookings "Share" (wired), and map pins (routed to the right court).
- Ticket share + booker-name sync: fixed.
- **Remaining known gaps are the 🔴 Phase-2 orphans + 2 "Coming Soon" stubs above** —
  they are not reachable by users, but must be wired/built for Phase 2.
