# 01 — Project Overview

## What Lobba is

A padel-court booking platform for Egypt. A single Flutter app that presents **two
distinct experiences** depending on who logs in:

- **Player** — discover courts, book a slot, split payment with friends, join open
  matches, track level/ranking, manage a wallet.
- **Court Owner** — manage courts, see bookings in real time, approve/decline
  requests, lock WhatsApp bookings, run last-minute deals, view analytics.

The app is **bilingual** (English + Arabic) with full **RTL** support, themed as
"Sage Atelier" (light) / "Ink & Brass" (dark).

## The core value proposition (and the hardest technical requirement)

**No double-booking, with flexible durations.** A court can be booked for 60, 90
or 120 minutes on a 30-minute grid. The system must guarantee that the *entire*
requested duration is free, and — critically — that the **end time of a booking
stays available** for the next player (a 90-min booking at 3:00 PM frees 4:30 PM,
it does not lock it).

This is currently enforced in Dart on-device (correct logic, wrong place). It must
become a **database constraint** — see `docs/06` and `backend/`.

## Roles & entry flow

```
Splash → Welcome (animated) → Role select (Player / Owner)
  ├─ Player  → sign up / log in → (assessment to find level) → Player shell
  └─ Owner   → sign up / log in → KYC / pending → Owner shell
```

- **Player shell** (bottom nav): Home · Discover · Matches · Rankings · Profile
- **Owner shell** (bottom nav): Dashboard · Courts · Bookings · Analytics · Deals

## Feature list (implemented in the front-end)

### Player
- Onboarding, role select, phone/email auth (OTP screens exist)
- Home: greeting, featured courts, quick actions, open matches, "people you play most with"
- Discover: court list with working Indoor/Outdoor/Top-rated filters, OpenStreetMap view
- Court detail: gallery, per-duration pricing, location (opens maps), call, cancellation policy
- **Booking flow (3 steps):** date + duration + **30-min slot grid + court (1..N) selection with live availability** → players (private by default, invite, 2v2 court grid + subs) → payment (wallet + Apple/Google/Cash, split) → review sheet (fees, VAT, cancellation policy) → confirmed → QR ticket
- Wallet: balance, top-up (saved card / Apple Pay / Google Pay), add card (masked, "encrypted")
- Matches: open matches list, filters, join → match detail (reflects the selected match)
- Leveling: assessment, level bands (0–7), reliability, rankings/leaderboard
- Social: friends (search by name/phone), tribes (create/discover/join), player profiles
- Notifications: friend requests, match ended, score confirm, ratings, invites, booking lifecycle, deals
- Profile & settings: account edit, language, notifications, my wallet, my bookings, dark mode

### Owner
- Dashboard: today/30/60/90-day KPIs, revenue, live bookings feed
- Court management: Court 1..N with live availability from the booking engine, status toggle, edit
- Booking requests: approve/decline, live player bookings, cash reminders
- Player profiles (scoped to owner's courts): history, cancellations, risk verdict, suspend
- WhatsApp booking lock: court + date + 30-min time grid + duration → lock (blocks players)
- Deals: create last-minute % discounts on dead-time 30-min slots
- Analytics: date-range (from–to) + hour-range filters, revenue bars, payment split, PDF export
- Court profile hub: logo, name, location, admin/manager contacts, all settings, payout method

## Scope status (high level)

| Area | State |
|---|---|
| UI / screens / navigation | ✅ Complete & polished |
| In-app "sync" (player ↔ owner) | ✅ Works — **but device-local only** |
| Booking overlap validation | ✅ Correct logic — **client-side only** |
| Backend / database | ❌ Designed, not built (see `backend/`) |
| Payments (real money) | ❌ Not started — wallet is a local number |
| Cross-device real-time | ❌ Needs the backend |
| Phase-2 features (teams, tournaments, academies, clubs, chat) | ⚠️ Screens exist but not wired / some stubs |

See `docs/07` for the exhaustive status and backlog.
