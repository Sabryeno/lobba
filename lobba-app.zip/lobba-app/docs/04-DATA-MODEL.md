# 04 — Data Model

The app currently has **no database**. Data lives in Riverpod providers, some
persisted to `SharedPreferences`. This document describes the in-app model so a
developer can map it to the real backend (`backend/`, `docs/06`).

## Core entities (as used in the app)

### Court / Venue — `features/discovery/data/courts_catalog.dart`
```dart
class Court {
  String id, name, area, distance, address, phone;
  int courtCount, ratingCount;   // courtCount = number of physical courts (Court 1..N)
  double rating, lat, lng;
  bool indoor;
  List<int> prices;              // [price60, price90, price120] in EGP
}
```
`kCourts` seeds 3 venues: `'1'` Al-Ahly (4 courts), `'2'` Zamalek (2), `'3'` Maadi (4).
`kOwnerVenueId = '1'` binds the owner app to Al-Ahly.

> In the backend this splits into **venues** (the club) and **courts** (each
> physical Court 1..N with its own price/status). See `backend/.../core.sql`.

### Booking — `features/booking/providers/bookings_provider.dart`
```dart
class Booking {
  String courtId;    // venue id
  int subCourt;      // physical court 1..N
  int day;           // DAY INDEX (0..4) into BookingOptions.days  ← not a real date
  int startMin;      // minutes from midnight (30-min grid)
  int durMin;        // 60 | 90 | 120
  String reference;  // "LB-..."
  bool isPublic;     // posted as an open match
  String player;     // 'You' | 'WhatsApp' | a name
  int get endMin => startMin + durMin;
}
```

**Overlap rule (the product's core):** two bookings clash iff same court + same day
AND their half-open intervals intersect:
```dart
bool clashesWith(Booking o) =>
  courtId==o.courtId && subCourt==o.subCourt && day==o.day &&
  startMin < o.endMin && o.startMin < endMin;   // END EXCLUSIVE
```
End-exclusive is deliberate: a 90-min booking at 3:00 PM occupies 3:00/3:30/4:00
and **frees 4:30**. This is proven in `backend/tests/overlap_test.sql`.

### Booking options — `features/booking/data/booking_options.dart`
- `slotStartMin` = 30-min grid, 3:00 PM (900) → 10:30 PM (1350).
- `durMinutes = [60, 90, 120]`.
- `days` = index → `['Thu','19']…` (a rolling label list; **not real dates**).

> ⚠️ **Migration gotcha:** the app uses `day` **indices**, the backend uses real
> `date`. You need a small mapping layer (index ⇄ actual DateTime) during the swap.

### Wallet — `features/profile/providers/wallet_provider.dart`
```dart
class WalletState { int balance; List<String> cards; }  // cards = masked labels only
```
Persisted locally. **Full card numbers / CVV are never stored** (only e.g. "Visa •••• 4242").
Balance is a plain integer → **must become server-authoritative** before real money.

### Account — `features/profile/providers/account_provider.dart`
```dart
class AccountData { String name, email, birthDate; }   // phone is read-only
```
`accountProvider.name` is the single source of truth for the booker name on tickets.

### Owner players — `features/organizer/providers/owner_players_provider.dart`
`OwnerPlayer` (name, phone, email, level, paymentMethod, history[]) + a computed
`risky` verdict. Suspensions persisted via `ownerSuspendedProvider`.

### Level — `core/level/lobba_level.dart`
Numeric bands 0.0–7.0 (Initiation → Elite) + reliability 0–100.
`playerLevelProvider` holds the current player's level/reliability.

## What is persisted vs in-memory

| Data | Storage | Key |
|---|---|---|
| Bookings | SharedPreferences | `bookings_store_v2` |
| Wallet balance / cards | SharedPreferences | `wallet_balance`, `wallet_cards` |
| Account (name/email/birth) | SharedPreferences | `acct_name`, `acct_email`, `acct_birth` |
| Court profile (owner) | SharedPreferences | `court_*` |
| Suspended players | SharedPreferences | `owner_suspended` |
| Theme mode / locale | SharedPreferences | via providers |
| Everything else | in-memory providers | (resets on cold start) |

## Backend mapping (summary)

| App | Backend table/fn |
|---|---|
| `Court` (catalog) | `venues` + `courts` |
| `Booking` | `bookings` (+ `EXCLUDE` constraint) |
| `isCourtFree` / `availableSubCourts` / `book` | `is_court_free` / `available_courts` / `book_court` RPC |
| wallet | (new) `wallets` / `wallet_transactions` + payment webhooks |
| account | `profiles` |
| owner players | derived from `bookings` joined to `profiles` |

Full schema and API: `backend/` and `docs/06`.
