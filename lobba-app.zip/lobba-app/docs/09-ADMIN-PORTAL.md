# 09 — Admin Portal

The **third surface** of Lobba, alongside the Player and Owner mobile apps: a
**web-based platform-admin portal** for the Lobba operator (you / your ops team).
Where the Owner app manages *one venue*, the Admin portal oversees the **whole
marketplace** — every venue, owner, player, booking, payout and dispute.

- **Working prototype:** `admin/Lobba-Admin-Portal.html` — a single self-contained
  HTML file. Open it in any browser (no server, no internet). Click **Log in** to
  enter. Data is mock (`const DB` + `localStorage`).
- **Visual design guide:** `docs/Lobba-Admin-Design-Guide.html`.
- **Platform, not phone.** The admin is desktop-web (sidebar + data tables). It is
  **not** part of the Flutter app and should be built as a separate web app.

## Business model baked in

The portal assumes a **10% platform commission** on bookings (`COMMISSION = 0.10`).
Owners receive payouts of (GMV − commission) to their bank/InstaPay. This is the
admin's core money flow: track GMV → commission earned → owner payouts.

## Navigation (3 groups, 12 sections)

```
MAIN         Dashboard · Users · Venues & Courts · KYC Approvals · Bookings · WhatsApp · Payouts
MARKETPLACE  Coaches · Academies · Deals
INSIGHTS     Analytics · Settings
```
The sidebar shows **live count badges** (pending KYC, pending payouts). Collapsible
to a 64px icon rail.

## Section-by-section features

### 1. Dashboard
Platform KPIs at a glance: **revenue (last 7 days)**, **commission earned** (10%),
**bookings**, **pending actions** (KYC + payouts). "Bookings by day" chart, "View
all" into each area. This is the ops team's morning screen.

### 2. Users
Every player and owner on the platform. Search/filter, view a user, and **Ban /
Unban** (with a confirm dialog: "Ban {name}?"). Used for abuse, fraud, chargebacks.
→ *Backend: `profiles` + a `banned` flag/role; ban must revoke sessions.*

### 3. Venues & Courts
Every venue and its physical courts across the platform. View/edit venue details,
court counts, status. The admin equivalent of the owner's Court Management, but
global. → *Backend: `venues` + `courts`.*

### 4. KYC Approvals ⭐ (gatekeeper)
New owner/venue applications awaiting verification. **Approve** (venue goes live and
becomes bookable) or **Reject** (with a reason → "Send rejection"). Empty state:
"All caught up." This is what stops fake venues from appearing to players.
→ *Backend: a `venue_applications` table + status; approval flips the venue to active.*

### 5. Bookings
Every booking platform-wide (all venues). Filter, inspect, and use for support and
dispute investigation. → *Backend: `bookings` (admin-scoped read across all venues).*

### 6. WhatsApp
The WhatsApp-native booking channel: players book inside the court's own WhatsApp
chat (natural language or tap menus) and pay an owner-set deposit. The admin
monitors/configures this channel. (Ties to the owner app's WhatsApp lock feature.)
→ *Backend + a WhatsApp Business API integration (separate project).*

### 7. Payouts ⭐ (money out)
Owner payout queue. Shows **pending payout** amount per owner (GMV − 10% commission),
destination (bank account or InstaPay). **Confirm transfer** marks it paid.
→ *Backend: `payouts` table, a scheduled aggregation of confirmed bookings per owner
per period, and — for real money — an actual disbursement integration. Never mark
paid without a real transfer.*

### 8. Coaches (Marketplace)
Directory of coaches offering lessons. Approve/verify, manage listings. *(Phase-2 —
the mobile side is stubbed.)*

### 9. Academies (Marketplace)
Padel academies/programs. Same management model as coaches. *(Phase-2.)*

### 10. Deals (Marketplace)
Platform-wide view of last-minute deals owners create. Moderate, feature, or pull
deals. → *Backend: `deals` (admin read/moderate across venues).*

### 11. Analytics (Insights)
Cross-venue analytics: GMV, commission, bookings trends, top venues, utilisation.
The macro version of the owner's per-venue analytics.
→ *Backend: aggregations over `bookings` (the `venue_revenue()` function generalises).*

### 12. Settings
Platform config: **commission rate**, support email, and other global switches.
"Save changes". → *Backend: a `platform_settings` singleton.*

## Cross-cutting behaviours

- **Confirm dialogs** for destructive/irreversible actions (Ban, Reject, Confirm
  transfer). Keep these — money and access decisions must be deliberate.
- **Toasts** for feedback.
- **Badges** on nav for pending work (KYC, payouts).
- **localStorage** persistence in the prototype → replace with real API calls.

## What's needed to make it production

| Need | Notes |
|---|---|
| **Auth + admin role** | A separate, tightly-controlled admin login (2FA strongly recommended). Not the same pool as players/owners. |
| **API / backend** | The admin reads/writes across ALL venues → it uses the **service-role** key server-side (bypasses RLS), never the anon key. Build admin endpoints or a server that fronts them. |
| **KYC pipeline** | Document upload/review, status machine, notifications to owners. |
| **Payouts** | Aggregation job + real disbursement (bank/InstaPay) + reconciliation + audit log. |
| **Audit log** | Every admin action (ban, approve, payout) must be logged with who/when. |
| **Framework** | Prototype is vanilla HTML/JS. Rebuild in React/Next (or keep vanilla if small). Reuse the `backend/` schema. |

## Security note (important)

The admin portal has **god-mode** over the platform. It must:
- Live behind a separate, hardened login (ideally 2FA + IP allowlist).
- Talk to the DB via the **service-role** key **server-side only** — never ship that
  key to a browser. The current prototype is client-only mock data; a real admin
  needs a thin server (or Supabase Edge Functions) in between.
- Log every action. Money and bans are irreversible-ish; you need a paper trail.
