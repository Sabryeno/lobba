# 05 — Build & Run

## Prerequisites

| Tool | Version used | Notes |
|---|---|---|
| Flutter SDK | **3.44.4 stable** | any recent 3.22+ should work |
| Dart | bundled with Flutter | |
| Android SDK + platform tools | — | for device/emulator + APK |
| Android NDK | 28.2.13676358 | one plugin (jni) wants this; set in `android/app/build.gradle.kts` |
| JDK | 17 | |
| Xcode (for iOS) | — | iOS not yet configured/tested |

## First run

```bash
cd source/lobba-mobile
flutter pub get
flutter run                 # on a connected device/emulator
```

If you use a custom pub cache (the original dev did, to avoid spaces in the path):
```bash
# PowerShell
$env:PUB_CACHE = "D:/somewhere/pubcache"   # a path WITHOUT spaces (Gradle-safe)
flutter pub get
```

## Build a release APK

```bash
flutter build apk --release --target=lib/main.dart
# output: build/app/outputs/flutter-apk/app-release.apk (~70 MB)
```
A pre-built APK is already in `../app/Lobba-Native.apk` — sideload it to try the app.

## ⚠️ The #1 build failure — i18n duplicate keys

The Arabic dictionary is a `const Map`. A **duplicate key** fails the build with
"Constant evaluation error". **Always** run this before building:

```bash
grep -oE "^  '[^']*':" lib/core/i18n/lobba_i18n.dart | sort | uniq -d
# must print nothing
```

## Firebase

- `android/app/google-services.json` **is present** (project `lobba-padel`).
- Firebase Auth (email/password) + Messaging + Analytics packages are included.
- Auth flow in the app is currently **mock** — wiring real sign-in is a task
  (see `docs/07`). If you move to Supabase (recommended, `docs/06`), you'll
  likely drop Firebase Auth; keep or drop Messaging as you prefer for push.

## Assets & fonts

- Fonts: Tajawal (Arabic), Inter (sans), Playfair Display (serif) — in `assets/fonts/`.
- Bilingual: English + Arabic with full RTL. Locale is switchable in-app (Settings).

## Platform notes

- **Android:** primary target, builds & runs. `applicationId = com.lobba.app`,
  `namespace = com.lobbaworld.padel_app`, version `1.0.1+2`.
- **iOS:** folder exists but **not configured or tested** — needs signing,
  Firebase iOS setup, and a build pass.
- **Web:** folder exists; not a target.

## Handy commands

```bash
flutter analyze                     # static analysis
flutter clean && flutter pub get    # if the build gets weird
flutter build apk --release --no-tree-shake-icons   # if icon tree-shaking ever bites
```

## Original dev environment (for reference)

Windows 11, Flutter 3.44.4 at a local path, project on `D:\Lobba\padelapp\mobile`,
`PUB_CACHE` on a space-free path. Builds were run in the background and typically
take a few minutes for a release APK.
