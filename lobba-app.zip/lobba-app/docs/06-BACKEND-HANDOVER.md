# 06 — Backend Handover

> The backend is **designed and written** (runnable SQL) but **not yet executed**.
> Everything is in the `backend/` folder of this package. Read `backend/README.md`
> alongside this.

## Why a backend is the next step (not optional)

The app is a front-end prototype. Without a server:
- **Two phones share nothing** — "sync" only works because both roles are the same
  app instance on one device.
- **Two players can double-book the same court** — the overlap check is correct but
  runs on-device, guarding only that phone's local list.
- **The wallet is a local integer** — anyone could edit it; top-ups are fake.

The data model has now **stabilised** (Court→sub-courts, Booking, 30-min grid,
durations, roles), so building the schema now won't be thrown away.

## Recommended stack: Supabase (Postgres)

Chosen over Firebase for one decisive reason: **Postgres can make double-booking
physically impossible at the database level** via an exclusion constraint. Firestore
cannot. Supabase also gives Auth (incl. phone OTP — good for Egypt), Realtime
(replaces a WebSocket server), Storage (logos/photos), and RLS.

> You have a half-configured **Firebase** project (`lobba-padel`). Pick **one**
> auth/data stack — running both is waste. If you keep Firebase, you must hand-roll
> booking transactions and lose the DB-level guarantee; not recommended.

## The guarantee (the whole point)

```sql
-- from backend/supabase/migrations/20260714000200_bookings.sql
alter table bookings add constraint bookings_no_overlap
  exclude using gist (
    court_id     with =,
    booking_date with =,
    int4range(start_min, start_min + dur_min) with &&   -- half-open: end is free
  ) where (status <> 'cancelled');
```
`tests/overlap_test.sql` asserts a 90-min booking at 3:00 PM leaves **4:30 PM free**,
blocks 3:30/4:00, allows back-to-back at the end time, and rejects a real
overlapping insert.

## What the backend package contains

```
backend/
├── README.md
├── .env.example
├── supabase/
│   ├── migrations/
│   │   ├── 20260714000100_core.sql       profiles, venues, courts, signup trigger
│   │   ├── 20260714000200_bookings.sql   bookings + EXCLUDE constraint, seats, deals
│   │   ├── 20260714000300_functions.sql  RPC: is_court_free, available_courts,
│   │   │                                   slot_grid, book_court, lock_slot,
│   │   │                                   cancel_booking, venue_revenue
│   │   └── 20260714000400_rls.sql        Row Level Security + realtime publication
│   └── seed.sql                          the 3 venues/courts (matches courts_catalog.dart)
└── tests/overlap_test.sql
```

## Run it (first milestone)

```bash
npm i -g supabase          # needs Docker Desktop installed & running
cd backend
supabase init              # if config.toml is missing
supabase start             # local Postgres + Studio
supabase db reset          # apply migrations + seed
psql "postgresql://postgres:postgres@127.0.0.1:54322/postgres" -f tests/overlap_test.sql
# → ALL OVERLAP TESTS PASSED — end time stays bookable.
```

## RPC API ↔ app mapping

| App (`bookings_provider.dart`) | Backend RPC |
|---|---|
| `isCourtFree()` | `is_court_free(court, date, start_min, dur_min)` |
| `availableSubCourts()` | `available_courts(venue, date, start_min, dur_min)` |
| slot grid greying | `slot_grid(venue, date, dur_min)` |
| `book()` → `BookingResult` | `book_court(...)` → `(ok, message, booking_id, reference)` |
| WhatsApp lock | `lock_slot(...)` |
| cancel | `cancel_booking(id)` |
| analytics | `venue_revenue(venue, from, to, from_hour, to_hour, court, dur)` |

## App-side migration plan (do it in this order)

1. **Repository interface first.** Extract a `BookingRepository` abstraction and
   make `bookingsProvider` depend on it. Ship a `LocalBookingRepository` (current
   SharedPreferences behaviour) behind it. **No screen changes.** This makes the
   backend a drop-in later.
2. **Add `supabase_flutter`**, init with the anon key.
3. **Auth**: players + owners with a role claim (replace the mock auth flow).
4. **Venues + courts**: replace `courts_catalog.dart` reads with a `CourtRepository`
   backed by Supabase. Resolve the day-index ⇄ real-date mapping here.
5. **Bookings**: implement `SupabaseBookingRepository` calling the RPCs above.
   Swap it in behind the interface from step 1.
6. **Realtime**: subscribe to `bookings` (and `courts`) so owner dashboard and
   player availability update across devices.
7. **Payments** (separate project): Paymob/Fawry, server-verified via webhooks;
   wallet balance becomes server-authoritative. **Never trust the client for money.**

Steps 1–6 don't require touching UI beyond the data layer. Step 7 is its own effort.

## Security (RLS) — already written

- `venues` / `courts` / active `deals` → public read (players browse).
- `bookings` → visible to the **player who made it**, the **owner of that venue**,
  or anyone if it's a public open match. Enforces "owner sees their courts only".
- Owners can only write their own venue's rows.
