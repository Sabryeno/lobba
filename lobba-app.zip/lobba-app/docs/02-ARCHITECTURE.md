# 02 — Architecture

## Tech stack

| Concern | Choice |
|---|---|
| UI framework | Flutter (Dart), entrypoint `lib/main.dart` |
| State management | **Riverpod** — `NotifierProvider` / `Provider` |
| Navigation | **go_router** (declarative routes + query params) |
| Local persistence | `shared_preferences` (mock "database"), `flutter_secure_storage` |
| Networking (ready, unused) | `dio` |
| Maps | `flutter_map` (OpenStreetMap tiles, no API key) + `geolocator` |
| Auth (partially wired) | `firebase_auth` (email/password), `google_sign_in` |
| Push (ready) | `firebase_messaging`, `flutter_local_notifications` |
| Charts / PDF | `fl_chart`, `pdf` + `printing` |
| Misc | `image_picker`, `share_plus`, `qr_flutter`, `url_launcher`, `intl` |

Full list: `source/lobba-mobile/pubspec.yaml`.

## Folder structure (feature-first)

```
lib/
├── main.dart                     app entrypoint
├── core/
│   ├── navigation/               app_router.dart (all routes), app_routes.dart (path constants)
│   ├── theme/                    lobba_tokens.dart (design tokens), app_colors.dart
│   ├── widgets/                  lobba_widgets.dart (PushScaffold, LPill, LAvatar, Eyebrow, Display…)
│   ├── i18n/                     lobba_i18n.dart (the .tr() system + 723-entry AR dictionary)
│   ├── providers/                theme_mode, profile_photo, …
│   ├── level/                    lobba_level.dart (0–7 band engine)
│   ├── services/                 notifications.dart, …
│   └── shell/                    main_shell.dart (player bottom-nav shell)
├── features/                     one folder per feature
│   ├── auth/  home/  discovery/  booking/  matches/  leaderboard/
│   ├── profile/  social/  deals/  notifications/  coaches/  academies/
│   ├── teams/  tournaments/  chat/  organizer/ (the owner app)
│   └── each has: screens/  providers/  (models/)
└── shared/                       models/, widgets/ shared across features
```

Each **feature** owns its `screens/` and `providers/`. The **organizer** feature is
the entire court-owner app.

## Key patterns to understand

### 1. The `.tr(context)` i18n system
There is **no ARB/intl_gen**. Instead, `lib/core/i18n/lobba_i18n.dart` defines:

```dart
extension LobbaTr on String {
  String tr(BuildContext c) => /* returns Arabic from a const map when locale==ar, else `this` */;
}
```

**The English string IS the key.** Usage: `'Book now'.tr(context)`. To add Arabic,
add `'Book now': 'احجز الآن',` to the `_ar` map.

> ⚠️ The `_ar` map is a `const Map` — a **duplicate key breaks the build** with a
> "Constant evaluation error". Before every build run:
> ```bash
> grep -oE "^  '[^']*':" lib/core/i18n/lobba_i18n.dart | sort | uniq -d
> ```
> (should print nothing). This is the single most common build failure.

### 2. Theme tokens (`context.t`)
`LobbaTokens` (in `core/theme/lobba_tokens.dart`) exposes every colour/surface via
`context.t` — e.g. `t.accent`, `t.ink`, `t.surface`, `t.line`, `t.sage`, `t.clay`,
`t.gold`, `t.onAccent`. Light = "Sage Atelier", dark = "Ink & Brass". Fonts:
`kSerif` (Playfair/Tajawal), `kSans` (Inter/Tajawal). **Never hardcode colours** —
always use tokens so light/dark + RTL keep working.

### 3. Routing
- `core/navigation/app_routes.dart` — path constants (`AppRoutes.booking = '/booking/:courtId'`).
- `core/navigation/app_router.dart` — the `GoRouter`; builders read path + **query
  params** and pass them to screens.
- Data passes between screens via **query params** (e.g. booking → confirmed → ticket
  carry `court`, `sub`, `day`, `slot`, `durIdx`, `price`, `players`). Some sub-screens
  use `Navigator.push(MaterialPageRoute(...))` — both coexist.

### 4. State: the booking engine (the heart of the app)
`lib/features/booking/providers/bookings_provider.dart` is the **in-app "central
database"** — a Riverpod `NotifierProvider<List<Booking>>` persisted to
`SharedPreferences`. Both the player and owner screens `watch` it, which is why
"sync" appears instant **on one device**. It exposes the overlap logic:
`clashesWith`, `isCourtFree`, `availableSubCourts`, `anyCourtFree`, `book()`
(returns a `BookingResult`), `forVenue`, `remove`.

This is the exact surface the real backend replaces (see `docs/06`). **The
migration strategy is to put a repository interface in front of this provider so
no screen changes when the backend lands.**

### 5. Court identity (single source of truth)
`lib/features/discovery/data/courts_catalog.dart` — `Court` model + `kCourts` list
+ `courtById()`. Every screen resolves court name/price/location from here; **never
hardcode a court name**. `kOwnerVenueId = '1'` binds the owner app to Al-Ahly.

### 6. Booking options
`lib/features/booking/data/booking_options.dart` — the shared 30-min slot grid
(`slotStartMin`, `slots`, `clockLabel`), durations, and date/time formatting used
by booking, confirmation, ticket, WhatsApp lock, and overlap math.

## How the two apps are separated

Login role decides which shell renders. The **owner app** is entirely under
`lib/features/organizer/`. The **player app** is everything else under the player
shell. They share `core/`, `shared/`, the booking engine, the court catalog, and
the i18n/theme systems.

## Data flow example — a player booking

```
Discovery/Home card (courtId) → CourtDetailScreen (resolves Court from catalog)
  → BookingFlowScreen(courtId, dealPercent?, initialDur?)
      step 0: pick day + duration + 30-min slot + free court (reads bookingsProvider)
      step 1: players (private default, invite, 2v2+subs grid)
      step 2: payment (wallet/apple/google/cash, split) → review sheet
      confirm → bookingsProvider.book(Booking(...))  ← overlap validated here
  → BookingConfirmedScreen(?court&sub&day&slot&durIdx&price&players)
  → QrTicketScreen(same params, booker name from accountProvider)
Owner dashboard/court-management/requests watch bookingsProvider → reflect it live.
```
