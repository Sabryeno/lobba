# Lobba — Backend

Postgres + Supabase backend for the Lobba padel app.
**Separate from the Flutter app** at `D:\Lobba\padelapp` — nothing here touches it.

## Why Postgres/Supabase

The product's core promise is *no double-booking*. Postgres can enforce that as a
**database constraint**, so no client bug, race, or bad actor can create an
overlap. Supabase adds Auth, Realtime (replaces the WebSocket server) and RLS on
top, with no server to operate.

## The rule that matters

A booking occupies the **half-open** interval `[start, start + duration)` —
the end time is **excluded**:

> A 90-min booking at **3:00 PM** occupies 3:00 / 3:30 / 4:00 and **leaves 4:30 free**.

`int4range()` is half-open by default, so this is enforced by the DB, not by app
code. See `tests/overlap_test.sql` — it asserts exactly this case.

## Layout

```
supabase/
  migrations/
    20260714000100_core.sql       profiles, venues, courts, signup trigger
    20260714000200_bookings.sql   bookings + EXCLUDE constraint, seats, deals
    20260714000300_functions.sql  RPC API (availability, book, analytics)
    20260714000400_rls.sql        Row Level Security + realtime publication
  seed.sql                        the 3 venues/courts from courts_catalog.dart
tests/
  overlap_test.sql                proves the end-time-stays-free behaviour
```

## Setup

```bash
# one-time
npm i -g supabase
supabase init          # only if supabase/config.toml is missing
supabase start         # local Postgres + Studio (Docker required)
supabase db reset      # apply migrations + seed

# prove the booking rule
psql "postgresql://postgres:postgres@127.0.0.1:54322/postgres" -f tests/overlap_test.sql
# -> ALL OVERLAP TESTS PASSED — end time stays bookable.
```

Then link to a hosted project when ready:

```bash
supabase link --project-ref <ref>
supabase db push
```

## RPC API (what the app calls)

These map 1:1 onto `bookings_provider.dart`, so the Flutter swap is a store
replacement, not a UI rewrite:

| App (Dart) | Backend |
|---|---|
| `isCourtFree()` | `is_court_free(court, date, start_min, dur_min)` |
| `availableSubCourts()` | `available_courts(venue, date, start_min, dur_min)` |
| slot grid greying | `slot_grid(venue, date, dur_min)` |
| `book()` → `BookingResult` | `book_court(...)` → `(ok, message, booking_id, reference)` |
| WhatsApp lock | `lock_slot(court, date, start_min, dur_min)` |
| cancel | `cancel_booking(booking_id)` |
| analytics filters | `venue_revenue(venue, from, to, from_hour, to_hour, court, dur)` |

`book_court` is race-safe: if two players book the same slot simultaneously, one
gets `ok=false, 'That court just got taken — pick another time or court.'`

## Realtime

`bookings` and `courts` are in the `supabase_realtime` publication. The player
availability grid and the owner dashboard both subscribe — that's what makes
owner↔player sync work **across devices** (today it's device-local).

## Security model (RLS)

- `venues` / `courts` / active `deals` — public read (players browse them).
- `bookings` — visible to the **player who made it**, the **owner of that venue**,
  or anyone if it's a public open match. This enforces "owner sees bookings at
  their courts only".
- Owners can only write their own venue's rows (`owns_venue()`).

## Not here yet (deliberately)

- **Payments.** The wallet is still a local integer in the app. Real top-ups must
  be server-verified via Paymob/Fawry webhooks — never trust the client. This is
  its own project; do not ship real money before it exists.
- Leveling, matches, tribes, notification delivery (FCM) — keep them mock until
  the booking core is live.

## Migration order for the app

1. Auth (players + owners with role)
2. Venues + courts → replaces `courts_catalog.dart`
3. **Bookings + overlap** → replaces the `bookings_provider` store
4. Realtime subscriptions
5. Payments
