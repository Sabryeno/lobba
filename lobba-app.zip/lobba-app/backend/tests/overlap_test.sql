-- ============================================================================
-- Lobba — proof that the overlap rule behaves exactly as required.
-- Run against a seeded local DB:  supabase db reset && psql "$DB_URL" -f tests/overlap_test.sql
--
-- The case that matters: a 90-min booking at 3:00 PM must NOT lock 4:30 PM.
-- ============================================================================

\set ON_ERROR_STOP on

do $$
declare
  v_venue uuid := '11111111-1111-1111-1111-111111111111';
  v_court uuid;
  v_date  date := current_date + 30;   -- clean day, away from seeds
  v_ok    boolean;
begin
  select id into v_court from courts where venue_id = v_venue and number = 1;

  -- Book 3:00 PM (900) for 90 min  -> occupies [900, 990) = 3:00, 3:30, 4:00
  insert into bookings (venue_id, court_id, reference, booking_date, start_min, dur_min, price)
  values (v_venue, v_court, 'TEST-90MIN', v_date, 900, 90, 750);

  -- 3:00 taken
  assert not is_court_free(v_court, v_date, 900, 90), '3:00 PM should be taken';
  -- 3:30 taken (mid-booking)
  assert not is_court_free(v_court, v_date, 930, 90), '3:30 PM should be taken';
  -- 4:00 taken (mid-booking)
  assert not is_court_free(v_court, v_date, 960, 90), '4:00 PM should be taken';

  -- *** THE ONE THAT MATTERS ***
  -- 4:30 (990) is the END of the booking -> must be FREE for the next player.
  assert is_court_free(v_court, v_date, 990, 90), '4:30 PM MUST be free — end time is exclusive';
  assert is_court_free(v_court, v_date, 990, 60), '4:30 PM (60 min) MUST be free';

  -- 2:00 PM + 60 min ends exactly at 3:00 -> must be allowed (back-to-back)
  assert is_court_free(v_court, v_date, 840, 60), '2:00 PM 60min must fit right before';

  -- 2:30 PM + 60 min ends 3:30 -> overlaps -> blocked
  assert not is_court_free(v_court, v_date, 870, 60), '2:30 PM 60min overlaps and must be blocked';

  -- A different court at the same time is unaffected
  assert is_court_free((select id from courts where venue_id = v_venue and number = 2), v_date, 900, 90),
         'Court 2 must stay free at 3:00 PM';

  -- The DB itself rejects an overlapping insert (not just the helper function)
  begin
    insert into bookings (venue_id, court_id, reference, booking_date, start_min, dur_min, price)
    values (v_venue, v_court, 'TEST-CLASH', v_date, 930, 60, 500);
    raise exception 'FAIL: overlapping insert was allowed';
  exception when exclusion_violation then
    null; -- expected
  end;

  -- Back-to-back insert at the end time succeeds
  insert into bookings (venue_id, court_id, reference, booking_date, start_min, dur_min, price)
  values (v_venue, v_court, 'TEST-BACKTOBACK', v_date, 990, 90, 750);

  -- Cancelling frees the slot again
  update bookings set status = 'cancelled' where reference = 'TEST-90MIN';
  assert is_court_free(v_court, v_date, 900, 90), 'cancelled booking must free the slot';

  -- cleanup
  delete from bookings where reference like 'TEST-%';

  raise notice 'ALL OVERLAP TESTS PASSED — end time stays bookable.';
end $$;
