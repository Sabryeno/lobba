-- ============================================================================
-- Lobba — seed data. Mirrors courts_catalog.dart so the app looks identical
-- when it switches from the local store to this backend.
-- Run: supabase db reset   (applies migrations then this seed)
-- ============================================================================

-- Venue ids are fixed so the Flutter side can be pointed at them during the
-- migration (kOwnerVenueId = the Al-Ahly uuid below).
insert into venues (id, name, area, address, phone, lat, lng, indoor, rating, rating_count,
                    admin_name, admin_phone, manager_name, manager_phone)
values
  ('11111111-1111-1111-1111-111111111111', 'Al-Ahly Padel Club', 'New Cairo',
   '90th Street, 5th Settlement', '+201001234567', 30.0074, 31.4913, true, 4.9, 128,
   'Mahmoud Sabry', '+20 100 123 4567', 'Youssef Hany', '+20 111 900 4432'),
  ('22222222-2222-2222-2222-222222222222', 'Zamalek Sports Club', 'Zamalek',
   '26th of July Corridor, Zamalek', '+201005557788', 30.0609, 31.2197, false, 4.7, 96,
   null, null, null, null),
  ('33333333-3333-3333-3333-333333333333', 'Maadi Padel Lounge', 'Maadi',
   'Road 9, Maadi', '+201062201120', 29.9603, 31.2569, true, 4.8, 210,
   null, null, null, null);

-- Al-Ahly: 4 courts (matches the owner app's "4 active courts")
insert into courts (venue_id, number, indoor, status, price_60, price_90, price_120)
select '11111111-1111-1111-1111-111111111111', n, true,
       case n when 3 then 'maintenance'::court_status else 'active'::court_status end,
       500, 750, 1000
from generate_series(1, 4) as n;

-- Zamalek: 2 outdoor courts
insert into courts (venue_id, number, indoor, status, price_60, price_90, price_120)
select '22222222-2222-2222-2222-222222222222', n, false, 'active', 350, 525, 700
from generate_series(1, 2) as n;

-- Maadi: 4 courts
insert into courts (venue_id, number, indoor, status, price_60, price_90, price_120)
select '33333333-3333-3333-3333-333333333333', n, true, 'active', 450, 675, 900
from generate_series(1, 4) as n;

-- Sample deals (percentage off, dead-time slots)
insert into deals (venue_id, court_id, percent, deal_date, start_min, dur_min)
select '11111111-1111-1111-1111-111111111111', c.id, 30, current_date, 900, 120
from courts c where c.venue_id = '11111111-1111-1111-1111-111111111111' and c.number = 2;

insert into deals (venue_id, court_id, percent, deal_date, start_min, dur_min)
select '33333333-3333-3333-3333-333333333333', c.id, 25, current_date, 1200, 60
from courts c where c.venue_id = '33333333-3333-3333-3333-333333333333' and c.number = 1;

-- Existing reservations so overlap blocking is visible immediately.
-- Al-Ahly Court 1, tomorrow 6:00 PM, 90 min  -> occupies 6:00/6:30/7:00, frees 7:30
insert into bookings (venue_id, court_id, reference, booking_date, start_min, dur_min, price, source)
select '11111111-1111-1111-1111-111111111111', c.id, 'LB-SEED-01', current_date + 1, 1080, 90, 750, 'app'
from courts c where c.venue_id = '11111111-1111-1111-1111-111111111111' and c.number = 1;

-- Al-Ahly Court 2, tomorrow 8:00 PM, 60 min
insert into bookings (venue_id, court_id, reference, booking_date, start_min, dur_min, price, source)
select '11111111-1111-1111-1111-111111111111', c.id, 'LB-SEED-02', current_date + 1, 1200, 60, 500, 'app'
from courts c where c.venue_id = '11111111-1111-1111-1111-111111111111' and c.number = 2;
