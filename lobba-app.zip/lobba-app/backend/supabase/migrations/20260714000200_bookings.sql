-- ============================================================================
-- Lobba — bookings + the anti-double-booking guarantee
--
-- A booking occupies the HALF-OPEN interval [start_min, start_min + dur_min).
-- End-exclusive is deliberate: a 90-min booking at 3:00 PM occupies 3:00/3:30/
-- 4:00 and LEAVES 4:30 BOOKABLE. int4range() is half-open by default, so the
-- database enforces exactly that — no client can get it wrong.
-- ============================================================================

create table bookings (
  id           uuid primary key default uuid_generate_v4(),
  venue_id     uuid not null references venues(id) on delete cascade,
  court_id     uuid not null references courts(id) on delete cascade,
  player_id    uuid references profiles(id) on delete set null,  -- null for owner/WhatsApp locks
  reference    text not null unique,
  booking_date date not null,
  start_min    int  not null,      -- minutes from midnight, on the 30-min grid
  dur_min      int  not null,      -- 60 | 90 | 120
  status       booking_status not null default 'confirmed',
  source       booking_source not null default 'app',
  is_public    boolean not null default false,  -- posted as an open match
  players      int not null default 1,
  split        boolean not null default false,
  price        int not null default 0,          -- court fee actually charged (deal-adjusted)
  created_at   timestamptz not null default now(),

  constraint bookings_dur_valid  check (dur_min in (60, 90, 120)),
  constraint bookings_grid_30min check (start_min % 30 = 0),
  constraint bookings_start_range check (start_min >= 0 and start_min < 1440),
  constraint bookings_players_range check (players between 1 and 6),
  -- 6 players only unlocks on 90/120 min
  constraint bookings_players_vs_dur check (dur_min > 60 or players <= 4)
);

-- End of the booking, for convenience in queries/clients.
alter table bookings
  add column end_min int generated always as (start_min + dur_min) stored;

-- ── THE guarantee ───────────────────────────────────────────────────────────
-- Same court + same date + any intersection of the time intervals => rejected.
-- Cancelled rows are ignored so a cancellation frees the slot immediately.
alter table bookings add constraint bookings_no_overlap
  exclude using gist (
    court_id     with =,
    booking_date with =,
    int4range(start_min, start_min + dur_min) with &&
  ) where (status <> 'cancelled');

create index bookings_venue_date_idx  on bookings(venue_id, booking_date);
create index bookings_court_date_idx  on bookings(court_id, booking_date);
create index bookings_player_idx      on bookings(player_id, booking_date desc);
create index bookings_public_idx      on bookings(booking_date) where is_public and status = 'confirmed';

-- ── per-player slots (split payment / join confirmation) ────────────────────
create table booking_players (
  booking_id uuid not null references bookings(id) on delete cascade,
  player_id  uuid references profiles(id) on delete set null,
  seat       int  not null,                    -- 1 = booker, 2..6 = invited/open
  share      int  not null default 0,          -- EGP owed by this player
  paid       boolean not null default false,   -- split mode
  joined     boolean not null default false,   -- non-split mode: confirmed joining
  invited_name text,                           -- placeholder before they register
  primary key (booking_id, seat),
  constraint booking_players_seat_range check (seat between 1 and 6)
);
create index booking_players_player_idx on booking_players(player_id);

-- ── deals (percentage off, applied per duration) ────────────────────────────
create table deals (
  id         uuid primary key default uuid_generate_v4(),
  venue_id   uuid not null references venues(id) on delete cascade,
  court_id   uuid references courts(id) on delete cascade,
  percent    int  not null,
  deal_date  date not null,
  start_min  int  not null,
  dur_min    int  not null default 60,
  expires_at timestamptz,
  active     boolean not null default true,
  created_at timestamptz not null default now(),
  constraint deals_percent_range check (percent between 5 and 60),
  constraint deals_grid_30min check (start_min % 30 = 0)
);
create index deals_venue_idx on deals(venue_id, deal_date) where active;
