-- ============================================================================
-- Lobba — core schema: profiles, venues, courts
-- Mirrors the Flutter model (courts_catalog.dart) so the app can swap its local
-- store for this backend without UI changes.
-- ============================================================================

create extension if not exists "uuid-ossp";
-- btree_gist lets us mix equality (uuid/date) with range overlap (&&) inside a
-- single exclusion constraint — this is what makes double-booking impossible.
create extension if not exists btree_gist;

-- ── enums ───────────────────────────────────────────────────────────────────
create type user_role     as enum ('player', 'owner');
create type court_status  as enum ('active', 'maintenance', 'closed');
create type booking_status as enum ('confirmed', 'pending', 'cancelled');
create type booking_source as enum ('app', 'whatsapp', 'owner');

-- ── profiles ────────────────────────────────────────────────────────────────
-- One row per auth user. Name here is the single source of truth for the
-- booker name shown on tickets (app: accountProvider).
create table profiles (
  id          uuid primary key references auth.users on delete cascade,
  role        user_role   not null default 'player',
  name        text        not null,
  phone       text,
  email       text,
  birth_date  date,
  level       numeric(2,1) not null default 3.0,   -- 0.0 .. 7.0 leveling band
  reliability int         not null default 100,    -- 0..100
  photo_url   text,
  created_at  timestamptz not null default now(),
  constraint profiles_level_range check (level >= 0 and level <= 7)
);

-- ── venues (clubs) ──────────────────────────────────────────────────────────
create table venues (
  id           uuid primary key default uuid_generate_v4(),
  owner_id     uuid references profiles(id) on delete set null,
  name         text not null,
  area         text not null,
  address      text,
  phone        text,
  lat          double precision,
  lng          double precision,
  indoor       boolean not null default true,
  rating       numeric(2,1) not null default 0,
  rating_count int not null default 0,
  -- admin / manager contacts (owner app: Court profile)
  admin_name    text,
  admin_phone   text,
  manager_name  text,
  manager_phone text,
  logo_url      text,
  created_at   timestamptz not null default now()
);
create index venues_owner_idx on venues(owner_id);

-- ── courts (the physical Court 1..N inside a venue) ──────────────────────────
create table courts (
  id        uuid primary key default uuid_generate_v4(),
  venue_id  uuid not null references venues(id) on delete cascade,
  number    int  not null,                      -- "Court 1", "Court 2", ...
  indoor    boolean not null default true,
  status    court_status not null default 'active',
  -- price per duration, in EGP
  price_60  int not null,
  price_90  int not null,
  price_120 int not null,
  opens_min  int not null default 900,          -- 15:00 (minutes from midnight)
  closes_min int not null default 1440,         -- 24:00
  created_at timestamptz not null default now(),
  unique (venue_id, number),
  constraint courts_number_positive check (number > 0),
  constraint courts_hours check (closes_min > opens_min)
);
create index courts_venue_idx on courts(venue_id);

-- Price for a given duration (60 | 90 | 120).
create or replace function court_price(c courts, p_dur int)
returns int language sql immutable as $$
  select case p_dur when 60 then c.price_60 when 90 then c.price_90 else c.price_120 end;
$$;

-- Keep profiles in sync with auth.users on signup.
create or replace function handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, name, email, phone, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', split_part(coalesce(new.email, 'Player'), '@', 1)),
    new.email,
    new.phone,
    coalesce((new.raw_user_meta_data->>'role')::user_role, 'player')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();
