-- ============================================================================
-- Lobba — Row Level Security.
-- Rule of thumb: venues/courts are public (players must browse them); bookings
-- are visible to the player who made them and to the owner of that venue only.
-- This is what enforces "owner sees bookings at THEIR courts only".
-- ============================================================================

alter table profiles        enable row level security;
alter table venues          enable row level security;
alter table courts          enable row level security;
alter table bookings        enable row level security;
alter table booking_players enable row level security;
alter table deals           enable row level security;

-- helper: does the current user own this venue?
create or replace function owns_venue(p_venue_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from venues v where v.id = p_venue_id and v.owner_id = auth.uid());
$$;

-- ── profiles ────────────────────────────────────────────────────────────────
create policy "profiles: read all authenticated"
  on profiles for select to authenticated using (true);
create policy "profiles: update own"
  on profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- ── venues ──────────────────────────────────────────────────────────────────
create policy "venues: public read"
  on venues for select using (true);
create policy "venues: owner writes"
  on venues for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- ── courts ──────────────────────────────────────────────────────────────────
create policy "courts: public read"
  on courts for select using (true);
create policy "courts: owner writes"
  on courts for all to authenticated
  using (owns_venue(venue_id)) with check (owns_venue(venue_id));

-- ── bookings ────────────────────────────────────────────────────────────────
-- A player sees their own; a venue owner sees everything at their venue;
-- public (open match) bookings are readable so the matches feed works.
create policy "bookings: player or venue owner or public match"
  on bookings for select to authenticated
  using (player_id = auth.uid() or owns_venue(venue_id) or (is_public and status = 'confirmed'));

create policy "bookings: player creates own"
  on bookings for insert to authenticated
  with check (player_id = auth.uid() or owns_venue(venue_id));

create policy "bookings: player or owner updates"
  on bookings for update to authenticated
  using (player_id = auth.uid() or owns_venue(venue_id));

-- ── booking_players ─────────────────────────────────────────────────────────
create policy "booking_players: participants and venue owner"
  on booking_players for select to authenticated
  using (
    player_id = auth.uid()
    or exists (select 1 from bookings b where b.id = booking_id and (b.player_id = auth.uid() or owns_venue(b.venue_id)))
  );
create policy "booking_players: booker manages seats"
  on booking_players for all to authenticated
  using (exists (select 1 from bookings b where b.id = booking_id and b.player_id = auth.uid()))
  with check (exists (select 1 from bookings b where b.id = booking_id and b.player_id = auth.uid()));

-- ── deals ───────────────────────────────────────────────────────────────────
create policy "deals: public read"
  on deals for select using (active);
create policy "deals: owner writes"
  on deals for all to authenticated
  using (owns_venue(venue_id)) with check (owns_venue(venue_id));

-- ── realtime ────────────────────────────────────────────────────────────────
-- Both the player availability grid and the owner dashboard subscribe here;
-- this is what replaces the WebSocket server in the original spec.
alter publication supabase_realtime add table bookings;
alter publication supabase_realtime add table courts;
