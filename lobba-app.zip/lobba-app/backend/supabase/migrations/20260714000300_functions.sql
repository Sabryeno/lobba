-- ============================================================================
-- Lobba — RPC API used by the Flutter app.
-- These mirror bookings_provider.dart 1:1:
--   isCourtFree()        -> is_court_free()
--   availableSubCourts() -> available_courts()
--   book()               -> book_court()   (returns ok/message like BookingResult)
-- ============================================================================

-- Is ONE physical court free for the whole requested interval?
create or replace function is_court_free(
  p_court_id uuid, p_date date, p_start_min int, p_dur_min int
) returns boolean language sql stable as $$
  select not exists (
    select 1 from bookings b
    where b.court_id = p_court_id
      and b.booking_date = p_date
      and b.status <> 'cancelled'
      -- half-open overlap: end is exclusive, so the end slot stays bookable
      and b.start_min < p_start_min + p_dur_min
      and p_start_min < b.start_min + b.dur_min
  );
$$;

-- Which courts of a venue are free for this slot+duration (player's court picker
-- and the owner's live availability both read this).
create or replace function available_courts(
  p_venue_id uuid, p_date date, p_start_min int, p_dur_min int
) returns table (court_id uuid, number int, price int)
language sql stable as $$
  select c.id, c.number, court_price(c, p_dur_min)
  from courts c
  where c.venue_id = p_venue_id
    and c.status = 'active'
    and p_start_min >= c.opens_min
    and p_start_min + p_dur_min <= c.closes_min
    and is_court_free(c.id, p_date, p_start_min, p_dur_min)
  order by c.number;
$$;

-- Is ANY court free at this slot (drives the greying of the slot grid)?
create or replace function any_court_free(
  p_venue_id uuid, p_date date, p_start_min int, p_dur_min int
) returns boolean language sql stable as $$
  select exists (select 1 from available_courts(p_venue_id, p_date, p_start_min, p_dur_min));
$$;

-- The full 30-min grid for a venue/date/duration, with availability per slot.
create or replace function slot_grid(
  p_venue_id uuid, p_date date, p_dur_min int
) returns table (start_min int, free boolean, free_courts int)
language sql stable as $$
  select s.start_min,
         exists (select 1 from available_courts(p_venue_id, p_date, s.start_min, p_dur_min)),
         (select count(*)::int from available_courts(p_venue_id, p_date, s.start_min, p_dur_min))
  from generate_series(900, 1350, 30) as s(start_min)   -- 3:00 PM .. 10:30 PM
  order by s.start_min;
$$;

-- ── the validated write ─────────────────────────────────────────────────────
-- Race-safe: two players hitting the same court/slot at once — one wins, the
-- other gets ok=false because the exclusion constraint rejects the insert.
create or replace function book_court(
  p_court_id  uuid,
  p_date      date,
  p_start_min int,
  p_dur_min   int,
  p_players   int default 1,
  p_is_public boolean default false,
  p_split     boolean default false,
  p_deal_pct  int default null,
  p_source    booking_source default 'app'
) returns table (ok boolean, message text, booking_id uuid, reference text)
language plpgsql security definer set search_path = public as $$
declare
  v_court   courts%rowtype;
  v_price   int;
  v_ref     text;
  v_id      uuid;
begin
  select * into v_court from courts where id = p_court_id;
  if not found then
    return query select false, 'Court not found', null::uuid, null::text; return;
  end if;
  if v_court.status <> 'active' then
    return query select false, 'That court is not open for booking.', null::uuid, null::text; return;
  end if;

  v_price := court_price(v_court, p_dur_min);
  if p_deal_pct is not null then
    v_price := round(v_price * (100 - p_deal_pct) / 100.0);
  end if;

  v_ref := 'LB-' || to_char(now(), 'YYYY') || '-' || upper(substr(md5(random()::text), 1, 6));

  begin
    insert into bookings (venue_id, court_id, player_id, reference, booking_date,
                          start_min, dur_min, source, is_public, players, split, price)
    values (v_court.venue_id, p_court_id, auth.uid(), v_ref, p_date,
            p_start_min, p_dur_min, p_source, p_is_public, p_players, p_split, v_price)
    returning id into v_id;
  exception
    when exclusion_violation then
      -- someone took it between the availability check and this insert
      return query select false, 'That court just got taken — pick another time or court.', null::uuid, null::text;
      return;
    when check_violation then
      return query select false, 'Invalid slot — times run on a 30-minute grid.', null::uuid, null::text;
      return;
  end;

  -- seat 1 is always the booker
  insert into booking_players (booking_id, player_id, seat, share, paid, joined)
  values (v_id, auth.uid(), 1, case when p_split then round(v_price::numeric / p_players) else v_price end, true, true);

  return query select true, 'Booking confirmed', v_id, v_ref;
end;
$$;

-- Owner/WhatsApp lock: blocks a slot so the player app cannot book it.
create or replace function lock_slot(
  p_court_id uuid, p_date date, p_start_min int, p_dur_min int
) returns table (ok boolean, message text, booking_id uuid, reference text)
language sql security definer set search_path = public as $$
  select * from book_court(p_court_id, p_date, p_start_min, p_dur_min, 1, false, false, null, 'whatsapp');
$$;

create or replace function cancel_booking(p_booking_id uuid)
returns boolean language plpgsql security definer set search_path = public as $$
begin
  update bookings set status = 'cancelled' where id = p_booking_id;
  return found;
end;
$$;

-- ── owner analytics (replaces the mock factors in the app) ──────────────────
create or replace function venue_revenue(
  p_venue_id uuid, p_from date, p_to date,
  p_from_hour int default 0, p_to_hour int default 24, p_court_id uuid default null, p_dur int default null
) returns table (day date, revenue bigint, bookings bigint)
language sql stable as $$
  select b.booking_date,
         coalesce(sum(b.price), 0)::bigint,
         count(*)::bigint
  from bookings b
  where b.venue_id = p_venue_id
    and b.status = 'confirmed'
    and b.booking_date between p_from and p_to
    and b.start_min >= p_from_hour * 60
    and b.start_min <  p_to_hour * 60
    and (p_court_id is null or b.court_id = p_court_id)
    and (p_dur is null or b.dur_min = p_dur)
  group by b.booking_date
  order by b.booking_date;
$$;
