# Lobba 🎾

**Egypt's padel-court booking platform.** A bilingual (Arabic RTL / English) Flutter
app with three surfaces — **Player**, **Court Owner**, and a web **Admin portal** —
plus a Postgres/Supabase backend designed to guarantee no double-booking.

> Status: **front-end prototype** (polished, all screens built) on mock data.
> The backend is designed (runnable SQL) but not yet wired into the app.
> See [`docs/07-STATUS-AND-BACKLOG.md`](docs/07-STATUS-AND-BACKLOG.md).

## Repository layout

```
lobba-app/
├── mobile/     Flutter app — Player + Court-Owner (one codebase, role-routed)
├── admin/      Web admin portal prototype (single self-contained HTML file)
├── backend/    Postgres/Supabase schema, RPC API, RLS, overlap test
└── docs/       Full handover: architecture, screens, data model, design guides, user stories
```

Start with [`docs/00-START-HERE.md`](docs/00-START-HERE.md).

## Quick start (mobile)

```bash
cd mobile
flutter pub get
flutter run
```

Requirements: Flutter **3.44.4** (or ≥3.22), Android SDK, JDK 17.
Build a release APK: `flutter build apk --release --target=lib/main.dart`.

> ⚠️ **Firebase config is not committed.** Copy your own into
> `mobile/android/app/google-services.json` (a template is provided at
> `google-services.json.example`). The app builds/runs without it in most flows,
> but Firebase features need it.

> ⚠️ **Signing keys are not committed.** `mobile/android/key.properties` and the
> upload keystore are excluded. Release builds **fall back to debug signing** when
> they're absent, so the project still builds. For a store-ready release, add your
> own `key.properties` + keystore (see `mobile/android/app/build.gradle.kts`).

> ⚠️ **i18n build guard:** the Arabic dictionary is a `const Map`; a duplicate key
> breaks the build. Before building run:
> ```bash
> grep -oE "^  '[^']*':" mobile/lib/core/i18n/lobba_i18n.dart | sort | uniq -d   # must be empty
> ```

## Quick start (backend)

```bash
cd backend
npm i -g supabase          # needs Docker Desktop
supabase start
supabase db reset          # apply migrations + seed
psql "postgresql://postgres:postgres@127.0.0.1:54322/postgres" -f tests/overlap_test.sql
```
See [`backend/README.md`](backend/README.md).

## Admin portal

Open `admin/Lobba-Admin-Portal.html` in any browser and click **Log in** (mock data).
Spec: [`docs/09-ADMIN-PORTAL.md`](docs/09-ADMIN-PORTAL.md).

## Tech

Flutter · Riverpod · go_router · Firebase (auth/messaging, partial) ·
Postgres/Supabase (designed) · flutter_map (OpenStreetMap).

## Core design principle

**No double-booking, end-time stays free.** A 90-minute booking at 3:00 PM occupies
3:00/3:30/4:00 and leaves **4:30 bookable**. Enforced today in Dart (client-side),
and — in the backend — by a Postgres exclusion constraint so it's impossible at the
database level. Proof: `backend/tests/overlap_test.sql`.

## Documentation

| Doc | |
|---|---|
| [00-START-HERE](docs/00-START-HERE.md) | index / overview |
| [01-PROJECT-OVERVIEW](docs/01-PROJECT-OVERVIEW.md) | product, roles, features |
| [02-ARCHITECTURE](docs/02-ARCHITECTURE.md) | patterns, state, routing, i18n |
| [03-SCREEN-INVENTORY](docs/03-SCREEN-INVENTORY.md) | every screen + status |
| [04-DATA-MODEL](docs/04-DATA-MODEL.md) | entities, booking/overlap model |
| [05-BUILD-AND-RUN](docs/05-BUILD-AND-RUN.md) | build steps |
| [06-BACKEND-HANDOVER](docs/06-BACKEND-HANDOVER.md) | backend + migration plan |
| [07-STATUS-AND-BACKLOG](docs/07-STATUS-AND-BACKLOG.md) | done / mock / missing |
| [08-DESIGN-SYSTEM](docs/08-DESIGN-SYSTEM.md) | tokens, fonts, i18n |
| [09-ADMIN-PORTAL](docs/09-ADMIN-PORTAL.md) | admin portal features |
| [10-USER-STORIES-AND-SCENARIOS](docs/10-USER-STORIES-AND-SCENARIOS.md) | stories + QA scenarios |
| Design guides | `docs/Lobba-Design-Guide.html`, `docs/Lobba-Admin-Design-Guide.html` |

## Releases

The installable Android APK is **not** committed to git (size). Attach it to a
GitHub **Release** instead: build with the command above and upload `app-release.apk`.

## License

© Lobba. All rights reserved. (Add a license file if you intend to open-source.)
