#!/usr/bin/env bash
# Build the Lobba iOS app (.ipa) — RUN ON A MAC with Xcode + Flutter installed.
# Wraps the same routed web app (Player + Owner + Admin) in a WKWebView, exactly
# like the Android APK. Produces an installable .ipa for TestFlight / ad-hoc.
#
#   cd mobile && bash build_ios_ipa.sh
set -e

WEB_APP="../lobba-routed-app"

# 1) Build the single-file web bundle and stage it into the WebView assets.
( cd "$WEB_APP" && npm install && npm run build:mobile )
rm -f  assets/trial/index.html
rm -rf assets/trial/admin && mkdir -p assets/trial/admin
cp "$WEB_APP/dist-mobile/index.html"        assets/trial/index.html
cp "$WEB_APP/dist-mobile/admin/index.html"  assets/trial/admin/index.html
echo "Bundled routed app into assets/trial/"

# 2) Build the iOS archive / IPA.
flutter pub get
# No signing team configured -> build an unsigned .app you can run on Simulator,
# OR pass your team id for a real device/TestFlight build:
#   flutter build ipa --target=lib/main_trial.dart --export-options-plist=ExportOptions.plist
flutter build ios --release --no-codesign --target=lib/main_trial.dart
echo "Built Runner.app (unsigned). For a signed .ipa for TestFlight, open ios/Runner.xcworkspace"
echo "in Xcode, set your Team under Signing & Capabilities, then Product > Archive > Distribute."
