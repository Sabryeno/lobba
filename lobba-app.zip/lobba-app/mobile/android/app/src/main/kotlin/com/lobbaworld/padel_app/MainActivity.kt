package com.lobbaworld.padel_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
