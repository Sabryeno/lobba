# Build the Lobba TRIAL APK (WebView wrapper around the interactive prototype).
# Produces a signed, installable APK with the latest UI for testers.
# Run from the mobile/ folder:  powershell -ExecutionPolicy Bypass -File build_trial_apk.ps1
$ErrorActionPreference = "Stop"
$flutter = "C:\Users\mahms\Downloads\flutter_windows_3.44.1-stable\flutter\bin\flutter.bat"

# Keep the bundled trial UI in sync with the prototype before each build.
Copy-Item "..\prototype\index.html" "assets\trial\index.html" -Force
Write-Host "Bundled prototype into assets/trial/" -ForegroundColor Green

& $flutter pub get
& $flutter build apk --release --target=lib/main_trial.dart

$apk = "build\app\outputs\flutter-apk\app-release.apk"
if (Test-Path $apk) {
  $mb = "{0:N1}" -f ((Get-Item $apk).Length / 1MB)
  Copy-Item $apk "..\Lobba-Trial.apk" -Force
  Write-Host "TRIAL APK built: $apk ($mb MB) -> copied to ..\Lobba-Trial.apk" -ForegroundColor Green
} else {
  Write-Host "Build finished but APK not found - check the log above." -ForegroundColor Red
}
