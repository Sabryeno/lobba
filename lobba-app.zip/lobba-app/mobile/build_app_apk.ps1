# Build the Lobba ROUTED-APP APK.
# Inlines the React app (Player + Owner + Admin) into a single file that runs
# from file:// inside the WebView, bundles it, and builds a signed release APK.
# Run from the mobile/ folder:  powershell -ExecutionPolicy Bypass -File build_app_apk.ps1
$ErrorActionPreference = "Stop"
$flutter = "C:\Users\mahms\Downloads\flutter_windows_3.44.1-stable\flutter\bin\flutter.bat"
$webApp  = "..\lobba-routed-app"

# 1) Build the single-file web bundle.
Push-Location $webApp
& npm run build:mobile
Pop-Location

# 2) Stage it into the WebView shell's assets.
Remove-Item "assets\trial\index.html" -Force -ErrorAction SilentlyContinue
Remove-Item "assets\trial\admin" -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory "assets\trial\admin" -Force | Out-Null
Copy-Item "$webApp\dist-mobile\index.html" "assets\trial\index.html" -Force
Copy-Item "$webApp\dist-mobile\admin\index.html" "assets\trial\admin\index.html" -Force
Write-Host "Bundled routed app into assets/trial/" -ForegroundColor Green

# 3) Build the APK.
& $flutter pub get
& $flutter build apk --release --target=lib/main_trial.dart

$apk = "build\app\outputs\flutter-apk\app-release.apk"
if (Test-Path $apk) {
  $mb = "{0:N1}" -f ((Get-Item $apk).Length / 1MB)
  Copy-Item $apk "..\Lobba-App.apk" -Force
  Write-Host "APK built: $apk ($mb MB) -> copied to ..\Lobba-App.apk" -ForegroundColor Green
} else {
  Write-Host "Build finished but APK not found - check the log above." -ForegroundColor Red
}
