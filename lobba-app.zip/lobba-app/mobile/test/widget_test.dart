// Basic smoke test for the Lobba app.
//
// The full app (Lobba) requires a ProviderScope and performs async startup
// (router redirects, secure storage), which isn't suitable for a plain unit
// widget test. This test verifies the test harness and a basic widget tree.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('MaterialApp builds a basic widget tree', (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: Center(child: Text('Lobba')),
        ),
      ),
    );

    expect(find.text('Lobba'), findsOneWidget);
  });
}
