import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';

class LeaderboardScreen extends ConsumerStatefulWidget {
  const LeaderboardScreen({super.key});
  @override
  ConsumerState<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends ConsumerState<LeaderboardScreen> {
  int _tab = 0;
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final rows = [
      ['1', 'Karim El-Sisi', 'Alexandria', '6.5'],
      ['2', 'Sara Mostafa', 'Cairo', '6.1'],
      ['3', 'Omar Khalil', 'Cairo', '5.7'],
      ['4', 'Laila Hassan', 'Giza', '5.3'],
      ['5', 'Youssef Adel', 'Cairo', '5.0'],
    ];
    return Container(
      color: t.bg,
      child: ListView(padding: const EdgeInsets.only(bottom: 120), children: [
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 8, 22, 18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Rankings'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w500, color: t.headFg)),
            const SizedBox(height: 14),
            Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16), decoration: BoxDecoration(color: t.headCard, borderRadius: BorderRadius.circular(14)), child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              _standing(t, '#143', 'National'.tr(context)), _vl(t), _standing(t, '#38', 'Cairo'), _vl(t), _standing(t, '3.0', 'Level'.tr(context)),
            ])),
          ]),
        ))),
        // tabs
        Container(color: t.surface, child: Row(children: [_segTab(t, 'National'.tr(context), 0), _segTab(t, 'Cairo', 1)])),
        const SizedBox(height: 8),
        ...rows.map((r) => GestureDetector(
          onTap: () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', r[1])),
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 3), child: Row(children: [
            SizedBox(width: 22, child: Text(r[0], textAlign: TextAlign.center, style: TextStyle(fontFamily: kSerif, fontWeight: FontWeight.w600, color: t.accent))),
            const SizedBox(width: 12),
            LAvatar(r[1][0], size: 34),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(r[1], style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
              Text(r[2], style: TextStyle(fontSize: 10, color: t.ink3)),
            ])),
            Text(r[3], style: TextStyle(fontFamily: kSerif, fontSize: 13, fontWeight: FontWeight.w600, color: t.accent)),
          ])),
        )),
        // your row
        Padding(padding: const EdgeInsets.fromLTRB(12, 6, 12, 0), child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
          decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(13)),
          child: Row(children: [
            SizedBox(width: 28, child: Text('143', textAlign: TextAlign.center, style: TextStyle(fontFamily: kSerif, fontWeight: FontWeight.w600, color: t.accent))),
            const SizedBox(width: 6),
            LAvatar('A', size: 34, bg: t.accent, fg: t.onAccent),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Ahmed Mohamed', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
              Text('You · Cairo', style: TextStyle(fontSize: 10, color: t.accent)),
            ])),
            Padding(padding: const EdgeInsets.only(right: 8), child: Text('3.0', style: TextStyle(fontFamily: kSerif, fontSize: 13, fontWeight: FontWeight.w600, color: t.accent))),
          ]),
        )),
      ]),
    );
  }

  Widget _standing(LobbaTokens t, String v, String l) => Expanded(child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Text(v, style: TextStyle(fontFamily: kSerif, fontSize: 20, fontWeight: FontWeight.w600, color: t.headFg)),
          const SizedBox(height: 3),
          Text(l, textAlign: TextAlign.center, style: TextStyle(fontSize: 9.5, color: t.headFg.withOpacity(.7))),
        ]),
      ));
  Widget _vl(LobbaTokens t) => Container(width: 1, height: 30, color: t.headFg.withOpacity(.22));
  Widget _segTab(LobbaTokens t, String label, int i) => Expanded(child: GestureDetector(
        onTap: () => setState(() => _tab = i),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11), alignment: Alignment.center,
          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: _tab == i ? t.accent : Colors.transparent, width: 2))),
          child: Text(label, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: _tab == i ? t.accent : t.ink3)),
        ),
      ));
}
