import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/services/api_service.dart';
import '../../../core/constants/app_constants.dart';

class LeaderboardEntry {
  final String userId;
  final String fullName;
  final String? avatarUrl;
  final double eloRating;
  final String skillLevel;
  final String city;
  final int rankPosition;
  final int wins;
  final int losses;
  final double winRate;

  const LeaderboardEntry({
    required this.userId,
    required this.fullName,
    this.avatarUrl,
    required this.eloRating,
    required this.skillLevel,
    required this.city,
    required this.rankPosition,
    required this.wins,
    required this.losses,
    required this.winRate,
  });

  factory LeaderboardEntry.fromJson(Map<String, dynamic> j) => LeaderboardEntry(
        userId: j['userId'] ?? '',
        fullName: j['fullName'] ?? 'Player',
        avatarUrl: j['avatarUrl'],
        eloRating: (j['eloRating'] as num?)?.toDouble() ?? 1200,
        skillLevel: j['skillLevel'] ?? 'BEGINNER',
        city: j['city'] ?? '',
        rankPosition: j['rankPosition'] ?? 0,
        wins: j['wins'] ?? 0,
        losses: j['losses'] ?? 0,
        winRate: (j['winRate'] as num?)?.toDouble() ?? 0,
      );
}

class PlayerRank {
  final int nationalRank;
  final int cityRank;
  final String city;
  final int totalNational;
  final int totalCity;

  const PlayerRank({
    required this.nationalRank,
    required this.cityRank,
    required this.city,
    required this.totalNational,
    required this.totalCity,
  });

  factory PlayerRank.fromJson(Map<String, dynamic> j) => PlayerRank(
        nationalRank: j['nationalRank'] ?? 0,
        cityRank: j['cityRank'] ?? 0,
        city: j['city'] ?? '',
        totalNational: j['totalNational'] ?? 0,
        totalCity: j['totalCity'] ?? 0,
      );
}

class LeaderboardState {
  final List<LeaderboardEntry> nationalBoard;
  final List<LeaderboardEntry> cityBoard;
  final PlayerRank? myRank;
  final String selectedCity;
  final bool isLoadingNational;
  final bool isLoadingCity;

  const LeaderboardState({
    this.nationalBoard = const [],
    this.cityBoard = const [],
    this.myRank,
    this.selectedCity = 'Cairo',
    this.isLoadingNational = false,
    this.isLoadingCity = false,
  });

  LeaderboardState copyWith({
    List<LeaderboardEntry>? nationalBoard,
    List<LeaderboardEntry>? cityBoard,
    PlayerRank? myRank,
    String? selectedCity,
    bool? isLoadingNational,
    bool? isLoadingCity,
  }) =>
      LeaderboardState(
        nationalBoard: nationalBoard ?? this.nationalBoard,
        cityBoard: cityBoard ?? this.cityBoard,
        myRank: myRank ?? this.myRank,
        selectedCity: selectedCity ?? this.selectedCity,
        isLoadingNational: isLoadingNational ?? this.isLoadingNational,
        isLoadingCity: isLoadingCity ?? this.isLoadingCity,
      );
}

class LeaderboardNotifier extends StateNotifier<LeaderboardState> {
  final Ref _ref;

  LeaderboardNotifier(this._ref) : super(const LeaderboardState());

  Future<void> loadAll() async {
    await Future.wait([loadNational(), loadCity(state.selectedCity), loadMyRank()]);
  }

  Future<void> loadNational() async {
    state = state.copyWith(isLoadingNational: true);
    try {
      final dio = _ref.read(dioProvider);
      final resp = await dio.get('/leaderboard/national', queryParameters: {'limit': 100});
      final items = (resp.data['data'] as List)
          .map((e) => LeaderboardEntry.fromJson(e))
          .toList();
      state = state.copyWith(nationalBoard: items, isLoadingNational: false);
    } catch (_) {
      state = state.copyWith(isLoadingNational: false);
    }
  }

  Future<void> loadCity(String city) async {
    state = state.copyWith(isLoadingCity: true, selectedCity: city);
    try {
      final dio = _ref.read(dioProvider);
      final resp = await dio.get('/leaderboard/city/$city', queryParameters: {'limit': 50});
      final items = (resp.data['data'] as List)
          .map((e) => LeaderboardEntry.fromJson(e))
          .toList();
      state = state.copyWith(cityBoard: items, isLoadingCity: false);
    } catch (_) {
      state = state.copyWith(isLoadingCity: false);
    }
  }

  Future<void> loadMyRank() async {
    try {
      final dio = _ref.read(dioProvider);
      final resp = await dio.get('/leaderboard/me/rank');
      final rank = PlayerRank.fromJson(resp.data['data']);
      state = state.copyWith(myRank: rank);
    } catch (_) {}
  }
}

final leaderboardProvider =
    StateNotifierProvider<LeaderboardNotifier, LeaderboardState>((ref) {
  return LeaderboardNotifier(ref);
});
