import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';

class DealsScreen extends ConsumerWidget {
  const DealsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    return Scaffold(
      backgroundColor: t.bg,
      body: ListView(padding: EdgeInsets.zero, children: [
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 6, 22, 18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              GestureDetector(onTap: () => context.canPop() ? context.pop() : null, child: Icon(Icons.chevron_left_rounded, color: t.headFg, size: 24)),
            ]),
            const SizedBox(height: 6),
            Text('Last-minute deals'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w500, color: t.headFg)),
            const SizedBox(height: 3),
            Text('Near you · ending soon'.tr(context), style: TextStyle(fontSize: 11, color: t.headFg.withOpacity(.82))),
          ]),
        ))),
        const SizedBox(height: 16),
        _deal(context, t, '1', 2, 30, 'Al-Ahly Padel Club', 'New Cairo · Today 3–5 PM', '30% OFF', '1000', '700', '1h 23m'),
        const SizedBox(height: 12),
        _deal(context, t, '3', 1, 25, 'Maadi Padel Lounge', 'Maadi · Today 8–9 PM', '25% OFF', '450', '338', '2h 05m'),
      ]),
    );
  }

  Widget _deal(BuildContext c, LobbaTokens t, String id, int courtNum, int pct, String name, String meta, String off, String was, String now, String timer) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22),
        child: Container(
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          clipBehavior: Clip.antiAlias,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Stack(children: [
              Container(height: 88, decoration: BoxDecoration(gradient: LinearGradient(colors: [t.accentSoft, t.surface2]))),
              Positioned(top: 11, left: 11, child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: t.clay, borderRadius: BorderRadius.circular(99)), child: Text(off, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white)))),
              Positioned(top: 11, right: 11, child: Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4), decoration: BoxDecoration(color: Colors.black.withOpacity(.5), borderRadius: BorderRadius.circular(99)), child: Text('⏱ $timer', style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w600, color: Colors.white)))),
              Positioned(bottom: 10, left: 11, child: Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(99), border: Border.all(color: t.line)), child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.sports_tennis_rounded, size: 11, color: t.accent),
                const SizedBox(width: 4),
                Text('${'Court'.tr(c)} $courtNum', style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, color: t.accent)),
              ]))),
            ]),
            Padding(padding: const EdgeInsets.fromLTRB(14, 12, 14, 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(name, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink)),
                  Text(meta, style: TextStyle(fontSize: 10.5, color: t.ink3)),
                  const SizedBox(height: 3),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.trending_down_rounded, size: 11, color: t.sage),
                    const SizedBox(width: 4),
                    Text('Dead-time offer'.tr(c), style: TextStyle(fontSize: 9, fontWeight: FontWeight.w600, color: t.sage)),
                  ]),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(was, style: TextStyle(fontSize: 10, color: t.ink3, decoration: TextDecoration.lineThrough)),
                  Text('EGP $now', style: TextStyle(fontFamily: kSerif, fontSize: 16, fontWeight: FontWeight.w600, color: t.accent)),
                ]),
              ]),
              const SizedBox(height: 11),
              GestureDetector(
                onTap: () => c.push('${AppRoutes.courtDetail.replaceFirst(':courtId', id)}?deal=$pct'),
                child: Container(padding: const EdgeInsets.symmetric(vertical: 10), alignment: Alignment.center, decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(11)), child: Text('Book deal'.tr(c), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.onAccent))),
              ),
            ])),
          ]),
        ),
      );
}
