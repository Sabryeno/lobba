import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/services/api_service.dart';

class TournamentModel {
  final String id;
  final String name;
  final String? description;
  final String? coverImage;
  final String city;
  final String format;
  final String status;
  final DateTime startDate;
  final DateTime? registrationDeadline;
  final double entryFee;
  final int maxParticipants;
  final int currentParticipants;
  final double? prizeMoney;

  const TournamentModel({
    required this.id,
    required this.name,
    this.description,
    this.coverImage,
    required this.city,
    required this.format,
    required this.status,
    required this.startDate,
    this.registrationDeadline,
    required this.entryFee,
    required this.maxParticipants,
    required this.currentParticipants,
    this.prizeMoney,
  });

  factory TournamentModel.fromJson(Map<String, dynamic> j) => TournamentModel(
        id: j['id'],
        name: j['name'] ?? 'Tournament',
        description: j['description'],
        coverImage: j['coverImage'],
        city: j['venue']?['city'] ?? '',
        format: j['format'] ?? 'SINGLES',
        status: j['status'] ?? 'UPCOMING',
        startDate: DateTime.parse(j['startDate']),
        registrationDeadline: j['registrationDeadline'] != null
            ? DateTime.parse(j['registrationDeadline'])
            : null,
        entryFee: (j['entryFee'] as num?)?.toDouble() ?? 0,
        maxParticipants: j['maxParticipants'] ?? 16,
        currentParticipants: j['currentParticipants'] ?? 0,
        prizeMoney: (j['prizeMoney'] as num?)?.toDouble(),
      );

  bool get isOpen => status == 'REGISTRATION_OPEN';
  bool get isFull => currentParticipants >= maxParticipants;
  int get spotsLeft => maxParticipants - currentParticipants;
}

final tournamentsProvider = FutureProvider<List<TournamentModel>>((ref) async {
  final dio = ref.read(dioProvider);
  final resp = await dio.get('/tournaments');
  final body = resp.data;
  final list = body is Map<String, dynamic> && body['data'] is List
      ? body['data'] as List
      : body as List;
  return list
      .map((e) => TournamentModel.fromJson(e))
      .toList();
});

class TournamentsScreen extends ConsumerWidget {
  const TournamentsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(tournamentsProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
        title: const Text('Tournaments', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (tournaments) {
          if (tournaments.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.emoji_events, size: 64, color: AppColors.grey300),
                  const SizedBox(height: 16),
                  Text('No tournaments yet',
                      style: TextStyle(color: AppColors.textSecondary)),
                  Text('Check back soon!',
                      style: TextStyle(color: AppColors.textTertiary)),
                ],
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: tournaments.length,
            itemBuilder: (context, i) => _TournamentCard(t: tournaments[i]),
          );
        },
      ),
    );
  }
}

class _TournamentCard extends StatelessWidget {
  final TournamentModel t;
  const _TournamentCard({required this.t});

  @override
  Widget build(BuildContext context) {
    final statusColor = t.status == 'REGISTRATION_OPEN'
        ? AppColors.success
        : t.status == 'ONGOING'
            ? AppColors.warning
            : AppColors.grey400;

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 0,
      clipBehavior: Clip.hardEdge,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: AppColors.grey200),
      ),
      child: InkWell(
        onTap: () => context.push('/tournaments/${t.id}'),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hero image
            Container(
              height: 120,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF1A6B4A), Color(0xFF124E36)],
                ),
                image: t.coverImage != null
                    ? DecorationImage(
                        image: NetworkImage(t.coverImage!),
                        fit: BoxFit.cover,
                        colorFilter: ColorFilter.mode(
                            Colors.black.withOpacity(0.3), BlendMode.darken),
                      )
                    : null,
              ),
              child: Stack(
                children: [
                  Center(
                    child: Icon(Icons.emoji_events,
                        size: 48, color: Colors.white.withOpacity(0.7)),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: statusColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        t.status.replaceAll('_', ' '),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  if (t.prizeMoney != null)
                    Positioned(
                      bottom: 10,
                      left: 12,
                      child: Text(
                        '🏆 EGP ${t.prizeMoney!.toStringAsFixed(0)} Prize',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            shadows: [
                              Shadow(color: Colors.black, blurRadius: 4)
                            ]),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t.name,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.location_on_outlined,
                          size: 13, color: AppColors.textSecondary),
                      const SizedBox(width: 2),
                      Text(t.city,
                          style: TextStyle(
                              fontSize: 12, color: AppColors.textSecondary)),
                      const Spacer(),
                      Text(t.format,
                          style: TextStyle(
                              fontSize: 12, color: AppColors.textSecondary)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(Icons.calendar_today,
                          size: 13, color: AppColors.textSecondary),
                      const SizedBox(width: 4),
                      Text(
                        DateFormat('MMM d, y').format(t.startDate),
                        style: TextStyle(
                            fontSize: 13, color: AppColors.textSecondary),
                      ),
                      const Spacer(),
                      Text(
                        '${t.currentParticipants}/${t.maxParticipants} players',
                        style: TextStyle(
                            fontSize: 12,
                            color: t.isFull
                                ? AppColors.error
                                : AppColors.textSecondary),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Text(
                        'EGP ${t.entryFee.toStringAsFixed(0)} entry',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                            fontSize: 15),
                      ),
                      const Spacer(),
                      if (t.isOpen && !t.isFull)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppColors.primary,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Text('Register',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold)),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
