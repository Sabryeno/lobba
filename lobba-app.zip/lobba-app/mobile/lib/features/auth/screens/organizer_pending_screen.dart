import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/localization/app_localizations.dart';
import '../../../core/navigation/app_router.dart';
import '../../../shared/widgets/padel_button.dart';
import '../providers/locale_provider.dart';

class OrganizerPendingScreen extends ConsumerWidget {
  const OrganizerPendingScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final locale = ref.watch(localeProvider);

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Illustration
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  color: AppColors.primarySurface,
                  shape: BoxShape.circle,
                ),
                child: const Center(
                  child: Text('⏳', style: TextStyle(fontSize: 48)),
                ),
              )
                  .animate()
                  .scale(
                    begin: const Offset(0.7, 0.7),
                    end: const Offset(1, 1),
                    duration: 600.ms,
                    curve: Curves.elasticOut,
                  ),
              const SizedBox(height: 32),
              Text(
                l10n.tr('auth.organizer_pending_title'),
                textAlign: TextAlign.center,
                style: AppTypography.headlineMedium(locale),
              )
                  .animate(delay: 200.ms)
                  .fadeIn(duration: 400.ms),
              const SizedBox(height: 12),
              Text(
                l10n.tr('auth.organizer_pending_body'),
                textAlign: TextAlign.center,
                style: AppTypography.bodyLarge(locale).copyWith(
                  color: AppColors.textSecondary,
                  height: 1.6,
                ),
              )
                  .animate(delay: 300.ms)
                  .fadeIn(duration: 400.ms),
              const SizedBox(height: 48),
              PadelButton(
                label: l10n.tr('common.done'),
                onPressed: () => context.go(AppRoutes.welcome),
                variant: PadelButtonVariant.outlined,
              )
                  .animate(delay: 400.ms)
                  .fadeIn(duration: 400.ms),
            ],
          ),
        ),
      ),
    );
  }
}
