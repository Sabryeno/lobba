import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/localization/app_localizations.dart';
import '../../../core/navigation/app_router.dart';
import '../../../shared/widgets/padel_button.dart';
import '../../../shared/widgets/padel_input.dart';
import '../providers/auth_provider.dart';
import '../providers/locale_provider.dart';

class OrganizerSignupScreen extends ConsumerStatefulWidget {
  const OrganizerSignupScreen({super.key});

  @override
  ConsumerState<OrganizerSignupScreen> createState() =>
      _OrganizerSignupScreenState();
}

class _OrganizerSignupScreenState
    extends ConsumerState<OrganizerSignupScreen> {
  final _phoneController = TextEditingController();
  final _businessNameController = TextEditingController();
  final _contactPersonController = TextEditingController();
  final _commercialRegController = TextEditingController();

  bool _loading = false;
  String? _error;

  static final _egyptPhoneRegex =
      RegExp(r'^\+?20(10|11|12|15)\d{8}$');

  Future<void> _continue() async {
    final phone = _phoneController.text.trim();
    if (!_egyptPhoneRegex.hasMatch(phone)) {
      final l10n = AppLocalizations.of(context);
      setState(() => _error = l10n.tr('auth.phone_error_invalid'));
      return;
    }
    setState(() { _loading = true; _error = null; });
    try {
      final normPhone = phone.startsWith('0')
          ? '+20${phone.substring(1)}'
          : phone.startsWith('+')
              ? phone
              : '+20$phone';

      await ref.read(authStateProvider.notifier).requestOtp(phone: normPhone);
      if (!mounted) return;
      context.push(
        '${AppRoutes.otp}?phone=${Uri.encodeComponent(normPhone)}&flow=organizer',
      );
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _businessNameController.dispose();
    _contactPersonController.dispose();
    _commercialRegController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final locale = ref.watch(localeProvider);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: const BackButton(),
        title: Text(l10n.tr('auth.organizer_signup_title')),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Banner ────────────────────────────────────────────────────
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.primarySurface,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.storefront_rounded,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Text(
                        l10n.tr('auth.organizer_signup_subtitle'),
                        style: AppTypography.bodyMedium(locale).copyWith(
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                  ],
                ),
              )
                  .animate()
                  .fadeIn(duration: 400.ms)
                  .slideY(begin: -0.1, end: 0),
              const SizedBox(height: 32),

              PadelInput(
                controller: _businessNameController,
                label: l10n.tr('auth.business_name_label'),
                hint: 'Cairo Padel Club',
                prefixIcon: Icons.store_outlined,
              ),
              const SizedBox(height: 16),
              PadelInput(
                controller: _contactPersonController,
                label: l10n.tr('auth.contact_person_label'),
                hint: l10n.tr('auth.name_hint'),
                prefixIcon: Icons.person_outline_rounded,
              ),
              const SizedBox(height: 16),
              PadelInput(
                controller: _phoneController,
                label: l10n.tr('auth.phone_label'),
                hint: l10n.tr('auth.phone_hint'),
                keyboardType: TextInputType.phone,
                prefixIcon: Icons.phone_outlined,
                errorText: _error,
                onChanged: (_) => setState(() => _error = null),
              ),
              const SizedBox(height: 16),
              PadelInput(
                controller: _commercialRegController,
                label: l10n.tr('auth.commercial_reg_label'),
                hint: 'CR-XXXXXXXX',
                prefixIcon: Icons.receipt_long_outlined,
              ),

              const SizedBox(height: 12),
              // Admin approval note
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.accentLight.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.accentLight),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.info_outline_rounded,
                      size: 18,
                      color: AppColors.accent,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        l10n.tr('auth.organizer_pending_body'),
                        style: AppTypography.bodyMedium(locale).copyWith(
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 32),
              PadelButton(
                label: l10n.tr('common.next'),
                loading: _loading,
                onPressed: _continue,
              ),
              const SizedBox(height: 24),
            ]
                .animate(interval: 60.ms)
                .fadeIn(duration: 350.ms),
          ),
        ),
      ),
    );
  }
}
