import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/localization/app_localizations.dart';
import '../../../core/navigation/app_router.dart';
import '../../../shared/widgets/padel_button.dart';
import '../../../shared/widgets/padel_input.dart';
import '../providers/auth_provider.dart';
import '../providers/locale_provider.dart';

class PlayerSignupScreen extends ConsumerStatefulWidget {
  const PlayerSignupScreen({super.key});

  @override
  ConsumerState<PlayerSignupScreen> createState() => _PlayerSignupScreenState();
}

class _PlayerSignupScreenState extends ConsumerState<PlayerSignupScreen> {
  final _phoneController = TextEditingController();
  bool _loading = false;
  String? _error;
  bool _useEmail = false;

  static final _egyptPhoneRegex =
      RegExp(r'^\+?20(10|11|12|15)\d{8}$');

  bool get _isPhoneValid =>
      _egyptPhoneRegex.hasMatch(_phoneController.text.trim());

  Future<void> _continue() async {
    if (!_isPhoneValid) {
      final l10n = AppLocalizations.of(context);
      setState(() => _error = l10n.tr('auth.phone_error_invalid'));
      return;
    }
    setState(() { _loading = true; _error = null; });
    try {
      final phone = _normalisePhone(_phoneController.text.trim());
      await ref.read(authStateProvider.notifier).requestOtp(phone: phone);
      if (!mounted) return;
      context.push(
        '${AppRoutes.otp}?phone=${Uri.encodeComponent(phone)}&flow=player',
      );
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _normalisePhone(String raw) {
    if (raw.startsWith('0')) return '+20${raw.substring(1)}';
    if (!raw.startsWith('+')) return '+20$raw';
    return raw;
  }

  // ── Google sign-up/sign-in ────────────────────────────────────────────────
  Future<void> _continueWithGoogle() async {
    setState(() { _loading = true; _error = null; });
    try {
      final result = await ref
          .read(authStateProvider.notifier)
          .signInWithGoogle(flow: 'player');
      if (result == null || !mounted) return; // user cancelled the picker
      context.go(result == OtpVerifyResult.newUser
          ? AppRoutes.playerSetup
          : AppRoutes.home);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final locale = ref.watch(localeProvider);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: const BackButton(),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                l10n.tr('auth.player_signup_title'),
                style: AppTypography.headlineMedium(locale),
              )
                  .animate()
                  .fadeIn(duration: 400.ms)
                  .slideX(begin: -0.08, end: 0),
              const SizedBox(height: 8),
              Text(
                l10n.tr('auth.player_signup_subtitle'),
                style: AppTypography.bodyMedium(locale).copyWith(
                  color: AppColors.textSecondary,
                ),
              )
                  .animate(delay: 80.ms)
                  .fadeIn(duration: 400.ms),
              const SizedBox(height: 40),

              PadelInput(
                controller: _phoneController,
                label: l10n.tr('auth.phone_label'),
                hint: l10n.tr('auth.phone_hint'),
                keyboardType: TextInputType.phone,
                prefixIcon: Icons.phone_outlined,
                errorText: _error,
                onChanged: (_) => setState(() => _error = null),
              )
                  .animate(delay: 150.ms)
                  .fadeIn(duration: 400.ms)
                  .slideY(begin: 0.1, end: 0),

              const SizedBox(height: 32),

              PadelButton(
                label: l10n.tr('common.next'),
                loading: _loading,
                onPressed: _continue,
              )
                  .animate(delay: 200.ms)
                  .fadeIn(duration: 400.ms),

              const SizedBox(height: 20),

              // ── Social login ───────────────────────────────────────────────
              Row(
                children: [
                  const Expanded(child: Divider()),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Text(
                      l10n.tr('common.or'),
                      style: AppTypography.labelSmall(locale),
                    ),
                  ),
                  const Expanded(child: Divider()),
                ],
              ),
              const SizedBox(height: 20),
              PadelButton(
                label: l10n.tr('auth.sign_in_with_google'),
                variant: PadelButtonVariant.outlined,
                prefixIcon: Icons.g_mobiledata_rounded,
                onPressed: _loading ? null : _continueWithGoogle,
              ),
              const SizedBox(height: 24),

              // ── Login link ────────────────────────────────────────────────
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    l10n.tr('auth.already_have_account'),
                    style: AppTypography.bodyMedium(locale),
                  ),
                  TextButton(
                    onPressed: () => context.pop(),
                    child: Text(l10n.tr('auth.login')),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
