import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';

/// Free coach validation: player enters area + city + estimated level; once a
/// city is picked, the app recommends that city's main club (assigned by the
/// Lobba admin / owner) where the coach will validate their level.
class CoachValidateScreen extends StatefulWidget {
  const CoachValidateScreen({super.key});
  @override
  State<CoachValidateScreen> createState() => _CoachValidateScreenState();
}

class _CoachValidateScreenState extends State<CoachValidateScreen> {
  final _area = TextEditingController();
  String? _city;
  int _level = -1;
  bool _sent = false;

  // Main club per city — assigned by the app owner/admin.
  static const _clubByCity = {
    'Cairo': ['Al-Ahly Padel Club', 'New Cairo · 5th Settlement'],
    'Giza': ['Zamalek Sports Club', 'Giza · Sheikh Zayed'],
    'Alexandria': ['Alex Padel Center', 'Alexandria · Smouha'],
    'Maadi': ['Maadi Padel Lounge', 'Maadi · Degla'],
  };
  static const _levels = ['Beginner (D)', 'Improver (C)', 'Intermediate (C+/B)', 'Advanced (A)'];

  @override
  void dispose() { _area.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final club = _city != null ? _clubByCity[_city] : null;
    final canSend = _city != null && _level != -1;

    if (_sent) {
      return PushScaffold(title: 'Validation booked', child: Center(child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 84, height: 84, decoration: BoxDecoration(color: t.accentSoft, shape: BoxShape.circle, border: Border.all(color: t.accent, width: 2)), child: Icon(Icons.check_rounded, size: 40, color: t.accent)),
          const SizedBox(height: 18),
          Text('Request sent', style: TextStyle(fontFamily: kSerif, fontSize: 22, fontWeight: FontWeight.w500, color: t.ink)),
          const SizedBox(height: 8),
          Text('The coach at ${club![0]} will contact you to schedule your free level validation.', textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: t.ink2, height: 1.5)),
          const SizedBox(height: 22),
          SizedBox(height: 50, width: double.infinity, child: ElevatedButton(onPressed: () => context.pop(), style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: const Text('Done', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)))),
        ]),
      )));
    }

    return PushScaffold(
      title: 'Validate with a coach',
      subtitle: 'Free level check',
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: canSend ? () => setState(() => _sent = true) : null,
          style: ElevatedButton.styleFrom(backgroundColor: canSend ? t.accent : t.surface2, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: const Text('Request free validation', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        const Eyebrow('Your area'),
        const SizedBox(height: 8),
        TextField(controller: _area, style: TextStyle(color: t.ink, fontSize: 14), decoration: InputDecoration(hintText: 'e.g. 5th Settlement, New Cairo', hintStyle: TextStyle(color: t.ink3), filled: true, fillColor: t.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.accent, width: 1.5)))),
        const SizedBox(height: 16),
        const Eyebrow('City'),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: _clubByCity.keys.map((c) {
          final on = _city == c;
          return GestureDetector(onTap: () => setState(() => _city = c), child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
            decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(99), border: Border.all(color: on ? t.accent : t.line)),
            child: Text(c, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: on ? t.onAccent : t.ink2)),
          ));
        }).toList()),
        const SizedBox(height: 16),
        const Eyebrow('Your estimated level'),
        const SizedBox(height: 8),
        ...List.generate(_levels.length, (i) => Padding(padding: const EdgeInsets.only(bottom: 8), child: GestureDetector(
          onTap: () => setState(() => _level = i),
          child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: _level == i ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _level == i ? t.accent : t.line, width: _level == i ? 1.5 : 1)),
            child: Row(children: [
              Icon(_level == i ? Icons.radio_button_checked : Icons.radio_button_off, size: 18, color: _level == i ? t.accent : t.ink3),
              const SizedBox(width: 11),
              Text(_levels[i], style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: _level == i ? t.accent : t.ink)),
            ]),
          ),
        ))),
        // recommended club appears once a city is chosen
        if (club != null) ...[
          const SizedBox(height: 10),
          const Eyebrow('Recommended club'),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.accent)),
            child: Row(children: [
              Container(width: 46, height: 46, decoration: BoxDecoration(gradient: LinearGradient(colors: [t.accentSoft, t.surface2]), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.stadium_outlined, color: t.accent, size: 22)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(club[0], style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
                const SizedBox(height: 2),
                Text(club[1], style: TextStyle(fontSize: 10.5, color: t.ink3)),
              ])),
              LPill('Partner club', bg: t.accentSoft, fg: t.accent),
            ]),
          ),
          const SizedBox(height: 6),
          Text('Assigned by Lobba for $_city — the coach here runs your free validation.', style: TextStyle(fontSize: 9.5, color: t.ink3)),
        ],
      ]),
    );
  }
}
