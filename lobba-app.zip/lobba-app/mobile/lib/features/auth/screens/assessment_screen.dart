import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../../core/level/lobba_level.dart';
import '../providers/level_provider.dart';

class AssessmentScreen extends ConsumerStatefulWidget {
  const AssessmentScreen({super.key});
  @override
  ConsumerState<AssessmentScreen> createState() => _AssessmentScreenState();
}

class _AssessmentScreenState extends ConsumerState<AssessmentScreen> {
  int _stage = 0; // 0 intro, 1..10 questions, 11 result
  final _answers = <int>{};
  final _picks = <int, int>{}; // question stage → chosen option index (0–3)
  int _sel = -1;

  /// Map the 10 answers (each 0–3) onto a 0–7 level, rounded to the nearest 0.5.
  double get _level {
    final sum = _picks.values.fold<int>(0, (a, b) => a + b); // 0–30
    final raw = (sum / 30.0) * 7.0;
    return (raw * 2).round() / 2.0;
  }

  static const _questions = <List<dynamic>>[
    ['EXPERIENCE', 'How often do you play padel?', ['First time', 'A few times a year', 'Weekly', 'Several times a week']],
    ['BACKGROUND', 'Have you played racket sports before?', ['Never', 'Tennis / squash casually', 'Competitively', 'I coach / played pro']],
    ['SERVE', 'How is your underhand serve?', ['Still learning', 'Gets it in', 'Consistent & placed', 'I add spin & variation']],
    ['WALL PLAY', 'Can you play balls off the back glass?', ['Not yet', 'Sometimes', 'Reliably', 'Off side walls too']],
    ['VOLLEY', 'How comfortable are you at the net?', ['Avoid it', 'Basic volleys', 'Strong volleys', 'I finish points there']],
    ['SMASH', 'Your overhead / smash?', ['Rarely attempt', 'Flat smash', 'Placed smash', 'Bandeja & víbora']],
    ['POSITIONING', 'Do you move as a pair with your partner?', ['Not really', 'Learning it', 'Usually', 'Always in sync']],
    ['MATCHES', 'How many matches per month?', ['0–1', '2–4', '5–8', '9+']],
    ['STRATEGY', 'Do you plan points (lob, attack the net)?', ['No', 'A little', 'Often', 'Every point']],
    ['SELF-RATING', 'Where would you place yourself?', ['Beginner (D)', 'Improver (C)', 'Intermediate (C+/B)', 'Advanced (A)']],
  ];

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    if (_stage == 0) return _intro(t);
    if (_stage == 11) return _result(t);
    return _question(t);
  }

  Widget _intro(LobbaTokens t) => Scaffold(
        backgroundColor: t.bg,
        body: SafeArea(child: Column(children: [
          const Spacer(),
          Container(width: 96, height: 96, decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(28)), child: Icon(Icons.emoji_events_outlined, size: 44, color: t.accent)),
          const SizedBox(height: 24),
          Text('Find your level'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 25, fontWeight: FontWeight.w500, color: t.ink)),
          const SizedBox(height: 10),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 40), child: Text('Answer 10 quick questions so we can set your starting level and match you fairly.'.tr(context), textAlign: TextAlign.center, style: TextStyle(fontSize: 13.5, color: t.ink2, height: 1.6))),
          const Spacer(),
          Padding(padding: const EdgeInsets.fromLTRB(24, 0, 24, 28), child: Column(children: [
            SizedBox(height: 52, width: double.infinity, child: ElevatedButton(onPressed: () => setState(() => _stage = 1), style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: Text('Start assessment'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)))),
            const SizedBox(height: 12),
            GestureDetector(onTap: () => context.go(AppRoutes.home), child: Text('Skip — I’m new to padel'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink3))),
          ])),
        ])),
      );

  Widget _question(LobbaTokens t) {
    final q = _questions[_stage - 1];
    final opts = q[2] as List<String>;
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(22, 12, 22, 0), child: Row(children: [
          GestureDetector(onTap: () => setState(() { _stage--; _sel = _answers.contains(_stage) ? 0 : -1; }), child: Icon(Icons.chevron_left_rounded, color: t.ink2, size: 24)),
          const SizedBox(width: 12),
          Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(3), child: LinearProgressIndicator(value: _stage / 10, minHeight: 6, backgroundColor: t.surface2, color: t.accent))),
          const SizedBox(width: 12),
          Text('$_stage/10', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.ink3)),
        ])),
        Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(24, 26, 24, 0), children: [
          Text((q[0] as String).tr(context), style: TextStyle(fontSize: 10.5, letterSpacing: 1.6, color: t.ink3)),
          const SizedBox(height: 10),
          Text((q[1] as String).tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 22, fontWeight: FontWeight.w500, color: t.ink, height: 1.25)),
          const SizedBox(height: 24),
          ...List.generate(opts.length, (i) => Padding(padding: const EdgeInsets.only(bottom: 11), child: GestureDetector(
            onTap: () => setState(() => _sel = i),
            child: Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(color: _sel == i ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: _sel == i ? t.accent : t.line, width: _sel == i ? 1.5 : 1)),
              child: Row(children: [
                Container(width: 20, height: 20, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: _sel == i ? t.accent : t.line, width: 2)), child: _sel == i ? Center(child: Container(width: 9, height: 9, decoration: BoxDecoration(color: t.accent, shape: BoxShape.circle))) : null),
                const SizedBox(width: 12),
                Expanded(child: Text(opts[i].tr(context), style: TextStyle(fontSize: 13.5, fontWeight: _sel == i ? FontWeight.w600 : FontWeight.w500, color: _sel == i ? t.accent : t.ink))),
              ]),
            ),
          ))),
        ])),
        Padding(padding: const EdgeInsets.fromLTRB(24, 0, 24, 28), child: SizedBox(height: 52, width: double.infinity, child: ElevatedButton(
          onPressed: _sel == -1 ? null : () {
            _picks[_stage] = _sel;
            if (_stage >= 10) {
              ref.read(playerLevelProvider.notifier).setFromAssessment(_level);
              setState(() => _stage = 11);
            } else {
              setState(() { _answers.add(_stage); _stage++; _sel = -1; });
            }
          },
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text((_stage >= 10 ? 'See my result' : 'Next question').tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        ))),
      ])),
    );
  }

  Widget _result(LobbaTokens t) => Scaffold(
        backgroundColor: t.bg,
        body: SafeArea(child: Column(children: [
          const Spacer(),
          Text('YOUR STARTING LEVEL'.tr(context), style: TextStyle(fontSize: 10.5, letterSpacing: 1.6, color: t.ink3)),
          const SizedBox(height: 18),
          Container(width: 130, height: 130, decoration: BoxDecoration(color: t.accentSoft, shape: BoxShape.circle, border: Border.all(color: t.accent, width: 2)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(_level.toStringAsFixed(1), style: TextStyle(fontFamily: kSerif, fontSize: 44, fontWeight: FontWeight.w600, color: t.accent, height: 1)),
            Text('Level'.tr(context), style: TextStyle(fontSize: 11, color: t.accent)),
          ])),
          const SizedBox(height: 22),
          Text(bandName(context, _level), style: TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w500, color: t.ink)),
          const SizedBox(height: 8),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 40), child: Text('You’ll be matched with players around your level. Win games to climb the ladder.'.tr(context), textAlign: TextAlign.center, style: TextStyle(fontSize: 13.5, color: t.ink2, height: 1.6))),
          const Spacer(),
          Padding(padding: const EdgeInsets.fromLTRB(24, 0, 24, 28), child: Column(children: [
            // validate with a coach — free
            GestureDetector(
              onTap: () => context.push(AppRoutes.coachValidate),
              child: Container(
                width: double.infinity, padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(14)),
                child: Row(children: [
                  Icon(Icons.verified_outlined, color: t.accent, size: 20),
                  const SizedBox(width: 11),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Validate your level with a coach — free'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.accent)),
                    Text('A partner coach confirms your grade on court'.tr(context), style: TextStyle(fontSize: 10, color: t.ink2)),
                  ])),
                  Icon(Icons.chevron_right_rounded, color: t.accent),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(height: 52, width: double.infinity, child: ElevatedButton(onPressed: () => context.go(AppRoutes.home), style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: Text('Enter Lobba'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)))),
          ])),
        ])),
      );
}
