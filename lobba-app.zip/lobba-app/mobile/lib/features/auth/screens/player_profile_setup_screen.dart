import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/localization/app_localizations.dart';
import '../../../core/navigation/app_router.dart';
import '../../../shared/widgets/padel_button.dart';
import '../../../shared/widgets/padel_input.dart';
import '../providers/auth_provider.dart';
import '../providers/locale_provider.dart';

// ── Static data ───────────────────────────────────────────────────────────────

const _egyptCities = [
  'Cairo', 'Giza', 'Alexandria', 'Luxor', 'Aswan', 'Hurghada',
  'Sharm El-Sheikh', 'Mansoura', 'Tanta', 'Zagazig', 'Ismailia',
  'Suez', 'Port Said', 'Damietta', 'Minya', 'Asyut',
];

// ── Quiz definition ───────────────────────────────────────────────────────────

class _QuizQuestion {
  final String question;
  final List<String> options;
  final int correctIndex;
  final String explanation;

  const _QuizQuestion({
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.explanation,
  });
}

const _quizQuestions = [
  _QuizQuestion(
    question: 'In padel, how must the serve be delivered?',
    options: [
      'Overhead, like in tennis',
      'Underarm — ball bounced once on ground, hit at or below waist height',
      'Any style, as long as it lands in the service box',
      'Overarm, ball tossed into the air',
    ],
    correctIndex: 1,
    explanation:
        'The padel serve must be underarm: drop the ball, let it bounce once, then strike it at or below waist level diagonally into the service box.',
  ),
  _QuizQuestion(
    question:
        'The ball crosses the net and hits the back glass WITHOUT bouncing on your side of the floor first. What is the call?',
    options: [
      'OUT — the receiving team wins the point',
      'IN — the glass is always in play',
      'Let — the point is replayed',
      'It depends on which glass panel it hit',
    ],
    correctIndex: 0,
    explanation:
        'If the ball hits the glass before touching the floor on the receiver\'s side, it is OUT. The ball must bounce on the floor before touching the glass to remain in play.',
  ),
  _QuizQuestion(
    question:
        'The ball bounces on your side of the court and then hits the back glass. What do you do?',
    options: [
      'Play it — you can still hit the ball off the glass',
      'Stop — the point is over once it hits the glass',
      'Only play it if it bounces back off the glass',
      'Call a let — it\'s not clear',
    ],
    correctIndex: 0,
    explanation:
        'Once the ball bounces on the floor, any contact with the side or back glass walls is perfectly in play. You can continue the rally by playing the ball off the glass.',
  ),
  _QuizQuestion(
    question:
        'The ball exits the court through an open door or gap in the fence. What happens?',
    options: [
      'A player may exit the court to continue playing the ball',
      'The point is immediately lost — the ball left the court',
      'The point is replayed',
      'The serve is replayed only if it\'s the first shot',
    ],
    correctIndex: 0,
    explanation:
        'Players are allowed to exit through the gate to play a ball that has left the court, as long as it has not bounced twice and the player can reach it in time.',
  ),
  _QuizQuestion(
    question:
        'During a serve, the ball clips the net and lands correctly in the service box. What\'s the call?',
    options: [
      'A let — the serve is replayed',
      'Point to the receiver — the serve is lost',
      'A fault — the server gets a second serve',
      'The serve is valid — play continues',
    ],
    correctIndex: 0,
    explanation:
        'A serve that clips the net and still lands in the correct service box is called a let. The serve is replayed with no penalty — same serve, same service box.',
  ),
];

// ── Level helpers ─────────────────────────────────────────────────────────────

String _levelLabel(int level) => switch (level) {
      1 => 'Beginner',
      2 => 'Novice',
      3 => 'Casual',
      4 => 'Intermediate',
      5 => 'Advanced',
      6 => 'Pro',
      7 => 'Elite',
      _ => 'Beginner',
    };

String _levelGrade(int level) => switch (level) {
      1 => 'D',
      2 => 'D+',
      3 => 'C',
      4 => 'C+',
      5 => 'B',
      6 => 'A-',
      7 => 'A+',
      _ => 'D',
    };

Color _levelColor(int level) {
  if (level >= 6) return const Color(0xFF7C3AED); // purple — elite/pro
  if (level >= 4) return AppColors.accent;          // green — mid+
  return AppColors.primary;                          // teal — beginner
}

// ── Main widget ───────────────────────────────────────────────────────────────

class PlayerProfileSetupScreen extends ConsumerStatefulWidget {
  const PlayerProfileSetupScreen({super.key});

  @override
  ConsumerState<PlayerProfileSetupScreen> createState() =>
      _PlayerProfileSetupScreenState();
}

class _PlayerProfileSetupScreenState
    extends ConsumerState<PlayerProfileSetupScreen>
    with SingleTickerProviderStateMixin {
  // Wizard
  final _pageController = PageController();
  int _page = 0; // 0=Name/City, 1=Side, 2=Style, 3=Quiz, 4=Results

  // Step 0 — Name & City
  final _nameController = TextEditingController();
  String? _selectedCity;

  // Step 1 — Preferred side
  String? _preferredSide; // 'left' | 'right'

  // Step 2 — Play style + years
  String? _playStyle;     // 'friendly' | 'competitive' | 'both'
  String? _yearsPlaying;  // '0' | '<1' | '1-2' | '3-5' | '5+'

  // Step 3 — Quiz
  int _quizIndex = 0;
  final List<int?> _quizAnswers = List.filled(5, null);
  bool _showFeedback = false;

  // Step 4 — Results / submit
  bool _loading = false;
  bool _submitted = false;

  // ── Computed ───────────────────────────────────────────────────────────────

  int get _quizScore =>
      _quizAnswers.asMap().entries.where((e) {
        final ans = e.value;
        return ans != null && ans == _quizQuestions[e.key].correctIndex;
      }).length;

  int get _assignedLevel {
    final yearsBonus = switch (_yearsPlaying) {
      '1-2' => 1,
      '3-5' => 2,
      '5+'  => 3,
      _     => 0,
    };
    final styleBonus = _playStyle == 'competitive' ? 1 : 0;
    return (_quizScore + yearsBonus + styleBonus).clamp(1, 7);
  }

  // ── Navigation ─────────────────────────────────────────────────────────────

  void _nextPage() {
    if (_page < 4) {
      setState(() => _page = _page + 1);
      _pageController.animateToPage(
        _page,
        duration: 350.ms,
        curve: Curves.easeInOut,
      );
    }
  }

  void _prevPage() {
    if (_page > 0) {
      setState(() => _page = _page - 1);
      _pageController.animateToPage(
        _page,
        duration: 350.ms,
        curve: Curves.easeInOut,
      );
    } else if (_page == 3 && _quizIndex > 0) {
      setState(() => _quizIndex--);
    }
  }

  // ── Quiz answer ────────────────────────────────────────────────────────────

  void _answerQuiz(int answerIndex) {
    if (_quizAnswers[_quizIndex] != null || _showFeedback) return;
    setState(() {
      _quizAnswers[_quizIndex] = answerIndex;
      _showFeedback = true;
    });
    // Auto-advance after 900 ms
    Future.delayed(900.ms, () {
      if (!mounted) return;
      setState(() => _showFeedback = false);
      if (_quizIndex < 4) {
        setState(() => _quizIndex++);
      } else {
        _nextPage(); // All 5 done — go to results
      }
    });
  }

  // ── Submit ─────────────────────────────────────────────────────────────────

  Future<void> _submit() async {
    if (_submitted || _loading) return;
    setState(() => _loading = true);
    try {
      await ref.read(authStateProvider.notifier).completePlayerSetup(
            name: _nameController.text.trim(),
            city: _selectedCity!,
            skillLevel: _assignedLevel,
            preferredSide: _preferredSide,
            playStyle: _playStyle,
            yearsPlaying: _yearsPlaying,
            padelIqScore: _quizScore,
          );
      if (!mounted) return;
      setState(() => _submitted = true);
      await Future.delayed(400.ms);
      if (mounted) context.go(AppRoutes.home);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: AppColors.error),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final locale = ref.watch(localeProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _WizardHeader(page: _page, onBack: _page > 0 ? _prevPage : null),
            _StepProgress(current: _page, total: 5),
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _NameCityStep(
                    nameController: _nameController,
                    selectedCity: _selectedCity,
                    onCityChanged: (c) => setState(() => _selectedCity = c),
                    onNext: _nameController.text.trim().isNotEmpty &&
                            _selectedCity != null
                        ? _nextPage
                        : null,
                    locale: locale,
                  ),
                  _SideStep(
                    selected: _preferredSide,
                    onSelect: (s) {
                      setState(() => _preferredSide = s);
                      Future.delayed(200.ms, _nextPage);
                    },
                    onBack: _prevPage,
                    locale: locale,
                  ),
                  _StyleStep(
                    playStyle: _playStyle,
                    yearsPlaying: _yearsPlaying,
                    onStyleChanged: (s) => setState(() => _playStyle = s),
                    onYearsChanged: (y) => setState(() => _yearsPlaying = y),
                    onNext: _playStyle != null && _yearsPlaying != null
                        ? _nextPage
                        : null,
                    onBack: _prevPage,
                    locale: locale,
                  ),
                  _QuizStep(
                    questions: _quizQuestions,
                    quizIndex: _quizIndex,
                    answers: _quizAnswers,
                    showFeedback: _showFeedback,
                    onAnswer: _answerQuiz,
                    locale: locale,
                  ),
                  _ResultsStep(
                    score: _quizScore,
                    level: _assignedLevel,
                    preferredSide: _preferredSide,
                    playStyle: _playStyle,
                    yearsPlaying: _yearsPlaying,
                    loading: _loading,
                    onSubmit: _submit,
                    locale: locale,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Wizard header ─────────────────────────────────────────────────────────────

class _WizardHeader extends StatelessWidget {
  final int page;
  final VoidCallback? onBack;

  const _WizardHeader({required this.page, this.onBack});

  static const _titles = [
    'About You',
    'Court Side',
    'Play Style',
    'Padel IQ',
    'Your Profile',
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
            onPressed: onBack ?? () {},
            color: onBack != null ? AppColors.textPrimary : Colors.transparent,
          ),
          Expanded(
            child: Text(
              _titles[page],
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          const SizedBox(width: 48), // balance the back button
        ],
      ),
    );
  }
}

// ── Step progress dots ────────────────────────────────────────────────────────

class _StepProgress extends StatelessWidget {
  final int current;
  final int total;

  const _StepProgress({required this.current, required this.total});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(total, (i) {
          final active = i == current;
          final done = i < current;
          return AnimatedContainer(
            duration: 250.ms,
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: active ? 24 : 8,
            height: 8,
            decoration: BoxDecoration(
              color: done
                  ? AppColors.primary
                  : active
                      ? AppColors.accent
                      : AppColors.primarySurface,
              borderRadius: BorderRadius.circular(4),
            ),
          );
        }),
      ),
    );
  }
}

// ── Step 0: Name & City ───────────────────────────────────────────────────────

class _NameCityStep extends StatefulWidget {
  final TextEditingController nameController;
  final String? selectedCity;
  final ValueChanged<String?> onCityChanged;
  final VoidCallback? onNext;
  final Locale locale;

  const _NameCityStep({
    required this.nameController,
    required this.selectedCity,
    required this.onCityChanged,
    required this.onNext,
    required this.locale,
  });

  @override
  State<_NameCityStep> createState() => _NameCityStepState();
}

class _NameCityStepState extends State<_NameCityStep> {
  @override
  void initState() {
    super.initState();
    widget.nameController.addListener(() => setState(() {}));
  }

  @override
  Widget build(BuildContext context) {
    final canNext = widget.nameController.text.trim().isNotEmpty &&
        widget.selectedCity != null;

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          Text(
            "Let's set up your\npadel profile",
            style: AppTypography.headlineMedium(widget.locale),
          ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.1),
          const SizedBox(height: 8),
          Text(
            'A few quick steps to match you with the right players.',
            style: AppTypography.bodyMedium(widget.locale).copyWith(
              color: AppColors.textMuted,
            ),
          ).animate().fadeIn(delay: 150.ms, duration: 400.ms),
          const SizedBox(height: 32),

          PadelInput(
            controller: widget.nameController,
            label: 'Full Name',
            hint: 'e.g. Ahmed Hassan',
            prefixIcon: Icons.person_outline_rounded,
          ).animate().fadeIn(delay: 200.ms, duration: 400.ms),
          const SizedBox(height: 16),

          DropdownButtonFormField<String>(
            value: widget.selectedCity,
            hint: const Text('Select your city'),
            items: _egyptCities
                .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                .toList(),
            onChanged: widget.onCityChanged,
            decoration: const InputDecoration(
              labelText: 'City',
              prefixIcon: Icon(Icons.location_city_outlined),
            ),
          ).animate().fadeIn(delay: 300.ms, duration: 400.ms),

          const SizedBox(height: 40),
          PadelButton(
            label: 'Continue',
            onPressed: canNext ? widget.onNext : null,
            prefixIcon: Icons.arrow_forward_rounded,
          ).animate().fadeIn(delay: 400.ms, duration: 400.ms),
        ],
      ),
    );
  }
}

// ── Step 1: Preferred court side ──────────────────────────────────────────────

class _SideStep extends StatelessWidget {
  final String? selected;
  final ValueChanged<String> onSelect;
  final VoidCallback onBack;
  final Locale locale;

  const _SideStep({
    required this.selected,
    required this.onSelect,
    required this.onBack,
    required this.locale,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Which side do you\nprefer to play?',
            style: AppTypography.headlineMedium(locale),
          ).animate().fadeIn(duration: 350.ms),
          const SizedBox(height: 8),
          Text(
            'In padel, the court is split into left and right halves. Most players have a dominant side.',
            style: AppTypography.bodyMedium(locale)
                .copyWith(color: AppColors.textMuted),
          ).animate().fadeIn(delay: 100.ms),
          const SizedBox(height: 28),

          // Court diagram
          _CourtSideDiagram(selected: selected).animate().fadeIn(delay: 150.ms),
          const SizedBox(height: 24),

          // Left / Right cards
          Row(
            children: [
              Expanded(
                child: _SideCard(
                  label: 'Left',
                  icon: Icons.west_rounded,
                  subtitle: 'Backhand side\n(for right-handers)',
                  selected: selected == 'left',
                  onTap: () => onSelect('left'),
                ).animate().fadeIn(delay: 200.ms).slideX(begin: -0.1),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SideCard(
                  label: 'Right',
                  icon: Icons.east_rounded,
                  subtitle: 'Forehand side\n(for right-handers)',
                  selected: selected == 'right',
                  onTap: () => onSelect('right'),
                ).animate().fadeIn(delay: 280.ms).slideX(begin: 0.1),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (selected == null)
            Center(
              child: Text(
                'Tap a side to continue',
                style: AppTypography.labelSmall(locale)
                    .copyWith(color: AppColors.textMuted),
              ),
            ),
        ],
      ),
    );
  }
}

class _SideCard extends StatelessWidget {
  final String label;
  final IconData icon;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;

  const _SideCard({
    required this.label,
    required this.icon,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: 200.ms,
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.border,
            width: selected ? 2 : 1,
          ),
          boxShadow: selected
              ? [BoxShadow(color: AppColors.primary.withOpacity(0.25), blurRadius: 12, offset: const Offset(0, 4))]
              : [],
        ),
        child: Column(
          children: [
            Icon(icon,
                size: 32, color: selected ? Colors.white : AppColors.textMuted),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: selected ? Colors.white : AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                color: selected
                    ? Colors.white.withOpacity(0.85)
                    : AppColors.textMuted,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Minimal top-down court diagram highlighting left/right half
class _CourtSideDiagram extends StatelessWidget {
  final String? selected;

  const _CourtSideDiagram({this.selected});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 130,
      decoration: BoxDecoration(
        color: const Color(0xFF1A5276),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white24),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(11),
        child: Row(
          children: [
            // Left half
            Expanded(
              child: AnimatedContainer(
                duration: 250.ms,
                color: selected == 'left'
                    ? AppColors.primary.withOpacity(0.6)
                    : Colors.transparent,
                child: Center(
                  child: Text(
                    'LEFT',
                    style: TextStyle(
                      color: selected == 'left'
                          ? Colors.white
                          : Colors.white38,
                      fontWeight: FontWeight.w800,
                      fontSize: 13,
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ),
            ),
            // Centre net line
            Container(width: 2, color: Colors.white30),
            // Right half
            Expanded(
              child: AnimatedContainer(
                duration: 250.ms,
                color: selected == 'right'
                    ? AppColors.accent.withOpacity(0.55)
                    : Colors.transparent,
                child: Center(
                  child: Text(
                    'RIGHT',
                    style: TextStyle(
                      color: selected == 'right'
                          ? Colors.white
                          : Colors.white38,
                      fontWeight: FontWeight.w800,
                      fontSize: 13,
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Step 2: Play style + years ────────────────────────────────────────────────

class _StyleStep extends StatelessWidget {
  final String? playStyle;
  final String? yearsPlaying;
  final ValueChanged<String> onStyleChanged;
  final ValueChanged<String> onYearsChanged;
  final VoidCallback? onNext;
  final VoidCallback onBack;
  final Locale locale;

  const _StyleStep({
    required this.playStyle,
    required this.yearsPlaying,
    required this.onStyleChanged,
    required this.onYearsChanged,
    required this.onNext,
    required this.onBack,
    required this.locale,
  });

  @override
  Widget build(BuildContext context) {
    final styles = [
      ('friendly', '🎉', 'Friendly'),
      ('competitive', '⚔️', 'Competitive'),
      ('both', '🤝', 'Both'),
    ];

    final years = [
      ('0', 'Just started'),
      ('<1', '< 1 year'),
      ('1-2', '1 – 2 years'),
      ('3-5', '3 – 5 years'),
      ('5+', '5+ years'),
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'How do you play?',
            style: AppTypography.headlineMedium(locale),
          ).animate().fadeIn(duration: 350.ms),
          const SizedBox(height: 24),

          // Play style
          Text('Play preference',
              style: AppTypography.titleMedium(locale)
                  .copyWith(color: AppColors.textMuted)),
          const SizedBox(height: 10),
          Row(
            children: styles.map((s) {
              final isSelected = playStyle == s.$1;
              return Expanded(
                child: GestureDetector(
                  onTap: () => onStyleChanged(s.$1),
                  child: AnimatedContainer(
                    duration: 200.ms,
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color:
                          isSelected ? AppColors.primary : AppColors.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected
                            ? AppColors.primary
                            : AppColors.border,
                      ),
                    ),
                    child: Column(
                      children: [
                        Text(s.$2, style: const TextStyle(fontSize: 22)),
                        const SizedBox(height: 4),
                        Text(
                          s.$3,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: isSelected
                                ? Colors.white
                                : AppColors.textPrimary,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 28),

          // Years playing
          Text('Years playing padel',
              style: AppTypography.titleMedium(locale)
                  .copyWith(color: AppColors.textMuted)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: years.map((y) {
              final isSelected = yearsPlaying == y.$1;
              return GestureDetector(
                onTap: () => onYearsChanged(y.$1),
                child: AnimatedContainer(
                  duration: 200.ms,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.accent : AppColors.surface,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        color: isSelected
                            ? AppColors.accent
                            : AppColors.border),
                  ),
                  child: Text(
                    y.$2,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: isSelected ? Colors.white : AppColors.textPrimary,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 40),
          PadelButton(
            label: 'Take the Padel IQ Quiz',
            onPressed: onNext,
            prefixIcon: Icons.quiz_outlined,
          ).animate().fadeIn(delay: 200.ms),
        ],
      ),
    );
  }
}

// ── Step 3: Padel IQ Quiz ─────────────────────────────────────────────────────

class _QuizStep extends StatelessWidget {
  final List<_QuizQuestion> questions;
  final int quizIndex;
  final List<int?> answers;
  final bool showFeedback;
  final ValueChanged<int> onAnswer;
  final Locale locale;

  const _QuizStep({
    required this.questions,
    required this.quizIndex,
    required this.answers,
    required this.showFeedback,
    required this.onAnswer,
    required this.locale,
  });

  @override
  Widget build(BuildContext context) {
    final q = questions[quizIndex];
    final userAnswer = answers[quizIndex];
    final answered = userAnswer != null;

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Progress
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Question ${quizIndex + 1} of ${questions.length}',
                style: AppTypography.labelSmall(locale)
                    .copyWith(color: AppColors.textMuted),
              ),
              Text(
                '${answers.where((a) => a != null).length} answered',
                style: AppTypography.labelSmall(locale)
                    .copyWith(color: AppColors.accent),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Quiz progress bar
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: (quizIndex + (answered ? 1 : 0)) / questions.length,
              minHeight: 4,
              backgroundColor: AppColors.primarySurface,
              valueColor: AlwaysStoppedAnimation<Color>(AppColors.accent),
            ),
          ),
          const SizedBox(height: 20),

          // Question card
          AnimatedSwitcher(
            duration: 300.ms,
            child: Container(
              key: ValueKey(quizIndex),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // IQ icon
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: AppColors.accent.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(Icons.lightbulb_outline_rounded,
                            color: AppColors.accent, size: 18),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Padel IQ',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: AppColors.accent,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Text(
                    q.question,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Answer options
          AnimatedSwitcher(
            duration: 250.ms,
            child: Column(
              key: ValueKey('options_$quizIndex'),
              children: List.generate(q.options.length, (i) {
                final isUserAnswer = userAnswer == i;
                final isCorrect = i == q.correctIndex;
                Color optionColor = AppColors.surface;
                Color borderColor = AppColors.border;
                Color textColor = AppColors.textPrimary;
                Widget? trailingIcon;

                if (answered) {
                  if (isUserAnswer && isCorrect) {
                    optionColor = const Color(0xFF16A34A).withOpacity(0.15);
                    borderColor = const Color(0xFF16A34A);
                    textColor = const Color(0xFF16A34A);
                    trailingIcon = const Icon(Icons.check_circle_rounded,
                        color: Color(0xFF16A34A), size: 20);
                  } else if (isUserAnswer && !isCorrect) {
                    optionColor = AppColors.error.withOpacity(0.12);
                    borderColor = AppColors.error;
                    textColor = AppColors.error;
                    trailingIcon = const Icon(Icons.cancel_rounded,
                        color: AppColors.error, size: 20);
                  } else if (!isUserAnswer && isCorrect) {
                    // Show the correct answer in green
                    optionColor = const Color(0xFF16A34A).withOpacity(0.08);
                    borderColor = const Color(0xFF16A34A);
                    textColor = const Color(0xFF16A34A);
                    trailingIcon = const Icon(Icons.check_circle_outline_rounded,
                        color: Color(0xFF16A34A), size: 20);
                  }
                }

                return GestureDetector(
                  onTap: answered ? null : () => onAnswer(i),
                  child: AnimatedContainer(
                    duration: 200.ms,
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: optionColor,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderColor),
                    ),
                    child: Row(
                      children: [
                        // Letter badge
                        Container(
                          width: 26,
                          height: 26,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: borderColor.withOpacity(0.15),
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            String.fromCharCode(65 + i), // A, B, C, D
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: answered ? borderColor : AppColors.textMuted,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            q.options[i],
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: textColor,
                              height: 1.35,
                            ),
                          ),
                        ),
                        if (trailingIcon != null) ...[
                          const SizedBox(width: 8),
                          trailingIcon,
                        ],
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),

          // Explanation (shown after answering)
          if (answered) ...[
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.primarySurface,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: AppColors.primary, size: 18),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      q.explanation,
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.primary,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ).animate().fadeIn(duration: 300.ms).slideY(begin: 0.05),
          ],
        ],
      ),
    );
  }
}

// ── Step 4: Results ───────────────────────────────────────────────────────────

class _ResultsStep extends StatelessWidget {
  final int score;
  final int level;
  final String? preferredSide;
  final String? playStyle;
  final String? yearsPlaying;
  final bool loading;
  final VoidCallback onSubmit;
  final Locale locale;

  const _ResultsStep({
    required this.score,
    required this.level,
    required this.preferredSide,
    required this.playStyle,
    required this.yearsPlaying,
    required this.loading,
    required this.onSubmit,
    required this.locale,
  });

  @override
  Widget build(BuildContext context) {
    final levelColor = _levelColor(level);

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Column(
        children: [
          // IQ Score ring
          _IqScoreRing(score: score, total: 5)
              .animate()
              .scale(
                  begin: const Offset(0.5, 0.5),
                  duration: 600.ms,
                  curve: Curves.elasticOut),
          const SizedBox(height: 24),

          // Level badge
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
            decoration: BoxDecoration(
              color: levelColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(40),
              border: Border.all(color: levelColor, width: 1.5),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.sports_tennis_rounded,
                    color: levelColor, size: 22),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Your Level',
                      style: TextStyle(
                          fontSize: 11,
                          color: levelColor.withOpacity(0.8),
                          fontWeight: FontWeight.w600),
                    ),
                    Text(
                      '${_levelLabel(level)}  ·  ${_levelGrade(level)}',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: levelColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ).animate().fadeIn(delay: 400.ms, duration: 400.ms),
          const SizedBox(height: 28),

          // Preferences summary
          _SummaryCard(
            items: [
              ('Court side', _sideName(preferredSide), Icons.compare_arrows_rounded),
              ('Play style', _styleName(playStyle), Icons.emoji_events_outlined),
              ('Experience', _yearsName(yearsPlaying), Icons.calendar_today_outlined),
              ('IQ score', '$score / 5 correct', Icons.lightbulb_outline_rounded),
            ],
          ).animate().fadeIn(delay: 500.ms, duration: 400.ms),
          const SizedBox(height: 32),

          PadelButton(
            label: "Let's Play! 🎾",
            loading: loading,
            onPressed: onSubmit,
          ).animate().fadeIn(delay: 600.ms, duration: 400.ms),
          const SizedBox(height: 16),
          Text(
            'Your level is calculated from your quiz performance,\nyears of experience, and playing style.',
            textAlign: TextAlign.center,
            style: AppTypography.labelSmall(locale)
                .copyWith(color: AppColors.textMuted),
          ).animate().fadeIn(delay: 700.ms),
        ],
      ),
    );
  }

  String _sideName(String? s) => switch (s) {
        'left' => 'Left (Backhand)',
        'right' => 'Right (Forehand)',
        _ => 'Not set',
      };

  String _styleName(String? s) => switch (s) {
        'friendly' => '🎉 Friendly',
        'competitive' => '⚔️ Competitive',
        'both' => '🤝 Both',
        _ => 'Not set',
      };

  String _yearsName(String? y) => switch (y) {
        '0' => 'Just started',
        '<1' => 'Less than 1 year',
        '1-2' => '1 – 2 years',
        '3-5' => '3 – 5 years',
        '5+' => '5+ years',
        _ => 'Not set',
      };
}

class _IqScoreRing extends StatelessWidget {
  final int score;
  final int total;

  const _IqScoreRing({required this.score, required this.total});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 140,
      height: 140,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox(
            width: 140,
            height: 140,
            child: CircularProgressIndicator(
              value: score / total,
              strokeWidth: 12,
              backgroundColor: AppColors.primarySurface,
              valueColor:
                  AlwaysStoppedAnimation<Color>(AppColors.accent),
              strokeCap: StrokeCap.round,
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '$score / $total',
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary,
                ),
              ),
              const Text(
                'Padel IQ',
                style: TextStyle(
                  fontSize: 12,
                  color: AppColors.textMuted,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final List<(String, String, IconData)> items;

  const _SummaryCard({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: items.map((item) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              children: [
                Icon(item.$3, size: 18, color: AppColors.primary),
                const SizedBox(width: 12),
                Text(
                  '${item.$1}:',
                  style: const TextStyle(
                    fontSize: 13,
                    color: AppColors.textMuted,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Spacer(),
                Text(
                  item.$2,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
