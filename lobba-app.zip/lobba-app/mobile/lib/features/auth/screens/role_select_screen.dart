import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/providers/theme_mode_provider.dart';
import '../../../core/i18n/lobba_i18n.dart';

/// First auth step — choose Player or Court-owner. Each routes to the login /
/// sign-up screen for that role.
class RoleSelectScreen extends ConsumerWidget {
  const RoleSelectScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final dark = ref.watch(themeModeProvider) == ThemeMode.dark;
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: IconButton(
                  onPressed: () => ref.read(themeModeProvider.notifier).toggle(),
                  icon: Icon(dark ? Icons.dark_mode_outlined : Icons.light_mode_outlined, color: t.ink2),
                ),
              ),
              const Spacer(flex: 2),
              Container(
                width: 64, height: 64,
                decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(18)),
                alignment: Alignment.center,
                child: Text('L', style: TextStyle(fontFamily: kSerif, fontSize: 32, fontWeight: FontWeight.w600, color: t.onAccent)),
              ),
              const SizedBox(height: 18),
              Text('Lobba', style: TextStyle(fontFamily: kSerif, fontSize: 34, fontWeight: FontWeight.w500, color: t.ink)),
              const SizedBox(height: 8),
              Text('Egypt’s padel platform'.tr(context), style: TextStyle(fontSize: 14, color: t.ink2)),
              const SizedBox(height: 40),
              _RoleCard(
                t: t, icon: Icons.sports_tennis_rounded, title: 'I’m a Player'.tr(context),
                subtitle: 'Book courts, join matches, climb the levels.'.tr(context),
                onTap: () => context.go('/auth/player'),
              ),
              const SizedBox(height: 14),
              _RoleCard(
                t: t, icon: Icons.storefront_outlined, title: 'I’m a Court-owner'.tr(context),
                subtitle: 'Manage bookings, courts, earnings & payouts.'.tr(context),
                onTap: () => context.go('/auth/owner'),
              ),
              const Spacer(flex: 3),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final LobbaTokens t;
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;
  const _RoleCard({required this.t, required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: t.line)),
        child: Row(children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(14)),
            child: Icon(icon, color: t.accent, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(fontFamily: kSerif, fontSize: 17, fontWeight: FontWeight.w500, color: t.ink)),
              const SizedBox(height: 3),
              Text(subtitle, style: TextStyle(fontSize: 12, color: t.ink3, height: 1.4)),
            ]),
          ),
          Icon(Icons.chevron_right_rounded, color: t.ink3),
        ]),
      ),
    );
  }
}
