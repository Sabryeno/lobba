import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../providers/auth_provider.dart';
import '../models/user_model.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});
  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigate();
  }

  Future<void> _navigate() async {
    await Future.delayed(const Duration(milliseconds: 2400));
    if (!mounted) return;
    ref.read(authStateProvider).when(
          data: (user) {
            if (user == null) {
              context.go(AppRoutes.welcome);
            } else if (user.role == UserRole.organizer) {
              context.go(AppRoutes.organizerDashboard);
            } else {
              context.go(AppRoutes.home);
            }
          },
          loading: () => context.go(AppRoutes.welcome),
          error: (_, __) => context.go(AppRoutes.welcome),
        );
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final fg = t.headFg;
    return Scaffold(
      backgroundColor: t.headBg,
      body: Stack(children: [
        // soft radial glow behind the mark
        Center(child: Container(
          width: 320, height: 320,
          decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [fg.withOpacity(.10), Colors.transparent])),
        ).animate().fadeIn(duration: 900.ms).scale(begin: const Offset(.7, .7), end: const Offset(1, 1), duration: 1400.ms, curve: Curves.easeOut)),

        Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // logo mark with a pulsing court-ring motif behind it
            SizedBox(
              width: 132, height: 132,
              child: Stack(alignment: Alignment.center, children: [
                // expanding ring pulse (evokes a padel court / serve)
                Container(width: 108, height: 108, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: fg.withOpacity(.35), width: 1.4)))
                    .animate(onPlay: (c) => c.repeat())
                    .scaleXY(begin: .82, end: 1.25, duration: 1800.ms, curve: Curves.easeOut)
                    .fadeOut(duration: 1800.ms),
                Container(width: 108, height: 108, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: fg.withOpacity(.22), width: 1)))
                    .animate(onPlay: (c) => c.repeat())
                    .scaleXY(begin: .82, end: 1.45, delay: 500.ms, duration: 1800.ms, curve: Curves.easeOut)
                    .fadeOut(delay: 500.ms, duration: 1800.ms),
                // the logo tile
                Container(
                  width: 78, height: 78,
                  decoration: BoxDecoration(
                    color: fg, borderRadius: BorderRadius.circular(22),
                    boxShadow: [BoxShadow(color: fg.withOpacity(.28), blurRadius: 26, spreadRadius: 2)],
                  ),
                  alignment: Alignment.center,
                  child: Text('L', style: TextStyle(fontFamily: kSerif, fontSize: 44, fontWeight: FontWeight.w600, color: t.headBg)),
                )
                    .animate()
                    .scale(begin: const Offset(.55, .55), end: const Offset(1, 1), duration: 700.ms, curve: Curves.easeOutBack)
                    .fadeIn(duration: 500.ms)
                    .then()
                    .shimmer(duration: 1200.ms, color: t.headBg.withOpacity(.25)),
              ]),
            ),
            const SizedBox(height: 22),
            // wordmark
            Text('Lobba', style: TextStyle(fontFamily: kSerif, fontSize: 40, fontWeight: FontWeight.w600, color: fg))
                .animate().fadeIn(delay: 380.ms, duration: 600.ms).slideY(begin: 0.35, end: 0, curve: Curves.easeOut),
            const SizedBox(height: 10),
            // tagline
            Text('PADEL, PERFECTED', style: TextStyle(fontSize: 11.5, letterSpacing: 4, fontWeight: FontWeight.w600, color: fg.withOpacity(.85)))
                .animate().fadeIn(delay: 650.ms, duration: 700.ms),
          ]),
        ),

        // bottom: brand line + a thin animated loading shimmer
        Positioned(bottom: 42, left: 0, right: 0, child: Column(children: [
          SizedBox(
            width: 120, height: 3,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: Stack(children: [
                Container(color: fg.withOpacity(.15)),
                Container(width: 60, color: fg.withOpacity(.65))
                    .animate(onPlay: (c) => c.repeat())
                    .slideX(begin: -1.2, end: 2.2, duration: 1300.ms, curve: Curves.easeInOut),
              ]),
            ),
          ).animate().fadeIn(delay: 800.ms, duration: 500.ms),
          const SizedBox(height: 16),
          Text('Egypt’s padel platform', style: TextStyle(fontSize: 11, color: fg.withOpacity(.5)))
              .animate().fadeIn(delay: 900.ms, duration: 600.ms),
        ])),
      ]),
    );
  }
}
