import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/navigation/app_router.dart';
import '../../../shared/widgets/padel_button.dart';
import '../providers/auth_provider.dart';
import '../providers/locale_provider.dart';

// ── Step enum ─────────────────────────────────────────────────────────────────

enum _KycStep { nationalId, location, tradeLicense, review }

// ── Main screen ───────────────────────────────────────────────────────────────

class OrganizerKycScreen extends ConsumerStatefulWidget {
  const OrganizerKycScreen({super.key});

  @override
  ConsumerState<OrganizerKycScreen> createState() =>
      _OrganizerKycScreenState();
}

class _OrganizerKycScreenState extends ConsumerState<OrganizerKycScreen> {
  _KycStep _step = _KycStep.nationalId;
  final _picker = ImagePicker();

  // ── Step 1: National ID ────────────────────────────────────────────────────
  XFile? _idFront;
  XFile? _idBack;

  // ── Step 2: Map location ───────────────────────────────────────────────────
  GoogleMapController? _mapController;
  static const LatLng _cairoCenter = LatLng(30.0444, 31.2357);
  LatLng _mapCenter = _cairoCenter;
  LatLng? _venueLocation;
  String _venueAddress = '';
  bool _geocodingActive = false;

  // ── Step 3: Trade license ──────────────────────────────────────────────────
  XFile? _tradeLicense;

  // ── Submission ─────────────────────────────────────────────────────────────
  bool _submitting = false;
  String? _error;

  // ── Image capture ──────────────────────────────────────────────────────────

  Future<void> _captureId({required bool isFront}) async {
    XFile? file;
    // Try camera first, fall back to gallery (e.g. simulator)
    try {
      file = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 90,
      );
    } catch (_) {
      file = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 90,
      );
    }
    if (file == null || !mounted) return;
    setState(() {
      if (isFront) {
        _idFront = file;
      } else {
        _idBack = file;
      }
    });
  }

  Future<void> _pickTradeLicense() async {
    final file = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );
    if (file == null || !mounted) return;
    setState(() => _tradeLicense = file);
  }

  // ── Map helpers ────────────────────────────────────────────────────────────

  Future<void> _goToMyLocation() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return;
    }
    if (permission == LocationPermission.deniedForever) return;

    final pos = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
    final target = LatLng(pos.latitude, pos.longitude);
    _mapController?.animateCamera(CameraUpdate.newLatLngZoom(target, 17));
  }

  Future<void> _reverseGeocode(LatLng latlng) async {
    setState(() => _geocodingActive = true);
    try {
      final placemarks = await placemarkFromCoordinates(
        latlng.latitude,
        latlng.longitude,
      );
      if (!mounted) return;
      if (placemarks.isNotEmpty) {
        final p = placemarks.first;
        final parts = <String>[
          if (p.street?.isNotEmpty == true) p.street!,
          if (p.subLocality?.isNotEmpty == true) p.subLocality!,
          if (p.locality?.isNotEmpty == true) p.locality!,
        ];
        setState(() => _venueAddress = parts.join(', '));
      }
    } catch (_) {
      if (!mounted) return;
      setState(() => _venueAddress =
          '${latlng.latitude.toStringAsFixed(5)}, ${latlng.longitude.toStringAsFixed(5)}');
    } finally {
      if (mounted) setState(() => _geocodingActive = false);
    }
  }

  // ── Step navigation ────────────────────────────────────────────────────────

  bool get _canProceed {
    switch (_step) {
      case _KycStep.nationalId:
        return _idFront != null && _idBack != null;
      case _KycStep.location:
        return _venueLocation != null;
      case _KycStep.tradeLicense:
        return _tradeLicense != null;
      case _KycStep.review:
        return true;
    }
  }

  void _onNext() {
    switch (_step) {
      case _KycStep.nationalId:
        setState(() => _step = _KycStep.location);
      case _KycStep.location:
        setState(() => _step = _KycStep.tradeLicense);
      case _KycStep.tradeLicense:
        setState(() => _step = _KycStep.review);
      case _KycStep.review:
        _submit();
    }
  }

  void _onBack() {
    switch (_step) {
      case _KycStep.nationalId:
        context.pop();
      case _KycStep.location:
        setState(() => _step = _KycStep.nationalId);
      case _KycStep.tradeLicense:
        setState(() => _step = _KycStep.location);
      case _KycStep.review:
        setState(() => _step = _KycStep.tradeLicense);
    }
  }

  Future<void> _submit() async {
    setState(() {
      _submitting = true;
      _error = null;
    });
    try {
      await ref.read(authStateProvider.notifier).submitKyc(
            idFrontPath: _idFront!.path,
            idBackPath: _idBack!.path,
            tradeLicensePath: _tradeLicense!.path,
            venueLat: _venueLocation!.latitude,
            venueLng: _venueLocation!.longitude,
            venueAddress: _venueAddress,
          );
      if (!mounted) return;
      context.go(AppRoutes.organizerPending);
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final locale = ref.watch(localeProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: _onBack,
        ),
        title: Text(
          'Court Owner Verification',
          style: AppTypography.titleMedium(locale),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(72),
          child: _StepIndicator(currentStep: _step),
        ),
      ),
      body: SafeArea(
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 280),
          transitionBuilder: (child, animation) => FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.04, 0),
                end: Offset.zero,
              ).animate(CurvedAnimation(
                parent: animation,
                curve: Curves.easeOutCubic,
              )),
              child: child,
            ),
          ),
          child: _buildCurrentStep(locale),
        ),
      ),
    );
  }

  Widget _buildCurrentStep(Locale locale) {
    switch (_step) {
      case _KycStep.nationalId:
        return _NationalIdStep(
          key: const ValueKey('national_id'),
          idFront: _idFront,
          idBack: _idBack,
          onCaptureFront: () => _captureId(isFront: true),
          onCaptureBack: () => _captureId(isFront: false),
          onNext: _canProceed ? _onNext : null,
          locale: locale,
        );

      case _KycStep.location:
        return _LocationStep(
          key: const ValueKey('location'),
          initialCenter: _cairoCenter,
          onMapCreated: (ctrl) => _mapController = ctrl,
          onCameraMove: (pos) => _mapCenter = pos.target,
          onCameraIdle: () {
            setState(() => _venueLocation = _mapCenter);
            _reverseGeocode(_mapCenter); // fire-and-forget; sets state internally
          },
          onGoToMyLocation: _goToMyLocation,
          address: _venueAddress,
          geocodingActive: _geocodingActive,
          onConfirm: _canProceed ? _onNext : null,
          locale: locale,
        );

      case _KycStep.tradeLicense:
        return _TradeLicenseStep(
          key: const ValueKey('trade_license'),
          file: _tradeLicense,
          onPick: _pickTradeLicense,
          onNext: _canProceed ? _onNext : null,
          locale: locale,
        );

      case _KycStep.review:
        return _ReviewStep(
          key: const ValueKey('review'),
          idFront: _idFront!,
          idBack: _idBack!,
          venueAddress: _venueAddress,
          tradeLicense: _tradeLicense!,
          verifiedPhone: ref.read(authStateProvider).value?.phone ?? '',
          submitting: _submitting,
          error: _error,
          onSubmit: _submit,
          locale: locale,
        );
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Step Indicator
// ─────────────────────────────────────────────────────────────────────────────

class _StepIndicator extends StatelessWidget {
  final _KycStep currentStep;

  const _StepIndicator({required this.currentStep});

  @override
  Widget build(BuildContext context) {
    final steps = [
      (icon: Icons.badge_outlined, label: 'National ID'),
      (icon: Icons.location_on_outlined, label: 'Location'),
      (icon: Icons.description_outlined, label: 'License'),
      (icon: Icons.task_alt_rounded, label: 'Review'),
    ];
    final currentIndex = _KycStep.values.indexOf(currentStep);

    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 4, 24, 16),
      child: Row(
        children: List.generate(steps.length * 2 - 1, (i) {
          if (i.isOdd) {
            // Connector
            final lineIndex = i ~/ 2;
            final isComplete = lineIndex < currentIndex;
            return Expanded(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                height: 2,
                color: isComplete ? AppColors.primary : AppColors.border,
              ),
            );
          }

          final idx = i ~/ 2;
          final info = steps[idx];
          final isComplete = idx < currentIndex;
          final isCurrent = idx == currentIndex;

          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isComplete
                      ? AppColors.primary
                      : isCurrent
                          ? AppColors.primarySurface
                          : AppColors.surface,
                  border: Border.all(
                    color:
                        (isComplete || isCurrent) ? AppColors.primary : AppColors.border,
                    width: isCurrent ? 2 : 1.5,
                  ),
                ),
                child: Icon(
                  isComplete ? Icons.check_rounded : info.icon,
                  size: 18,
                  color: isComplete
                      ? Colors.white
                      : isCurrent
                          ? AppColors.primary
                          : AppColors.textTertiary,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                info.label,
                style: TextStyle(
                  fontSize: 9,
                  fontWeight: isCurrent ? FontWeight.w700 : FontWeight.w400,
                  color: isCurrent ? AppColors.primary : AppColors.textTertiary,
                ),
              ),
            ],
          );
        }),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Step 1 — National ID
// ─────────────────────────────────────────────────────────────────────────────

class _NationalIdStep extends StatelessWidget {
  final XFile? idFront;
  final XFile? idBack;
  final VoidCallback onCaptureFront;
  final VoidCallback onCaptureBack;
  final VoidCallback? onNext;
  final Locale locale;

  const _NationalIdStep({
    super.key,
    required this.idFront,
    required this.idBack,
    required this.onCaptureFront,
    required this.onCaptureBack,
    required this.onNext,
    required this.locale,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Text(
            'National ID',
            style: AppTypography.headlineMedium(locale),
          ).animate().fadeIn(duration: 350.ms).slideX(begin: -0.05),
          const SizedBox(height: 8),
          Text(
            'Take a clear photo of the front and back of your Egyptian National ID card',
            style: TextStyle(
              color: AppColors.textSecondary,
              fontSize: 14,
              height: 1.5,
            ),
          ).animate(delay: 60.ms).fadeIn(duration: 350.ms),

          const SizedBox(height: 32),

          // ID capture tiles
          Row(
            children: [
              Expanded(
                child: _IdCaptureTile(
                  label: 'Front Side',
                  hint: 'Your photo & name',
                  file: idFront,
                  onTap: onCaptureFront,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: _IdCaptureTile(
                  label: 'Back Side',
                  hint: 'ID number & address',
                  file: idBack,
                  onTap: onCaptureBack,
                ),
              ),
            ],
          ).animate(delay: 120.ms).fadeIn(duration: 350.ms).slideY(begin: 0.05),

          const SizedBox(height: 24),

          // Tips
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.accentLight.withOpacity(0.25),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.accentLight),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.lightbulb_outline_rounded,
                      size: 16,
                      color: AppColors.accent,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Photo tips',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                _Tip('Place the ID on a flat, dark surface'),
                _Tip('Ensure all four corners are fully visible'),
                _Tip('Avoid glare, shadows, and blurry shots'),
              ],
            ),
          ).animate(delay: 180.ms).fadeIn(duration: 350.ms),

          const SizedBox(height: 36),

          PadelButton(
            label: 'Next → Location',
            onPressed: onNext,
          ).animate(delay: 240.ms).fadeIn(duration: 350.ms),
        ],
      ),
    );
  }
}

class _IdCaptureTile extends StatelessWidget {
  final String label;
  final String hint;
  final XFile? file;
  final VoidCallback onTap;

  const _IdCaptureTile({
    required this.label,
    required this.hint,
    required this.file,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 168,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: file != null ? null : AppColors.surface,
          border: Border.all(
            color: file != null ? AppColors.primary : AppColors.border,
            width: file != null ? 2 : 1.5,
          ),
        ),
        clipBehavior: Clip.hardEdge,
        child: file != null
            ? Stack(
                fit: StackFit.expand,
                children: [
                  Image.file(File(file!.path), fit: BoxFit.cover),
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: AppColors.primary,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.check_rounded,
                        color: Colors.white,
                        size: 13,
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 7),
                      color: Colors.black.withOpacity(0.55),
                      child: const Text(
                        'Tap to retake',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                ],
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: AppColors.primarySurface,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.photo_camera_rounded,
                      color: AppColors.primary,
                      size: 26,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    label,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    hint,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 11,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Tap to capture',
                    style: TextStyle(
                      color: AppColors.primary,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _Tip extends StatelessWidget {
  final String text;
  const _Tip(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 7),
            child: Container(
              width: 4,
              height: 4,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.accent,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: AppColors.textSecondary,
                fontSize: 12,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Step 2 — Venue Location
// ─────────────────────────────────────────────────────────────────────────────

class _LocationStep extends StatelessWidget {
  final LatLng initialCenter;
  final void Function(GoogleMapController) onMapCreated;
  final void Function(CameraPosition) onCameraMove;
  final VoidCallback onCameraIdle;
  final VoidCallback onGoToMyLocation;
  final String address;
  final bool geocodingActive;
  final VoidCallback? onConfirm;
  final Locale locale;

  const _LocationStep({
    super.key,
    required this.initialCenter,
    required this.onMapCreated,
    required this.onCameraMove,
    required this.onCameraIdle,
    required this.onGoToMyLocation,
    required this.address,
    required this.geocodingActive,
    required this.onConfirm,
    required this.locale,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Header
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 16, 24, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Venue Location',
                style: AppTypography.headlineMedium(locale),
              ),
              const SizedBox(height: 4),
              Text(
                'Drag the map to pin your venue\'s exact location',
                style: TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),

        // Map with overlaid pin
        Expanded(
          child: Stack(
            alignment: Alignment.center,
            children: [
              GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: initialCenter,
                  zoom: 14,
                ),
                onMapCreated: onMapCreated,
                onCameraMove: onCameraMove,
                onCameraIdle: onCameraIdle,
                myLocationButtonEnabled: false,
                zoomControlsEnabled: false,
                mapToolbarEnabled: false,
                compassEnabled: false,
              ),

              // Fixed center marker (pin visual)
              IgnorePointer(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Pin head
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primary.withOpacity(0.45),
                            blurRadius: 14,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.storefront_rounded,
                        color: Colors.white,
                        size: 22,
                      ),
                    ),
                    // Pin tail
                    Container(
                      width: 2.5,
                      height: 14,
                      color: AppColors.primary,
                    ),
                    // Shadow dot
                    Container(
                      width: 10,
                      height: 4,
                      decoration: BoxDecoration(
                        color: AppColors.primary.withOpacity(0.35),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ],
                ),
              ),

              // My location FAB
              Positioned(
                bottom: 12,
                right: 12,
                child: Material(
                  elevation: 3,
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: onGoToMyLocation,
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.my_location_rounded,
                        color: AppColors.primary,
                        size: 22,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        // Bottom panel: address + confirm button
        Container(
          padding: const EdgeInsets.fromLTRB(24, 16, 24, 20),
          decoration: BoxDecoration(
            color: AppColors.background,
            border: Border(top: BorderSide(color: AppColors.border)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.location_pin,
                    size: 20,
                    color: AppColors.primary,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: geocodingActive
                        ? SizedBox(
                            height: 4,
                            child: LinearProgressIndicator(
                              backgroundColor: AppColors.border,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                  AppColors.primary),
                              borderRadius: BorderRadius.circular(2),
                            ),
                          )
                        : Text(
                            address.isEmpty
                                ? 'Move the map to select location'
                                : address,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: address.isEmpty
                                  ? AppColors.textTertiary
                                  : AppColors.textPrimary,
                              fontWeight: address.isEmpty
                                  ? FontWeight.w400
                                  : FontWeight.w600,
                              fontSize: 14,
                            ),
                          ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              PadelButton(
                label: 'Confirm Location',
                onPressed: onConfirm,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Step 3 — Trade License
// ─────────────────────────────────────────────────────────────────────────────

class _TradeLicenseStep extends StatelessWidget {
  final XFile? file;
  final VoidCallback onPick;
  final VoidCallback? onNext;
  final Locale locale;

  const _TradeLicenseStep({
    super.key,
    required this.file,
    required this.onPick,
    required this.onNext,
    required this.locale,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Trade License',
            style: AppTypography.headlineMedium(locale),
          ).animate().fadeIn(duration: 350.ms).slideX(begin: -0.05),
          const SizedBox(height: 8),
          Text(
            'Upload a clear photo or scan of your Egyptian trade license',
            style: TextStyle(
              color: AppColors.textSecondary,
              fontSize: 14,
              height: 1.5,
            ),
          ).animate(delay: 60.ms).fadeIn(duration: 350.ms),

          const SizedBox(height: 28),

          // Upload zone
          GestureDetector(
            onTap: onPick,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: double.infinity,
              height: 230,
              decoration: BoxDecoration(
                color: file != null ? null : AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: file != null ? AppColors.primary : AppColors.border,
                  width: file != null ? 2 : 1.5,
                ),
              ),
              clipBehavior: Clip.hardEdge,
              child: file != null
                  ? Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.file(File(file!.path), fit: BoxFit.cover),
                        Positioned(
                          top: 12,
                          right: 12,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: const BoxDecoration(
                              color: AppColors.primary,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.check_rounded,
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          left: 0,
                          right: 0,
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            color: Colors.black.withOpacity(0.55),
                            child: const Text(
                              'Tap to change',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        ),
                      ],
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 68,
                          height: 68,
                          decoration: BoxDecoration(
                            color: AppColors.primarySurface,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.upload_file_rounded,
                            size: 34,
                            color: AppColors.primary,
                          ),
                        ),
                        const SizedBox(height: 18),
                        const Text(
                          'Tap to upload trade license',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'JPG, PNG accepted  •  Max 10 MB',
                          style: TextStyle(
                            color: AppColors.textSecondary,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
            ),
          ).animate(delay: 120.ms).fadeIn(duration: 350.ms).slideY(begin: 0.05),

          const SizedBox(height: 20),

          // Security note
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primarySurface,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.lock_outline_rounded,
                  size: 18,
                  color: AppColors.primary,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Your documents are encrypted and used only for verification. They are never shared with third parties.',
                    style: TextStyle(
                      color: AppColors.primary,
                      fontSize: 12,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ).animate(delay: 180.ms).fadeIn(duration: 350.ms),

          const SizedBox(height: 36),

          PadelButton(
            label: 'Next → Review',
            onPressed: onNext,
          ).animate(delay: 240.ms).fadeIn(duration: 350.ms),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Step 4 — Review & Submit
// ─────────────────────────────────────────────────────────────────────────────

class _ReviewStep extends StatelessWidget {
  final XFile idFront;
  final XFile idBack;
  final String venueAddress;
  final XFile tradeLicense;
  final String verifiedPhone;
  final bool submitting;
  final String? error;
  final VoidCallback onSubmit;
  final Locale locale;

  const _ReviewStep({
    super.key,
    required this.idFront,
    required this.idBack,
    required this.venueAddress,
    required this.tradeLicense,
    required this.verifiedPhone,
    required this.submitting,
    required this.error,
    required this.onSubmit,
    required this.locale,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Review & Submit',
            style: AppTypography.headlineMedium(locale),
          ).animate().fadeIn(duration: 350.ms),
          const SizedBox(height: 6),
          Text(
            'Everything looks good? Submit for admin review.',
            style: TextStyle(
              color: AppColors.textSecondary,
              fontSize: 14,
            ),
          ).animate(delay: 60.ms).fadeIn(duration: 350.ms),

          const SizedBox(height: 28),

          // ── National ID card ──────────────────────────────────────────────
          _ReviewCard(
            icon: Icons.badge_rounded,
            title: 'National ID',
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Front',
                        style: TextStyle(
                          fontSize: 11,
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 4),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.file(
                          File(idFront.path),
                          height: 90,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Back',
                        style: TextStyle(
                          fontSize: 11,
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 4),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.file(
                          File(idBack.path),
                          height: 90,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ).animate(delay: 80.ms).fadeIn(duration: 350.ms),

          const SizedBox(height: 12),

          // ── Verified phone ────────────────────────────────────────────────
          _ReviewCard(
            icon: Icons.phone_rounded,
            title: 'Verified Mobile Number',
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE8F5E9),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.verified_rounded,
                        size: 14,
                        color: Color(0xFF388E3C),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'OTP Verified',
                        style: TextStyle(
                          color: const Color(0xFF388E3C),
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    verifiedPhone.isNotEmpty ? verifiedPhone : 'Verified',
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                    ),
                  ),
                ),
              ],
            ),
          ).animate(delay: 120.ms).fadeIn(duration: 350.ms),

          const SizedBox(height: 12),

          // ── Location ──────────────────────────────────────────────────────
          _ReviewCard(
            icon: Icons.location_on_rounded,
            title: 'Venue Location',
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.map_outlined,
                  size: 18,
                  color: AppColors.primary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    venueAddress.isNotEmpty ? venueAddress : 'Location pinned',
                    style: const TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ).animate(delay: 160.ms).fadeIn(duration: 350.ms),

          const SizedBox(height: 12),

          // ── Trade license ─────────────────────────────────────────────────
          _ReviewCard(
            icon: Icons.description_rounded,
            title: 'Trade License',
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.file(
                File(tradeLicense.path),
                height: 110,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
          ).animate(delay: 200.ms).fadeIn(duration: 350.ms),

          const SizedBox(height: 28),

          // Error message
          if (error != null) ...[
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.error.withOpacity(0.07),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.error.withOpacity(0.3)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.error_outline_rounded,
                    color: AppColors.error,
                    size: 18,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      error!,
                      style: TextStyle(
                        color: AppColors.error,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],

          PadelButton(
            label: 'Submit for Review',
            loading: submitting,
            onPressed: onSubmit,
          ).animate(delay: 240.ms).fadeIn(duration: 350.ms),

          const SizedBox(height: 12),

          Center(
            child: Text(
              'Your application will be reviewed within 1–2 business days',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.textSecondary,
                fontSize: 12,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Shared review card widget
// ─────────────────────────────────────────────────────────────────────────────

class _ReviewCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final Widget child;

  const _ReviewCard({
    required this.icon,
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceElevated,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: AppColors.primary),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.primarySurface,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.check_circle_rounded,
                        size: 11, color: AppColors.primary),
                    const SizedBox(width: 4),
                    Text(
                      'Uploaded',
                      style: TextStyle(
                        color: AppColors.primary,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}
