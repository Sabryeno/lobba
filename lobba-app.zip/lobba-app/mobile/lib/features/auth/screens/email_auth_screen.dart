import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../models/user_model.dart';
import '../providers/auth_provider.dart';
import '../../../core/theme/lobba_tokens.dart';
import '../../../core/i18n/lobba_i18n.dart';

/// Login / sign-up for a specific role (passed from the role-select screen),
/// backed by Firebase Auth (email + password). Themed with Sage / Ink tokens.
class EmailAuthScreen extends ConsumerStatefulWidget {
  const EmailAuthScreen({super.key, required this.role});
  final UserRole role;

  @override
  ConsumerState<EmailAuthScreen> createState() => _EmailAuthScreenState();
}

class _EmailAuthScreenState extends ConsumerState<EmailAuthScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _city = TextEditingController();

  bool _isLogin = true; // default to Log in; user can switch to Create account
  bool _busy = false;
  String? _error;

  bool get _isOwner => widget.role == UserRole.organizer;

  @override
  void dispose() {
    _name.dispose(); _email.dispose(); _password.dispose(); _city.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() { _busy = true; _error = null; });
    final auth = ref.read(authStateProvider.notifier);
    try {
      if (_isLogin) {
        await auth.loginWithEmail(email: _email.text, password: _password.text);
      } else {
        await auth.signUpWithEmail(
          name: _name.text, email: _email.text, password: _password.text,
          role: widget.role, city: _city.text.trim().isEmpty ? null : _city.text.trim(),
        );
      }
    } catch (e) {
      if (mounted) setState(() => _error = _friendly(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendly(Object e) {
    final s = e.toString();
    if (s.contains('email-already-in-use')) return 'That email is already registered — switch to Log in.';
    if (s.contains('invalid-email')) return 'That email looks invalid.';
    if (s.contains('weak-password')) return 'Password too weak (min 6 characters).';
    if (s.contains('wrong-password') || s.contains('invalid-credential')) return 'Wrong email or password.';
    if (s.contains('user-not-found')) return 'No account for that email — Sign up first.';
    if (s.contains('operation-not-allowed') || s.contains('configuration-not-found')) {
      return 'Email/Password sign-in isn’t enabled in Firebase yet.';
    }
    if (s.contains('network')) return 'Network error — check the connection.';
    return 'Something went wrong. Please try again.';
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Form(
              key: _formKey,
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: GestureDetector(
                    onTap: () => context.go('/welcome'),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.chevron_left_rounded, color: t.ink2, size: 22),
                      Text('Change role'.tr(context), style: TextStyle(color: t.ink2, fontSize: 13)),
                    ]),
                  ),
                ),
                const SizedBox(height: 20),
                Center(
                  child: Container(
                    width: 60, height: 60,
                    decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(17)),
                    alignment: Alignment.center,
                    child: Text('L', style: TextStyle(fontFamily: kSerif, fontSize: 30, fontWeight: FontWeight.w600, color: t.onAccent)),
                  ),
                ),
                const SizedBox(height: 14),
                Center(child: _rolePill(t)),
                const SizedBox(height: 12),
                Text((_isLogin ? 'Welcome back' : 'Create your account').tr(context),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: kSerif, fontSize: 24, fontWeight: FontWeight.w500, color: t.ink)),
                const SizedBox(height: 24),

                if (!_isLogin) ...[
                  _field(t, _name, 'Full name'.tr(context), TextInputType.name,
                      validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter your name' : null),
                  const SizedBox(height: 12),
                ],
                _field(t, _email, 'Email'.tr(context), TextInputType.emailAddress,
                    validator: (v) => (v == null || !v.contains('@')) ? 'Enter a valid email' : null),
                const SizedBox(height: 12),
                _field(t, _password, 'Password'.tr(context), TextInputType.visiblePassword, obscure: true,
                    validator: (v) => (v == null || v.length < 6) ? 'Min 6 characters' : null),
                if (!_isLogin) ...[
                  const SizedBox(height: 12),
                  _field(t, _city, 'City (optional)'.tr(context), TextInputType.text),
                ],

                if (_error != null) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: t.clay.withOpacity(.12), borderRadius: BorderRadius.circular(12), border: Border.all(color: t.clay)),
                    child: Row(children: [
                      Icon(Icons.error_outline, color: t.clay, size: 18),
                      const SizedBox(width: 8),
                      Expanded(child: Text(_error!, style: TextStyle(color: t.clay, fontSize: 12.5, height: 1.4))),
                    ]),
                  ),
                ],
                const SizedBox(height: 22),
                SizedBox(
                  height: 52,
                  child: ElevatedButton(
                    onPressed: _busy ? null : _submit,
                    style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                    child: _busy
                        ? SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: t.onAccent))
                        : Text((_isLogin ? 'Log in' : 'Create account').tr(context), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  ),
                ),
                const SizedBox(height: 16),
                Center(
                  child: TextButton(
                    onPressed: _busy ? null : () => setState(() { _isLogin = !_isLogin; _error = null; }),
                    child: Text((_isLogin ? 'New here? Create an account' : 'Already have an account? Log in').tr(context),
                        style: TextStyle(color: t.accent, fontWeight: FontWeight.w600)),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _rolePill(LobbaTokens t) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
        decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(99)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(_isOwner ? Icons.storefront_outlined : Icons.sports_tennis_rounded, size: 14, color: t.accent),
          const SizedBox(width: 6),
          Text((_isOwner ? 'Court-owner' : 'Player').tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.accent)),
        ]),
      );

  Widget _field(LobbaTokens t, TextEditingController c, String hint, TextInputType kb, {bool obscure = false, String? Function(String?)? validator}) => TextFormField(
        controller: c, keyboardType: kb, obscureText: obscure, validator: validator,
        style: TextStyle(color: t.ink, fontSize: 14),
        decoration: InputDecoration(
          hintText: hint, filled: true, fillColor: t.surface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.accent, width: 1.5)),
          errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.clay)),
        ),
      );
}
