import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/localization/app_localizations.dart';
import '../../../core/navigation/app_router.dart';
import '../../../shared/widgets/padel_button.dart';
import '../providers/locale_provider.dart';
import '../providers/auth_provider.dart';

class WelcomeScreen extends ConsumerWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final locale = ref.watch(localeProvider);
    final size = MediaQuery.sizeOf(context);

    return Scaffold(
      backgroundColor: AppColors.primary,
      body: SafeArea(
        child: Column(
          children: [
            // ── Language toggle ────────────────────────────────────────────
            Align(
              alignment: l10n.isArabic
                  ? Alignment.centerLeft
                  : Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 16,
                ),
                child: _LanguageToggle(),
              ),
            ),

            // ── Hero area ─────────────────────────────────────────────────
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Court illustration / logo placeholder
                  Container(
                    width: size.width * 0.55,
                    height: size.width * 0.55,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.08),
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Text(
                        '🎾',
                        style: TextStyle(fontSize: 64),
                      ),
                    ),
                  )
                      .animate()
                      .scale(
                        begin: const Offset(0.8, 0.8),
                        end: const Offset(1, 1),
                        duration: 700.ms,
                        curve: Curves.elasticOut,
                      ),
                  const SizedBox(height: 40),
                  Text(
                    l10n.tr('auth.welcome_title'),
                    textAlign: TextAlign.center,
                    style: AppTypography.displayLarge(locale).copyWith(
                      color: Colors.white,
                    ),
                  )
                      .animate(delay: 200.ms)
                      .fadeIn(duration: 500.ms)
                      .slideY(begin: 0.15, end: 0),
                  const SizedBox(height: 12),
                  Text(
                    l10n.tr('auth.welcome_subtitle'),
                    textAlign: TextAlign.center,
                    style: AppTypography.bodyLarge(locale).copyWith(
                      color: Colors.white70,
                    ),
                  )
                      .animate(delay: 350.ms)
                      .fadeIn(duration: 500.ms),
                ],
              ),
            ),

            // ── CTA buttons ───────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
              child: Column(
                children: [
                  PadelButton(
                    label: l10n.tr('auth.signup'),
                    onPressed: () => _showRoleSheet(context),
                    backgroundColor: AppColors.accent,
                    foregroundColor: Colors.white,
                  ),
                  const SizedBox(height: 12),
                  PadelButton(
                    label: l10n.tr('auth.login'),
                    onPressed: () => context.push(AppRoutes.playerSignup),
                    variant: PadelButtonVariant.ghost,
                    foregroundColor: Colors.white,
                  ),
                  const SizedBox(height: 16),
                  // ── "or" divider ──────────────────────────────────────────
                  Row(
                    children: const [
                      Expanded(child: Divider(color: Colors.white24)),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 12),
                        child: Text('or',
                            style: TextStyle(color: Colors.white54, fontSize: 12)),
                      ),
                      Expanded(child: Divider(color: Colors.white24)),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // ── Continue with Google ──────────────────────────────────
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: () => _handleGoogle(context, ref),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: AppColors.textPrimary,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text('G',
                              style: TextStyle(
                                  color: Color(0xFF4285F4),
                                  fontWeight: FontWeight.w800,
                                  fontSize: 20)),
                          SizedBox(width: 10),
                          Text('Continue with Google',
                              style: TextStyle(fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Terms note
                  Text(
                    '${l10n.tr('auth.terms_prefix')}${l10n.tr('auth.terms_link')}${l10n.tr('auth.and')}${l10n.tr('auth.privacy_link')}',
                    textAlign: TextAlign.center,
                    style: AppTypography.labelSmall(locale).copyWith(
                      color: Colors.white38,
                    ),
                  ),
                ]
                    .animate(delay: 500.ms, interval: 80.ms)
                    .fadeIn(duration: 400.ms)
                    .slideY(begin: 0.2, end: 0),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _handleGoogle(BuildContext context, WidgetRef ref) async {
    try {
      final result = await ref
          .read(authStateProvider.notifier)
          .signInWithGoogle(flow: 'player');
      if (result == null || !context.mounted) return; // cancelled
      // New Google users finish profile setup; returning users go home.
      context.go(result == OtpVerifyResult.newUser
          ? AppRoutes.playerSetup
          : AppRoutes.home);
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Google sign-in failed. Please try again.')),
      );
    }
  }

  void _showRoleSheet(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            _RoleOption(
              icon: Icons.sports_tennis_rounded,
              title: l10n.tr('auth.player_signup_title'),
              subtitle: l10n.tr('auth.player_signup_subtitle'),
              onTap: () {
                ctx.pop();
                context.push(AppRoutes.playerSignup);
              },
            ),
            const SizedBox(height: 12),
            _RoleOption(
              icon: Icons.store_rounded,
              title: l10n.tr('auth.organizer_signup_title'),
              subtitle: l10n.tr('auth.organizer_signup_subtitle'),
              onTap: () {
                ctx.pop();
                context.push(AppRoutes.organizerSignup);
              },
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

class _LanguageToggle extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(localeProvider);
    final isAr = locale.languageCode == 'ar';
    return GestureDetector(
      onTap: () => ref
          .read(localeProvider.notifier)
          .setLocale(isAr ? const Locale('en') : const Locale('ar')),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          isAr ? 'EN' : 'عربي',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
      ),
    );
  }
}

class _RoleOption extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _RoleOption({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.border),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: AppColors.primarySurface,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: AppColors.primary),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppColors.textSecondary,
                        ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.arrow_forward_ios_rounded,
              size: 16,
              color: AppColors.textTertiary,
            ),
          ],
        ),
      ),
    );
  }
}
