import 'package:freezed_annotation/freezed_annotation.dart';

part 'user_model.freezed.dart';
part 'user_model.g.dart';

enum UserRole { player, organizer, admin }

@freezed
class UserModel with _$UserModel {
  const factory UserModel({
    required String id,
    required String name,
    required UserRole role,
    String? phone,
    String? email,
    String? photoUrl,
    @Default(1) int skillLevelNumeric,
    String? skillGradeLetter,
    String? city,
    double? lat,
    double? lng,
    @Default(false) bool isApproved,
    required DateTime createdAt,
  }) = _UserModel;

  factory UserModel.fromJson(Map<String, dynamic> json) =>
      _$UserModelFromJson(json);
}

@freezed
class AuthTokens with _$AuthTokens {
  const factory AuthTokens({
    required String accessToken,
    required String refreshToken,
    required DateTime expiresAt,
  }) = _AuthTokens;

  factory AuthTokens.fromJson(Map<String, dynamic> json) =>
      _$AuthTokensFromJson(json);
}
