import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// The signed-in player's current level (0–7) + reliability (0–100).
class PlayerLevel {
  final double level;
  final int reliability;
  const PlayerLevel(this.level, this.reliability);
}

final playerLevelProvider =
    NotifierProvider<PlayerLevelNotifier, PlayerLevel>(PlayerLevelNotifier.new);

class PlayerLevelNotifier extends Notifier<PlayerLevel> {
  static const _kLevel = 'player_level';
  static const _kRel = 'player_reliability';

  @override
  PlayerLevel build() {
    _load();
    return const PlayerLevel(1.0, 20); // new-user default (low reliability)
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      if (p.containsKey(_kLevel)) {
        state = PlayerLevel(p.getDouble(_kLevel) ?? 1.0, p.getInt(_kRel) ?? 20);
      }
    } catch (_) {}
  }

  Future<void> _save() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setDouble(_kLevel, state.level);
      await p.setInt(_kRel, state.reliability);
    } catch (_) {}
  }

  /// Set the starting level from the one-time assessment (reliability = 30%).
  void setFromAssessment(double level) {
    state = PlayerLevel(level.clamp(0, 7), 30);
    _save();
  }

  /// Manual downward adjustment — can't raise.
  void lower(double newLevel) {
    state = PlayerLevel(newLevel.clamp(0, state.level), state.reliability);
    _save();
  }
}
