import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:dio/dio.dart' as dio_pkg;
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'dart:convert';

import '../models/user_model.dart';
import '../../../core/network/api_client.dart';

/// Builds the app UserModel from a signed-in Firebase user. The profile
/// (name, role, city) is persisted as a small JSON blob in the auth user's
/// displayName, so role-based routing works without a separate database.
UserModel _userFromFirebase(fb.User u) {
  Map<String, dynamic> profile = const {};
  try {
    if (u.displayName != null && u.displayName!.startsWith('{')) {
      profile = json.decode(u.displayName!) as Map<String, dynamic>;
    }
  } catch (_) {}
  final roleName = (profile['r'] as String?) ?? 'player';
  final role = UserRole.values.firstWhere(
    (r) => r.name == roleName,
    orElse: () => UserRole.player,
  );
  return UserModel(
    id: u.uid,
    name: (profile['n'] as String?) ?? (u.displayName ?? 'Player'),
    role: role,
    email: u.email,
    city: profile['c'] as String?,
    isApproved: role != UserRole.player,
    createdAt: DateTime.now(),
  );
}

const _kAccessToken = 'access_token';
const _kRefreshToken = 'refresh_token';
const _kUser = 'user_data';

/// Web OAuth client ID from google-services.json (the oauth_client entry with
/// client_type 3). REQUIRED for the backend to verify the Google ID token.
/// Fill this in AFTER enabling the Google provider in Firebase and
/// re-downloading google-services.json (it gains the web client then).
const kGoogleServerClientId = ''; // e.g. '1234567890-abc.apps.googleusercontent.com'

// ── Auth state (current user, null = logged out) ──────────────────────────
final authStateProvider =
    AsyncNotifierProvider<AuthNotifier, UserModel?>(AuthNotifier.new);

class AuthNotifier extends AsyncNotifier<UserModel?> {
  late FlutterSecureStorage _storage;

  @override
  Future<UserModel?> build() async {
    _storage = const FlutterSecureStorage();
    // Firebase-backed session: if a user is signed in, build their profile.
    final current = fb.FirebaseAuth.instance.currentUser;
    if (current == null) return null;
    return _userFromFirebase(current);
  }

  // ── Email/password SIGN-UP (real, Firebase) ───────────────────────────────
  Future<void> signUpWithEmail({
    required String name,
    required String email,
    required String password,
    required UserRole role,
    String? city,
  }) async {
    state = const AsyncLoading();
    try {
      final cred = await fb.FirebaseAuth.instance
          .createUserWithEmailAndPassword(email: email.trim(), password: password);
      // Persist the profile (name, role, city) on the auth user.
      await cred.user!.updateDisplayName(json.encode({
        'n': name.trim(),
        'r': role.name,
        if (city != null && city.isNotEmpty) 'c': city,
      }));
      await cred.user!.reload();
      final refreshed = fb.FirebaseAuth.instance.currentUser ?? cred.user!;
      state = AsyncData(_userFromFirebase(refreshed));
    } catch (e, st) {
      state = AsyncError(e, st);
      rethrow;
    }
  }

  // ── Phone sign-up: step 1 — send OTP ────────────────────────────────────
  Future<void> requestOtp({required String phone}) async {
    final api = ref.read(apiClientProvider);
    await api.post('/auth/otp/send', data: {'phone': phone});
  }

  // ── Phone sign-up: step 2 — verify OTP ───────────────────────────────────
  Future<OtpVerifyResult> verifyOtp({
    required String phone,
    required String code,
    required String flow, // 'player' | 'organizer'
  }) async {
    final api = ref.read(apiClientProvider);
    final response = await api.post('/auth/otp/verify', data: {
      'phone': phone,
      'code': code,
      'flow': flow,
    });
    final tokens = AuthTokens.fromJson(response.data['tokens']);
    await _saveTokens(tokens);

    // New user: profile not complete yet
    if (response.data['isNewUser'] == true) {
      return OtpVerifyResult.newUser;
    }

    final user = UserModel.fromJson(response.data['user']);
    await _saveUser(user);
    state = AsyncData(user);
    return OtpVerifyResult.existingUser;
  }

  // ── Google Sign-In → exchanges Google ID token for backend JWTs ──────────
  // Returns newUser/existingUser like verifyOtp, or null if the user cancelled.
  Future<OtpVerifyResult?> signInWithGoogle({required String flow}) async {
    final googleSignIn = GoogleSignIn(
      scopes: const ['email', 'profile'],
      serverClientId:
          kGoogleServerClientId.isEmpty ? null : kGoogleServerClientId,
    );

    final googleUser = await googleSignIn.signIn();
    if (googleUser == null) return null; // user cancelled the picker

    final googleAuth = await googleUser.authentication;
    final idToken = googleAuth.idToken;
    if (idToken == null) {
      throw Exception(
        'Google sign-in returned no ID token. Check that the Google provider '
        'is enabled in Firebase, the SHA-1 is registered, and '
        'kGoogleServerClientId is set from google-services.json.',
      );
    }

    state = const AsyncLoading();
    try {
      final api = ref.read(apiClientProvider);
      // Backend verifies the Google token, find-or-creates the user, and
      // returns the SAME JWTs the rest of the app uses.
      final response = await api.post('/auth/login/google', data: {
        'idToken': idToken,
        'flow': flow,
      });

      final tokens = AuthTokens.fromJson(response.data['tokens']);
      await _saveTokens(tokens);

      if (response.data['isNewUser'] == true) {
        // Keep state unauthenticated until profile setup completes.
        state = const AsyncData(null);
        return OtpVerifyResult.newUser;
      }

      final user = UserModel.fromJson(response.data['user']);
      await _saveUser(user);
      state = AsyncData(user);
      return OtpVerifyResult.existingUser;
    } catch (e, st) {
      state = AsyncError(e, st);
      rethrow;
    }
  }

  // ── Complete player profile setup ─────────────────────────────────────────
  Future<void> completePlayerSetup({
    required String name,
    required String city,
    required int skillLevel,
    String? preferredSide,   // 'left' | 'right'
    String? playStyle,        // 'friendly' | 'competitive' | 'both'
    String? yearsPlaying,     // '0' | '<1' | '1-2' | '3-5' | '5+'
    int? padelIqScore,        // 0–5
  }) async {
    final api = ref.read(apiClientProvider);
    final response = await api.post('/auth/profile/player', data: {
      'name': name,
      'city': city,
      'skillLevel': skillLevel,
      if (preferredSide != null) 'preferredSide': preferredSide,
      if (playStyle != null) 'playStyle': playStyle,
      if (yearsPlaying != null) 'yearsPlaying': yearsPlaying,
      if (padelIqScore != null) 'padelIqScore': padelIqScore,
    });
    final user = UserModel.fromJson(response.data);
    await _saveUser(user);
    state = AsyncData(user);
  }

  // ── Submit KYC documents ──────────────────────────────────────────────────
  Future<void> submitKyc({
    required String idFrontPath,
    required String idBackPath,
    required String tradeLicensePath,
    required double venueLat,
    required double venueLng,
    required String venueAddress,
  }) async {
    final api = ref.read(apiClientProvider);

    final formData = dio_pkg.FormData.fromMap({
      'idFront': await dio_pkg.MultipartFile.fromFile(
        idFrontPath,
        filename: 'id_front.jpg',
      ),
      'idBack': await dio_pkg.MultipartFile.fromFile(
        idBackPath,
        filename: 'id_back.jpg',
      ),
      'tradeLicense': await dio_pkg.MultipartFile.fromFile(
        tradeLicensePath,
        filename: 'trade_license.jpg',
      ),
      'venueLat': venueLat.toString(),
      'venueLng': venueLng.toString(),
      'venueAddress': venueAddress,
    });

    final response = await api.post('/users/me/kyc', data: formData);
    // Update local user state with new kycStatus
    final updated = UserModel.fromJson(response.data as Map<String, dynamic>);
    await _saveUser(updated);
    state = AsyncData(updated);
  }

  // ── Complete organizer setup ──────────────────────────────────────────────
  Future<void> completeOrganizerSetup({
    required String businessName,
    required String contactPerson,
    String? commercialReg,
  }) async {
    final api = ref.read(apiClientProvider);
    await api.post('/auth/profile/organizer', data: {
      'businessName': businessName,
      'contactPerson': contactPerson,
      if (commercialReg != null) 'commercialReg': commercialReg,
    });
    // Organizer is pending — do not update state to logged in yet
  }

  // ── Email login ───────────────────────────────────────────────────────────
  Future<void> loginWithEmail({
    required String email,
    required String password,
  }) async {
    state = const AsyncLoading();
    try {
      final cred = await fb.FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email.trim(), password: password);
      state = AsyncData(_userFromFirebase(cred.user!));
    } catch (e, st) {
      state = AsyncError(e, st);
      rethrow;
    }
  }

  // ── Logout ────────────────────────────────────────────────────────────────
  Future<void> logout() async {
    try {
      await fb.FirebaseAuth.instance.signOut();
    } catch (_) {}
    try {
      await GoogleSignIn().signOut();
    } catch (_) {}
    await _clearStorage();
    state = const AsyncData(null);
  }

  // ── Token refresh (called by Dio interceptor) ─────────────────────────────
  Future<String?> refreshAccessToken() async {
    final refreshToken = await _storage.read(key: _kRefreshToken);
    if (refreshToken == null) return null;
    try {
      final api = ref.read(apiClientProvider);
      final response = await api.post('/auth/token/refresh', data: {
        'refreshToken': refreshToken,
      });
      final tokens = AuthTokens.fromJson(response.data);
      await _saveTokens(tokens);
      return tokens.accessToken;
    } catch (_) {
      await _clearStorage();
      state = const AsyncData(null);
      return null;
    }
  }

  Future<void> _saveTokens(AuthTokens tokens) async {
    await Future.wait([
      _storage.write(key: _kAccessToken, value: tokens.accessToken),
      _storage.write(key: _kRefreshToken, value: tokens.refreshToken),
    ]);
  }

  Future<void> _saveUser(UserModel user) async {
    await _storage.write(key: _kUser, value: json.encode(user.toJson()));
  }

  Future<void> _clearStorage() async {
    await _storage.deleteAll();
  }

  Future<String?> get accessToken => _storage.read(key: _kAccessToken);
}

enum OtpVerifyResult { newUser, existingUser }
