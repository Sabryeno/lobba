import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../../core/services/api_service.dart';

class TeamModel {
  final String id;
  final String name;
  final String? logoUrl;
  final String? description;
  final int memberCount;
  final double? teamElo;
  final bool isPublic;

  const TeamModel({
    required this.id,
    required this.name,
    this.logoUrl,
    this.description,
    required this.memberCount,
    this.teamElo,
    required this.isPublic,
  });

  factory TeamModel.fromJson(Map<String, dynamic> j) => TeamModel(
        id: j['id'],
        name: j['name'] ?? 'Team',
        logoUrl: j['logoUrl'],
        description: j['description'],
        memberCount: j['memberCount'] ?? (j['members'] as List?)?.length ?? 0,
        teamElo: (j['teamElo'] as num?)?.toDouble(),
        isPublic: j['isPublic'] ?? true,
      );
}

final teamsProvider = FutureProvider<List<TeamModel>>((ref) async {
  final dio = ref.read(dioProvider);
  final resp = await dio.get('/teams/my');
  final body = resp.data;
  final list = body is Map<String, dynamic> && body['data'] is List
      ? body['data'] as List
      : body as List;
  return list
      .map((e) => TeamModel.fromJson(
            e is Map<String, dynamic> && e['team'] is Map<String, dynamic>
                ? e['team'] as Map<String, dynamic>
                : e as Map<String, dynamic>,
          ))
      .toList();
});

class TeamsScreen extends ConsumerWidget {
  const TeamsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final teamsAsync = ref.watch(teamsProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
        title: Text('Teams'.tr(context), style: const TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.group_add_outlined),
            onPressed: () => _showCreateTeamSheet(context, ref),
          ),
        ],
      ),
      body: teamsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (teams) => teams.isEmpty
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.group_outlined, size: 64, color: AppColors.grey300),
                    const SizedBox(height: 16),
                    Text('No teams yet'.tr(context),
                        style: TextStyle(color: AppColors.textSecondary, fontSize: 16)),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: () => _showCreateTeamSheet(context, ref),
                      icon: const Icon(Icons.add),
                      label: Text('Create a Team'.tr(context)),
                      style: FilledButton.styleFrom(backgroundColor: AppColors.primary),
                    ),
                  ],
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: teams.length,
                itemBuilder: (context, i) => _TeamCard(team: teams[i]),
              ),
      ),
    );
  }

  void _showCreateTeamSheet(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _CreateTeamSheet(ref: ref),
    );
  }
}

class _CreateTeamSheet extends StatefulWidget {
  final WidgetRef ref;
  const _CreateTeamSheet({required this.ref});

  @override
  State<_CreateTeamSheet> createState() => _CreateTeamSheetState();
}

class _CreateTeamSheetState extends State<_CreateTeamSheet> {
  final _nameCtrl = TextEditingController();
  final _descriptionCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();
  bool _isPublic = true;
  bool _loading = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _descriptionCtrl.dispose();
    _cityCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(20, 4, 20, bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Create Team'.tr(context),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _nameCtrl,
              decoration: InputDecoration(labelText: 'Team name'.tr(context)),
              textInputAction: TextInputAction.next,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _cityCtrl,
              decoration: InputDecoration(labelText: 'City'.tr(context)),
              textInputAction: TextInputAction.next,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _descriptionCtrl,
              decoration: InputDecoration(labelText: 'Description'.tr(context)),
              minLines: 2,
              maxLines: 4,
            ),
            const SizedBox(height: 8),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: _isPublic,
              onChanged: (value) => setState(() => _isPublic = value),
              title: Text('Public team'.tr(context)),
              subtitle: Text('Players can join without an invite'.tr(context)),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _loading ? null : _submit,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.primary,
                ),
                child: _loading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Text('Create Team'.tr(context)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Team name is required'.tr(context))),
      );
      return;
    }
    setState(() => _loading = true);
    try {
      final dio = widget.ref.read(dioProvider);
      final resp = await dio.post('/teams', data: {
        'name': name,
        'city': _cityCtrl.text.trim().isEmpty ? null : _cityCtrl.text.trim(),
        'description': _descriptionCtrl.text.trim().isEmpty
            ? null
            : _descriptionCtrl.text.trim(),
        'isPublic': _isPublic,
      });
      widget.ref.invalidate(teamsProvider);
      if (!mounted) return;
      final body = resp.data;
      final team = body is Map<String, dynamic> && body['data'] is Map
          ? body['data'] as Map<String, dynamic>
          : body as Map<String, dynamic>;
      Navigator.pop(context);
      context.push('/teams/${team['id']}');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not create team: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}

class _TeamCard extends StatelessWidget {
  final TeamModel team;
  const _TeamCard({required this.team});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: AppColors.grey200),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          radius: 26,
          backgroundImage:
              team.logoUrl != null ? NetworkImage(team.logoUrl!) : null,
          backgroundColor: AppColors.primarySurface,
          child: team.logoUrl == null
              ? Text(team.name[0].toUpperCase(),
                  style: const TextStyle(
                      color: AppColors.primary, fontWeight: FontWeight.bold))
              : null,
        ),
        title: Text(team.name,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        subtitle: Text(
          '${team.memberCount} members${team.teamElo != null ? ' · Level ${team.teamElo!.toStringAsFixed(1)}' : ''}',
          style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: team.isPublic ? AppColors.primarySurface : AppColors.grey100,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(
            (team.isPublic ? 'Open' : 'Invite').tr(context),
            style: TextStyle(
              color: team.isPublic ? AppColors.primary : AppColors.textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        onTap: () => context.push('/teams/${team.id}'),
      ),
    );
  }
}
