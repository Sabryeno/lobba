import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../../shared/widgets/lobba_app_bar.dart';

class TeamDetailScreen extends ConsumerWidget {
  final String id;
  const TeamDetailScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: LobbaAppBar(title: 'Team'.tr(context)),
      body: Center(child: Text('Team Detail — Coming Soon'.tr(context))),
    );
  }
}
