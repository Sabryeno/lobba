import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Editable player preferences shown on the profile (best hand, court position,
/// match type, preferred time). Persisted so edits survive a relaunch.
class PlayerPrefs {
  final String bestHand;       // Right | Left | Both
  final String courtPosition;  // Left side | Right side | Both
  final String matchType;      // Competitive | Casual | Both
  final String preferredTime;  // All day | Morning | Evening
  const PlayerPrefs({
    required this.bestHand,
    required this.courtPosition,
    required this.matchType,
    required this.preferredTime,
  });

  PlayerPrefs copyWith({String? bestHand, String? courtPosition, String? matchType, String? preferredTime}) => PlayerPrefs(
        bestHand: bestHand ?? this.bestHand,
        courtPosition: courtPosition ?? this.courtPosition,
        matchType: matchType ?? this.matchType,
        preferredTime: preferredTime ?? this.preferredTime,
      );

  static const initial = PlayerPrefs(bestHand: 'Right', courtPosition: 'Left side', matchType: 'Competitive', preferredTime: 'All day');
}

final playerPrefsProvider = NotifierProvider<PlayerPrefsNotifier, PlayerPrefs>(PlayerPrefsNotifier.new);

class PlayerPrefsNotifier extends Notifier<PlayerPrefs> {
  @override
  PlayerPrefs build() {
    _load();
    return PlayerPrefs.initial;
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      state = PlayerPrefs(
        bestHand: p.getString('pref_hand') ?? PlayerPrefs.initial.bestHand,
        courtPosition: p.getString('pref_court') ?? PlayerPrefs.initial.courtPosition,
        matchType: p.getString('pref_match') ?? PlayerPrefs.initial.matchType,
        preferredTime: p.getString('pref_time') ?? PlayerPrefs.initial.preferredTime,
      );
    } catch (_) {}
  }

  Future<void> save(PlayerPrefs prefs) async {
    state = prefs;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('pref_hand', prefs.bestHand);
      await p.setString('pref_court', prefs.courtPosition);
      await p.setString('pref_match', prefs.matchType);
      await p.setString('pref_time', prefs.preferredTime);
    } catch (_) {}
  }
}
