import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// The player's Lobba wallet — a balance plus saved cards stored ONLY as masked
/// labels (e.g. "Visa •••• 4242"). Full card numbers and CVV are never stored.
class WalletState {
  final int balance; // EGP
  final List<String> cards; // masked labels
  const WalletState(this.balance, this.cards);
}

final walletProvider = NotifierProvider<WalletNotifier, WalletState>(WalletNotifier.new);

class WalletNotifier extends Notifier<WalletState> {
  @override
  WalletState build() {
    _load();
    return const WalletState(0, []);
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      state = WalletState(p.getInt('wallet_balance') ?? 0, p.getStringList('wallet_cards') ?? const []);
    } catch (_) {}
  }

  Future<void> _save() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('wallet_balance', state.balance);
      await p.setStringList('wallet_cards', state.cards);
    } catch (_) {}
  }

  /// Add a card — only the masked label is kept (never the full PAN/CVV).
  void addCard(String maskedLabel) {
    state = WalletState(state.balance, [...state.cards, maskedLabel]);
    _save();
  }

  void topUp(int amount) {
    state = WalletState(state.balance + amount, state.cards);
    _save();
  }

  void charge(int amount) {
    state = WalletState((state.balance - amount).clamp(0, 1 << 30), state.cards);
    _save();
  }
}
