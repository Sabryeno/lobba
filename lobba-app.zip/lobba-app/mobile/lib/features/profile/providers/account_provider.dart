import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../auth/providers/auth_provider.dart';

/// Editable account data (name, email, birth date). Name seeds from the signed
/// in user, then any edit overrides it and is shown everywhere the name appears.
class AccountData {
  final String name;
  final String email;
  final String birthDate; // dd/MM/yyyy, empty if unset
  const AccountData({required this.name, required this.email, required this.birthDate});

  AccountData copyWith({String? name, String? email, String? birthDate}) =>
      AccountData(name: name ?? this.name, email: email ?? this.email, birthDate: birthDate ?? this.birthDate);
}

final accountProvider = NotifierProvider<AccountNotifier, AccountData>(AccountNotifier.new);

class AccountNotifier extends Notifier<AccountData> {
  @override
  AccountData build() {
    final seeded = ref.watch(authStateProvider).valueOrNull?.name ?? 'Player';
    _load(seeded);
    return AccountData(name: seeded, email: 'ahmed@lobba.app', birthDate: '');
  }

  Future<void> _load(String seededName) async {
    try {
      final p = await SharedPreferences.getInstance();
      state = AccountData(
        name: p.getString('acct_name') ?? seededName,
        email: p.getString('acct_email') ?? 'ahmed@lobba.app',
        birthDate: p.getString('acct_birth') ?? '',
      );
    } catch (_) {}
  }

  Future<void> save(AccountData data) async {
    state = data;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('acct_name', data.name);
      await p.setString('acct_email', data.email);
      await p.setString('acct_birth', data.birthDate);
    } catch (_) {}
  }
}
