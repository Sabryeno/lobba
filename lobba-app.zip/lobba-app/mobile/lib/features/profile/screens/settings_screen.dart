import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../auth/providers/locale_provider.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../auth/providers/auth_provider.dart';
import '../providers/account_provider.dart';
import 'wallet_screens.dart';
import 'account_edit_screen.dart';

void _open(BuildContext c, Widget screen) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => screen));

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    return PushScaffold(
      title: 'Settings'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 18, 22, 24), children: [
        Container(
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Column(children: [
            _row(t, 'Account & phone'.tr(context), trailing: Icon(Icons.chevron_right_rounded, size: 16, color: t.ink3), onTap: () => _open(context, const _AccountScreen())),
            _div(t),
            _row(t, 'Language'.tr(context), trailing: Text('English · العربية', style: TextStyle(fontSize: 11.5, color: t.ink3)), onTap: () => _open(context, const _LanguageScreen())),
            _div(t),
            _row(t, 'Notifications'.tr(context), trailing: Icon(Icons.chevron_right_rounded, size: 16, color: t.ink3), onTap: () => _open(context, const _NotificationSettingsScreen())),
            _div(t),
            _row(t, 'My wallet'.tr(context), trailing: Icon(Icons.chevron_right_rounded, size: 16, color: t.ink3), onTap: () => _open(context, const WalletScreen())),
          ]),
        ),
        const SizedBox(height: 14),
        Container(
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Column(children: [
            GestureDetector(onTap: () => ref.read(authStateProvider.notifier).logout(), child: _rowText(t, 'Log out'.tr(context), color: t.clay)),
            _div(t),
            GestureDetector(onTap: () => context.push(AppRoutes.deleteAccount), child: Row(children: [
              Expanded(child: _rowText(t, 'Delete account & data'.tr(context), color: t.clay, icon: Icons.delete_outline_rounded)),
              Padding(padding: const EdgeInsets.only(right: 15), child: Icon(Icons.chevron_right_rounded, size: 16, color: t.ink3)),
            ])),
          ]),
        ),
        const SizedBox(height: 10),
        Center(child: Text('Deleting removes your profile, level, bookings & chats permanently.'.tr(context), textAlign: TextAlign.center, style: TextStyle(fontSize: 9.5, color: t.ink3))),
      ]),
    );
  }

  Widget _row(LobbaTokens t, String label, {required Widget trailing, VoidCallback? onTap}) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12), child: Row(children: [
          Expanded(child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: t.ink))), trailing,
        ])),
      );
  Widget _rowText(LobbaTokens t, String label, {required Color color, IconData? icon}) => Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15), child: Row(children: [
        if (icon != null) ...[Icon(icon, size: 17, color: color), const SizedBox(width: 10)],
        Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: color)),
      ]));
  Widget _div(LobbaTokens t) => Divider(height: 1, thickness: 1, color: t.line);
}

class DeleteAccountScreen extends ConsumerWidget {
  const DeleteAccountScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    return PushScaffold(
      title: 'Delete account',
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: Column(children: [
          SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
            onPressed: () async { await ref.read(authStateProvider.notifier).logout(); },
            style: ElevatedButton.styleFrom(backgroundColor: t.clay, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(99))),
            child: const Text('Delete my account', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          )),
          const SizedBox(height: 10),
          GestureDetector(onTap: () => context.pop(), child: Text('Cancel', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink2))),
        ]))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 20, 22, 24), children: [
        Center(child: Column(children: [
          Container(width: 64, height: 64, decoration: BoxDecoration(color: t.clay.withOpacity(.14), shape: BoxShape.circle), child: Icon(Icons.warning_amber_rounded, size: 30, color: t.clay)),
          const SizedBox(height: 14),
          Text('This can’t be undone', style: TextStyle(fontFamily: kSerif, fontSize: 19, fontWeight: FontWeight.w500, color: t.ink)),
          const SizedBox(height: 7),
          Text('Deleting your account permanently removes everything tied to it.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: t.ink2, height: 1.5)),
        ])),
        const SizedBox(height: 18),
        Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)), child: Column(children: [
          for (final s in ['Profile, photo & phone number', 'Level, ranking & match history', 'Bookings, friends, tribes & chats'])
            Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(children: [Icon(Icons.close_rounded, size: 15, color: t.clay), const SizedBox(width: 10), Expanded(child: Text(s, style: TextStyle(fontSize: 12, color: t.ink2)))])),
        ])),
        const SizedBox(height: 14),
        Container(padding: const EdgeInsets.all(12), alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)), child: Text('⭳  Export my data first', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.accent))),
      ]),
    );
  }
}

// ── Settings sub-screens ─────────────────────────────────────────────
Widget _card(LobbaTokens t, List<Widget> rows) => Container(
      decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
      child: Column(children: [
        for (var i = 0; i < rows.length; i++) ...[
          if (i > 0) Divider(height: 1, thickness: 1, color: t.line),
          rows[i],
        ]
      ]),
    );

class _AccountScreen extends ConsumerWidget {
  const _AccountScreen();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final a = ref.watch(accountProvider);
    Widget field(String label, String value) => Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13), child: Row(children: [
          Expanded(child: Text(label.tr(context), style: TextStyle(fontSize: 13, color: t.ink2))),
          Text(value, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
        ]));
    return PushScaffold(
      title: 'Account & phone'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 18, 22, 24), children: [
        _card(t, [
          field('Name', a.name),
          field('Date of birth', a.birthDate.isEmpty ? '—' : a.birthDate),
          field('Phone', '+20 100 123 4567'),
          field('Email', a.email),
          field('Member since', 'Jul 2026'),
        ]),
        const SizedBox(height: 14),
        GestureDetector(onTap: () => _open(context, const AccountEditScreen()), child: Container(
          padding: const EdgeInsets.all(14), alignment: Alignment.center,
          decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(14)),
          child: Text('Edit account'.tr(context), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.onAccent)),
        )),
      ]),
    );
  }
}

class _LanguageScreen extends ConsumerWidget {
  const _LanguageScreen();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final code = ref.watch(localeProvider).languageCode;
    Widget opt(String name, String sub, String value) => GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => ref.read(localeProvider.notifier).setLocale(Locale(value)),
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14), child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name.tr(context), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink)),
              Text(sub.tr(context), style: TextStyle(fontSize: 11, color: t.ink3)),
            ])),
            if (code == value) Icon(Icons.check_circle_rounded, size: 20, color: t.accent)
            else Icon(Icons.radio_button_unchecked_rounded, size: 20, color: t.line),
          ])),
        );
    return PushScaffold(
      title: 'Language'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 18, 22, 24), children: [
        _card(t, [opt('English', 'Left-to-right', 'en'), opt('العربية', 'من اليمين إلى اليسار', 'ar')]),
        const SizedBox(height: 12),
        Center(child: Text('Switching to العربية flips the whole app to right-to-left.'.tr(context), textAlign: TextAlign.center, style: TextStyle(fontSize: 10.5, color: t.ink3))),
      ]),
    );
  }
}

class _NotificationSettingsScreen extends StatefulWidget {
  const _NotificationSettingsScreen();
  @override
  State<_NotificationSettingsScreen> createState() => _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<_NotificationSettingsScreen> {
  final _v = {'Booking updates': true, 'Match invites': true, 'Tribe activity': true, 'Deals near me': false, 'Coach & academy news': false};
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Notifications'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 18, 22, 24), children: [
        _card(t, _v.keys.map((k) => Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 2), child: Row(children: [
          Expanded(child: Text(k.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: t.ink))),
          Switch(value: _v[k]!, activeColor: t.accent, onChanged: (x) => setState(() => _v[k] = x)),
        ]))).toList()),
      ]),
    );
  }
}

