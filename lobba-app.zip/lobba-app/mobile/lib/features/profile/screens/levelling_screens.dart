import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../../core/level/lobba_level.dart';
import '../../auth/providers/level_provider.dart';

void _open(BuildContext c, Widget s) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => s));

// ── Levelling hub ────────────────────────────────────────────────────────────
class LevellingHubScreen extends ConsumerWidget {
  const LevellingHubScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final pl = ref.watch(playerLevelProvider);
    return PushScaffold(
      title: 'Levelling'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        // your level summary
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(18)),
          child: Row(children: [
            Container(width: 64, height: 64, alignment: Alignment.center, decoration: BoxDecoration(color: t.onAccent.withOpacity(.15), shape: BoxShape.circle), child: Text(pl.level.toStringAsFixed(1), style: TextStyle(fontFamily: kSerif, fontSize: 24, fontWeight: FontWeight.w700, color: t.onAccent))),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${'Your level'.tr(context)} · ${bandName(context, pl.level)}', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.onAccent)),
              const SizedBox(height: 6),
              Row(children: [
                Icon(Icons.shield_outlined, size: 13, color: t.onAccent.withOpacity(.8)),
                const SizedBox(width: 5),
                Text('${'Reliability'.tr(context)} ${pl.reliability}%', style: TextStyle(fontSize: 11, color: t.onAccent.withOpacity(.85))),
              ]),
            ])),
          ]),
        ),
        const SizedBox(height: 18),
        Eyebrow('Find out more about your level'.tr(context)),
        const SizedBox(height: 10),
        _row(context, t, Icons.bar_chart_rounded, 'Level ranges'.tr(context), () => _open(context, const LevelRangesScreen())),
        const SizedBox(height: 9),
        _row(context, t, Icons.show_chart_rounded, 'Reliability & Variation'.tr(context), () => _open(context, const ReliabilityScreen())),
        const SizedBox(height: 20),
        Eyebrow('Change your level'.tr(context)),
        const SizedBox(height: 10),
        // raise — locked
        Opacity(opacity: .5, child: _row(context, t, Icons.trending_up_rounded, 'Raise your level'.tr(context), null, locked: true)),
        const SizedBox(height: 9),
        _row(context, t, Icons.trending_down_rounded, 'Lower your level'.tr(context), () => _open(context, const LowerLevelScreen())),
      ]),
    );
  }

  Widget _row(BuildContext c, LobbaTokens t, IconData ic, String label, VoidCallback? onTap, {bool locked = false}) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
          child: Row(children: [
            Container(width: 38, height: 38, decoration: BoxDecoration(color: t.surface2, shape: BoxShape.circle), child: Icon(ic, size: 18, color: t.accent)),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink))),
            Icon(locked ? Icons.info_outline_rounded : Icons.chevron_right_rounded, size: 18, color: t.ink3),
          ]),
        ),
      );
}

// ── Level ranges ─────────────────────────────────────────────────────────────
class LevelRangesScreen extends StatelessWidget {
  const LevelRangesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Level ranges'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 14, 22, 24), children: [
        Text('Levels range from 0 to 7. Levels 6–7 are reserved for elite and professional players.'.tr(context), style: TextStyle(fontSize: 12.5, color: t.ink2, height: 1.5)),
        const SizedBox(height: 16),
        ...kLevelBands.map((b) => Padding(padding: const EdgeInsets.only(bottom: 11), child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: t.headBg, borderRadius: BorderRadius.circular(16)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 30, height: 30, alignment: Alignment.center, decoration: BoxDecoration(color: t.gold, shape: BoxShape.circle), child: Text('${b.index}', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: t.headBg))),
              const SizedBox(width: 11),
              Expanded(child: Text('${b.name.tr(context)}: ${'Level'.tr(context)} ${b.range}', style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: t.headFg))),
            ]),
            const SizedBox(height: 9),
            Text(b.desc.tr(context), style: TextStyle(fontSize: 11.5, color: t.headFg.withOpacity(.8), height: 1.5)),
          ]),
        ))),
      ]),
    );
  }
}

// ── Reliability & Variation ──────────────────────────────────────────────────
class ReliabilityScreen extends ConsumerWidget {
  const ReliabilityScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final pl = ref.watch(playerLevelProvider);
    return PushScaffold(
      title: 'Reliability & Variation'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Reliability'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.ink)),
            Text('${pl.reliability}%', style: TextStyle(fontFamily: kSerif, fontSize: 18, fontWeight: FontWeight.w700, color: t.accent)),
          ]),
          const SizedBox(height: 10),
          ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: pl.reliability / 100, minHeight: 9, backgroundColor: t.surface2, valueColor: AlwaysStoppedAnimation(t.accent))),
        ])),
        const SizedBox(height: 16),
        Text('Reliability grows as you play competitive matches — the higher it is, the smaller your level swings.'.tr(context), style: TextStyle(fontSize: 12.5, color: t.ink2, height: 1.6)),
        const SizedBox(height: 12),
        Text('Only competitive matches change your level.'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
      ]),
    );
  }
}

// ── Lower your level ─────────────────────────────────────────────────────────
class LowerLevelScreen extends ConsumerStatefulWidget {
  const LowerLevelScreen({super.key});
  @override
  ConsumerState<LowerLevelScreen> createState() => _LowerLevelScreenState();
}

class _LowerLevelScreenState extends ConsumerState<LowerLevelScreen> {
  double? _pick;

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final current = ref.watch(playerLevelProvider).level;
    final options = [for (var v = 0.5; v <= 7.0; v += 0.5) v];
    return PushScaffold(
      title: 'Lower your level'.tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: _pick == null ? null : () {
            ref.read(playerLevelProvider.notifier).lower(_pick!);
            ScaffoldMessenger.of(context)..clearSnackBars()..showSnackBar(SnackBar(content: Text('Level lowered'.tr(context))));
            Navigator.of(context).pop();
          },
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, disabledBackgroundColor: t.line, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text('Change your level'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 14, 22, 24), children: [
        Text('You can only lower your level manually — raise it again by playing or a level test.'.tr(context), style: TextStyle(fontSize: 12, color: t.ink2, height: 1.5)),
        const SizedBox(height: 16),
        ...options.map((v) {
          final locked = v > current;
          final on = _pick == v;
          return Padding(padding: const EdgeInsets.only(bottom: 9), child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: locked ? null : () => setState(() => _pick = v),
            child: Opacity(opacity: locked ? .45 : 1, child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
              decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: on ? t.accent : t.line, width: on ? 1.5 : 1)),
              child: Row(children: [
                Container(width: 34, height: 34, alignment: Alignment.center, decoration: BoxDecoration(color: t.gold.withOpacity(.9), shape: BoxShape.circle), child: Text(v.toStringAsFixed(1), style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: t.headBg))),
                const SizedBox(width: 12),
                Expanded(child: Text(bandName(context, v), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink))),
                Icon(locked ? Icons.lock_outline_rounded : (on ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded), size: 20, color: locked ? t.ink3 : (on ? t.accent : t.line)),
              ]),
            )),
          ));
        }),
      ]),
    );
  }
}
