import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../providers/player_prefs_provider.dart';

/// Edit the player preferences shown on the profile — saved to the prefs
/// provider so the profile reflects them immediately.
class EditProfileScreen extends ConsumerStatefulWidget {
  const EditProfileScreen({super.key});
  @override
  ConsumerState<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends ConsumerState<EditProfileScreen> {
  late PlayerPrefs _p;

  @override
  void initState() {
    super.initState();
    _p = ref.read(playerPrefsProvider);
  }

  void _save() {
    ref.read(playerPrefsProvider.notifier).save(_p);
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(SnackBar(content: Text('Saved'.tr(context))));
    context.pop();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Edit profile'.tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: _save,
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text('Save changes'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        Eyebrow('Player preferences'.tr(context)),
        const SizedBox(height: 12),
        _group(t, '✋ ${'Best hand'.tr(context)}', const ['Right', 'Left', 'Both'], _p.bestHand, (v) => setState(() => _p = _p.copyWith(bestHand: v))),
        const SizedBox(height: 16),
        _group(t, '📍 ${'Court position'.tr(context)}', const ['Left side', 'Right side', 'Both'], _p.courtPosition, (v) => setState(() => _p = _p.copyWith(courtPosition: v))),
        const SizedBox(height: 16),
        _group(t, '🏅 ${'Match type'.tr(context)}', const ['Competitive', 'Casual', 'Both'], _p.matchType, (v) => setState(() => _p = _p.copyWith(matchType: v))),
        const SizedBox(height: 16),
        _group(t, '🌅 ${'Preferred time to play'.tr(context)}', const ['All day', 'Morning', 'Evening'], _p.preferredTime, (v) => setState(() => _p = _p.copyWith(preferredTime: v))),
      ]),
    );
  }

  Widget _group(LobbaTokens t, String label, List<String> options, String value, ValueChanged<String> onPick) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: t.ink)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: options.map((o) {
          final on = o == value;
          return GestureDetector(
            onTap: () => onPick(o),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
              decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(99), border: Border.all(color: on ? t.accent : t.line)),
              child: Text(o.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: on ? t.onAccent : t.ink2)),
            ),
          );
        }).toList()),
      ]);
}
