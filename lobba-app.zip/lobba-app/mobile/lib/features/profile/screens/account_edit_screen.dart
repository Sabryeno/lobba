import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../providers/account_provider.dart';

/// Edit account data — name, birth date, email. Phone is shown read-only.
class AccountEditScreen extends ConsumerStatefulWidget {
  const AccountEditScreen({super.key});
  @override
  ConsumerState<AccountEditScreen> createState() => _AccountEditScreenState();
}

class _AccountEditScreenState extends ConsumerState<AccountEditScreen> {
  late final TextEditingController _name;
  late final TextEditingController _email;
  String _birth = '';

  @override
  void initState() {
    super.initState();
    final a = ref.read(accountProvider);
    _name = TextEditingController(text: a.name);
    _email = TextEditingController(text: a.email);
    _birth = a.birthDate;
  }

  @override
  void dispose() { _name.dispose(); _email.dispose(); super.dispose(); }

  Future<void> _pickBirth() async {
    final now = DateTime.now();
    final d = await showDatePicker(context: context, initialDate: DateTime(now.year - 25), firstDate: DateTime(now.year - 80), lastDate: now);
    if (d != null) setState(() => _birth = '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}');
  }

  void _save() {
    ref.read(accountProvider.notifier).save(AccountData(name: _name.text.trim().isEmpty ? ref.read(accountProvider).name : _name.text.trim(), email: _email.text.trim(), birthDate: _birth));
    ScaffoldMessenger.of(context)..clearSnackBars()..showSnackBar(SnackBar(content: Text('Saved'.tr(context))));
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Edit account'.tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: _save,
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text('Save changes'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        _label(t, 'Name'.tr(context)),
        _field(t, _name, 'Ahmed Mohamed'),
        const SizedBox(height: 16),
        _label(t, 'Date of birth'.tr(context)),
        GestureDetector(onTap: _pickBirth, child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
          child: Row(children: [
            Icon(Icons.calendar_today_outlined, size: 16, color: t.accent),
            const SizedBox(width: 11),
            Text(_birth.isEmpty ? 'DD/MM/YYYY' : _birth, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: _birth.isEmpty ? t.ink3 : t.ink)),
          ]),
        )),
        const SizedBox(height: 16),
        _label(t, 'Email'.tr(context)),
        _field(t, _email, 'you@lobba.app', kb: TextInputType.emailAddress),
        const SizedBox(height: 16),
        // phone read-only
        _label(t, 'Phone'.tr(context)),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
          decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
          child: Row(children: [
            Expanded(child: Text('+20 100 123 4567', style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink3))),
            Icon(Icons.lock_outline_rounded, size: 15, color: t.ink3),
          ]),
        ),
        const SizedBox(height: 6),
        Text('Phone number can’t be changed here.'.tr(context), style: TextStyle(fontSize: 10, color: t.ink3)),
      ]),
    );
  }

  Widget _label(LobbaTokens t, String s) => Padding(padding: const EdgeInsets.only(bottom: 7), child: Eyebrow(s));
  Widget _field(LobbaTokens t, TextEditingController c, String hint, {TextInputType? kb}) => TextField(
        controller: c, keyboardType: kb,
        style: TextStyle(color: t.ink, fontSize: 14),
        decoration: InputDecoration(
          hintText: hint, hintStyle: TextStyle(color: t.ink3), filled: true, fillColor: t.surface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.accent, width: 1.5)),
        ),
      );
}
