import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../../core/level/lobba_level.dart';

/// Public player profile — history, rating, win/lose record + level stats.
/// Built entirely from plain widgets (no CustomPaint) so it always renders.
class PlayerDetailScreen extends ConsumerWidget {
  final String playerId;
  const PlayerDetailScreen({super.key, required this.playerId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final name = playerId.isNotEmpty ? playerId : 'Sara Mostafa';
    return Scaffold(
      backgroundColor: t.bg,
      body: ListView(padding: EdgeInsets.zero, children: [
        // green header
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 6, 18, 20),
          child: Column(children: [
            Align(alignment: Alignment.centerLeft, child: GestureDetector(onTap: () => context.pop(), child: Icon(Icons.chevron_left_rounded, color: t.headFg, size: 24))),
            const SizedBox(height: 8),
            CircleAvatar(radius: 42, backgroundColor: t.headFg, child: Text(name[0], style: TextStyle(fontFamily: kSerif, fontSize: 32, color: t.headBg))),
            const SizedBox(height: 11),
            Text(name, style: TextStyle(fontFamily: kSerif, fontSize: 22, fontWeight: FontWeight.w500, color: t.headFg)),
            const SizedBox(height: 4),
            Text('Zamalek, Cairo · played recently', style: TextStyle(fontSize: 11.5, color: t.headFg.withOpacity(.85))),
            const SizedBox(height: 11),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              LPill(bandName(context, 4.0), bg: t.headFg, fg: t.headBg),
              const SizedBox(width: 7),
              LPill(levelText(context, 4.0), bg: t.headChipBg, fg: t.headFg),
            ]),
          ]),
        ))),
        const SizedBox(height: 16),
        // stats
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          _stat(t, '128', 'Matches'.tr(context)), const SizedBox(width: 9),
          _stat(t, '71%', 'Win rate'.tr(context)), const SizedBox(width: 9),
          _stat(t, '#38', 'Cairo'),
        ])),
        const SizedBox(height: 11),
        // preferred side + last city
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          Expanded(child: _fact(t, Icons.back_hand_outlined, 'Prefers'.tr(context), 'Right side'.tr(context))),
          const SizedBox(width: 9),
          Expanded(child: _fact(t, Icons.place_outlined, 'Recently played'.tr(context), 'New Cairo')),
        ])),
        const SizedBox(height: 9),
        // win / tie / lose record
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
          child: Row(children: [
            _record(t, '91', 'Won'.tr(context), t.sage), _rvl(t), _record(t, '6', 'Tied'.tr(context), t.gold), _rvl(t), _record(t, '31', 'Lost'.tr(context), t.clay),
          ]),
        )),
        const SizedBox(height: 13),
        // level trend — simple bar chart (rising)
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Level over 6 months'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
              LPill('Rising · +67', bg: t.sage.withOpacity(.16), fg: t.sage, icon: Icons.trending_up_rounded),
            ]),
            const SizedBox(height: 14),
            SizedBox(height: 74, child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              for (var i = 0; i < 6; i++) Expanded(child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                  Container(
                    height: 20.0 + i * 9.5,
                    decoration: BoxDecoration(
                      color: i == 5 ? t.accent : t.accentSoft,
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(5)),
                    ),
                  ),
                ]),
              )),
            ])),
            const SizedBox(height: 6),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'].map((m) => Text(m, style: TextStyle(fontSize: 8.5, color: t.ink3))).toList()),
          ]),
        )),
        const SizedBox(height: 14),
        // recent form
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          Eyebrow('Recent form'.tr(context)),
          const SizedBox(width: 10),
          ...['W', 'W', 'L', 'W', 'W'].map((r) => Padding(padding: const EdgeInsets.only(right: 5), child: Container(
            width: 22, height: 22, alignment: Alignment.center,
            decoration: BoxDecoration(color: (r == 'W' ? t.sage : t.clay).withOpacity(.18), borderRadius: BorderRadius.circular(6)),
            child: Text(r, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: r == 'W' ? t.sage : t.clay)),
          ))),
        ])),
        const SizedBox(height: 22),
        // actions — fixed-height buttons (inline, so nothing can stretch them)
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          Expanded(child: SizedBox(height: 48, child: OutlinedButton(
            onPressed: () => _snack(context, 'Friend request sent to $name'),
            style: OutlinedButton.styleFrom(side: BorderSide(color: t.accent), shape: const StadiumBorder()),
            child: Text('Add friend'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.accent)),
          ))),
          const SizedBox(width: 10),
          Expanded(child: SizedBox(height: 48, child: ElevatedButton(
            onPressed: () => _snack(context, 'Invited $name to play'),
            style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: const StadiumBorder()),
            child: Text('Invite to play'.tr(context), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ))),
        ])),
        const SizedBox(height: 26),
      ]),
    );
  }

  void _snack(BuildContext c, String msg) => ScaffoldMessenger.of(c)
    ..clearSnackBars()
    ..showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));

  Widget _stat(LobbaTokens t, String v, String l) => Expanded(child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
        child: Column(children: [
          Text(v, style: TextStyle(fontFamily: kSerif, fontSize: 19, fontWeight: FontWeight.w600, color: t.accent)),
          const SizedBox(height: 2),
          Text(l, style: TextStyle(fontSize: 9.5, color: t.ink3)),
        ]),
      ));

  Widget _fact(LobbaTokens t, IconData ic, String label, String value) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
        child: Row(children: [
          Icon(ic, size: 18, color: t.accent),
          const SizedBox(width: 9),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(fontSize: 9, color: t.ink3)),
            Text(value, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.ink), overflow: TextOverflow.ellipsis),
          ])),
        ]),
      );

  Widget _record(LobbaTokens t, String v, String l, Color c) => Expanded(child: Column(children: [
        Text(v, style: TextStyle(fontFamily: kSerif, fontSize: 18, fontWeight: FontWeight.w600, color: c)),
        Text(l, style: TextStyle(fontSize: 9.5, color: t.ink3)),
      ]));

  Widget _rvl(LobbaTokens t) => Container(width: 1, height: 26, color: t.line);
}
