import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../providers/wallet_provider.dart';

void _open(BuildContext c, Widget s) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => s));

// ── My Wallet ────────────────────────────────────────────────────────────────
class WalletScreen extends ConsumerWidget {
  const WalletScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final w = ref.watch(walletProvider);
    return PushScaffold(
      title: 'My wallet'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        // balance card
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(20)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Wallet balance'.tr(context), style: TextStyle(fontSize: 11.5, color: t.onAccent.withOpacity(.8))),
              Icon(Icons.account_balance_wallet_rounded, size: 20, color: t.onAccent.withOpacity(.9)),
            ]),
            const SizedBox(height: 10),
            Text('EGP ${w.balance}', style: TextStyle(fontFamily: kSerif, fontSize: 34, fontWeight: FontWeight.w700, color: t.onAccent)),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, height: 44, child: ElevatedButton(
              onPressed: () => _open(context, const TopUpScreen()),
              style: ElevatedButton.styleFrom(backgroundColor: t.onAccent, foregroundColor: t.accent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              child: Text('Top up'.tr(context), style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700)),
            )),
          ]),
        ),
        const SizedBox(height: 18),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Eyebrow('Cards'.tr(context)),
          GestureDetector(onTap: () => _open(context, const AddCardScreen()), child: Text('+ ${'Add card'.tr(context)}', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.accent))),
        ]),
        const SizedBox(height: 10),
        if (w.cards.isEmpty)
          Container(padding: const EdgeInsets.all(16), alignment: Alignment.center, decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)), child: Text('No cards yet'.tr(context), style: TextStyle(fontSize: 12, color: t.ink3)))
        else
          ...w.cards.map((c) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
            child: Row(children: [
              Icon(Icons.credit_card_rounded, size: 20, color: t.accent),
              const SizedBox(width: 12),
              Expanded(child: Text(c, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink))),
              Icon(Icons.lock_rounded, size: 14, color: t.ink3),
            ]),
          ))),
        const SizedBox(height: 8),
        Text('Card details are encrypted for your protection.'.tr(context), style: TextStyle(fontSize: 10, color: t.ink3)),
      ]),
    );
  }
}

// ── Add card ─────────────────────────────────────────────────────────────────
class AddCardScreen extends ConsumerStatefulWidget {
  const AddCardScreen({super.key});
  @override
  ConsumerState<AddCardScreen> createState() => _AddCardScreenState();
}

class _AddCardScreenState extends ConsumerState<AddCardScreen> {
  final _num = TextEditingController();
  final _exp = TextEditingController();
  final _cvv = TextEditingController();
  final _name = TextEditingController();

  @override
  void dispose() { _num.dispose(); _exp.dispose(); _cvv.dispose(); _name.dispose(); super.dispose(); }

  String _brand(String digits) {
    if (digits.startsWith('4')) return 'Visa';
    if (digits.startsWith('5')) return 'Mastercard';
    if (digits.startsWith('3')) return 'Amex';
    return 'Card';
  }

  void _save() {
    final digits = _num.text.replaceAll(RegExp(r'\D'), '');
    if (digits.length < 12) {
      ScaffoldMessenger.of(context)..clearSnackBars()..showSnackBar(SnackBar(content: Text('Card number'.tr(context))));
      return;
    }
    final last4 = digits.substring(digits.length - 4);
    // Store ONLY a masked label — never the full number or the CVV.
    ref.read(walletProvider.notifier).addCard('${_brand(digits)} •••• $last4');
    ScaffoldMessenger.of(context)..clearSnackBars()..showSnackBar(SnackBar(content: Text('Card added'.tr(context))));
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Add card'.tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: _save,
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text('Save card'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        _label(t, 'Card number'.tr(context)),
        _field(t, _num, '1234 5678 9012 3456', kb: TextInputType.number, max: 19, formatters: [_CardNumberFormatter()]),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_label(t, 'Expiry'.tr(context)), _field(t, _exp, 'MM/YY', kb: TextInputType.number, max: 5, formatters: [_ExpiryFormatter()])])),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_label(t, 'CVV'.tr(context)), _field(t, _cvv, '•••', kb: TextInputType.number, max: 4, obscure: true)])),
        ]),
        const SizedBox(height: 14),
        _label(t, 'Cardholder name'.tr(context)),
        _field(t, _name, 'AHMED MOHAMED'),
        const SizedBox(height: 14),
        Row(children: [
          Icon(Icons.lock_rounded, size: 14, color: t.ink3),
          const SizedBox(width: 8),
          Expanded(child: Text('Card details are encrypted for your protection.'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink3))),
        ]),
      ]),
    );
  }

  Widget _label(LobbaTokens t, String s) => Padding(padding: const EdgeInsets.only(bottom: 7), child: Eyebrow(s));
  Widget _field(LobbaTokens t, TextEditingController c, String hint, {TextInputType? kb, int? max, bool obscure = false, List<TextInputFormatter>? formatters}) => TextField(
        controller: c, keyboardType: kb, obscureText: obscure, maxLength: max, inputFormatters: formatters,
        style: TextStyle(color: t.ink, fontSize: 14, letterSpacing: obscure ? 3 : 0.5),
        decoration: InputDecoration(
          hintText: hint, hintStyle: TextStyle(color: t.ink3), counterText: '', filled: true, fillColor: t.surface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.accent, width: 1.5)),
        ),
      );
}

// ── Top up ───────────────────────────────────────────────────────────────────
class TopUpScreen extends ConsumerStatefulWidget {
  final int initialMethod; // 0 saved card · 1 Apple Pay · 2 Google Pay
  const TopUpScreen({super.key, this.initialMethod = 0});
  @override
  ConsumerState<TopUpScreen> createState() => _TopUpScreenState();
}

class _TopUpScreenState extends ConsumerState<TopUpScreen> {
  int _amount = 250;
  late int _method = widget.initialMethod; // 0 saved card · 1 Apple Pay · 2 Google Pay

  void _pay() {
    ref.read(walletProvider.notifier).topUp(_amount);
    ScaffoldMessenger.of(context)..clearSnackBars()..showSnackBar(SnackBar(content: Text('Wallet topped up'.tr(context))));
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final w = ref.watch(walletProvider);
    final card = w.cards.isNotEmpty ? w.cards.first : null;
    return PushScaffold(
      title: 'Top up wallet'.tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: _pay,
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text('${'Top up'.tr(context)} · EGP $_amount', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        Text('Add money to your Lobba wallet'.tr(context), style: TextStyle(fontSize: 12, color: t.ink2)),
        const SizedBox(height: 14),
        Eyebrow('Amount'.tr(context)),
        const SizedBox(height: 10),
        Wrap(spacing: 9, runSpacing: 9, children: [100, 250, 500, 1000].map((a) {
          final on = a == _amount;
          return GestureDetector(onTap: () => setState(() => _amount = a), child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: on ? t.accent : t.line)),
            child: Text('EGP $a', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: on ? t.onAccent : t.ink)),
          ));
        }).toList()),
        const SizedBox(height: 20),
        Eyebrow('Pay with'.tr(context)),
        const SizedBox(height: 10),
        _payOption(t, 0, Icons.credit_card_rounded, card ?? 'Saved card'.tr(context), enabled: card != null),
        const SizedBox(height: 9),
        _payOption(t, 1, Icons.apple, 'Apple Pay'),
        const SizedBox(height: 9),
        _payOption(t, 2, Icons.g_mobiledata_rounded, 'Google Pay'),
        if (card == null) ...[
          const SizedBox(height: 10),
          GestureDetector(onTap: () => _open(context, const AddCardScreen()), child: Text('+ ${'Add card'.tr(context)}', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.accent))),
        ],
      ]),
    );
  }

  Widget _payOption(LobbaTokens t, int i, IconData ic, String label, {bool enabled = true}) {
    final on = _method == i;
    return GestureDetector(
      onTap: enabled ? () => setState(() => _method = i) : null,
      child: Opacity(opacity: enabled ? 1 : .5, child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: on ? t.accent : t.line, width: on ? 1.5 : 1)),
        child: Row(children: [
          Icon(ic, size: 22, color: t.ink),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink))),
          Icon(on ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded, size: 20, color: on ? t.accent : t.line),
        ]),
      )),
    );
  }
}

// Formats card number as groups of 4.
class _CardNumberFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldV, TextEditingValue newV) {
    final digits = newV.text.replaceAll(RegExp(r'\D'), '');
    final buf = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i > 0 && i % 4 == 0) buf.write(' ');
      buf.write(digits[i]);
    }
    return TextEditingValue(text: buf.toString(), selection: TextSelection.collapsed(offset: buf.length));
  }
}

// Formats expiry as MM/YY.
class _ExpiryFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldV, TextEditingValue newV) {
    final digits = newV.text.replaceAll(RegExp(r'\D'), '');
    final buf = StringBuffer();
    for (var i = 0; i < digits.length && i < 4; i++) {
      if (i == 2) buf.write('/');
      buf.write(digits[i]);
    }
    return TextEditingValue(text: buf.toString(), selection: TextSelection.collapsed(offset: buf.length));
  }
}
