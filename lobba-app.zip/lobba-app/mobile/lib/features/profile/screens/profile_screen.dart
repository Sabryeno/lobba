import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/providers/theme_mode_provider.dart';
import '../../../core/providers/profile_photo_provider.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/level/lobba_level.dart';
import '../../../features/auth/providers/auth_provider.dart';
import '../../../features/auth/providers/level_provider.dart';
import '../providers/player_prefs_provider.dart';
import '../providers/account_provider.dart';
import 'levelling_screens.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final dark = ref.watch(themeModeProvider) == ThemeMode.dark;
    final name = ref.watch(accountProvider).name;
    final photo = ref.watch(profilePhotoProvider);
    final pl = ref.watch(playerLevelProvider);
    final prefs = ref.watch(playerPrefsProvider);

    return Container(
      color: t.bg,
      child: ListView(
        padding: const EdgeInsets.only(bottom: 120),
        children: [
          // header
          Container(
            color: t.accentSoft,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(22, 14, 22, 22),
                child: Column(children: [
                  GestureDetector(
                    onTap: () async {
                      final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 600);
                      if (x != null) ref.read(profilePhotoProvider.notifier).state = x.path;
                    },
                    child: Stack(children: [
                      CircleAvatar(
                        radius: 37, backgroundColor: t.accent,
                        backgroundImage: photo != null ? FileImage(File(photo)) : null,
                        child: photo == null ? Text(name.isNotEmpty ? name[0] : 'A', style: TextStyle(fontFamily: kSerif, fontSize: 30, color: t.onAccent)) : null,
                      ),
                      Positioned(right: 0, bottom: 0, child: Container(
                        width: 24, height: 24,
                        decoration: BoxDecoration(color: t.surface, shape: BoxShape.circle, border: Border.all(color: t.bg, width: 2)),
                        child: Icon(Icons.camera_alt_rounded, size: 12, color: t.accent),
                      )),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  Text(name, style: TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w500, color: t.ink)),
                  const SizedBox(height: 9),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    _chip(t, levelText(context, pl.level), filled: true),
                    const SizedBox(width: 7),
                    _chip(t, bandName(context, pl.level), filled: false),
                  ]),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 18),
          // stats
          Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
            _stat(t, '0', 'Wins'.tr(context)), const SizedBox(width: 9),
            _stat(t, '0%', 'Win rate'.tr(context)), const SizedBox(width: 9),
            _stat(t, '0', 'Hours'.tr(context)),
          ])),
          const SizedBox(height: 14),
          // standing card
          Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Container(
            padding: const EdgeInsets.fromLTRB(18, 15, 18, 15),
            decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(18)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('YOUR STANDING'.tr(context), style: TextStyle(fontSize: 10, letterSpacing: 1.4, color: t.onAccent.withOpacity(.7))),
              const SizedBox(height: 11),
              Row(children: [
                _standing(t, '—', 'National'.tr(context)),
                _vline(t),
                _standing(t, '—', 'Cairo'),
                _vline(t),
                _standing(t, '—', 'This week'.tr(context)),
              ]),
            ]),
          )),
          const SizedBox(height: 16),
          // level progression
          Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: GestureDetector(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const LevellingHubScreen())),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Level progression'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.ink)),
                  Row(children: [Text('${'Level'.tr(context)} ${pl.level.toStringAsFixed(1)}', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.accent)), Icon(Icons.chevron_right_rounded, size: 16, color: t.ink3)]),
                ]),
                const SizedBox(height: 14),
                SizedBox(height: 60, child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  for (final h in const [0.35, 0.5, 0.45, 0.7, 0.6, 0.85]) Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Container(height: 55 * h, decoration: BoxDecoration(color: h >= 0.85 ? t.accent : t.accentSoft, borderRadius: const BorderRadius.vertical(top: Radius.circular(4)))))),
                ])),
                const SizedBox(height: 6),
                Text('${'Reliability'.tr(context)} ${pl.reliability}%', style: TextStyle(fontSize: 10, color: t.ink3)),
              ]),
            ),
          )),
          const SizedBox(height: 14),
          // player preferences
          Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 0), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Eyebrow('Player preferences'.tr(context)),
            GestureDetector(onTap: () => context.push(AppRoutes.editProfile), child: Text('Edit'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.accent))),
          ])),
          const SizedBox(height: 10),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Column(children: [
            Row(children: [
              _pref(t, '✋', 'Best hand'.tr(context), prefs.bestHand.tr(context)),
              const SizedBox(width: 9),
              _pref(t, '📍', 'Court position'.tr(context), prefs.courtPosition.tr(context)),
            ]),
            const SizedBox(height: 9),
            Row(children: [
              _pref(t, '🏅', 'Match type'.tr(context), prefs.matchType.tr(context)),
              const SizedBox(width: 9),
              _pref(t, '🌅', 'Preferred time to play'.tr(context), prefs.preferredTime.tr(context)),
            ]),
          ])),
          const SizedBox(height: 18),
          // menu
          Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Container(
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
            child: Column(children: [
              _menu(t, Icons.people_outline_rounded, 'Friends & Tribe'.tr(context), () => context.push(AppRoutes.friends)),
              _div(t),
              _menu(t, Icons.calendar_today_outlined, 'My bookings'.tr(context), () => context.push(AppRoutes.myBookings)),
              _div(t),
              _menu(t, Icons.settings_outlined, 'Settings'.tr(context), () => context.push(AppRoutes.settings)),
              _div(t),
              _menu(t, Icons.bar_chart_rounded, 'Levelling'.tr(context), () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const LevellingHubScreen()))),
              _div(t),
              _menu(t, Icons.emoji_events_outlined, 'Rankings'.tr(context), () => context.push(AppRoutes.leaderboard)),
              _div(t),
              _menu(t, Icons.insights_outlined, 'Find your level'.tr(context), () => context.push(AppRoutes.assessment)),
              _div(t),
              // dark mode toggle
              Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 6), child: Row(children: [
                Icon(Icons.dark_mode_outlined, size: 18, color: t.accent),
                const SizedBox(width: 12),
                Expanded(child: Text('Dark mode'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: t.ink))),
                Switch(value: dark, activeColor: t.accent, onChanged: (_) => ref.read(themeModeProvider.notifier).toggle()),
              ])),
            ]),
          )),
          const SizedBox(height: 14),
          // logout
          Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: GestureDetector(
            onTap: () => ref.read(authStateProvider.notifier).logout(),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
              decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
              child: Text('Log out'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.clay)),
            ),
          )),
        ],
      ),
    );
  }

  Widget _chip(LobbaTokens t, String s, {required bool filled}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(color: filled ? t.accent : t.surface, borderRadius: BorderRadius.circular(99)),
        child: Text(s, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: filled ? t.onAccent : t.ink2)),
      );

  Widget _pref(LobbaTokens t, String emoji, String label, String value) => Expanded(child: Container(
        height: 92,
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(emoji, style: const TextStyle(fontSize: 18)),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9.5, color: t.ink3)),
            Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: t.ink)),
          ]),
        ]),
      ));

  Widget _playmate(BuildContext context, LobbaTokens t, String name, double lvl, int common) => GestureDetector(
        onTap: () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', name)),
        child: Container(
          width: 130,
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          clipBehavior: Clip.antiAlias,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(height: 70, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [t.accentSoft, t.surface2])), alignment: Alignment.center, child: Text(name[0], style: TextStyle(fontFamily: kSerif, fontSize: 26, color: t.accent))),
            Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: t.ink)),
              Text('${'Level'.tr(context)} ${lvl.toStringAsFixed(1)}', style: TextStyle(fontSize: 10.5, color: t.accent)),
              Text('$common ${'matches in common'.tr(context)}', style: TextStyle(fontSize: 9, color: t.ink3)),
            ])),
          ]),
        ),
      );

  Widget _stat(LobbaTokens t, String v, String l) => Expanded(child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)),
        child: Column(children: [
          Text(v, style: TextStyle(fontFamily: kSerif, fontSize: 20, fontWeight: FontWeight.w600, color: t.accent)),
          const SizedBox(height: 2),
          Text(l, style: TextStyle(fontSize: 10, color: t.ink3)),
        ]),
      ));

  Widget _standing(LobbaTokens t, String v, String l) => Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
        Text(v, textAlign: TextAlign.center, style: TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w600, color: t.onAccent)),
        const SizedBox(height: 1),
        Text(l, textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: t.onAccent.withOpacity(.7))),
      ]));

  Widget _vline(LobbaTokens t) => Container(width: 1, height: 34, color: t.onAccent.withOpacity(.22));

  Widget _menu(LobbaTokens t, IconData ic, String label, VoidCallback onTap) => InkWell(
        onTap: onTap,
        child: Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14), child: Row(children: [
          Icon(ic, size: 18, color: t.accent),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: t.ink))),
          Icon(Icons.chevron_right_rounded, size: 18, color: t.ink3),
        ])),
      );

  Widget _div(LobbaTokens t) => Divider(height: 1, thickness: 1, color: t.line);
}
