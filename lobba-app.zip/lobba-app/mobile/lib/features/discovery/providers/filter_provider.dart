import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'filter_provider.freezed.dart';

enum CourtTypeFilter { all, indoor, outdoor }

@freezed
class CourtFilter with _$CourtFilter {
  const factory CourtFilter({
    @Default(CourtTypeFilter.all) CourtTypeFilter type,
    double? maxPrice,
    double? radiusKm,
    double? minRating,
  }) = _CourtFilter;
}

final activeFilterProvider =
    NotifierProvider<FilterNotifier, CourtFilter>(FilterNotifier.new);

class FilterNotifier extends Notifier<CourtFilter> {
  @override
  CourtFilter build() => const CourtFilter();

  void setType(CourtTypeFilter type) => state = state.copyWith(type: type);
  void setMaxPrice(double? price) => state = state.copyWith(maxPrice: price);
  void setRadiusKm(double? km) => state = state.copyWith(radiusKm: km);
  void setMinRating(double? r) => state = state.copyWith(minRating: r);
  void reset() => state = const CourtFilter();
}
