// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'filter_provider.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$CourtFilter {
  CourtTypeFilter get type => throw _privateConstructorUsedError;
  double? get maxPrice => throw _privateConstructorUsedError;
  double? get radiusKm => throw _privateConstructorUsedError;
  double? get minRating => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CourtFilterCopyWith<CourtFilter> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CourtFilterCopyWith<$Res> {
  factory $CourtFilterCopyWith(
          CourtFilter value, $Res Function(CourtFilter) then) =
      _$CourtFilterCopyWithImpl<$Res, CourtFilter>;
  @useResult
  $Res call(
      {CourtTypeFilter type,
      double? maxPrice,
      double? radiusKm,
      double? minRating});
}

/// @nodoc
class _$CourtFilterCopyWithImpl<$Res, $Val extends CourtFilter>
    implements $CourtFilterCopyWith<$Res> {
  _$CourtFilterCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? type = null,
    Object? maxPrice = freezed,
    Object? radiusKm = freezed,
    Object? minRating = freezed,
  }) {
    return _then(_value.copyWith(
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as CourtTypeFilter,
      maxPrice: freezed == maxPrice
          ? _value.maxPrice
          : maxPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      radiusKm: freezed == radiusKm
          ? _value.radiusKm
          : radiusKm // ignore: cast_nullable_to_non_nullable
              as double?,
      minRating: freezed == minRating
          ? _value.minRating
          : minRating // ignore: cast_nullable_to_non_nullable
              as double?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CourtFilterImplCopyWith<$Res>
    implements $CourtFilterCopyWith<$Res> {
  factory _$$CourtFilterImplCopyWith(
          _$CourtFilterImpl value, $Res Function(_$CourtFilterImpl) then) =
      __$$CourtFilterImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {CourtTypeFilter type,
      double? maxPrice,
      double? radiusKm,
      double? minRating});
}

/// @nodoc
class __$$CourtFilterImplCopyWithImpl<$Res>
    extends _$CourtFilterCopyWithImpl<$Res, _$CourtFilterImpl>
    implements _$$CourtFilterImplCopyWith<$Res> {
  __$$CourtFilterImplCopyWithImpl(
      _$CourtFilterImpl _value, $Res Function(_$CourtFilterImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? type = null,
    Object? maxPrice = freezed,
    Object? radiusKm = freezed,
    Object? minRating = freezed,
  }) {
    return _then(_$CourtFilterImpl(
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as CourtTypeFilter,
      maxPrice: freezed == maxPrice
          ? _value.maxPrice
          : maxPrice // ignore: cast_nullable_to_non_nullable
              as double?,
      radiusKm: freezed == radiusKm
          ? _value.radiusKm
          : radiusKm // ignore: cast_nullable_to_non_nullable
              as double?,
      minRating: freezed == minRating
          ? _value.minRating
          : minRating // ignore: cast_nullable_to_non_nullable
              as double?,
    ));
  }
}

/// @nodoc

class _$CourtFilterImpl implements _CourtFilter {
  const _$CourtFilterImpl(
      {this.type = CourtTypeFilter.all,
      this.maxPrice,
      this.radiusKm,
      this.minRating});

  @override
  @JsonKey()
  final CourtTypeFilter type;
  @override
  final double? maxPrice;
  @override
  final double? radiusKm;
  @override
  final double? minRating;

  @override
  String toString() {
    return 'CourtFilter(type: $type, maxPrice: $maxPrice, radiusKm: $radiusKm, minRating: $minRating)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CourtFilterImpl &&
            (identical(other.type, type) || other.type == type) &&
            (identical(other.maxPrice, maxPrice) ||
                other.maxPrice == maxPrice) &&
            (identical(other.radiusKm, radiusKm) ||
                other.radiusKm == radiusKm) &&
            (identical(other.minRating, minRating) ||
                other.minRating == minRating));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, type, maxPrice, radiusKm, minRating);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CourtFilterImplCopyWith<_$CourtFilterImpl> get copyWith =>
      __$$CourtFilterImplCopyWithImpl<_$CourtFilterImpl>(this, _$identity);
}

abstract class _CourtFilter implements CourtFilter {
  const factory _CourtFilter(
      {final CourtTypeFilter type,
      final double? maxPrice,
      final double? radiusKm,
      final double? minRating}) = _$CourtFilterImpl;

  @override
  CourtTypeFilter get type;
  @override
  double? get maxPrice;
  @override
  double? get radiusKm;
  @override
  double? get minRating;
  @override
  @JsonKey(ignore: true)
  _$$CourtFilterImplCopyWith<_$CourtFilterImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
