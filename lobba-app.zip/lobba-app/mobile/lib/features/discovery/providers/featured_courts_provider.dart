import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';

import '../../../core/network/api_client.dart';
import '../../../shared/models/court_preview.dart';

/// Fetches featured courts from the backend.
/// Backend endpoint: GET /courts/featured?lat=&lng=&limit=5
/// Falls back to top-rated if location is unavailable.
final featuredCourtsProvider =
    AsyncNotifierProvider<FeaturedCourtsNotifier, List<CourtPreview>>(
  FeaturedCourtsNotifier.new,
);

class FeaturedCourtsNotifier extends AsyncNotifier<List<CourtPreview>> {
  @override
  Future<List<CourtPreview>> build() => _fetch();

  Future<List<CourtPreview>> _fetch({double? lat, double? lng}) async {
    final api = ref.read(apiClientProvider);
    final response = await api.get(
      '/courts/featured',
      queryParameters: {
        if (lat != null) 'lat': lat,
        if (lng != null) 'lng': lng,
        'limit': 5,
      },
    );
    final list = response.data as List<dynamic>;
    return list
        .map((e) => CourtPreview.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  /// Called when user grants location — refetches with coordinates.
  Future<void> refreshWithLocation(double lat, double lng) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _fetch(lat: lat, lng: lng));
  }
}
