import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/network/api_client.dart';
import '../../../shared/models/court_preview.dart';
import 'filter_provider.dart';

/// GET /courts/nearby — sorted by distance, respects active filters.
final nearbyCourtsProvider =
    AsyncNotifierProvider<NearbyCourtsNotifier, List<CourtPreview>>(
  NearbyCourtsNotifier.new,
);

class NearbyCourtsNotifier extends AsyncNotifier<List<CourtPreview>> {
  @override
  Future<List<CourtPreview>> build() {
    // Re-fetch whenever filters change
    ref.watch(activeFilterProvider);
    return _fetch();
  }

  Future<List<CourtPreview>> _fetch({double? lat, double? lng}) async {
    final api = ref.read(apiClientProvider);
    final filter = ref.read(activeFilterProvider);

    final response = await api.get(
      '/courts/nearby',
      queryParameters: {
        if (lat != null) 'lat': lat,
        if (lng != null) 'lng': lng,
        if (filter.type != CourtTypeFilter.all) 'type': filter.type.name,
        if (filter.maxPrice != null) 'maxPrice': filter.maxPrice,
        if (filter.minRating != null) 'minRating': filter.minRating,
        if (filter.radiusKm != null) 'radius': filter.radiusKm,
        'limit': 10,
      },
    );
    final list = response.data as List<dynamic>;
    return list
        .map((e) => CourtPreview.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> refreshWithLocation(double lat, double lng) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _fetch(lat: lat, lng: lng));
  }
}
