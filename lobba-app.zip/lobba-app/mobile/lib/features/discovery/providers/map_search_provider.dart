import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/network/api_client.dart';
import 'filter_provider.dart';

/// Extended model for map screen — includes lat/lng for pin placement.
class MapCourtPreview {
  final String id;
  final String venueId;
  final String venueName;
  final bool isIndoor;
  final double rating;
  final int pricePerSixtyMin;
  final int courtCount;
  final double distanceKm;
  final double lat;
  final double lng;
  final String? photoUrl;

  const MapCourtPreview({
    required this.id,
    required this.venueId,
    required this.venueName,
    required this.isIndoor,
    required this.rating,
    required this.pricePerSixtyMin,
    required this.courtCount,
    required this.distanceKm,
    required this.lat,
    required this.lng,
    this.photoUrl,
  });

  factory MapCourtPreview.fromJson(Map<String, dynamic> j) => MapCourtPreview(
        id: j['id'] as String,
        venueId: j['venueId'] as String,
        venueName: j['venueName'] as String,
        isIndoor: j['isIndoor'] as bool,
        rating: (j['rating'] as num).toDouble(),
        pricePerSixtyMin: j['pricePerSixtyMin'] as int,
        courtCount: j['courtCount'] as int,
        distanceKm: (j['distanceKm'] as num).toDouble(),
        lat: (j['lat'] as num).toDouble(),
        lng: (j['lng'] as num).toDouble(),
        photoUrl: j['photoUrl'] as String?,
      );

  String get distanceLabel {
    if (distanceKm < 1) return '${(distanceKm * 1000).round()} m';
    return '${distanceKm.toStringAsFixed(1)} km';
  }
}

final mapSearchProvider =
    AsyncNotifierProvider<MapSearchNotifier, List<MapCourtPreview>>(
  MapSearchNotifier.new,
);

class MapSearchNotifier extends AsyncNotifier<List<MapCourtPreview>> {
  Timer? _debounce;

  @override
  Future<List<MapCourtPreview>> build() {
    ref.watch(activeFilterProvider);
    ref.onDispose(() => _debounce?.cancel());
    return _fetch();
  }

  /// Debounced search — waits 350 ms after last keystroke.
  void search(String query) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () async {
      state = const AsyncLoading();
      state = await AsyncValue.guard(() => _fetch(query: query));
    });
  }

  Future<List<MapCourtPreview>> _fetch({String? query}) async {
    final api = ref.read(apiClientProvider);
    final filter = ref.read(activeFilterProvider);

    final response = await api.get(
      '/courts/search',
      queryParameters: {
        if (query != null && query.isNotEmpty) 'q': query,
        if (filter.type != CourtTypeFilter.all) 'type': filter.type.name,
        if (filter.maxPrice != null) 'maxPrice': filter.maxPrice,
        if (filter.minRating != null) 'minRating': filter.minRating,
        if (filter.radiusKm != null) 'radius': filter.radiusKm,
        'limit': 20,
        'includeCoords': true,
      },
    );

    final list = response.data as List<dynamic>;
    return list
        .map((e) => MapCourtPreview.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}
