import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../data/courts_catalog.dart';

class DiscoveryScreen extends ConsumerStatefulWidget {
  const DiscoveryScreen({super.key});
  @override
  ConsumerState<DiscoveryScreen> createState() => _DiscoveryScreenState();
}

class _DiscoveryScreenState extends ConsumerState<DiscoveryScreen> {
  int _filter = 0;
  static const _filters = ['All', 'Indoor', 'Outdoor', 'Top rated'];

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Container(
      color: t.bg,
      child: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.only(bottom: 120),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 8, 22, 0),
              child: Row(children: [
                Expanded(child: Display('Discover'.tr(context), size: 24)),
                GestureDetector(
                  onTap: () => context.push(AppRoutes.discoverMap),
                  child: Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(color: t.surface, shape: BoxShape.circle, border: Border.all(color: t.line)),
                    child: Icon(Icons.map_outlined, size: 18, color: t.ink2),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 34,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 22),
                itemCount: _filters.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (c, i) {
                  final on = i == _filter;
                  return GestureDetector(
                    onTap: () => setState(() => _filter = i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: on ? t.accent : t.surface,
                        borderRadius: BorderRadius.circular(99),
                        border: Border.all(color: on ? t.accent : t.line),
                      ),
                      child: Text(_filters[i].tr(c), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: on ? t.onAccent : t.ink2)),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 18),
            ..._visibleCourts().expand((c) => [
              _courtCard(t, c),
              const SizedBox(height: 15),
            ]),
            if (_visibleCourts().isEmpty) Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 40),
              child: Center(child: Text('No courts match this filter'.tr(context), style: TextStyle(fontSize: 12.5, color: t.ink3))),
            ),
          ],
        ),
      ),
    );
  }

  // Apply the active filter chip: All · Indoor · Outdoor · Top rated.
  List<Court> _visibleCourts() {
    switch (_filter) {
      case 1:
        return kCourts.where((c) => c.indoor).toList();
      case 2:
        return kCourts.where((c) => !c.indoor).toList();
      case 3:
        return [...kCourts]..sort((a, b) => b.rating.compareTo(a.rating));
      default:
        return kCourts;
    }
  }

  Widget _courtCard(LobbaTokens t, Court c) {
    final name = c.name, meta = c.meta, price = '${c.prices.first}', rating = c.rating.toStringAsFixed(1);
    final indoor = c.indoor, available = c.indoor; // indoor venues show as available tonight
    final nextSlot = available ? 'Next slot · 6:00 PM tonight' : null;
    return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22),
        child: GestureDetector(
          onTap: () => context.push(AppRoutes.courtDetail.replaceFirst(':courtId', c.id)),
          child: Container(
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: t.line)),
            clipBehavior: Clip.antiAlias,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Stack(children: [
                Container(height: 120, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [t.accentSoft, t.surface2]))),
                Positioned(top: 12, left: 12, child: _pill(t, (indoor ? 'Indoor' : 'Outdoor').tr(context), bg: t.surface, fg: t.ink2)),
                if (available) Positioned(top: 12, left: 74, child: _pill(t, '● Available'.tr(context), bg: t.accentSoft, fg: t.accent)),
                Positioned(top: 12, right: 12, child: _pill(t, '★ $rating', bg: Colors.black.withOpacity(.5), fg: Colors.white)),
              ]),
              Padding(
                padding: const EdgeInsets.fromLTRB(15, 14, 15, 15),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(child: Text(name, style: TextStyle(fontFamily: kSerif, fontSize: 16.5, fontWeight: FontWeight.w500, color: t.ink))),
                    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Text(price, style: TextStyle(fontFamily: kSerif, fontSize: 15, fontWeight: FontWeight.w600, color: t.accent)),
                      Text('EGP /hr'.tr(context), style: TextStyle(fontSize: 10, color: t.ink3)),
                    ]),
                  ]),
                  const SizedBox(height: 5),
                  Text(meta, style: TextStyle(fontSize: 11.5, color: t.ink3)),
                  if (nextSlot != null) ...[
                    const SizedBox(height: 9),
                    Row(children: [
                      Icon(Icons.schedule_rounded, size: 13, color: t.accent),
                      const SizedBox(width: 6),
                      Text(nextSlot, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.accent)),
                    ]),
                  ],
                ]),
              ),
            ]),
          ),
        ),
      );
  }

  Widget _pill(LobbaTokens t, String txt, {required Color bg, required Color fg}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(99)),
        child: Text(txt, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: fg)),
      );
}
