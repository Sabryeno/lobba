import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/i18n/lobba_i18n.dart';

/// Real OpenStreetMap view of nearby courts with price pins — pure Dart tiles,
/// no API key. Pan / zoom / tap a pin to preview the court.
class MapSearchScreen extends ConsumerStatefulWidget {
  const MapSearchScreen({super.key});
  @override
  ConsumerState<MapSearchScreen> createState() => _MapSearchScreenState();
}

class _Court {
  final String name, area, price, meta;
  final LatLng at;
  const _Court(this.name, this.area, this.price, this.meta, this.at);
}

const _courts = [
  _Court('Al-Ahly Padel Club', 'New Cairo', '500', 'New Cairo · 2.3 km · ★ 4.9 · next 6 PM', LatLng(30.0074, 31.4913)),
  _Court('Zamalek Sports Club', 'Zamalek', '350', 'Zamalek · 5.1 km · ★ 4.7 · next 7 PM', LatLng(30.0614, 31.2197)),
  _Court('Maadi Padel Lounge', 'Maadi', '450', 'Maadi · 7.8 km · ★ 4.8 · next 8 PM', LatLng(29.9602, 31.2569)),
];
const _user = LatLng(30.03, 31.47);

class _MapSearchScreenState extends ConsumerState<MapSearchScreen> {
  int _sel = 0;

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Scaffold(
      backgroundColor: t.surface2,
      body: Stack(fit: StackFit.expand, children: [
        // real map
        Positioned.fill(
          child: FlutterMap(
            options: const MapOptions(initialCenter: LatLng(30.02, 31.37), initialZoom: 10.5, minZoom: 4, maxZoom: 18),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.lobba.app',
              ),
              // user location
              MarkerLayer(markers: [
                Marker(point: _user, width: 22, height: 22, child: Container(
                  decoration: BoxDecoration(color: t.slate, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 3), boxShadow: [BoxShadow(color: t.slate.withOpacity(.4), blurRadius: 10, spreadRadius: 3)]),
                )),
              ]),
              // court price pins
              MarkerLayer(markers: [
                for (var i = 0; i < _courts.length; i++)
                  Marker(
                    point: _courts[i].at, width: 78, height: 34, alignment: Alignment.topCenter,
                    child: GestureDetector(
                      onTap: () => setState(() => _sel = i),
                      child: _pin(t, _courts[i].price, selected: i == _sel),
                    ),
                  ),
              ]),
            ],
          ),
        ),
        // top bar — pinned to the top (not stretched by StackFit.expand)
        Positioned(top: 0, left: 0, right: 0, child: SafeArea(child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
          child: Row(children: [
            GestureDetector(onTap: () => context.pop(), child: Container(width: 40, height: 40, decoration: BoxDecoration(color: t.surface, shape: BoxShape.circle, border: Border.all(color: t.line), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.1), blurRadius: 8)]), child: Icon(Icons.chevron_left_rounded, size: 20, color: t.ink2))),
            const SizedBox(width: 10),
            Expanded(child: Container(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 8)]), child: Row(children: [Icon(Icons.search_rounded, size: 15, color: t.ink3), const SizedBox(width: 9), Text('Courts near New Cairo'.tr(context), style: TextStyle(fontSize: 12.5, color: t.ink3))]))),
          ]),
        ))),
        // OSM attribution (required by tile usage policy)
        Positioned(right: 4, bottom: 96, child: Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2), color: Colors.white70, child: const Text('© OpenStreetMap', style: TextStyle(fontSize: 8, color: Colors.black54)))),
        // bottom court card
        Positioned(left: 16, right: 16, bottom: 16, child: SafeArea(top: false, child: GestureDetector(
          onTap: () => context.push(AppRoutes.courtDetail.replaceFirst(':courtId', '${_sel + 1}')),
          child: Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: t.line), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.14), blurRadius: 24, offset: const Offset(0, 10))]),
            child: Row(children: [
              Container(width: 52, height: 52, decoration: BoxDecoration(gradient: LinearGradient(colors: [t.accentSoft, t.surface2]), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.sports_tennis_rounded, color: t.accent, size: 22)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text(_courts[_sel].name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
                const SizedBox(height: 2),
                Text(_courts[_sel].meta, style: TextStyle(fontSize: 10.5, color: t.ink3)),
              ])),
              Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(10)), child: Text('View'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.onAccent))),
            ]),
          ),
        ))),
      ]),
    );
  }

  Widget _pin(LobbaTokens t, String price, {bool selected = false}) => Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
          decoration: BoxDecoration(color: selected ? t.accent : t.surface, borderRadius: BorderRadius.circular(99), border: Border.all(color: selected ? t.accent : t.line), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 8, offset: const Offset(0, 3))]),
          child: Text(price, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: selected ? t.onAccent : t.ink)),
        ),
        Icon(Icons.arrow_drop_down_rounded, size: 16, color: selected ? t.accent : t.surface),
      ]);
}
