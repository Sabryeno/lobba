import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';

class _Court {
  final String name, area;
  final int price;
  final double km;
  final String rating;
  const _Court(this.name, this.area, this.price, this.km, this.rating);
}

const _all = [
  _Court('Al-Ahly Padel Club', 'New Cairo', 500, 2.3, '4.9'),
  _Court('Zamalek Sports Club', 'Zamalek', 350, 5.1, '4.7'),
  _Court('Maadi Padel Lounge', 'Maadi', 450, 7.8, '4.8'),
  _Court('Nasr City Arena', 'Nasr City', 400, 4.6, '4.6'),
  _Court('Sheikh Zayed Padel', 'Sheikh Zayed', 650, 12.4, '4.9'),
  _Court('Heliopolis Club', 'Heliopolis', 700, 9.2, '4.7'),
];

/// Advanced court search — by name / area, price band, and nearby (distance).
class AdvancedSearchScreen extends ConsumerStatefulWidget {
  const AdvancedSearchScreen({super.key});
  @override
  ConsumerState<AdvancedSearchScreen> createState() => _AdvancedSearchScreenState();
}

class _AdvancedSearchScreenState extends ConsumerState<AdvancedSearchScreen> {
  final _q = TextEditingController();
  int _price = -1; // -1 any, 0 <400, 1 400-600, 2 >600
  bool _nearby = false;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  List<_Court> get _results {
    final q = _q.text.trim().toLowerCase();
    var list = _all.where((c) {
      final matchesQ = q.isEmpty || c.name.toLowerCase().contains(q) || c.area.toLowerCase().contains(q);
      final matchesP = _price == -1 ||
          (_price == 0 && c.price < 400) ||
          (_price == 1 && c.price >= 400 && c.price <= 600) ||
          (_price == 2 && c.price > 600);
      return matchesQ && matchesP;
    }).toList();
    if (_nearby) list.sort((a, b) => a.km.compareTo(b.km));
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final results = _results;
    return PushScaffold(
      title: 'Search courts'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 14, 22, 24), children: [
        // search field
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 3),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
          child: Row(children: [
            Icon(Icons.search_rounded, size: 17, color: t.ink3),
            const SizedBox(width: 9),
            Expanded(child: TextField(
              controller: _q, autofocus: true, onChanged: (_) => setState(() {}),
              style: TextStyle(color: t.ink, fontSize: 13.5),
              decoration: InputDecoration(hintText: 'Name or area'.tr(context), hintStyle: TextStyle(color: t.ink3), border: InputBorder.none, isDense: true),
            )),
            if (_q.text.isNotEmpty) GestureDetector(onTap: () => setState(() => _q.clear()), child: Icon(Icons.close_rounded, size: 16, color: t.ink3)),
          ]),
        ),
        const SizedBox(height: 14),
        Eyebrow('Filters'.tr(context)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _chip(t, Icons.near_me_rounded, 'Nearby'.tr(context), _nearby, () => setState(() => _nearby = !_nearby)),
          _chip(t, null, 'Under EGP 400'.tr(context), _price == 0, () => setState(() => _price = _price == 0 ? -1 : 0)),
          _chip(t, null, 'EGP 400–600'.tr(context), _price == 1, () => setState(() => _price = _price == 1 ? -1 : 1)),
          _chip(t, null, 'Over EGP 600'.tr(context), _price == 2, () => setState(() => _price = _price == 2 ? -1 : 2)),
        ]),
        const SizedBox(height: 18),
        if (results.isEmpty)
          Padding(padding: const EdgeInsets.only(top: 40), child: Center(child: Text('No courts found'.tr(context), style: TextStyle(fontSize: 13, color: t.ink3))))
        else
          ...results.map((c) => Padding(padding: const EdgeInsets.only(bottom: 10), child: GestureDetector(
            onTap: () => context.push(AppRoutes.courtDetail.replaceFirst(':courtId', '1')),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
              child: Row(children: [
                Container(width: 48, height: 48, decoration: BoxDecoration(gradient: LinearGradient(colors: [t.accentSoft, t.surface2]), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.sports_tennis_rounded, color: t.accent, size: 20)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(c.name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
                  const SizedBox(height: 2),
                  Text('${c.area} · ${c.km} km · ★ ${c.rating}', style: TextStyle(fontSize: 10.5, color: t.ink3)),
                ])),
                Text.rich(TextSpan(children: [
                  TextSpan(text: '${c.price}', style: TextStyle(fontFamily: kSerif, fontSize: 15, fontWeight: FontWeight.w600, color: t.accent)),
                  TextSpan(text: ' EGP', style: TextStyle(fontSize: 10, color: t.ink2)),
                ])),
              ]),
            ),
          ))),
      ]),
    );
  }

  Widget _chip(LobbaTokens t, IconData? ic, String label, bool on, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
          decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(99), border: Border.all(color: on ? t.accent : t.line)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            if (ic != null) ...[Icon(ic, size: 13, color: on ? t.onAccent : t.ink2), const SizedBox(width: 5)],
            Text(label, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: on ? t.onAccent : t.ink2)),
          ]),
        ),
      );
}
