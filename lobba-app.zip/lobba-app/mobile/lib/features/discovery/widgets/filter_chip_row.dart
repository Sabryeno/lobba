import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/localization/app_localizations.dart';
import '../providers/filter_provider.dart';
import 'discovery_filter_sheet.dart';

class FilterChipRow extends ConsumerWidget {
  /// When true, uses a more compact style for the map search overlay.
  final bool compact;
  const FilterChipRow({super.key, this.compact = false});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final filter = ref.watch(activeFilterProvider);
    final notifier = ref.read(activeFilterProvider.notifier);

    final chips = [
      (CourtTypeFilter.all, l10n.tr('discovery.filter_indoor').replaceAll('Indoor', 'All')),
      (CourtTypeFilter.indoor, '🏠  ${l10n.tr('discovery.filter_indoor')}'),
      (CourtTypeFilter.outdoor, '☀️  ${l10n.tr('discovery.filter_outdoor')}'),
    ];

    // Count active advanced filters (price, rating, radius)
    final advancedCount = [
      filter.maxPrice != null,
      filter.minRating != null,
      filter.radiusKm != null,
    ].where((v) => v).length;

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 20),
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: [
          // Advanced filter button
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () => DiscoveryFilterSheet.show(context),
              child: Container(
                padding: EdgeInsets.symmetric(
                  horizontal: compact ? 10 : 12,
                  vertical: compact ? 6 : 7,
                ),
                decoration: BoxDecoration(
                  color: advancedCount > 0
                      ? AppColors.primary
                      : AppColors.surfaceElevated,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: advancedCount > 0
                        ? AppColors.primary
                        : AppColors.border,
                    width: advancedCount > 0 ? 0 : 0.5,
                  ),
                  boxShadow: advancedCount > 0
                      ? [
                          BoxShadow(
                            color: AppColors.primary.withOpacity(0.2),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.tune_rounded,
                      size: compact ? 13 : 14,
                      color: advancedCount > 0
                          ? Colors.white
                          : AppColors.textSecondary,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      advancedCount > 0 ? 'Filters ($advancedCount)' : 'Filter',
                      style: TextStyle(
                        fontSize: compact ? 11 : 12,
                        fontWeight: FontWeight.w600,
                        color: advancedCount > 0
                            ? Colors.white
                            : AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Type chips
          ...chips.map((chip) {
            final (type, label) = chip;
            final selected = filter.type == type;
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                child: GestureDetector(
                  onTap: () => notifier.setType(type),
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: compact ? 12 : 14,
                      vertical: compact ? 6 : 7,
                    ),
                    decoration: BoxDecoration(
                      color: selected
                          ? AppColors.primary
                          : AppColors.surfaceElevated,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: selected ? AppColors.primary : AppColors.border,
                        width: selected ? 0 : 0.5,
                      ),
                      boxShadow: selected
                          ? [
                              BoxShadow(
                                color: AppColors.primary.withOpacity(0.2),
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ]
                          : null,
                    ),
                    child: Text(
                      label,
                      style: TextStyle(
                        fontSize: compact ? 11 : 12,
                        fontWeight: FontWeight.w600,
                        color: selected
                            ? Colors.white
                            : AppColors.textSecondary,
                      ),
                    ),
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
