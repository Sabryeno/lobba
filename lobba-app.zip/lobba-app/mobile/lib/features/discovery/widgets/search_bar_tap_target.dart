import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../features/auth/providers/locale_provider.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Read-only search bar on the home screen.
/// Tapping it triggers [onTap] which pushes the full map-search screen.
/// Never takes keyboard focus itself — all typing happens on the map screen.
class SearchBarTapTarget extends ConsumerWidget {
  final String hint;
  final VoidCallback onTap;

  const SearchBarTapTarget({
    super.key,
    required this.hint,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(localeProvider);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        decoration: BoxDecoration(
          color: AppColors.surfaceElevated,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
          boxShadow: [
            BoxShadow(
              color: AppColors.textPrimary.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(
              Icons.search_rounded,
              size: 20,
              color: AppColors.textTertiary,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                hint,
                style: AppTypography.bodyMedium(locale).copyWith(
                  color: AppColors.textTertiary,
                ),
              ),
            ),
            // Map badge — signals this opens the map
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.primarySurface,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.map_outlined, size: 12, color: AppColors.primary),
                  SizedBox(width: 4),
                  Text(
                    'Map',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: AppColors.primary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
