import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../providers/filter_provider.dart';

/// Opens the discovery filter sheet and returns once dismissed.
///
/// Usage:
/// ```dart
/// await DiscoveryFilterSheet.show(context);
/// ```
class DiscoveryFilterSheet extends ConsumerStatefulWidget {
  const DiscoveryFilterSheet({super.key});

  static Future<void> show(BuildContext context) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => const DiscoveryFilterSheet(),
    );
  }

  @override
  ConsumerState<DiscoveryFilterSheet> createState() =>
      _DiscoveryFilterSheetState();
}

class _DiscoveryFilterSheetState extends ConsumerState<DiscoveryFilterSheet> {
  // Local copies — committed to provider on "Apply"
  late CourtTypeFilter _type;
  late double _maxPrice;
  late double _minRating;
  late double _radiusKm;

  static const _maxPriceMax = 1000.0;
  static const _radiusMax = 50.0;

  @override
  void initState() {
    super.initState();
    final f = ref.read(activeFilterProvider);
    _type = f.type;
    _maxPrice = f.maxPrice ?? _maxPriceMax;
    _minRating = f.minRating ?? 0;
    _radiusKm = f.radiusKm ?? _radiusMax;
  }

  int get _activeCount {
    int n = 0;
    if (_type != CourtTypeFilter.all) n++;
    if (_maxPrice < _maxPriceMax) n++;
    if (_minRating > 0) n++;
    if (_radiusKm < _radiusMax) n++;
    return n;
  }

  void _apply() {
    final notifier = ref.read(activeFilterProvider.notifier);
    notifier.setType(_type);
    notifier.setMaxPrice(_maxPrice < _maxPriceMax ? _maxPrice : null);
    notifier.setMinRating(_minRating > 0 ? _minRating : null);
    notifier.setRadiusKm(_radiusKm < _radiusMax ? _radiusKm : null);
    Navigator.of(context).pop();
  }

  void _reset() {
    setState(() {
      _type = CourtTypeFilter.all;
      _maxPrice = _maxPriceMax;
      _minRating = 0;
      _radiusKm = _radiusMax;
    });
  }

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.fromLTRB(24, 0, 24, 24 + bottom),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Handle
          Center(
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.divider,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),

          // Title row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Filters',
                style: AppTypography.titleLarge(locale).copyWith(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w700,
                ),
              ),
              if (_activeCount > 0)
                TextButton(
                  onPressed: _reset,
                  style: TextButton.styleFrom(
                    foregroundColor: AppColors.primary,
                    padding: EdgeInsets.zero,
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: Text(
                    'Reset all',
                    style: AppTypography.bodySmall(locale).copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: 24),

          // ── Court type ──────────────────────────────────────────────────────
          _SectionLabel('Court Type', locale),
          const SizedBox(height: 12),
          Row(
            children: [
              _TypeChip(
                label: 'All',
                icon: Icons.sports_rounded,
                selected: _type == CourtTypeFilter.all,
                onTap: () => setState(() => _type = CourtTypeFilter.all),
              ),
              const SizedBox(width: 8),
              _TypeChip(
                label: 'Indoor',
                icon: Icons.home_rounded,
                selected: _type == CourtTypeFilter.indoor,
                onTap: () => setState(() => _type = CourtTypeFilter.indoor),
              ),
              const SizedBox(width: 8),
              _TypeChip(
                label: 'Outdoor',
                icon: Icons.wb_sunny_rounded,
                selected: _type == CourtTypeFilter.outdoor,
                onTap: () => setState(() => _type = CourtTypeFilter.outdoor),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // ── Max price ───────────────────────────────────────────────────────
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _SectionLabel('Max Price / session', locale),
              Text(
                _maxPrice >= _maxPriceMax
                    ? 'Any price'
                    : 'EGP ${_maxPrice.toInt()}',
                style: AppTypography.titleMedium(locale).copyWith(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          SliderTheme(
            data: SliderThemeData(
              activeTrackColor: AppColors.primary,
              inactiveTrackColor: AppColors.divider,
              thumbColor: AppColors.primary,
              overlayColor: AppColors.primary.withOpacity(.12),
              trackHeight: 4,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
            ),
            child: Slider(
              value: _maxPrice,
              min: 100,
              max: _maxPriceMax,
              divisions: 18,
              onChanged: (v) => setState(() => _maxPrice = v),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('EGP 100',
                    style: AppTypography.labelSmall(locale)
                        .copyWith(color: AppColors.textTertiary)),
                Text('EGP 1000+',
                    style: AppTypography.labelSmall(locale)
                        .copyWith(color: AppColors.textTertiary)),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // ── Min rating ──────────────────────────────────────────────────────
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _SectionLabel('Minimum Rating', locale),
              Text(
                _minRating == 0 ? 'Any rating' : '${_minRating.toStringAsFixed(1)} ★',
                style: AppTypography.titleMedium(locale).copyWith(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(5, (i) {
              final starVal = (i + 1).toDouble();
              return GestureDetector(
                onTap: () => setState(
                    () => _minRating = _minRating == starVal ? 0 : starVal),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Icon(
                    starVal <= _minRating
                        ? Icons.star_rounded
                        : Icons.star_outline_rounded,
                    size: 36,
                    color: starVal <= _minRating
                        ? const Color(0xFFF5A623)
                        : AppColors.divider,
                  ),
                ),
              );
            }),
          ),

          const SizedBox(height: 24),

          // ── Radius ──────────────────────────────────────────────────────────
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _SectionLabel('Search Radius', locale),
              Text(
                _radiusKm >= _radiusMax
                    ? 'Anywhere'
                    : '${_radiusKm.toInt()} km',
                style: AppTypography.titleMedium(locale).copyWith(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          SliderTheme(
            data: SliderThemeData(
              activeTrackColor: AppColors.primary,
              inactiveTrackColor: AppColors.divider,
              thumbColor: AppColors.primary,
              overlayColor: AppColors.primary.withOpacity(.12),
              trackHeight: 4,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
            ),
            child: Slider(
              value: _radiusKm,
              min: 1,
              max: _radiusMax,
              divisions: 49,
              onChanged: (v) => setState(() => _radiusKm = v),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('1 km',
                    style: AppTypography.labelSmall(locale)
                        .copyWith(color: AppColors.textTertiary)),
                Text('50+ km',
                    style: AppTypography.labelSmall(locale)
                        .copyWith(color: AppColors.textTertiary)),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // ── Apply button ────────────────────────────────────────────────────
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _apply,
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.primary,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: Text(
                _activeCount > 0
                    ? 'Apply $_activeCount filter${_activeCount == 1 ? '' : 's'}'
                    : 'Show All Courts',
                style: AppTypography.titleMedium(locale).copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String label;
  final Locale locale;
  const _SectionLabel(this.label, this.locale);

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: AppTypography.titleMedium(locale).copyWith(
        color: AppColors.textPrimary,
        fontWeight: FontWeight.w600,
      ),
    );
  }
}

class _TypeChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _TypeChip({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.divider,
            width: 1.5,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 16,
              color: selected ? Colors.white : AppColors.textSecondary,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: selected ? Colors.white : AppColors.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
