/// Central court catalog — the single source of truth for court identity so the
/// selected court's name, price, location and rating flow correctly through
/// discovery → detail → booking → confirmation → ticket.
class Court {
  final String id, name, area, distance, address, phone;
  final int courtCount, ratingCount;
  final double rating;
  final bool indoor;
  final double lat, lng;
  final List<int> prices; // [60 min, 90 min, 120 min]
  const Court({
    required this.id,
    required this.name,
    required this.area,
    required this.distance,
    required this.address,
    required this.phone,
    required this.courtCount,
    required this.ratingCount,
    required this.rating,
    required this.indoor,
    required this.lat,
    required this.lng,
    required this.prices,
  });

  int priceFor(int durIndex) => prices[durIndex.clamp(0, 2)];
  String get meta => '$area · $distance · $courtCount ${courtCount == 1 ? 'court' : 'courts'}';
}

const List<Court> kCourts = [
  Court(
    id: '1', name: 'Al-Ahly Padel Club', area: 'New Cairo', distance: '2.3 km',
    address: '90th Street, 5th Settlement', phone: '+201001234567',
    courtCount: 4, ratingCount: 128, rating: 4.9, indoor: true,
    lat: 30.0074, lng: 31.4913, prices: [500, 750, 1000],
  ),
  Court(
    id: '2', name: 'Zamalek Sports Club', area: 'Zamalek', distance: '5.1 km',
    address: '26th of July Corridor, Zamalek', phone: '+201005557788',
    courtCount: 2, ratingCount: 96, rating: 4.7, indoor: false,
    lat: 30.0609, lng: 31.2197, prices: [350, 525, 700],
  ),
  Court(
    id: '3', name: 'Maadi Padel Lounge', area: 'Maadi', distance: '7.8 km',
    address: 'Road 9, Maadi', phone: '+201062201120',
    courtCount: 4, ratingCount: 210, rating: 4.8, indoor: true,
    lat: 29.9603, lng: 31.2569, prices: [450, 675, 900],
  ),
];

/// The venue the court-owner app represents. All owner screens (dashboard,
/// court management, WhatsApp locking, analytics) are scoped to this venue so
/// they mirror exactly what players see for it.
const String kOwnerVenueId = '1';

/// Resolve a court by id; falls back to the first court so a screen always has
/// a valid court to render.
Court courtById(String? id) => kCourts.firstWhere((c) => c.id == id, orElse: () => kCourts.first);
