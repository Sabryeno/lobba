import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/services/api_service.dart';

class ChatPreview {
  final String id;
  final bool isGroup;
  final String? groupName;
  final String? groupAvatar;
  final String? otherUserId;
  final String? otherUserName;
  final String? otherUserAvatar;
  final String? lastMessage;
  final DateTime? lastMessageAt;
  final int unreadCount;

  const ChatPreview({
    required this.id,
    required this.isGroup,
    this.groupName,
    this.groupAvatar,
    this.otherUserId,
    this.otherUserName,
    this.otherUserAvatar,
    this.lastMessage,
    this.lastMessageAt,
    required this.unreadCount,
  });

  factory ChatPreview.fromJson(Map<String, dynamic> j) {
    final isGroup = j['isGroup'] == true;
    final participants = j['participants'] as List? ?? [];
    final other = participants.isNotEmpty ? participants.first : null;
    return ChatPreview(
      id: j['id'],
      isGroup: isGroup,
      groupName: j['groupName'],
      groupAvatar: j['groupAvatar'],
      otherUserId: other?['user']?['id'],
      otherUserName: other?['user']?['profile']?['fullName'],
      otherUserAvatar: other?['user']?['profile']?['avatarUrl'],
      lastMessage: j['lastMessage']?['content'],
      lastMessageAt: j['lastMessage']?['createdAt'] != null
          ? DateTime.parse(j['lastMessage']['createdAt'])
          : null,
      unreadCount: j['unreadCount'] ?? 0,
    );
  }

  String get displayName => isGroup ? (groupName ?? 'Group Chat') : (otherUserName ?? 'Player');
  String? get displayAvatar => isGroup ? groupAvatar : otherUserAvatar;
}

class Message {
  final String id;
  final String chatId;
  final String senderId;
  final String? senderName;
  final String? senderAvatar;
  final String content;
  final String type;
  final DateTime createdAt;
  final bool isRead;

  const Message({
    required this.id,
    required this.chatId,
    required this.senderId,
    this.senderName,
    this.senderAvatar,
    required this.content,
    required this.type,
    required this.createdAt,
    required this.isRead,
  });

  factory Message.fromJson(Map<String, dynamic> j) => Message(
        id: j['id'],
        chatId: j['chatId'] ?? '',
        senderId: j['senderId'] ?? '',
        senderName: j['sender']?['profile']?['fullName'],
        senderAvatar: j['sender']?['profile']?['avatarUrl'],
        content: j['content'] ?? '',
        type: j['type'] ?? 'TEXT',
        createdAt: DateTime.parse(j['createdAt']),
        isRead: j['isRead'] ?? false,
      );
}

class ChatsState {
  final List<ChatPreview> chats;
  final bool isLoading;

  const ChatsState({this.chats = const [], this.isLoading = false});

  ChatsState copyWith({List<ChatPreview>? chats, bool? isLoading}) =>
      ChatsState(chats: chats ?? this.chats, isLoading: isLoading ?? this.isLoading);
}

class ChatsNotifier extends StateNotifier<ChatsState> {
  final Ref _ref;

  ChatsNotifier(this._ref) : super(const ChatsState());

  Future<void> load() async {
    state = state.copyWith(isLoading: true);
    try {
      final dio = _ref.read(dioProvider);
      final resp = await dio.get('/chat');
      final body = resp.data;
      final list = body is Map<String, dynamic> && body['data'] is List
          ? body['data'] as List
          : body as List;
      final items = list
          .map((e) => ChatPreview.fromJson(e))
          .toList();
      state = state.copyWith(chats: items, isLoading: false);
    } catch (_) {
      state = state.copyWith(isLoading: false);
    }
  }

  Future<String?> startPrivateChat(String targetUserId) async {
    try {
      final dio = _ref.read(dioProvider);
      final resp = await dio.post('/chat/private/$targetUserId');
      await load();
      final body = resp.data;
      final chat = body is Map<String, dynamic> && body['data'] is Map
          ? body['data'] as Map<String, dynamic>
          : body as Map<String, dynamic>;
      return chat['id'] as String?;
    } catch (_) {
      return null;
    }
  }

  Future<Message?> sendMessage(String chatId, String content) async {
    try {
      final dio = _ref.read(dioProvider);
      final resp = await dio.post(
        '/chat/$chatId/messages',
        data: {'content': content, 'type': 'TEXT'},
      );
      final body = resp.data;
      final message = body is Map<String, dynamic> && body['data'] is Map
          ? body['data'] as Map<String, dynamic>
          : body as Map<String, dynamic>;
      await load();
      return Message.fromJson(message);
    } catch (_) {
      return null;
    }
  }
}

final chatsProvider = StateNotifierProvider<ChatsNotifier, ChatsState>((ref) {
  return ChatsNotifier(ref);
});

// Messages for a single chat
final messagesProvider =
    FutureProvider.family<List<Message>, String>((ref, chatId) async {
  final dio = ref.read(dioProvider);
  final resp = await dio.get('/chat/$chatId/messages', queryParameters: {'limit': 50});
  final body = resp.data;
  final list = body is Map<String, dynamic> && body['data'] is List
      ? body['data'] as List
      : body is Map<String, dynamic> &&
              body['data'] is Map<String, dynamic> &&
              (body['data'] as Map<String, dynamic>)['data'] is List
          ? (body['data'] as Map<String, dynamic>)['data'] as List
          : body as List;
  return list.map((e) => Message.fromJson(e)).toList();
});
