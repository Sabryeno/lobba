import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';

/// Match group chat — WhatsApp-style in the app theme (no 1:1 DMs).
class ChatDetailScreen extends ConsumerStatefulWidget {
  final String chatId;
  const ChatDetailScreen({super.key, required this.chatId});
  @override
  ConsumerState<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends ConsumerState<ChatDetailScreen> {
  final _ctrl = TextEditingController();
  final _msgs = <Map<String, dynamic>>[
    {'from': 'Sara', 'text': 'Yalla, still on for 6? 🎾', 'me': false},
    {'from': 'You', 'text': 'Yes! Booked Court A ✅', 'me': true},
    {'from': 'Omar', 'text': 'Perfect — I’ll bring the balls 🎾', 'me': false},
  ];

  void _send() {
    if (_ctrl.text.trim().isEmpty) return;
    setState(() { _msgs.add({'from': 'You', 'text': _ctrl.text.trim(), 'me': true}); _ctrl.clear(); });
  }

  void _showAttach(LobbaTokens t) {
    showModalBottomSheet(context: context, backgroundColor: t.surface, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))), builder: (ctx) {
      Widget opt(IconData ic, String label) => InkWell(
            onTap: () { Navigator.pop(ctx); setState(() => _msgs.add({'from': 'You', 'text': '[$label]', 'me': true})); },
            child: Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Column(children: [
              Container(width: 52, height: 52, decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(16)), child: Icon(ic, color: t.accent, size: 24)),
              const SizedBox(height: 6),
              Text(label.tr(context), style: TextStyle(fontSize: 11, color: t.ink2)),
            ])),
          );
      return SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(24, 14, 24, 24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 38, height: 4, decoration: BoxDecoration(color: t.line, borderRadius: BorderRadius.circular(99))),
        const SizedBox(height: 18),
        Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          opt(Icons.photo_library_outlined, 'Photo'),
          opt(Icons.camera_alt_outlined, 'Camera'),
          opt(Icons.videocam_outlined, 'Video'),
          opt(Icons.location_on_outlined, 'Location'),
        ]),
      ])));
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Scaffold(
      backgroundColor: t.surface2,
      body: SafeArea(child: Column(children: [
        // header
        Container(
          color: t.surface,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Row(children: [
            GestureDetector(onTap: () => context.pop(), child: Icon(Icons.chevron_left_rounded, color: t.ink2, size: 24)),
            const SizedBox(width: 6),
            LAvatar('A', size: 34, bg: t.accent, fg: t.onAccent),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Al-Ahly · Today 6 PM', style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink)),
              Text('4 players · Ahmed, Sara, Omar, Hana', style: TextStyle(fontSize: 10, color: t.ink3)),
            ])),
          ]),
        ),
        Divider(height: 1, color: t.line),
        // messages
        Expanded(child: ListView(padding: const EdgeInsets.all(14), children: [
          Center(child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3), decoration: BoxDecoration(color: t.bg, borderRadius: BorderRadius.circular(99), border: Border.all(color: t.line)), child: Text('Today'.tr(context), style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w600, color: t.ink3)))),
          const SizedBox(height: 10),
          ..._msgs.map((m) => _bubble(t, m['from'], m['text'], m['me'])),
        ])),
        // input
        Container(
          color: t.surface,
          padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
          child: Row(children: [
            GestureDetector(onTap: () => _showAttach(t), child: Icon(Icons.attach_file_rounded, color: t.ink2, size: 22)),
            const SizedBox(width: 9),
            Expanded(child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 3),
              decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(99)),
              child: TextField(controller: _ctrl, style: TextStyle(color: t.ink, fontSize: 13), decoration: InputDecoration(hintText: 'Message'.tr(context), hintStyle: TextStyle(color: t.ink3), border: InputBorder.none, isDense: true), onSubmitted: (_) => _send()),
            )),
            const SizedBox(width: 9),
            GestureDetector(onTap: _send, child: Container(width: 38, height: 38, decoration: BoxDecoration(color: t.accent, shape: BoxShape.circle), child: Icon(Icons.send_rounded, color: t.onAccent, size: 16))),
          ]),
        ),
      ])),
    );
  }

  Widget _bubble(LobbaTokens t, String from, String text, bool me) => Align(
        alignment: me ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
          child: Column(crossAxisAlignment: me ? CrossAxisAlignment.end : CrossAxisAlignment.start, children: [
            if (!me) Padding(padding: const EdgeInsets.only(left: 4, bottom: 2), child: Text(from, style: TextStyle(fontSize: 9, fontWeight: FontWeight.w600, color: t.accent))),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
              decoration: BoxDecoration(
                color: me ? t.accent : t.surface,
                borderRadius: BorderRadius.only(topLeft: const Radius.circular(14), topRight: const Radius.circular(14), bottomLeft: Radius.circular(me ? 14 : 4), bottomRight: Radius.circular(me ? 4 : 14)),
                border: me ? null : Border.all(color: t.line),
              ),
              child: Text(text, style: TextStyle(fontSize: 12.5, color: me ? t.onAccent : t.ink)),
            ),
          ]),
        ),
      );
}
