import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/navigation/app_router.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../providers/chat_provider.dart';

class ChatsScreen extends ConsumerStatefulWidget {
  const ChatsScreen({super.key});

  @override
  ConsumerState<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends ConsumerState<ChatsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(chatsProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(chatsProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
        title: Text('Messages'.tr(context), style: const TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => _showNewChatSheet(context),
          ),
        ],
      ),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : state.chats.isEmpty
              ? _EmptyChats()
              : RefreshIndicator(
                  onRefresh: () => ref.read(chatsProvider.notifier).load(),
                  color: AppColors.primary,
                  child: ListView.separated(
                    itemCount: state.chats.length,
                    separatorBuilder: (_, __) =>
                        Divider(height: 1, color: AppColors.grey200),
                    itemBuilder: (context, i) => _ChatTile(chat: state.chats[i]),
                  ),
                ),
    );
  }

  void _showNewChatSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Start a Chat'.tr(context),
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'Open a player profile from the leaderboard, matches, or clubs, then tap the chat button.'.tr(context),
                style: TextStyle(color: AppColors.textSecondary, height: 1.4),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () {
                    Navigator.pop(context);
                    context.push(AppRoutes.leaderboard);
                  },
                  icon: const Icon(Icons.leaderboard_outlined),
                  label: Text('Find Players'.tr(context)),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.primary,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChatTile extends StatelessWidget {
  final ChatPreview chat;
  const _ChatTile({required this.chat});

  @override
  Widget build(BuildContext context) {
    final timeStr = chat.lastMessageAt != null
        ? _formatTime(chat.lastMessageAt!)
        : '';

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: Stack(
        children: [
          CircleAvatar(
            radius: 26,
            backgroundImage:
                chat.displayAvatar != null ? NetworkImage(chat.displayAvatar!) : null,
            backgroundColor: chat.isGroup
                ? AppColors.organizerSurface
                : AppColors.primarySurface,
            child: chat.displayAvatar == null
                ? Icon(
                    chat.isGroup ? Icons.group : Icons.person,
                    color: chat.isGroup ? AppColors.organizer : AppColors.primary,
                    size: 24,
                  )
                : null,
          ),
          if (chat.unreadCount > 0)
            Positioned(
              right: 0,
              top: 0,
              child: Container(
                width: 18,
                height: 18,
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    chat.unreadCount > 9 ? '9+' : '${chat.unreadCount}',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
        ],
      ),
      title: Row(
        children: [
          Expanded(
            child: Text(
              chat.displayName,
              style: TextStyle(
                fontWeight: chat.unreadCount > 0
                    ? FontWeight.bold
                    : FontWeight.w500,
                fontSize: 15,
              ),
            ),
          ),
          Text(timeStr,
              style: TextStyle(
                  fontSize: 12,
                  color: chat.unreadCount > 0
                      ? AppColors.primary
                      : AppColors.textSecondary)),
        ],
      ),
      subtitle: Text(
        chat.lastMessage ?? 'No messages yet'.tr(context),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: chat.unreadCount > 0
              ? AppColors.textPrimary
              : AppColors.textSecondary,
          fontWeight:
              chat.unreadCount > 0 ? FontWeight.w500 : FontWeight.normal,
          fontSize: 13,
        ),
      ),
      onTap: () => context.push('/chats/${chat.id}'),
    );
  }

  String _formatTime(DateTime dt) {
    final now = DateTime.now();
    if (dt.day == now.day) return DateFormat('h:mm a').format(dt);
    if (now.difference(dt).inDays < 7) return DateFormat('EEE').format(dt);
    return DateFormat('MMM d').format(dt);
  }
}

class _EmptyChats extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.chat_bubble_outline, size: 64, color: AppColors.grey300),
          const SizedBox(height: 16),
          Text('No messages yet'.tr(context),
              style: TextStyle(color: AppColors.textSecondary, fontSize: 16)),
          const SizedBox(height: 8),
          Text('Connect with other players!'.tr(context),
              style: TextStyle(color: AppColors.textTertiary, fontSize: 14)),
        ],
      ),
    );
  }
}
