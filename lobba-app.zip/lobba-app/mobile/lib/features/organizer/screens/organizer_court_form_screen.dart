import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';

/// Add or edit a court — name/number, format, type, photos, price, brand logo.
class CourtFormScreen extends StatefulWidget {
  final String? initialName;
  final String? initialFormat; // 'single' | 'double'
  final bool initialIndoor;
  final int? initialPrice;
  const CourtFormScreen({super.key, this.initialName, this.initialFormat, this.initialIndoor = true, this.initialPrice});

  @override
  State<CourtFormScreen> createState() => _CourtFormScreenState();
}

class _CourtFormScreenState extends State<CourtFormScreen> {
  late final TextEditingController _name = TextEditingController(text: widget.initialName ?? '');
  late final TextEditingController _price = TextEditingController(text: widget.initialPrice?.toString() ?? '');
  late String _format = widget.initialFormat ?? 'double';
  late bool _indoor = widget.initialIndoor;
  final _photos = <String>[];
  String? _logo;

  bool get _isEdit => widget.initialName != null;

  @override
  void dispose() {
    _name.dispose(); _price.dispose();
    super.dispose();
  }

  Future<void> _addPhoto() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1200);
    if (x != null) setState(() => _photos.add(x.path));
  }

  Future<void> _pickLogo() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 600);
    if (x != null) setState(() => _logo = x.path);
  }

  void _save() {
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(SnackBar(content: Text('Court saved'.tr(context))));
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: (_isEdit ? 'Edit court' : 'Add court').tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: _save,
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text('Save court'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        _label(t, 'Court name or number'.tr(context)),
        _field(t, _name, 'Court 1'),
        const SizedBox(height: 18),
        _label(t, 'Court format'.tr(context)),
        Row(children: [
          _seg(t, Icons.person_outline, 'Single'.tr(context), 'single'),
          const SizedBox(width: 10),
          _seg(t, Icons.group_outlined, 'Double'.tr(context), 'double'),
        ]),
        const SizedBox(height: 18),
        _label(t, 'Court type'.tr(context)),
        Row(children: [
          _segBool(t, Icons.home_outlined, 'Indoor'.tr(context), true),
          const SizedBox(width: 10),
          _segBool(t, Icons.wb_sunny_outlined, 'Outdoor'.tr(context), false),
        ]),
        const SizedBox(height: 18),
        _label(t, 'Price per hour'.tr(context)),
        _field(t, _price, '750', kb: TextInputType.number, prefix: 'EGP '),
        const SizedBox(height: 18),
        _label(t, 'Photos'.tr(context)),
        SizedBox(height: 78, child: ListView(scrollDirection: Axis.horizontal, children: [
          for (final p in _photos) Padding(padding: const EdgeInsets.only(right: 9), child: ClipRRect(borderRadius: BorderRadius.circular(13), child: Image.file(File(p), width: 78, height: 78, fit: BoxFit.cover))),
          GestureDetector(onTap: _addPhoto, child: Container(
            width: 78, height: 78,
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.add_a_photo_outlined, size: 20, color: t.accent),
              const SizedBox(height: 4),
              Text('Add photo'.tr(context), style: TextStyle(fontSize: 8.5, color: t.ink3)),
            ]),
          )),
        ])),
        const SizedBox(height: 18),
        _label(t, 'Brand logo'.tr(context)),
        GestureDetector(onTap: _pickLogo, child: Row(children: [
          Container(
            width: 60, height: 60,
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
            clipBehavior: Clip.antiAlias,
            child: _logo != null ? Image.file(File(_logo!), fit: BoxFit.cover) : Icon(Icons.image_outlined, color: t.ink3),
          ),
          const SizedBox(width: 12),
          Text('Add logo'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.accent)),
        ])),
      ]),
    );
  }

  Widget _label(LobbaTokens t, String s) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Eyebrow(s));

  Widget _field(LobbaTokens t, TextEditingController c, String hint, {TextInputType? kb, String? prefix}) => TextField(
        controller: c, keyboardType: kb,
        style: TextStyle(color: t.ink, fontSize: 14),
        decoration: InputDecoration(
          hintText: hint, hintStyle: TextStyle(color: t.ink3), prefixText: prefix, prefixStyle: TextStyle(color: t.ink2, fontSize: 14),
          filled: true, fillColor: t.surface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.accent, width: 1.5)),
        ),
      );

  Widget _seg(LobbaTokens t, IconData ic, String label, String value) {
    final on = _format == value;
    return Expanded(child: GestureDetector(onTap: () => setState(() => _format = value), child: Container(
      padding: const EdgeInsets.symmetric(vertical: 13), alignment: Alignment.center,
      decoration: BoxDecoration(color: on ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: on ? t.accent : t.line, width: on ? 1.5 : 1)),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(ic, size: 17, color: on ? t.accent : t.ink3), const SizedBox(width: 7), Text(label, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: on ? t.accent : t.ink2))]),
    )));
  }

  Widget _segBool(LobbaTokens t, IconData ic, String label, bool value) {
    final on = _indoor == value;
    return Expanded(child: GestureDetector(onTap: () => setState(() => _indoor = value), child: Container(
      padding: const EdgeInsets.symmetric(vertical: 13), alignment: Alignment.center,
      decoration: BoxDecoration(color: on ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: on ? t.accent : t.line, width: on ? 1.5 : 1)),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(ic, size: 17, color: on ? t.accent : t.ink3), const SizedBox(width: 7), Text(label, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: on ? t.accent : t.ink2))]),
    )));
  }
}
