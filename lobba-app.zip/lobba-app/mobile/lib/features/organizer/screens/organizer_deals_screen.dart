import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/i18n/lobba_i18n.dart';
import 'organizer_deal_form_screen.dart';

/// Court-owner last-minute deals — create, edit, hold and delete discounts on
/// unsold slots.
class OrganizerDealsScreen extends ConsumerStatefulWidget {
  const OrganizerDealsScreen({super.key});
  @override
  ConsumerState<OrganizerDealsScreen> createState() => _OrganizerDealsScreenState();
}

class _Deal {
  final String court, when, off, was, now, ends;
  bool held;
  _Deal(this.court, this.when, this.off, this.was, this.now, this.ends, {this.held = false});
}

class _OrganizerDealsScreenState extends ConsumerState<OrganizerDealsScreen> {
  final _deals = [
    _Deal('Court 3', 'Today · 3–5 PM', '30%', '450', '315', '1h 23m'),
    _Deal('Court 2', 'Today · 8–9 PM', '25%', '500', '375', '2h 05m'),
  ];

  void _create() => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DealFormScreen()));
  void _edit(_Deal d) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DealFormScreen(isEdit: true)));

  void _menu(_Deal d) {
    final t = context.t;
    showModalBottomSheet(context: context, backgroundColor: t.surface, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))), builder: (ctx) {
      Widget item(IconData ic, String label, Color color, VoidCallback onTap) => ListTile(
            leading: Icon(ic, color: color, size: 20),
            title: Text(label, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: color)),
            onTap: () { Navigator.pop(ctx); onTap(); },
          );
      return SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 8),
        Container(width: 38, height: 4, decoration: BoxDecoration(color: t.line, borderRadius: BorderRadius.circular(99))),
        const SizedBox(height: 8),
        item(Icons.edit_outlined, 'Edit'.tr(context), t.ink, () => _edit(d)),
        item(d.held ? Icons.play_arrow_rounded : Icons.pause_rounded, (d.held ? 'Resume' : 'Hold').tr(context), t.ink, () => setState(() => d.held = !d.held)),
        item(Icons.delete_outline_rounded, 'Delete'.tr(context), t.clay, () => setState(() => _deals.remove(d))),
        const SizedBox(height: 8),
      ]));
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Container(
      color: t.bg,
      child: ListView(padding: const EdgeInsets.only(bottom: 30), children: [
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 10, 22, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Last-minute deals'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w500, color: t.headFg)),
            const SizedBox(height: 4),
            Text('Set a discount for unsold slots'.tr(context), style: TextStyle(fontSize: 11, color: t.headFg.withOpacity(.82))),
          ]),
        ))),
        const SizedBox(height: 16),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: GestureDetector(
          onTap: _create,
          child: Container(
            padding: const EdgeInsets.all(14), alignment: Alignment.center,
            decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(14)),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.add_rounded, color: t.onAccent, size: 18),
              const SizedBox(width: 8),
              Text('Create deal'.tr(context), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.onAccent)),
            ]),
          ),
        )),
        const SizedBox(height: 18),
        Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 10), child: Text('Active deals'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 16, fontWeight: FontWeight.w500, color: t.ink))),
        ..._deals.map((d) => _deal(context, t, d)),
      ]),
    );
  }

  Widget _deal(BuildContext context, LobbaTokens t, _Deal d) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 0, 22, 11),
        child: Opacity(
          opacity: d.held ? .55 : 1,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3), decoration: BoxDecoration(color: t.clay, borderRadius: BorderRadius.circular(99)), child: Text('-${d.off}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white))),
                const SizedBox(width: 9),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text(d.court, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.ink)),
                    if (d.held) Padding(padding: const EdgeInsets.only(left: 7), child: Text('· ${'On hold'.tr(context)}', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: t.gold))),
                  ]),
                  Text(d.when, style: TextStyle(fontSize: 10.5, color: t.ink3)),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('EGP ${d.was}', style: TextStyle(fontSize: 10, color: t.ink3, decoration: TextDecoration.lineThrough)),
                  Text('EGP ${d.now}', style: TextStyle(fontFamily: kSerif, fontSize: 15, fontWeight: FontWeight.w600, color: t.accent)),
                ]),
                GestureDetector(onTap: () => _menu(d), child: Padding(padding: const EdgeInsets.only(left: 8), child: Icon(Icons.more_vert_rounded, size: 18, color: t.ink3))),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Icon(Icons.timer_outlined, size: 13, color: t.gold),
                const SizedBox(width: 5),
                Text('${'Ends in'.tr(context)} ${d.ends}', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: t.gold)),
              ]),
            ]),
          ),
        ),
      );
}
