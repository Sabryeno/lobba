import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../booking/data/booking_options.dart';
import '../../booking/providers/bookings_provider.dart';
import '../../discovery/data/courts_catalog.dart';
import 'organizer_court_form_screen.dart';

/// Court-owner court management — status (active/maintenance/closed), price,
/// hours. Demo data, Sage Atelier / Ink & Brass theme, bilingual.
class OrganizerCourtsScreen extends ConsumerStatefulWidget {
  const OrganizerCourtsScreen({super.key});
  @override
  ConsumerState<OrganizerCourtsScreen> createState() => _OrganizerCourtsScreenState();
}

class _Court {
  final String name, type, hours;
  final int price;
  String status; // active | maintenance | closed
  _Court(this.name, this.type, this.price, this.hours, this.status);
}

class _OrganizerCourtsScreenState extends ConsumerState<OrganizerCourtsScreen> {
  final _courts = [
    _Court('Court 1', 'Indoor', 750, '9:00 AM – 12:00 AM', 'active'),
    _Court('Court 2', 'Indoor', 500, '9:00 AM – 12:00 AM', 'active'),
    _Court('Court 3', 'Outdoor', 450, '8:00 AM – 11:00 PM', 'maintenance'),
    _Court('Court 4', 'Outdoor', 450, '8:00 AM – 11:00 PM', 'closed'),
  ];

  void _openForm({_Court? c}) => Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => CourtFormScreen(
          initialName: c?.name,
          initialFormat: 'double',
          initialIndoor: c == null || c.type == 'Indoor',
          initialPrice: c?.price,
        ),
      ));

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Container(
      color: t.bg,
      child: ListView(padding: const EdgeInsets.only(bottom: 30), children: [
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 10, 18, 16),
          child: Row(children: [
            Expanded(child: Text('Court management'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w500, color: t.headFg))),
            GestureDetector(
              onTap: () => _openForm(),
              child: Container(width: 40, height: 40, decoration: BoxDecoration(color: t.headFg.withOpacity(.14), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.add_rounded, color: t.headFg, size: 20)),
            ),
          ]),
        ))),
        const SizedBox(height: 16),
        // Live availability — reflects exactly the bookings players make.
        ...(() {
          ref.watch(bookingsProvider);
          final store = ref.watch(bookingsProvider.notifier);
          return List.generate(_courts.length, (i) => _card(t, _courts[i], store.forVenueCourt(kOwnerVenueId, i + 1)));
        }()),
        Padding(padding: const EdgeInsets.fromLTRB(22, 4, 22, 0), child: GestureDetector(
          onTap: () => _openForm(),
          child: Container(padding: const EdgeInsets.all(14), alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)), child: Text('+ ${'Add court'.tr(context)}', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.accent))),
        )),
      ]),
    );
  }

  (String, Color) _statusOf(LobbaTokens t, String s) => switch (s) {
        'active' => ('Active'.tr(context), t.sage),
        'maintenance' => ('Maintenance'.tr(context), t.gold),
        _ => ('Closed'.tr(context), t.clay),
      };

  Widget _card(LobbaTokens t, _Court c, List<Booking> bookings) {
    final (label, color) = _statusOf(t, c.status);
    final on = c.status == 'active';
    // Real-time availability from the shared engine (same data players see).
    final count = bookings.length;
    final next = bookings.isNotEmpty ? bookings.first : null;
    return Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 11), child: Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 40, height: 40, decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(12)), child: Icon(Icons.sports_tennis_rounded, color: t.accent, size: 20)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(c.name, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: t.ink)),
              const SizedBox(width: 8),
              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: color.withOpacity(.16), borderRadius: BorderRadius.circular(99)), child: Text(label, style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, color: color))),
            ]),
            const SizedBox(height: 2),
            Text('${c.type == 'Indoor' ? 'Indoor'.tr(context) : 'Outdoor'.tr(context)} · ${c.hours}', style: TextStyle(fontSize: 10.5, color: t.ink3)),
          ])),
          Switch(value: on, activeColor: t.accent, onChanged: (v) => setState(() => c.status = v ? 'active' : 'closed')),
        ]),
        const SizedBox(height: 10),
        // live availability strip
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
          decoration: BoxDecoration(color: count == 0 ? t.sage.withOpacity(.12) : t.gold.withOpacity(.12), borderRadius: BorderRadius.circular(10)),
          child: Row(children: [
            Icon(count == 0 ? Icons.event_available_rounded : Icons.event_busy_rounded, size: 14, color: count == 0 ? t.sage : t.gold),
            const SizedBox(width: 8),
            Expanded(child: Text(
              count == 0
                  ? 'Fully available'.tr(context)
                  : '$count ${'booked'.tr(context)} · ${'next'.tr(context)} ${next != null ? BookingOptions.clockLabel(next.startMin) : ''}',
              style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: count == 0 ? t.sage : t.ink2))),
          ]),
        ),
        Divider(color: t.line, height: 22),
        Row(children: [
          Expanded(child: Row(children: [
            Text('EGP ${c.price}', style: TextStyle(fontFamily: kSerif, fontSize: 16, fontWeight: FontWeight.w600, color: t.accent)),
            const SizedBox(width: 4),
            Text('/ ${'per hour'.tr(context)}', style: TextStyle(fontSize: 10.5, color: t.ink3)),
          ])),
          _mini(t, Icons.schedule_rounded, () => ScaffoldMessenger.of(context)
            ..clearSnackBars()
            ..showSnackBar(SnackBar(content: Text('${c.name} · ${c.hours}')))),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => _openForm(c: c),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(9)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.edit_outlined, size: 14, color: t.onAccent),
                const SizedBox(width: 5),
                Text('Edit'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.onAccent)),
              ]),
            ),
          ),
        ]),
      ]),
    ));
  }

  Widget _mini(LobbaTokens t, IconData ic, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(9)),
          child: Icon(ic, size: 15, color: t.ink2),
        ),
      );
}
