import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/i18n/lobba_i18n.dart';

/// Court-owner shell — a clean bottom nav in the Sage Atelier / Ink & Brass
/// theme (5 tabs: Dashboard · Courts · Bookings · Analytics · Deals).
class OrganizerShell extends StatelessWidget {
  final Widget child;
  const OrganizerShell({super.key, required this.child});

  static const _tabs = [
    (route: AppRoutes.organizerDashboard, icon: Icons.grid_view_rounded, label: 'Dashboard'),
    (route: AppRoutes.organizerVenues, icon: Icons.sports_tennis_rounded, label: 'Courts'),
    (route: AppRoutes.organizerBookings, icon: Icons.event_note_rounded, label: 'Bookings'),
    (route: AppRoutes.organizerAnalytics, icon: Icons.insights_rounded, label: 'Analytics'),
    (route: AppRoutes.organizerDeals, icon: Icons.local_offer_rounded, label: 'Deals'),
  ];

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final loc = GoRouterState.of(context).matchedLocation;
    final idx = _tabs.indexWhere((tab) => loc.startsWith(tab.route));
    final selected = idx == -1 ? 0 : idx;

    return Scaffold(
      backgroundColor: t.bg,
      body: child,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
            child: Row(
              children: List.generate(_tabs.length, (i) {
                final on = i == selected;
                final tab = _tabs[i];
                return Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => context.go(tab.route),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(tab.icon, size: 22, color: on ? t.accent : t.ink3),
                        const SizedBox(height: 4),
                        Text(
                          tab.label.tr(context),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w600, color: on ? t.accent : t.ink3),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}
