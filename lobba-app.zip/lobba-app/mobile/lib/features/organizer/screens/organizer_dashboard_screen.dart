import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../auth/providers/auth_provider.dart';
import '../../booking/providers/bookings_provider.dart';
import '../../discovery/data/courts_catalog.dart';
import 'owner_player_screen.dart';
import 'court_profile_screen.dart';

// Format minutes-from-midnight as "6:00".
String _hm(int min) {
  final h24 = min ~/ 60;
  final m = min % 60;
  final h = h24 % 12 == 0 ? 12 : h24 % 12;
  return '$h:${m.toString().padLeft(2, '0')}';
}

/// Court-owner home — today's numbers, revenue, pending alerts, quick actions
/// and recent bookings. Sage Atelier / Ink & Brass theme, bilingual.
class OrganizerDashboardScreen extends ConsumerStatefulWidget {
  const OrganizerDashboardScreen({super.key});
  @override
  ConsumerState<OrganizerDashboardScreen> createState() => _OrganizerDashboardScreenState();
}

class _OrganizerDashboardScreenState extends ConsumerState<OrganizerDashboardScreen> {
  // Dashboard period filter — Today / last 30 / 60 / 90 days.
  static const _periodDays = [1, 30, 60, 90];
  int _period = 0;
  int get _pDays => _periodDays[_period];
  int get _revenue => 4250 * _pDays;
  int get _bookingsCount => 18 * _pDays;
  int get _utilPct => const [72, 68, 70, 71][_period];

  String _money(int v) {
    final s = v.toString();
    final b = StringBuffer('EGP ');
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) b.write(',');
      b.write(s[i]);
    }
    return b.toString();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final user = ref.watch(authStateProvider).valueOrNull;
    final name = user?.name ?? 'Owner'.tr(context);

    return Container(
      color: t.bg,
      child: ListView(padding: const EdgeInsets.only(bottom: 30), children: [
        // green header
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 10, 18, 20),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Good afternoon ·'.tr(context), style: TextStyle(fontSize: 11, letterSpacing: .6, color: t.headFg.withOpacity(.8))),
              const SizedBox(height: 4),
              Text(name, style: TextStyle(fontFamily: kSerif, fontSize: 23, fontWeight: FontWeight.w500, color: t.headFg)),
            ])),
            GestureDetector(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CourtProfileScreen())),
              child: const CourtBrandAvatar(size: 42),
            ),
          ]),
        ))),
        const SizedBox(height: 14),
        // period filter — reflects on the numbers below
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          for (var i = 0; i < 4; i++) ...[
            if (i > 0) const SizedBox(width: 7),
            Expanded(child: _periodChip(t, i)),
          ],
        ])),
        const SizedBox(height: 14),
        // stats (scale with the selected period)
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          _stat(t, Icons.payments_outlined, _money(_revenue), _period == 0 ? 'Today’s revenue'.tr(context) : '${'Revenue · last'.tr(context)} $_pDays ${'days'.tr(context)}'),
          const SizedBox(width: 11),
          _stat(t, Icons.event_available_rounded, '$_bookingsCount', _period == 0 ? 'Bookings today'.tr(context) : '${'Bookings · last'.tr(context)} $_pDays ${'days'.tr(context)}'),
        ])),
        const SizedBox(height: 11),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          _util(context, t, _utilPct),
          const SizedBox(width: 11),
          _stat(t, Icons.sports_tennis_rounded, '4', 'Active courts'.tr(context)),
        ])),
        const SizedBox(height: 16),
        // revenue overview
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Revenue overview'.tr(context), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: t.ink)),
            const SizedBox(height: 14),
            Row(children: [
              _rev(t, 'This week'.tr(context), 'EGP 28,400', '96'),
              Container(width: 1, height: 46, color: t.line),
              _rev(t, 'This month'.tr(context), 'EGP 112,000', '380'),
            ]),
          ]),
        )),
        const SizedBox(height: 14),
        // pending alert
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: GestureDetector(
          onTap: () => context.go(AppRoutes.organizerBookings),
          child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: t.gold.withOpacity(.14), borderRadius: BorderRadius.circular(14), border: Border.all(color: t.gold.withOpacity(.34))),
            child: Row(children: [
              Icon(Icons.pending_actions_rounded, color: t.gold, size: 20),
              const SizedBox(width: 10),
              Expanded(child: Text('3 ${'awaiting payment'.tr(context)}', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink2))),
              Icon(Icons.chevron_right_rounded, color: t.gold, size: 20),
            ]),
          ),
        )),
        const SizedBox(height: 16),
        // quick actions
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          _action(context, t, Icons.add_circle_outline_rounded, 'Add court'.tr(context), AppRoutes.addCourt),
          const SizedBox(width: 10),
          _action(context, t, Icons.sports_tennis_outlined, 'My courts'.tr(context), AppRoutes.organizerVenues),
          const SizedBox(width: 10),
          _action(context, t, Icons.calendar_month_outlined, 'Schedule'.tr(context), AppRoutes.organizerBookings),
        ])),
        const SizedBox(height: 20),
        // recent bookings
        Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 10), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Recent bookings'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 16, fontWeight: FontWeight.w500, color: t.ink)),
          GestureDetector(onTap: () => context.go(AppRoutes.organizerBookings), child: Text('View all'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.accent))),
        ])),
        // Every booking for this venue — player app, WhatsApp locks and existing
        // reservations — refreshes here in real time (shared bookings engine).
        ...(() {
          ref.watch(bookingsProvider);
          final store = ref.watch(bookingsProvider.notifier);
          final list = store.forVenue(kOwnerVenueId);
          if (list.isEmpty) {
            return [Padding(padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14), child: Text('No bookings yet'.tr(context), style: TextStyle(fontSize: 12, color: t.ink3)))];
          }
          return list.map((b) {
            final c = courtById(b.courtId);
            final idx = [60, 90, 120].indexOf(b.durMin).clamp(0, 2);
            final isYou = b.player == 'You';
            final isWa = b.player == 'WhatsApp';
            final name = isWa ? 'WhatsApp lock'.tr(context) : b.player;
            return _booking(context, t, _hm(b.startMin), _hm(b.endMin), name,
                '${'Court'.tr(context)} ${b.subCourt}', isWa ? '—' : 'EGP ${c.priceFor(idx)}',
                (isWa ? 'Locked' : 'Confirmed').tr(context), isWa ? t.clay : t.sage, live: isYou);
          }).toList();
        }()),
      ]),
    );
  }

  Widget _periodChip(LobbaTokens t, int i) {
    final on = _period == i;
    final label = i == 0 ? 'Today'.tr(context) : '${_periodDays[i]}${'d'.tr(context)}';
    return GestureDetector(
      onTap: () => setState(() => _period = i),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        alignment: Alignment.center,
        decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: on ? t.accent : t.line)),
        child: Text(label, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: on ? t.onAccent : t.ink2)),
      ),
    );
  }

  Widget _stat(LobbaTokens t, IconData ic, String v, String l) => Expanded(child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 34, height: 34, decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(10)), child: Icon(ic, size: 18, color: t.accent)),
          const SizedBox(height: 11),
          Text(v, style: TextStyle(fontFamily: kSerif, fontSize: 19, fontWeight: FontWeight.w600, color: t.accent)),
          const SizedBox(height: 2),
          Text(l, style: TextStyle(fontSize: 10.5, color: t.ink3)),
        ]),
      ));

  Widget _util(BuildContext context, LobbaTokens t, int pct) => Expanded(child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 34, height: 34, decoration: BoxDecoration(color: t.sage.withOpacity(.16), borderRadius: BorderRadius.circular(10)), child: Icon(Icons.donut_large_rounded, size: 18, color: t.sage)),
          const SizedBox(height: 11),
          Text('$pct%', style: TextStyle(fontFamily: kSerif, fontSize: 19, fontWeight: FontWeight.w600, color: t.sage)),
          const SizedBox(height: 5),
          ClipRRect(borderRadius: BorderRadius.circular(4), child: LinearProgressIndicator(value: pct / 100, minHeight: 5, backgroundColor: t.sage.withOpacity(.14), valueColor: AlwaysStoppedAnimation(t.sage))),
          const SizedBox(height: 4),
          Text('Utilization today'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink3)),
        ]),
      ));

  Widget _rev(LobbaTokens t, String label, String v, String count) => Expanded(child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: t.ink3)),
          const SizedBox(height: 4),
          Text(v, style: TextStyle(fontFamily: kSerif, fontSize: 16, fontWeight: FontWeight.w600, color: t.accent)),
          const SizedBox(height: 2),
          Text('$count', style: TextStyle(fontSize: 10.5, color: t.ink3)),
        ]),
      ));

  Widget _action(BuildContext context, LobbaTokens t, IconData ic, String label, String route) => Expanded(child: GestureDetector(
        onTap: () => context.push(route),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
          decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(14)),
          child: Column(children: [
            Icon(ic, color: t.accent, size: 22),
            const SizedBox(height: 6),
            Text(label, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: t.accent)),
          ]),
        ),
      ));

  Widget _booking(BuildContext context, LobbaTokens t, String start, String end, String name, String meta, String amount, String status, Color statusColor, {bool split = false, bool live = false}) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 0, 22, 9),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => openOwnerPlayer(context, name),
          child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: live ? t.accentSoft.withOpacity(.5) : t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: live ? t.accent.withOpacity(.4) : t.line)),
          child: Row(children: [
            Container(width: 50, padding: const EdgeInsets.symmetric(vertical: 6), decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(9)), child: Column(children: [
              Text(start, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: t.accent)),
              Text(end, style: TextStyle(fontSize: 9.5, color: t.ink3)),
            ])),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Flexible(child: Text(name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink))),
                if (live) Padding(padding: const EdgeInsets.only(left: 5), child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1), decoration: BoxDecoration(color: t.sage.withOpacity(.18), borderRadius: BorderRadius.circular(5)), child: Text('New'.tr(context), style: TextStyle(fontSize: 8, fontWeight: FontWeight.w700, color: t.sage)))),
                const SizedBox(width: 4),
                Icon(Icons.chevron_right_rounded, size: 14, color: t.ink3),
              ]),
              const SizedBox(height: 2),
              Text(meta, style: TextStyle(fontSize: 10.5, color: t.ink3)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(amount, style: TextStyle(fontFamily: kSerif, fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
              const SizedBox(height: 4),
              Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: statusColor.withOpacity(.16), borderRadius: BorderRadius.circular(6)), child: Text(status, style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, color: statusColor))),
            ]),
          ]),
        ),
        ),
      );
}
