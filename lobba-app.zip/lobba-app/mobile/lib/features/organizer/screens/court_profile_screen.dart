import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/providers/theme_mode_provider.dart';
import '../../auth/providers/locale_provider.dart';
import '../../auth/providers/auth_provider.dart';
import '../providers/court_profile_provider.dart';
import 'organizer_settings_screens.dart';
import 'organizer_extra_screens.dart';

void _open(BuildContext c, Widget s) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => s));

/// Round court-logo avatar for the dashboard header — shows the uploaded logo or
/// a fallback court icon. Watches the court profile so it updates live.
class CourtBrandAvatar extends ConsumerWidget {
  final double size;
  const CourtBrandAvatar({super.key, this.size = 42});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final logo = ref.watch(courtProfileProvider).logoPath;
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(color: t.headFg.withOpacity(.14), borderRadius: BorderRadius.circular(13)),
      clipBehavior: Clip.antiAlias,
      child: logo != null && File(logo).existsSync()
          ? Image.file(File(logo), fit: BoxFit.cover)
          : Icon(Icons.sports_tennis_rounded, color: t.headFg, size: size * .46),
    );
  }
}

/// The court-owner profile hub — court identity, admin/manager contacts, quick
/// links to bookings & analytics, all settings, dark mode, language, log out.
class CourtProfileScreen extends ConsumerWidget {
  const CourtProfileScreen({super.key});

  Future<void> _pickLogo(WidgetRef ref) async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 800);
    if (x != null) ref.read(courtProfileProvider.notifier).setLogo(x.path);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final c = ref.watch(courtProfileProvider);
    final dark = ref.watch(themeModeProvider) == ThemeMode.dark;
    final code = ref.watch(localeProvider).languageCode;
    final logo = c.logoPath;

    return PushScaffold(
      title: 'Court profile'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 18, 22, 28), children: [
        // logo + name + location
        Center(child: Column(children: [
          GestureDetector(
            onTap: () => _pickLogo(ref),
            child: Stack(children: [
              Container(
                width: 96, height: 96,
                decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(28), border: Border.all(color: t.line)),
                clipBehavior: Clip.antiAlias,
                child: logo != null && File(logo).existsSync()
                    ? Image.file(File(logo), fit: BoxFit.cover)
                    : Icon(Icons.sports_tennis_rounded, size: 40, color: t.accent),
              ),
              Positioned(right: -2, bottom: -2, child: Container(width: 30, height: 30, decoration: BoxDecoration(color: t.accent, shape: BoxShape.circle, border: Border.all(color: t.bg, width: 2)), child: Icon(Icons.camera_alt_rounded, size: 15, color: t.onAccent))),
            ]),
          ),
          const SizedBox(height: 12),
          Text(c.name, style: TextStyle(fontFamily: kSerif, fontSize: 20, fontWeight: FontWeight.w600, color: t.ink)),
          const SizedBox(height: 3),
          Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.location_on_outlined, size: 13, color: t.ink3),
            const SizedBox(width: 4),
            Text(c.location, style: TextStyle(fontSize: 11.5, color: t.ink3)),
          ]),
        ])),
        const SizedBox(height: 20),
        // court info
        Padding(padding: const EdgeInsets.only(left: 4, bottom: 8), child: Row(children: [
          Expanded(child: Eyebrow('Court details'.tr(context))),
          GestureDetector(
            onTap: () => _open(context, const CourtDetailsEditScreen()),
            child: Row(children: [
              Icon(Icons.edit_outlined, size: 13, color: t.accent),
              const SizedBox(width: 3),
              Text('Edit'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.accent)),
            ]),
          ),
        ])),
        _card(t, [
          _infoRow(t, Icons.place_outlined, 'Address'.tr(context), c.address),
          _infoRow(t, Icons.admin_panel_settings_outlined, 'Admin'.tr(context), '${c.adminName} · ${c.adminPhone}'),
          _infoRow(t, Icons.badge_outlined, 'Manager'.tr(context), '${c.managerName} · ${c.managerPhone}'),
        ]),
        const SizedBox(height: 16),
        // quick links
        _card(t, [
          _navRow(context, t, Icons.event_note_rounded, 'View bookings'.tr(context), onTap: () { Navigator.of(context).pop(); context.go(AppRoutes.organizerBookings); }),
          _navRow(context, t, Icons.insights_rounded, 'Analytics'.tr(context), onTap: () { Navigator.of(context).pop(); context.go(AppRoutes.organizerAnalytics); }),
        ]),
        const SizedBox(height: 16),
        // settings
        Padding(padding: const EdgeInsets.only(left: 4, bottom: 8), child: Eyebrow('Settings'.tr(context))),
        _card(t, [
          _navRow(context, t, Icons.account_balance_wallet_outlined, 'Payout method'.tr(context), onTap: () => _open(context, const PayoutMethodScreen())),
          _navRow(context, t, Icons.chat_outlined, 'WhatsApp bookings'.tr(context), onTap: () => _open(context, const WhatsAppSlotsScreen())),
          _navRow(context, t, Icons.school_outlined, 'Training sessions'.tr(context), onTap: () => _open(context, const TrainingScreen())),
          _navRow(context, t, Icons.storefront_outlined, 'Store'.tr(context), onTap: () => _open(context, const StoreScreen())),
          _navRow(context, t, Icons.people_outline_rounded, 'Booking history'.tr(context), onTap: () => _open(context, const PlayersHistoryScreen())),
        ]),
        const SizedBox(height: 16),
        // dark mode (single row)
        Container(
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 4), child: Row(children: [
            Icon(Icons.dark_mode_outlined, size: 18, color: t.accent),
            const SizedBox(width: 11),
            Expanded(child: Text('Dark mode'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: t.ink))),
            Switch(value: dark, activeColor: t.accent, onChanged: (_) => ref.read(themeModeProvider.notifier).toggle()),
          ])),
        ),
        const SizedBox(height: 12),
        // language — single line select
        Container(
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10), child: Row(children: [
            Icon(Icons.language_rounded, size: 18, color: t.accent),
            const SizedBox(width: 11),
            Expanded(child: Text('Language'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: t.ink))),
            _langToggle(context, ref, t, code),
          ])),
        ),
        const SizedBox(height: 18),
        // log out
        GestureDetector(
          onTap: () => ref.read(authStateProvider.notifier).logout(),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15), alignment: Alignment.center,
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
            child: Text('Log out'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.clay)),
          ),
        ),
      ]),
    );
  }

  Widget _langToggle(BuildContext context, WidgetRef ref, LobbaTokens t, String code) {
    Widget opt(String label, String value) {
      final on = code == value;
      return GestureDetector(
        onTap: () => ref.read(localeProvider.notifier).setLocale(Locale(value)),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(color: on ? t.accent : Colors.transparent, borderRadius: BorderRadius.circular(9)),
          child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: on ? t.onAccent : t.ink3)),
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(11)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [opt('English', 'en'), const SizedBox(width: 2), opt('العربية', 'ar')]),
    );
  }

  Widget _card(LobbaTokens t, List<Widget> rows) => Container(
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
        child: Column(children: [
          for (var i = 0; i < rows.length; i++) ...[
            if (i > 0) Divider(height: 1, thickness: 1, color: t.line),
            rows[i],
          ]
        ]),
      );

  Widget _navRow(BuildContext c, LobbaTokens t, IconData ic, String label, {VoidCallback? onTap}) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14), child: Row(children: [
          Icon(ic, size: 18, color: t.accent),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: t.ink))),
          Icon(Icons.chevron_right_rounded, size: 16, color: t.ink3),
        ])),
      );

  Widget _infoRow(LobbaTokens t, IconData ic, String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(ic, size: 17, color: t.accent),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: t.ink3)),
            const SizedBox(height: 2),
            Text(value, style: TextStyle(fontSize: 12.5, color: t.ink)),
          ])),
        ]),
      );
}

// ── Edit court details ───────────────────────────────────────────────────────
class CourtDetailsEditScreen extends ConsumerStatefulWidget {
  const CourtDetailsEditScreen({super.key});
  @override
  ConsumerState<CourtDetailsEditScreen> createState() => _CourtDetailsEditScreenState();
}

class _CourtDetailsEditScreenState extends ConsumerState<CourtDetailsEditScreen> {
  late final TextEditingController _name, _location, _address, _adminName, _adminPhone, _managerName, _managerPhone;

  @override
  void initState() {
    super.initState();
    final c = ref.read(courtProfileProvider);
    _name = TextEditingController(text: c.name);
    _location = TextEditingController(text: c.location);
    _address = TextEditingController(text: c.address);
    _adminName = TextEditingController(text: c.adminName);
    _adminPhone = TextEditingController(text: c.adminPhone);
    _managerName = TextEditingController(text: c.managerName);
    _managerPhone = TextEditingController(text: c.managerPhone);
  }

  @override
  void dispose() {
    for (final c in [_name, _location, _address, _adminName, _adminPhone, _managerName, _managerPhone]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    ref.read(courtProfileProvider.notifier).save(CourtProfile(
          name: _name.text.trim(),
          location: _location.text.trim(),
          address: _address.text.trim(),
          adminName: _adminName.text.trim(),
          adminPhone: _adminPhone.text.trim(),
          managerName: _managerName.text.trim(),
          managerPhone: _managerPhone.text.trim(),
          logoPath: ref.read(courtProfileProvider).logoPath,
        ));
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(SnackBar(content: Text('Court details saved'.tr(context))));
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Court details'.tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: _save,
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text('Save changes'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        _label(t, 'Court name'.tr(context)), _field(t, _name, TextInputType.text),
        const SizedBox(height: 14),
        _label(t, 'Location'.tr(context)), _field(t, _location, TextInputType.text),
        const SizedBox(height: 14),
        _label(t, 'Address'.tr(context)), _field(t, _address, TextInputType.streetAddress, lines: 2),
        const SizedBox(height: 14),
        _label(t, 'Admin name'.tr(context)), _field(t, _adminName, TextInputType.text),
        const SizedBox(height: 14),
        _label(t, 'Admin mobile'.tr(context)), _field(t, _adminPhone, TextInputType.phone),
        const SizedBox(height: 14),
        _label(t, 'Manager name'.tr(context)), _field(t, _managerName, TextInputType.text),
        const SizedBox(height: 14),
        _label(t, 'Manager mobile'.tr(context)), _field(t, _managerPhone, TextInputType.phone),
      ]),
    );
  }

  Widget _label(LobbaTokens t, String s) => Padding(padding: const EdgeInsets.only(left: 2, bottom: 7), child: Text(s, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.ink2)));

  Widget _field(LobbaTokens t, TextEditingController c, TextInputType kb, {int lines = 1}) => TextField(
        controller: c, keyboardType: kb, maxLines: lines,
        style: TextStyle(color: t.ink, fontSize: 14),
        decoration: InputDecoration(
          filled: true, fillColor: t.surface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.accent, width: 1.5)),
        ),
      );
}
