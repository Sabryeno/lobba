import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../services/report_pdf.dart';

/// The analytics filter — a custom date range (from/to), an hour range
/// (from/to hour), a court and a duration. Defaults to the last 7 days, all
/// open hours, all courts, all durations.
class AnalyticsFilter {
  final int days;       // length of the selected date range (default 7)
  final int court;      // 0 = All, 1..4 = Court 1..4
  final int fromHour;   // opening hour of the time window (default 15 = 3 PM)
  final int toHour;     // closing hour (default 23 = 11 PM)
  final int dur;        // 0 = All, 1 = 60, 2 = 90, 3 = 120
  const AnalyticsFilter({this.days = 7, this.court = 0, this.fromHour = 15, this.toHour = 23, this.dur = 0});

  AnalyticsFilter copyWith({int? days, int? court, int? fromHour, int? toHour, int? dur}) =>
      AnalyticsFilter(days: days ?? this.days, court: court ?? this.court, fromHour: fromHour ?? this.fromHour, toHour: toHour ?? this.toHour, dur: dur ?? this.dur);

  bool get customDates => days != 7;
  bool get customHours => fromHour != 15 || toHour != 23;
  int get activeCount => (court != 0 ? 1 : 0) + (dur != 0 ? 1 : 0) + (customDates ? 1 : 0) + (customHours ? 1 : 0);
}

/// Court-owner analytics — weekly revenue bars, key metrics, payment split.
/// Filters recompute every number shown and require an explicit "Show results".
class OrganizerAnalyticsScreen extends ConsumerStatefulWidget {
  const OrganizerAnalyticsScreen({super.key});
  @override
  ConsumerState<OrganizerAnalyticsScreen> createState() => _OrganizerAnalyticsScreenState();
}

class _OrganizerAnalyticsScreenState extends ConsumerState<OrganizerAnalyticsScreen> {
  static const _days = ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  static const _base = [3200.0, 4100, 2600, 4700, 3500, 5600, 5000];
  static const _courts = ['All courts', 'Court 1', 'Court 2', 'Court 3', 'Court 4'];
  static const _durs = ['All', '60 min', '90 min', '120 min'];

  AnalyticsFilter _f = const AnalyticsFilter();

  double get _courtFactor => const [1.0, 0.34, 0.24, 0.22, 0.20][_f.court];
  double get _durFactor => const [1.0, 0.4, 0.4, 0.2][_f.dur];
  double get _daysFactor => _f.days / 7.0;
  // Full open window is 8h (3 PM–11 PM); a narrower hour range scales revenue.
  double get _hourFactor => ((_f.toHour - _f.fromHour).clamp(1, 8)) / 8.0;
  double get _factor => _courtFactor * _durFactor * _daysFactor * _hourFactor;

  List<double> get _amounts => _base.map((v) => v * _factor).toList();
  double get _total => _amounts.fold(0.0, (a, b) => a + b);
  int get _typicalTicket => const [640, 500, 750, 1000][_f.dur];
  int get _bookings => (_total / _typicalTicket).round().clamp(1, 100000);
  int get _avg => (_total / _bookings).round();
  int get _busyIndex {
    var best = 0;
    for (var i = 1; i < _amounts.length; i++) {
      if (_amounts[i] > _amounts[best]) best = i;
    }
    return best;
  }

  String _hourLabel(int h) {
    final ampm = h >= 12 ? 'PM' : 'AM';
    final hh = h % 12 == 0 ? 12 : h % 12;
    return '$hh $ampm';
  }

  // Busiest 2-hour window inside the selected hour range.
  String get _busiestHour {
    final peak = _f.fromHour >= 18 ? _f.fromHour : (18.clamp(_f.fromHour, _f.toHour - 2));
    return '${_hourLabel(peak)}–${_hourLabel(peak + 2)}';
  }

  String get _dateRangeLabel => _f.days == 7 ? 'Last 7 days' : 'Last ${_f.days} days';
  String get _hourRangeLabel => '${_hourLabel(_f.fromHour)} – ${_hourLabel(_f.toHour)}';
  String get _topCourt => _f.court == 0 ? 'Court 1' : _courts[_f.court];

  String _money(num v) {
    final s = v.round().toString();
    final b = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) b.write(',');
      b.write(s[i]);
    }
    return 'EGP $b';
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final maxAmt = _amounts.reduce((a, b) => a > b ? a : b);
    final rangeLabel = '$_dateRangeLabel · $_hourRangeLabel';
    return Container(
      color: t.bg,
      child: ListView(padding: const EdgeInsets.only(bottom: 30), children: [
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 10, 22, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Analytics'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w500, color: t.headFg)),
                const SizedBox(height: 4),
                Text(rangeLabel, style: TextStyle(fontSize: 11, color: t.headFg.withOpacity(.82))),
              ])),
              GestureDetector(
                onTap: () => _openFilter(context, t),
                child: Stack(clipBehavior: Clip.none, children: [
                  Container(width: 40, height: 40, decoration: BoxDecoration(color: t.headFg.withOpacity(.14), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.tune_rounded, color: t.headFg, size: 19)),
                  if (_f.activeCount > 0) Positioned(right: -3, top: -3, child: Container(
                    padding: const EdgeInsets.all(4), decoration: BoxDecoration(color: t.gold, shape: BoxShape.circle),
                    child: Text('${_f.activeCount}', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: Colors.white)),
                  )),
                ]),
              ),
              const SizedBox(width: 9),
              GestureDetector(
                onTap: () => exportAnalyticsReport(),
                child: Container(width: 40, height: 40, decoration: BoxDecoration(color: t.headFg.withOpacity(.14), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.ios_share_rounded, color: t.headFg, size: 18)),
              ),
            ]),
          ]),
        ))),
        const SizedBox(height: 16),
        // active filter chips
        if (_f.activeCount > 0) Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 4), child: Wrap(spacing: 7, runSpacing: 7, children: [
          if (_f.court != 0) _activeChip(t, _courts[_f.court], () => _apply(_f.copyWith(court: 0))),
          if (_f.customDates) _activeChip(t, _dateRangeLabel, () => _apply(_f.copyWith(days: 7))),
          if (_f.customHours) _activeChip(t, _hourRangeLabel, () => _apply(_f.copyWith(fromHour: 15, toHour: 23))),
          if (_f.dur != 0) _activeChip(t, _durs[_f.dur].tr(context), () => _apply(_f.copyWith(dur: 0))),
        ])),
        if (_f.activeCount > 0) const SizedBox(height: 12),
        // revenue by day chart
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Revenue by day'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.ink)),
            const SizedBox(height: 16),
            SizedBox(height: 120, child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              for (var i = 0; i < 7; i++) Expanded(child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                  Text('${(_amounts[i] / 1000).toStringAsFixed(1)}k', style: TextStyle(fontSize: 8, color: t.ink3)),
                  const SizedBox(height: 4),
                  Container(height: (90.0 * (maxAmt == 0 ? 0.0 : _amounts[i] / maxAmt)).clamp(2.0, 90.0), decoration: BoxDecoration(color: i == _busyIndex ? t.accent : t.accentSoft, borderRadius: const BorderRadius.vertical(top: Radius.circular(5)))),
                ]),
              )),
            ])),
            const SizedBox(height: 6),
            Row(children: [for (final d in _days) Expanded(child: Text(d, textAlign: TextAlign.center, style: TextStyle(fontSize: 8.5, color: t.ink3)))]),
          ]),
        )),
        const SizedBox(height: 14),
        // metrics grid
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          _metric(t, _money(_total), 'Total revenue'.tr(context)),
          const SizedBox(width: 11),
          _metric(t, _money(_avg), 'Avg per booking'.tr(context)),
        ])),
        const SizedBox(height: 11),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          _metric(t, _busiestHour, 'Busiest hour'.tr(context)),
          const SizedBox(width: 11),
          _metric(t, _topCourt.tr(context), 'Top court'.tr(context)),
        ])),
        const SizedBox(height: 11),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          _metric(t, '$_bookings', 'Bookings'.tr(context)),
          const SizedBox(width: 11),
          _metric(t, _durs[_f.dur].tr(context), 'Duration'.tr(context)),
        ])),
        const SizedBox(height: 14),
        // payment split
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Payment split'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.ink)),
            const SizedBox(height: 14),
            _bar(t, 'InstaPay', .58, t.accent),
            const SizedBox(height: 10),
            _bar(t, 'Fawry', .3, t.sage),
            const SizedBox(height: 10),
            _bar(t, 'Cash'.tr(context), .12, t.gold),
          ]),
        )),
      ]),
    );
  }

  void _apply(AnalyticsFilter f) => setState(() => _f = f);

  Widget _activeChip(LobbaTokens t, String label, VoidCallback onClear) => GestureDetector(
        onTap: onClear,
        child: Container(
          padding: const EdgeInsets.fromLTRB(11, 6, 8, 6),
          decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(99)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: t.accent)),
            const SizedBox(width: 4),
            Icon(Icons.close_rounded, size: 13, color: t.accent),
          ]),
        ),
      );

  void _openFilter(BuildContext context, LobbaTokens t) {
    var draft = _f;
    showModalBottomSheet(
      context: context, backgroundColor: t.surface, isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        Widget group(String title, List<String> options, int selected, ValueChanged<int> onPick) => Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: t.ink)),
                const SizedBox(height: 9),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (var i = 0; i < options.length; i++) GestureDetector(
                    onTap: () => setSheet(() => onPick(i)),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(color: selected == i ? t.accent : t.surface2, borderRadius: BorderRadius.circular(99), border: Border.all(color: selected == i ? t.accent : t.line)),
                      child: Text(options[i].tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: selected == i ? t.onAccent : t.ink2)),
                    ),
                  ),
                ]),
                const SizedBox(height: 18),
              ],
            );
        return SafeArea(child: Padding(
          padding: EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 16 + MediaQuery.of(ctx).viewInsets.bottom),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 38, height: 4, decoration: BoxDecoration(color: t.line, borderRadius: BorderRadius.circular(99)))),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: Text('Filter'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 18, fontWeight: FontWeight.w600, color: t.ink))),
              GestureDetector(
                onTap: () => setSheet(() => draft = const AnalyticsFilter()),
                child: Text('Reset'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.clay)),
              ),
            ]),
            const SizedBox(height: 18),
            // By date — custom From–To range + quick presets
            Text('By date (from – to)'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: t.ink)),
            const SizedBox(height: 9),
            GestureDetector(
              onTap: () async {
                final now = DateTime.now();
                final picked = await showDateRangePicker(
                  context: ctx, firstDate: now.subtract(const Duration(days: 365)), lastDate: now,
                  initialDateRange: DateTimeRange(start: now.subtract(Duration(days: draft.days - 1)), end: now),
                );
                if (picked != null) setSheet(() => draft = draft.copyWith(days: picked.duration.inDays + 1));
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(12), border: Border.all(color: t.line)),
                child: Row(children: [
                  Icon(Icons.date_range_rounded, size: 16, color: t.accent),
                  const SizedBox(width: 10),
                  Expanded(child: Text(draft.days == 7 ? 'Last 7 days'.tr(context) : '${'Last'.tr(context)} ${draft.days} ${'days'.tr(context)}', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink))),
                  Text('Pick dates'.tr(context), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: t.accent)),
                ]),
              ),
            ),
            const SizedBox(height: 9),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final d in const [7, 30, 60, 90]) GestureDetector(
                onTap: () => setSheet(() => draft = draft.copyWith(days: d)),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
                  decoration: BoxDecoration(color: draft.days == d ? t.accent : t.surface2, borderRadius: BorderRadius.circular(99), border: Border.all(color: draft.days == d ? t.accent : t.line)),
                  child: Text('${'Last'.tr(context)} $d ${'days'.tr(context)}', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: draft.days == d ? t.onAccent : t.ink2)),
                ),
              ),
            ]),
            const SizedBox(height: 18),
            group('By court'.tr(context), _courts, draft.court, (i) => draft = draft.copyWith(court: i)),
            // By time — from hour to hour
            Text('By time (from – to hour)'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: t.ink)),
            const SizedBox(height: 4),
            Text('${_hourLabel(draft.fromHour)} – ${_hourLabel(draft.toHour)}', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.accent)),
            RangeSlider(
              values: RangeValues(draft.fromHour.toDouble(), draft.toHour.toDouble()),
              min: 8, max: 24, divisions: 16, activeColor: t.accent,
              labels: RangeLabels(_hourLabel(draft.fromHour), _hourLabel(draft.toHour)),
              onChanged: (v) {
                var lo = v.start.round();
                var hi = v.end.round();
                if (hi - lo < 1) hi = lo + 1;
                setSheet(() => draft = draft.copyWith(fromHour: lo, toHour: hi));
              },
            ),
            const SizedBox(height: 12),
            group('By duration'.tr(context), _durs, draft.dur, (i) => draft = draft.copyWith(dur: i)),
            SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
              onPressed: () { _apply(draft); Navigator.pop(ctx); },
              style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: Text('Show results'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            )),
          ]),
        ));
      }),
    );
  }

  Widget _metric(LobbaTokens t, String v, String l) => Expanded(child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(v, style: TextStyle(fontFamily: kSerif, fontSize: 17, fontWeight: FontWeight.w600, color: t.accent)),
          const SizedBox(height: 3),
          Text(l, style: TextStyle(fontSize: 10.5, color: t.ink3)),
        ]),
      ));

  Widget _bar(LobbaTokens t, String label, double v, Color c) => Row(children: [
        SizedBox(width: 62, child: Text(label, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.ink2))),
        Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: v, minHeight: 9, backgroundColor: t.surface2, valueColor: AlwaysStoppedAnimation(c)))),
        const SizedBox(width: 10),
        Text('${(v * 100).round()}%', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: t.ink)),
      ]);
}
