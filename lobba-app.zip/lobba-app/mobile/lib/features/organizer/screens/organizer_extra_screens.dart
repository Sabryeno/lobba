import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../providers/owner_players_provider.dart';
import 'owner_player_screen.dart';

// ── Brand logo (owner) ───────────────────────────────────────────────────────
class BrandLogoScreen extends StatefulWidget {
  const BrandLogoScreen({super.key});
  @override
  State<BrandLogoScreen> createState() => _BrandLogoScreenState();
}

class _BrandLogoScreenState extends State<BrandLogoScreen> {
  String? _logo;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      setState(() => _logo = p.getString('owner_brand_logo'));
    } catch (_) {}
  }

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 800);
    if (x == null) return;
    setState(() => _logo = x.path);
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('owner_brand_logo', x.path);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Brand logo'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 20, 22, 24), children: [
        Center(child: GestureDetector(
          onTap: _pick,
          child: Container(
            width: 150, height: 150,
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: t.line)),
            clipBehavior: Clip.antiAlias,
            child: _logo != null
                ? Image.file(File(_logo!), fit: BoxFit.cover)
                : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.add_photo_alternate_outlined, size: 34, color: t.accent),
                    const SizedBox(height: 8),
                    Text('Add logo'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.accent)),
                  ]),
          ),
        )),
        const SizedBox(height: 16),
        Center(child: Text('Shown on your courts and tickets.', style: TextStyle(fontSize: 11, color: t.ink3))),
      ]),
    );
  }
}

// ── Players who booked this owner's courts ───────────────────────────────────
class PlayersHistoryScreen extends ConsumerWidget {
  const PlayersHistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final players = ref.watch(ownerPlayersProvider).values.toList();
    ref.watch(ownerSuspendedProvider);
    final suspend = ref.read(ownerSuspendedProvider.notifier);
    return PushScaffold(
      title: 'Booking history'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        Text('Tap a player to view their full profile.'.tr(context), style: TextStyle(fontSize: 11.5, color: t.ink3)),
        const SizedBox(height: 14),
        ...players.map((p) {
          final suspended = suspend.isSuspended(p.name);
          final trusted = !p.risky;
          return Padding(padding: const EdgeInsets.only(bottom: 11), child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => openOwnerPlayer(context, p.name),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: suspended ? t.clay.withOpacity(.4) : t.line)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  CircleAvatar(radius: 20, backgroundColor: t.accentSoft, child: Text(p.name[0], style: TextStyle(fontFamily: kSerif, color: t.accent, fontWeight: FontWeight.w600))),
                  const SizedBox(width: 11),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p.name, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: t.ink)),
                    Text('${'Level'.tr(context)} ${p.level}', style: TextStyle(fontSize: 10.5, color: t.ink3)),
                  ])),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3), decoration: BoxDecoration(color: (trusted ? t.sage : t.clay).withOpacity(.16), borderRadius: BorderRadius.circular(99)), child: Text(trusted ? 'Trusted player'.tr(context) : 'Risk player'.tr(context), style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, color: trusted ? t.sage : t.clay))),
                ]),
                const SizedBox(height: 11),
                Row(children: [
                  _stat(t, '${p.done}', 'Successful bookings'.tr(context), t.sage),
                  const SizedBox(width: 10),
                  _stat(t, '${p.cancels}', 'Cancellations'.tr(context), t.clay),
                ]),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: GestureDetector(
                    onTap: () => suspend.toggle(p.name),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 10), alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: suspended ? t.surface2 : t.clay.withOpacity(.12),
                        borderRadius: BorderRadius.circular(11),
                        border: Border.all(color: suspended ? t.line : t.clay.withOpacity(.4)),
                      ),
                      child: Text(suspended ? 'Reinstate'.tr(context) : 'Suspend from booking'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: suspended ? t.ink2 : t.clay)),
                    ),
                  )),
                  const SizedBox(width: 9),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(11)), child: Row(children: [
                    Text('View'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.accent)),
                    Icon(Icons.chevron_right_rounded, size: 15, color: t.accent),
                  ])),
                ]),
                if (suspended) Padding(padding: const EdgeInsets.only(top: 6), child: Text('· ${'Suspended'.tr(context)}', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: t.clay))),
              ]),
            ),
          ));
        }),
      ]),
    );
  }

  Widget _stat(LobbaTokens t, String v, String l, Color c) => Expanded(child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(11)),
        child: Column(children: [
          Text(v, style: TextStyle(fontFamily: kSerif, fontSize: 17, fontWeight: FontWeight.w700, color: c)),
          Text(l, textAlign: TextAlign.center, style: TextStyle(fontSize: 9, color: t.ink3)),
        ]),
      ));
}

// ── Training sessions (owner) ────────────────────────────────────────────────
class TrainingScreen extends StatefulWidget {
  const TrainingScreen({super.key});
  @override
  State<TrainingScreen> createState() => _TrainingScreenState();
}

class _TrainingScreenState extends State<TrainingScreen> {
  bool _oneToOne = true, _group = true;
  final _priceOne = TextEditingController(text: '400');
  final _priceGroup = TextEditingController(text: '150');

  @override
  void dispose() { _priceOne.dispose(); _priceGroup.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Training sessions'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        Text('Offer coaching at your courts — links to the player “Learn to play” tab.', style: TextStyle(fontSize: 11.5, color: t.ink3, height: 1.5)),
        const SizedBox(height: 16),
        _toggle(t, Icons.person_outline, '1-on-1'.tr(context), _oneToOne, (v) => setState(() => _oneToOne = v), _priceOne),
        const SizedBox(height: 11),
        _toggle(t, Icons.group_outlined, 'Group'.tr(context), _group, (v) => setState(() => _group = v), _priceGroup),
      ]),
    );
  }

  Widget _toggle(LobbaTokens t, IconData ic, String label, bool on, ValueChanged<bool> onCh, TextEditingController price) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
        child: Column(children: [
          Row(children: [
            Icon(ic, size: 18, color: t.accent),
            const SizedBox(width: 11),
            Expanded(child: Text(label, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink))),
            Switch(value: on, activeColor: t.accent, onChanged: onCh),
          ]),
          if (on) ...[
            const SizedBox(height: 8),
            TextField(controller: price, keyboardType: TextInputType.number, style: TextStyle(color: t.ink, fontSize: 14), decoration: InputDecoration(
              prefixText: 'EGP ', prefixStyle: TextStyle(color: t.ink2), filled: true, fillColor: t.surface2,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(11), borderSide: BorderSide(color: t.line)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(11), borderSide: BorderSide(color: t.accent)),
            )),
          ],
        ]),
      );
}

// ── Store (owner) ────────────────────────────────────────────────────────────
class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Store'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        Text('Sell your products to players'.tr(context), style: TextStyle(fontSize: 12, color: t.ink2, height: 1.5)),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(28), alignment: Alignment.center,
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: t.line)),
          child: Column(children: [
            Container(width: 60, height: 60, decoration: BoxDecoration(color: t.accentSoft, shape: BoxShape.circle), child: Icon(Icons.storefront_outlined, size: 28, color: t.accent)),
            const SizedBox(height: 14),
            Text('Store'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 17, fontWeight: FontWeight.w500, color: t.ink)),
            const SizedBox(height: 6),
            Text('Phase 2 · links to the player Store tab.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11.5, color: t.ink3)),
          ]),
        ),
        const SizedBox(height: 14),
        Container(padding: const EdgeInsets.all(14), alignment: Alignment.center, decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(14)), child: Text('Add store'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.onAccent))),
      ]),
    );
  }
}
