import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../../core/services/notifications.dart';
import '../../booking/data/booking_options.dart';
import '../../booking/providers/bookings_provider.dart';
import '../../discovery/data/courts_catalog.dart';
import 'organizer_extra_screens.dart';
import 'owner_player_screen.dart';

/// Court-owner booking requests — approve / decline incoming bookings.
class OrganizerBookingsScreen extends ConsumerStatefulWidget {
  const OrganizerBookingsScreen({super.key});
  @override
  ConsumerState<OrganizerBookingsScreen> createState() => _OrganizerBookingsScreenState();
}

class _Req {
  final String name, court, when, amount, pay;
  const _Req(this.name, this.court, this.when, this.amount, this.pay);
}

class _OrganizerBookingsScreenState extends ConsumerState<OrganizerBookingsScreen> {
  int _tab = 0;
  final _handled = <int, String>{}; // index -> 'Approved' | 'Declined'

  final _reqs = const [
    _Req('Ahmed Mohamed', 'Court 1', 'Today · 6:00 PM · 90 min', 'EGP 750', 'InstaPay'),
    _Req('Sara Mostafa', 'Court 2', 'Today · 8:00 PM · 60 min', 'EGP 500', 'Fawry'),
    _Req('Omar Khalil', 'Court 1', 'Tomorrow · 7:00 PM · 90 min', 'EGP 750', 'Cash'),
  ];

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Container(
      color: t.bg,
      child: ListView(padding: const EdgeInsets.only(bottom: 30), children: [
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 10, 22, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text('Booking requests'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w500, color: t.headFg))),
              GestureDetector(
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PlayersHistoryScreen())),
                child: Container(width: 40, height: 40, decoration: BoxDecoration(color: t.headFg.withOpacity(.14), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.people_outline_rounded, color: t.headFg, size: 20)),
              ),
            ]),
            const SizedBox(height: 12),
            Row(children: [_seg(t, 'New requests'.tr(context), 0), const SizedBox(width: 7), _seg(t, 'All'.tr(context), 1)]),
          ]),
        ))),
        const SizedBox(height: 16),
        // Live: real bookings placed & paid in the player app arrive here.
        ...(() {
          ref.watch(bookingsProvider);
          final store = ref.watch(bookingsProvider.notifier);
          final live = store.forVenue(kOwnerVenueId).where((b) => b.player == 'You').toList();
          return live.map((b) {
            final c = courtById(b.courtId);
            final idx = [60, 90, 120].indexOf(b.durMin).clamp(0, 2);
            final when = '${BookingOptions.dateLabel(b.day)} · ${BookingOptions.clockLabel(b.startMin)} · ${b.durMin} ${'min'.tr(context)}';
            return _liveCard(t, b.player, '${'Court'.tr(context)} ${b.subCourt}', when, 'EGP ${c.priceFor(idx)}');
          }).toList();
        }()),
        ...List.generate(_reqs.length, (i) => _card(t, i, _reqs[i])),
      ]),
    );
  }

  // A player-app booking that is already paid & confirmed — shown for awareness.
  Widget _liveCard(LobbaTokens t, String name, String court, String when, String amount) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 0, 22, 11),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => openOwnerPlayer(context, name),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: t.accentSoft.withOpacity(.5), borderRadius: BorderRadius.circular(16), border: Border.all(color: t.accent.withOpacity(.4))),
            child: Row(children: [
              CircleAvatar(radius: 18, backgroundColor: t.accentSoft, child: Text(name[0], style: TextStyle(fontFamily: kSerif, color: t.accent, fontWeight: FontWeight.w600))),
              const SizedBox(width: 11),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Text(name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
                  const SizedBox(width: 5),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1), decoration: BoxDecoration(color: t.sage.withOpacity(.18), borderRadius: BorderRadius.circular(5)), child: Text('New'.tr(context), style: TextStyle(fontSize: 8, fontWeight: FontWeight.w700, color: t.sage))),
                ]),
                const SizedBox(height: 2),
                Text('$court · $when', style: TextStyle(fontSize: 10.5, color: t.ink3)),
              ])),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(amount, style: TextStyle(fontFamily: kSerif, fontSize: 13, fontWeight: FontWeight.w600, color: t.accent)),
                const SizedBox(height: 4),
                _statusPill(t, 'Confirmed'.tr(context), t.sage),
              ]),
            ]),
          ),
        ),
      );

  Widget _seg(LobbaTokens t, String label, int i) {
    final on = i == _tab;
    return GestureDetector(onTap: () => setState(() => _tab = i), child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
      decoration: BoxDecoration(color: on ? t.headFg : t.headChipBg, borderRadius: BorderRadius.circular(99), border: Border.all(color: on ? t.headFg : t.headChipBd)),
      child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: on ? t.headBg : t.headFg)),
    ));
  }

  Widget _statusPill(LobbaTokens t, String text, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
        decoration: BoxDecoration(color: c.withOpacity(.16), borderRadius: BorderRadius.circular(99)),
        child: Text(text, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: c)),
      );

  Widget _card(LobbaTokens t, int i, _Req r) {
    final done = _handled[i];
    if (_tab == 0 && done != null) return const SizedBox.shrink();
    return Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 11), child: Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => openOwnerPlayer(context, r.name),
          child: Row(children: [
            CircleAvatar(radius: 18, backgroundColor: t.accentSoft, child: Text(r.name[0], style: TextStyle(fontFamily: kSerif, color: t.accent, fontWeight: FontWeight.w600))),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Flexible(child: Text(r.name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink))),
                const SizedBox(width: 3),
                Icon(Icons.chevron_right_rounded, size: 14, color: t.ink3),
              ]),
              Text('${r.court} · ${r.when}', style: TextStyle(fontSize: 10.5, color: t.ink3)),
            ])),
            Text(r.amount, style: TextStyle(fontFamily: kSerif, fontSize: 14, fontWeight: FontWeight.w600, color: t.accent)),
          ]),
        ),
        const SizedBox(height: 11),
        Row(children: [
          Icon(Icons.account_balance_wallet_outlined, size: 13, color: t.ink3),
          const SizedBox(width: 5),
          Text(r.pay, style: TextStyle(fontSize: 10.5, color: t.ink3)),
          const Spacer(),
          if (done != null)
            _statusPill(t, done == 'Approved' ? 'Approved'.tr(context) : 'Declined'.tr(context), done == 'Approved' ? t.sage : t.clay),
        ]),
        // Cash booking reminder control (5-min repeat while approved & unpaid).
        if (done == 'Approved' && r.pay == 'Cash') ...[
          const SizedBox(height: 9),
          GestureDetector(
            onTap: () { LobbaNotifications.stopCashReminder(); ScaffoldMessenger.of(context)..clearSnackBars()..showSnackBar(const SnackBar(content: Text('Reminders stopped'))); },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8), alignment: Alignment.center,
              decoration: BoxDecoration(color: t.gold.withOpacity(.14), borderRadius: BorderRadius.circular(10), border: Border.all(color: t.gold.withOpacity(.4))),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.notifications_active_outlined, size: 14, color: t.gold),
                const SizedBox(width: 6),
                Text('Cash reminder on · tap to mark paid', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: t.ink2)),
              ]),
            ),
          ),
        ],
        if (done == null) ...[
          const SizedBox(height: 11),
          Row(children: [
            Expanded(child: GestureDetector(onTap: () => setState(() => _handled[i] = 'Declined'), child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10), alignment: Alignment.center,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(11), border: Border.all(color: t.line)),
              child: Text('Decline'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.clay)),
            ))),
            const SizedBox(width: 9),
            Expanded(child: GestureDetector(onTap: () {
              setState(() => _handled[i] = 'Approved');
              if (r.pay == 'Cash') {
                LobbaNotifications.startCashReminder(r.name);
              } else {
                LobbaNotifications.notifyBooking(r.name);
              }
            }, child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10), alignment: Alignment.center,
              decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(11)),
              child: Text('Approve'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.onAccent)),
            ))),
          ]),
        ],
      ]),
    ));
  }
}
