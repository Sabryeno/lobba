import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../providers/owner_players_provider.dart';

/// Open the owner-side profile for a player by name. Use this anywhere a player
/// name is shown in the owner app so the name is always selectable.
void openOwnerPlayer(BuildContext context, String name) => Navigator.of(context)
    .push(MaterialPageRoute(builder: (_) => OwnerPlayerScreen(name: name)));

/// Court-owner view of a player: booking history at *this* venue, cancellation
/// count, payment method, a risk verdict, and a suspend control.
class OwnerPlayerScreen extends ConsumerWidget {
  final String name;
  const OwnerPlayerScreen({super.key, required this.name});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final p = resolveOwnerPlayer(ref, name);
    ref.watch(ownerSuspendedProvider); // rebuild on suspend change
    final suspended = ref.read(ownerSuspendedProvider.notifier).isSuspended(p.name);
    final trusted = !p.risky;

    Color statusColor(String s) => s == 'Confirmed' ? t.sage : s == 'Cancelled' ? t.clay : t.gold;

    return PushScaffold(
      title: 'Player'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 18, 22, 28), children: [
        // header
        Row(children: [
          CircleAvatar(radius: 28, backgroundColor: t.accentSoft, child: Text(p.name[0], style: TextStyle(fontFamily: kSerif, fontSize: 22, color: t.accent, fontWeight: FontWeight.w600))),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(p.name, style: TextStyle(fontFamily: kSerif, fontSize: 19, fontWeight: FontWeight.w600, color: t.ink)),
            const SizedBox(height: 3),
            Text('${'Level'.tr(context)} ${p.level}', style: TextStyle(fontSize: 11.5, color: t.ink3)),
          ])),
        ]),
        const SizedBox(height: 14),
        // risk verdict
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: (trusted ? t.sage : t.clay).withOpacity(.12),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: (trusted ? t.sage : t.clay).withOpacity(.4)),
          ),
          child: Row(children: [
            Icon(trusted ? Icons.verified_user_rounded : Icons.report_gmailerrorred_rounded, size: 22, color: trusted ? t.sage : t.clay),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(trusted ? 'Safe to approve'.tr(context) : 'Risky to approve'.tr(context), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: trusted ? t.sage : t.clay)),
              const SizedBox(height: 2),
              Text(trusted ? 'Reliable booking record.'.tr(context) : 'High cancellation rate.'.tr(context), style: TextStyle(fontSize: 11, color: t.ink3)),
            ])),
          ]),
        ),
        const SizedBox(height: 12),
        // contact + payment
        _infoCard(t, [
          _infoRow(t, Icons.phone_outlined, p.phone),
          _infoRow(t, Icons.mail_outline_rounded, p.email),
          _infoRow(t, Icons.account_balance_wallet_outlined, '${'Payment method'.tr(context)} · ${p.paymentMethod.tr(context)}'),
        ]),
        const SizedBox(height: 14),
        // stats
        Row(children: [
          _stat(t, '${p.done}', 'Successful bookings'.tr(context), t.sage),
          const SizedBox(width: 10),
          _stat(t, '${p.cancels}', 'Cancellations'.tr(context), t.clay),
        ]),
        const SizedBox(height: 18),
        Text('Booking history'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 15, fontWeight: FontWeight.w600, color: t.ink)),
        const SizedBox(height: 4),
        Text('At your courts only.'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink3)),
        const SizedBox(height: 12),
        ...p.history.map((b) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(b.court, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: t.ink)),
              const SizedBox(height: 2),
              Text(b.when, style: TextStyle(fontSize: 10.5, color: t.ink3)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(b.amount, style: TextStyle(fontFamily: kSerif, fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
              const SizedBox(height: 4),
              Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: statusColor(b.status).withOpacity(.16), borderRadius: BorderRadius.circular(6)), child: Text(b.status.tr(context), style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, color: statusColor(b.status)))),
            ]),
          ]),
        ))),
        const SizedBox(height: 8),
        // suspend
        GestureDetector(
          onTap: () => ref.read(ownerSuspendedProvider.notifier).toggle(p.name),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14), alignment: Alignment.center,
            decoration: BoxDecoration(
              color: suspended ? t.surface2 : t.clay.withOpacity(.12),
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: suspended ? t.line : t.clay.withOpacity(.4)),
            ),
            child: Text(suspended ? 'Reinstate player'.tr(context) : 'Suspend from booking'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: suspended ? t.ink2 : t.clay)),
          ),
        ),
        if (suspended) Padding(padding: const EdgeInsets.only(top: 8), child: Center(child: Text('· ${'Suspended'.tr(context)}', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: t.clay)))),
      ]),
    );
  }

  Widget _infoCard(LobbaTokens t, List<Widget> rows) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
        child: Column(children: rows),
      );

  Widget _infoRow(LobbaTokens t, IconData ic, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(children: [Icon(ic, size: 15, color: t.ink3), const SizedBox(width: 10), Expanded(child: Text(v, style: TextStyle(fontSize: 12, color: t.ink2)))]),
      );

  Widget _stat(LobbaTokens t, String v, String l, Color c) => Expanded(child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
        child: Column(children: [
          Text(v, style: TextStyle(fontFamily: kSerif, fontSize: 20, fontWeight: FontWeight.w700, color: c)),
          const SizedBox(height: 2),
          Text(l, textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: t.ink3)),
        ]),
      ));
}
