import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../../core/providers/theme_mode_provider.dart';
import '../../auth/providers/locale_provider.dart';
import '../../auth/providers/auth_provider.dart';
import '../../booking/data/booking_options.dart';
import '../../booking/providers/bookings_provider.dart';
import '../../discovery/data/courts_catalog.dart';
import 'organizer_extra_screens.dart';

void _open(BuildContext c, Widget s) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => s));

Widget _card(LobbaTokens t, List<Widget> rows) => Container(
      decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
      child: Column(children: [
        for (var i = 0; i < rows.length; i++) ...[
          if (i > 0) Divider(height: 1, thickness: 1, color: t.line),
          rows[i],
        ]
      ]),
    );

Widget _navRow(BuildContext c, LobbaTokens t, IconData ic, String label, {String? value, VoidCallback? onTap}) => GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14), child: Row(children: [
        Icon(ic, size: 18, color: t.accent),
        const SizedBox(width: 12),
        Expanded(child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: t.ink))),
        if (value != null) Text(value, style: TextStyle(fontSize: 11.5, color: t.ink3)),
        const SizedBox(width: 6),
        Icon(Icons.chevron_right_rounded, size: 16, color: t.ink3),
      ])),
    );

// ── Owner settings ──────────────────────────────────────────────────────────
class OwnerSettingsScreen extends ConsumerWidget {
  const OwnerSettingsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final dark = ref.watch(themeModeProvider) == ThemeMode.dark;
    final code = ref.watch(localeProvider).languageCode;

    Widget langOpt(String name, String value) => GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => ref.read(localeProvider.notifier).setLocale(Locale(value)),
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13), child: Row(children: [
            Expanded(child: Text(name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink))),
            Icon(code == value ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, size: 20, color: code == value ? t.accent : t.line),
          ])),
        );

    return PushScaffold(
      title: 'Owner settings'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 18, 22, 24), children: [
        _card(t, [
          _navRow(context, t, Icons.account_balance_wallet_outlined, 'Payout method'.tr(context), onTap: () => _open(context, const PayoutMethodScreen())),
          _navRow(context, t, Icons.chat_outlined, 'WhatsApp bookings'.tr(context), onTap: () => _open(context, const WhatsAppSlotsScreen())),
          _navRow(context, t, Icons.image_outlined, 'Brand logo'.tr(context), onTap: () => _open(context, const BrandLogoScreen())),
        ]),
        const SizedBox(height: 14),
        _card(t, [
          _navRow(context, t, Icons.school_outlined, 'Training sessions'.tr(context), onTap: () => _open(context, const TrainingScreen())),
          _navRow(context, t, Icons.storefront_outlined, 'Store'.tr(context), onTap: () => _open(context, const StoreScreen())),
          _navRow(context, t, Icons.people_outline_rounded, 'Booking history'.tr(context), onTap: () => _open(context, const PlayersHistoryScreen())),
        ]),
        const SizedBox(height: 14),
        // appearance
        Container(
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 4), child: Row(children: [
            Icon(Icons.dark_mode_outlined, size: 18, color: t.accent),
            const SizedBox(width: 11),
            Expanded(child: Text('Dark mode'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: t.ink))),
            Switch(value: dark, activeColor: t.accent, onChanged: (_) => ref.read(themeModeProvider.notifier).toggle()),
          ])),
        ),
        const SizedBox(height: 14),
        // language
        Padding(padding: const EdgeInsets.only(left: 4, bottom: 8), child: Eyebrow('Language'.tr(context))),
        _card(t, [langOpt('English', 'en'), langOpt('العربية', 'ar')]),
        const SizedBox(height: 18),
        // logout
        GestureDetector(
          onTap: () => ref.read(authStateProvider.notifier).logout(),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
            child: Text('Log out'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.clay)),
          ),
        ),
      ]),
    );
  }
}

// ── Payout method ────────────────────────────────────────────────────────────
class PayoutMethodScreen extends ConsumerStatefulWidget {
  const PayoutMethodScreen({super.key});
  @override
  ConsumerState<PayoutMethodScreen> createState() => _PayoutMethodScreenState();
}

class _PayoutMethodScreenState extends ConsumerState<PayoutMethodScreen> {
  String _method = 'bank'; // 'bank' | 'instapay'
  final _bankName = TextEditingController();
  final _accNumber = TextEditingController();
  final _accName = TextEditingController();
  final _instapay = TextEditingController();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      setState(() {
        _method = p.getString('owner_payout_method') ?? 'bank';
        _bankName.text = p.getString('owner_bank_name') ?? '';
        _accNumber.text = p.getString('owner_acc_number') ?? '';
        _accName.text = p.getString('owner_acc_name') ?? '';
        _instapay.text = p.getString('owner_instapay') ?? '';
        _loaded = true;
      });
    } catch (_) {
      setState(() => _loaded = true);
    }
  }

  Future<void> _save() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('owner_payout_method', _method);
      await p.setString('owner_bank_name', _bankName.text.trim());
      await p.setString('owner_acc_number', _accNumber.text.trim());
      await p.setString('owner_acc_name', _accName.text.trim());
      await p.setString('owner_instapay', _instapay.text.trim());
    } catch (_) {}
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(SnackBar(content: Text('Payout method saved'.tr(context))));
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _bankName.dispose(); _accNumber.dispose(); _accName.dispose(); _instapay.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Payout method'.tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: _save,
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text('Save changes'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: !_loaded
          ? const Center(child: Padding(padding: EdgeInsets.only(top: 60), child: CircularProgressIndicator()))
          : ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
              Text('Choose how players’ deposits reach you.'.tr(context), style: TextStyle(fontSize: 12, color: t.ink2, height: 1.5)),
              const SizedBox(height: 16),
              // segmented Bank / InstaPay
              Row(children: [
                _seg(t, Icons.account_balance_outlined, 'Bank account'.tr(context), 'bank'),
                const SizedBox(width: 10),
                _seg(t, Icons.phone_iphone_rounded, 'InstaPay'.tr(context), 'instapay'),
              ]),
              const SizedBox(height: 18),
              if (_method == 'bank') ...[
                _field(t, _bankName, 'Bank name'.tr(context), TextInputType.text),
                const SizedBox(height: 12),
                _field(t, _accNumber, 'Account number'.tr(context), TextInputType.number),
                const SizedBox(height: 12),
                _field(t, _accName, 'Account name'.tr(context), TextInputType.text),
              ] else ...[
                _field(t, _instapay, 'InstaPay number'.tr(context), TextInputType.phone),
              ],
            ]),
    );
  }

  Widget _seg(LobbaTokens t, IconData ic, String label, String value) {
    final on = _method == value;
    return Expanded(child: GestureDetector(
      onTap: () => setState(() => _method = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 15),
        alignment: Alignment.center,
        decoration: BoxDecoration(color: on ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: on ? t.accent : t.line, width: on ? 1.5 : 1)),
        child: Column(children: [
          Icon(ic, size: 22, color: on ? t.accent : t.ink3),
          const SizedBox(height: 7),
          Text(label, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: on ? t.accent : t.ink2)),
        ]),
      ),
    ));
  }

  Widget _field(LobbaTokens t, TextEditingController c, String hint, TextInputType kb) => TextField(
        controller: c, keyboardType: kb,
        style: TextStyle(color: t.ink, fontSize: 14),
        decoration: InputDecoration(
          hintText: hint, hintStyle: TextStyle(color: t.ink3), filled: true, fillColor: t.surface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.accent, width: 1.5)),
        ),
      );
}

// ── WhatsApp slot lock ───────────────────────────────────────────────────────
class WhatsAppSlotsScreen extends ConsumerStatefulWidget {
  const WhatsAppSlotsScreen({super.key});
  @override
  ConsumerState<WhatsAppSlotsScreen> createState() => _WhatsAppSlotsScreenState();
}

class _WhatsAppSlotsScreenState extends ConsumerState<WhatsAppSlotsScreen> {
  static const _durs = ['60 min', '90 min', '120 min'];
  static const _durMin = [60, 90, 120];
  List<String> get _slots => BookingOptions.slots; // 30-min grid
  int _court = 0, _day = 0, _dur = 1;
  int? _slot; // selected time index

  // Minimal upcoming-day strip: weekday + day number.
  List<List<String>> get _dates => BookingOptions.days;

  // Lock writes a real booking into the shared engine so the player app can no
  // longer double-book that court/time — true two-way sync.
  Future<void> _lock() async {
    if (_slot == null) return;
    final store = ref.read(bookingsProvider.notifier);
    final res = await store.book(Booking(
      courtId: kOwnerVenueId,
      subCourt: _court + 1,
      day: _day,
      startMin: BookingOptions.startMinFor(_slot!),
      durMin: _durMin[_dur],
      reference: 'WA-${_court + 1}-$_day-${_slot!}-$_dur-${DateTime.now().millisecondsSinceEpoch}',
      player: 'WhatsApp',
    ));
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(SnackBar(content: Text((res.ok ? 'Slot locked' : 'That court just got taken — pick another time or court.').tr(context))));
    if (res.ok) setState(() => _slot = null);
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final store = ref.watch(bookingsProvider.notifier);
    ref.watch(bookingsProvider);
    final locked = store.forVenue(kOwnerVenueId).where((b) => b.player == 'WhatsApp').toList();
    // A time slot is unavailable if the chosen court is not free for it.
    bool slotFree(int i) => store.isCourtFree(kOwnerVenueId, _court + 1, _day, BookingOptions.startMinFor(i), _durMin[_dur]);
    return PushScaffold(
      title: 'WhatsApp bookings'.tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton.icon(
          onPressed: _slot == null ? null : _lock,
          icon: const Icon(Icons.lock_rounded, size: 18),
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, disabledBackgroundColor: t.surface2, disabledForegroundColor: t.ink3, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          label: Text('Lock slot'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(13)),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.chat_outlined, size: 16, color: t.accent),
            const SizedBox(width: 10),
            Expanded(child: Text('Lock a slot taken on WhatsApp so it can’t be double-booked in the app.'.tr(context), style: TextStyle(fontSize: 11, color: t.ink2, height: 1.5))),
          ]),
        ),
        const SizedBox(height: 18),
        // Court — compact chips (owner venue's real courts)
        _label(t, 'Court'.tr(context)),
        Row(children: [
          for (var i = 0; i < courtById(kOwnerVenueId).courtCount; i++) ...[
            if (i > 0) const SizedBox(width: 7),
            Expanded(child: _chip(t, '${i + 1}', i == _court, () => setState(() { _court = i; _slot = null; }))),
          ],
        ]),
        const SizedBox(height: 16),
        // Date — minimal sliding strip with weekday + day number
        _label(t, 'Date'.tr(context)),
        SizedBox(height: 50, child: ListView.separated(
          scrollDirection: Axis.horizontal, itemCount: _dates.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (c, i) {
            final on = i == _day;
            return GestureDetector(onTap: () => setState(() => _day = i), child: Container(
              width: 44, alignment: Alignment.center,
              decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: on ? t.accent : t.line)),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(_dates[i][0], style: TextStyle(fontSize: 9, fontWeight: FontWeight.w600, color: on ? t.onAccent.withOpacity(.85) : t.ink3)),
                const SizedBox(height: 2),
                Text(_dates[i][1], style: TextStyle(fontFamily: kSerif, fontSize: 15, fontWeight: FontWeight.w700, color: on ? t.onAccent : t.ink)),
              ]),
            ));
          },
        )),
        const SizedBox(height: 16),
        // Duration
        _label(t, 'Duration'.tr(context)),
        Row(children: [
          for (var i = 0; i < _durs.length; i++) ...[
            if (i > 0) const SizedBox(width: 8),
            Expanded(child: _chip(t, _durs[i].tr(context), _dur == i, () => setState(() { _dur = i; _slot = null; }))),
          ],
        ]),
        const SizedBox(height: 16),
        // Time — 30-min grid; booked slots for this court are greyed out
        _label(t, 'Time · 30-min slots'.tr(context)),
        GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 2.5,
          children: List.generate(_slots.length, (i) {
            final free = slotFree(i);
            final on = _slot == i;
            return GestureDetector(
              onTap: free ? () => setState(() => _slot = i) : null,
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(color: !free ? t.surface2 : (on ? t.accent : t.surface), borderRadius: BorderRadius.circular(11), border: Border.all(color: on ? t.accent : t.line)),
                child: Text(_slots[i], style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, decoration: free ? null : TextDecoration.lineThrough, color: !free ? t.ink3 : (on ? t.onAccent : t.ink2))),
              ),
            );
          }),
        ),
        if (locked.isNotEmpty) ...[
          const SizedBox(height: 22),
          _label(t, 'Locked on WhatsApp'.tr(context)),
          ...locked.map((b) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: t.clay.withOpacity(.35))),
            child: Row(children: [
              Icon(Icons.lock_rounded, size: 15, color: t.clay),
              const SizedBox(width: 10),
              Expanded(child: Text('${'Court'.tr(context)} ${b.subCourt} · ${_dates[b.day.clamp(0, _dates.length - 1)][0]} ${_dates[b.day.clamp(0, _dates.length - 1)][1]} · ${BookingOptions.clockLabel(b.startMin)} · ${b.durMin} ${'min'.tr(context)}', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.ink2))),
              GestureDetector(
                onTap: () => ref.read(bookingsProvider.notifier).remove(b.reference),
                child: Text('Unlock'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.clay)),
              ),
            ]),
          ))),
        ],
      ]),
    );
  }

  Widget _label(LobbaTokens t, String s) => Padding(padding: const EdgeInsets.only(left: 2, bottom: 8), child: Text(s, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.ink2)));

  Widget _chip(LobbaTokens t, String label, bool on, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 9),
          alignment: Alignment.center,
          decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(11), border: Border.all(color: on ? t.accent : t.line)),
          child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: on ? t.onAccent : t.ink2)),
        ),
      );
}
