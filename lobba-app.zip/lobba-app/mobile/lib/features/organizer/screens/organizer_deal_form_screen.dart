import 'package:flutter/material.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';

/// Create / edit a last-minute deal — court, original price, discount %,
/// computed after-price, start time + duration.
class DealFormScreen extends StatefulWidget {
  final bool isEdit;
  const DealFormScreen({super.key, this.isEdit = false});
  @override
  State<DealFormScreen> createState() => _DealFormScreenState();
}

class _DealFormScreenState extends State<DealFormScreen> {
  static const _courts = ['Court 1', 'Court 2', 'Court 3', 'Court 4'];
  static const _durations = ['60 min', '90 min', '120 min'];
  // Demand per 30-min slot (%) — a deal is only allowed on "dead time" (< 40%).
  static const _slotDemand = {
    '2:00 PM': 15, '2:30 PM': 18, '3:00 PM': 22, '3:30 PM': 28, '4:00 PM': 34,
    '4:30 PM': 39, '5:00 PM': 58, '5:30 PM': 72, '6:00 PM': 90, '6:30 PM': 93,
    '7:00 PM': 95, '7:30 PM': 94, '8:00 PM': 92, '8:30 PM': 80, '9:00 PM': 62,
    '9:30 PM': 44, '10:00 PM': 30, '10:30 PM': 24, '11:00 PM': 18,
  };
  int _court = 0, _dur = 0;
  double _discount = 25;
  String? _slot; // chosen dead-time slot
  final _price = TextEditingController(text: '750');

  int get _priceVal => int.tryParse(_price.text.trim()) ?? 0;
  int get _after => (_priceVal * (1 - _discount / 100)).round();
  bool _isDead(int demand) => demand < 40;

  @override
  void dispose() {
    _price.dispose();
    super.dispose();
  }

  void _save() {
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(SnackBar(content: Text('Deal created'.tr(context))));
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: (widget.isEdit ? 'Edit' : 'New deal').tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: _slot == null ? null : _save,
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, disabledBackgroundColor: t.line, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text('Save deal'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        _label(t, 'Select a court'.tr(context)),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (var i = 0; i < _courts.length; i++) _chip(t, _courts[i], i == _court, () => setState(() => _court = i)),
        ]),
        const SizedBox(height: 18),
        _label(t, 'Original price'.tr(context)),
        _field(t, _price, '750', prefix: 'EGP '),
        const SizedBox(height: 18),
        _label(t, 'Discount %'.tr(context)),
        Row(children: [
          Expanded(child: Slider(value: _discount, min: 5, max: 60, divisions: 11, activeColor: t.accent, label: '${_discount.round()}%', onChanged: (v) => setState(() => _discount = v))),
          SizedBox(width: 46, child: Text('${_discount.round()}%', textAlign: TextAlign.end, style: TextStyle(fontFamily: kSerif, fontSize: 16, fontWeight: FontWeight.w600, color: t.accent))),
        ]),
        const SizedBox(height: 6),
        // price after discount
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(14)), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Price after discount'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.accent)),
          Row(children: [
            Text('EGP $_priceVal', style: TextStyle(fontSize: 11, color: t.ink3, decoration: TextDecoration.lineThrough)),
            const SizedBox(width: 8),
            Text('EGP $_after', style: TextStyle(fontFamily: kSerif, fontSize: 18, fontWeight: FontWeight.w700, color: t.accent)),
          ]),
        ])),
        const SizedBox(height: 18),
        _label(t, 'Start time · 30-min slots'.tr(context)),
        Container(
          padding: const EdgeInsets.all(11),
          decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            Icon(Icons.trending_down_rounded, size: 15, color: t.accent),
            const SizedBox(width: 8),
            Expanded(child: Text('Deals apply only to low-demand (dead-time) slots.'.tr(context), style: TextStyle(fontSize: 10.5, color: t.accent, height: 1.4))),
          ]),
        ),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final e in _slotDemand.entries)
            _slotChip(t, e.key, e.value),
        ]),
        const SizedBox(height: 18),
        _label(t, 'Duration'.tr(context)),
        Row(children: [for (var i = 0; i < _durations.length; i++) ...[
          if (i > 0) const SizedBox(width: 9),
          Expanded(child: GestureDetector(onTap: () => setState(() => _dur = i), child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12), alignment: Alignment.center,
            decoration: BoxDecoration(color: _dur == i ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _dur == i ? t.accent : t.line, width: _dur == i ? 1.5 : 1)),
            child: Text(_durations[i].tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: _dur == i ? t.accent : t.ink)),
          ))),
        ]]),
      ]),
    );
  }

  Widget _label(LobbaTokens t, String s) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Eyebrow(s));

  Widget _slotChip(LobbaTokens t, String slot, int demand) {
    final dead = _isDead(demand);
    final on = _slot == slot;
    return GestureDetector(
      onTap: dead ? () => setState(() => _slot = slot) : null,
      child: Opacity(opacity: dead ? 1 : .5, child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: on ? t.accent : t.line)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(slot, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: on ? t.onAccent : t.ink)),
          Text((dead ? 'Dead time' : 'Peak').tr(context), style: TextStyle(fontSize: 8, fontWeight: FontWeight.w600, color: on ? t.onAccent.withOpacity(.85) : (dead ? t.sage : t.clay))),
        ]),
      )),
    );
  }

  Widget _chip(LobbaTokens t, String label, bool on, VoidCallback onTap) => GestureDetector(onTap: onTap, child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
        decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(99), border: Border.all(color: on ? t.accent : t.line)),
        child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: on ? t.onAccent : t.ink2)),
      ));

  Widget _field(LobbaTokens t, TextEditingController c, String hint, {String? prefix}) => TextField(
        controller: c, keyboardType: prefix != null ? TextInputType.number : TextInputType.text,
        onChanged: (_) => setState(() {}),
        style: TextStyle(color: t.ink, fontSize: 14),
        decoration: InputDecoration(
          hintText: hint, hintStyle: TextStyle(color: t.ink3), prefixText: prefix, prefixStyle: TextStyle(color: t.ink2, fontSize: 14),
          filled: true, fillColor: t.surface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.accent, width: 1.5)),
        ),
      );
}
