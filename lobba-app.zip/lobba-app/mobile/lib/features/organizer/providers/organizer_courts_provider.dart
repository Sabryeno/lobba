import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/network/api_client.dart';
import '../../../shared/models/organizer_court.dart';

/// Fetches and manages the authenticated organizer's court portfolio.
///
/// Endpoint: GET /courts/my
/// Supports pull-to-refresh and optimistic active/inactive toggle.
final organizerCourtsProvider =
    AsyncNotifierProvider<OrganizerCourtsNotifier, List<OrganizerCourt>>(
  OrganizerCourtsNotifier.new,
);

class OrganizerCourtsNotifier extends AsyncNotifier<List<OrganizerCourt>> {
  @override
  Future<List<OrganizerCourt>> build() => _fetch();

  Future<List<OrganizerCourt>> _fetch() async {
    final api = ref.read(apiClientProvider);
    final response = await api.get('/courts/my');
    return (response.data as List<dynamic>)
        .map((e) => OrganizerCourt.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(_fetch);
  }

  /// Optimistically toggles a court's active status.
  /// Reverts on API error and rethrows so the UI can show a snackbar.
  Future<void> toggleActive(String courtId, {required bool isActive}) async {
    final previous = state.valueOrNull ?? [];

    // Flip locally right away
    state = AsyncData(
      previous
          .map((c) => c.id == courtId ? c.copyWith(isActive: isActive) : c)
          .toList(),
    );

    try {
      final api = ref.read(apiClientProvider);
      await api.patch('/courts/$courtId', data: {'isActive': isActive});
    } catch (e, st) {
      // Roll back
      state = AsyncData(previous);
      Error.throwWithStackTrace(e, st);
    }
  }
}
