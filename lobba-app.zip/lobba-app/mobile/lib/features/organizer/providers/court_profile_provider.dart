import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// The owner's court/venue identity — shown in the Court profile hub and via the
/// brand avatar in the dashboard header. Persisted locally.
class CourtProfile {
  final String name, location, address, adminName, adminPhone, managerName, managerPhone;
  final String? logoPath;
  const CourtProfile({
    this.name = 'Lobba Padel Club',
    this.location = 'New Cairo, Cairo',
    this.address = '90th Street, 5th Settlement, New Cairo',
    this.adminName = 'Mahmoud Sabry',
    this.adminPhone = '+20 100 123 4567',
    this.managerName = 'Youssef Hany',
    this.managerPhone = '+20 111 900 4432',
    this.logoPath,
  });

  CourtProfile copyWith({
    String? name, String? location, String? address,
    String? adminName, String? adminPhone, String? managerName, String? managerPhone,
    String? logoPath,
  }) =>
      CourtProfile(
        name: name ?? this.name,
        location: location ?? this.location,
        address: address ?? this.address,
        adminName: adminName ?? this.adminName,
        adminPhone: adminPhone ?? this.adminPhone,
        managerName: managerName ?? this.managerName,
        managerPhone: managerPhone ?? this.managerPhone,
        logoPath: logoPath ?? this.logoPath,
      );
}

class CourtProfileNotifier extends Notifier<CourtProfile> {
  @override
  CourtProfile build() {
    _load();
    return const CourtProfile();
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      state = CourtProfile(
        name: p.getString('court_name') ?? const CourtProfile().name,
        location: p.getString('court_location') ?? const CourtProfile().location,
        address: p.getString('court_address') ?? const CourtProfile().address,
        adminName: p.getString('court_admin_name') ?? const CourtProfile().adminName,
        adminPhone: p.getString('court_admin_phone') ?? const CourtProfile().adminPhone,
        managerName: p.getString('court_manager_name') ?? const CourtProfile().managerName,
        managerPhone: p.getString('court_manager_phone') ?? const CourtProfile().managerPhone,
        logoPath: p.getString('owner_brand_logo'),
      );
    } catch (_) {}
  }

  Future<void> save(CourtProfile c) async {
    state = c;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('court_name', c.name);
      await p.setString('court_location', c.location);
      await p.setString('court_address', c.address);
      await p.setString('court_admin_name', c.adminName);
      await p.setString('court_admin_phone', c.adminPhone);
      await p.setString('court_manager_name', c.managerName);
      await p.setString('court_manager_phone', c.managerPhone);
    } catch (_) {}
  }

  Future<void> setLogo(String path) async {
    state = state.copyWith(logoPath: path);
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('owner_brand_logo', path);
    } catch (_) {}
  }
}

final courtProfileProvider = NotifierProvider<CourtProfileNotifier, CourtProfile>(CourtProfileNotifier.new);
