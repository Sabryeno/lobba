import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/network/api_client.dart';

// ── Models ────────────────────────────────────────────────────────────────────

class DashboardToday {
  final int revenue;
  final int bookingCount;
  final int utilization; // 0–100 %
  const DashboardToday({
    required this.revenue,
    required this.bookingCount,
    required this.utilization,
  });
  factory DashboardToday.fromJson(Map<String, dynamic> j) => DashboardToday(
        revenue: (j['revenue'] as num? ?? 0).toInt(),
        bookingCount: (j['bookingCount'] as num? ?? 0).toInt(),
        utilization: (j['utilization'] as num? ?? 0).toInt(),
      );
}

class DashboardPeriod {
  final int revenue;
  final int bookingCount;
  const DashboardPeriod({required this.revenue, required this.bookingCount});
  factory DashboardPeriod.fromJson(Map<String, dynamic> j) => DashboardPeriod(
        revenue: (j['revenue'] as num? ?? 0).toInt(),
        bookingCount: (j['bookingCount'] as num? ?? 0).toInt(),
      );
}

class RecentBooking {
  final String id;
  final String bookingRef;
  final String courtName;
  final String venueName;
  final String playerName;
  final String date;
  final String startTime;
  final String endTime;
  final int totalAmountEgp;
  final String status;
  final String paymentStatus;
  final String paymentMode;

  const RecentBooking({
    required this.id,
    required this.bookingRef,
    required this.courtName,
    required this.venueName,
    required this.playerName,
    required this.date,
    required this.startTime,
    required this.endTime,
    required this.totalAmountEgp,
    required this.status,
    required this.paymentStatus,
    required this.paymentMode,
  });

  factory RecentBooking.fromJson(Map<String, dynamic> j) => RecentBooking(
        id: j['id'] as String,
        bookingRef: j['bookingRef'] as String? ?? '',
        courtName: j['courtName'] as String? ?? 'Court',
        venueName: j['venueName'] as String? ?? 'Venue',
        playerName: j['playerName'] as String? ?? 'Player',
        date: j['date'] as String? ?? '',
        startTime: j['startTime'] as String? ?? '',
        endTime: j['endTime'] as String? ?? '',
        totalAmountEgp: (j['totalAmountEgp'] as num? ?? 0).toInt(),
        status: j['status'] as String? ?? 'pending_payment',
        paymentStatus: j['paymentStatus'] as String? ?? 'pending',
        paymentMode: j['paymentMode'] as String? ?? 'full',
      );

  bool get isConfirmed => status == 'confirmed';
  bool get isCancelled => status == 'cancelled';
  bool get isSplit => paymentMode == 'split';
}

class DashboardData {
  final DashboardToday today;
  final DashboardPeriod week;
  final DashboardPeriod month;
  final List<RecentBooking> recentBookings;
  final int courtCount;
  final int pendingPayments;

  const DashboardData({
    required this.today,
    required this.week,
    required this.month,
    required this.recentBookings,
    required this.courtCount,
    required this.pendingPayments,
  });

  factory DashboardData.fromJson(Map<String, dynamic> j) => DashboardData(
        today: DashboardToday.fromJson(j['today'] as Map<String, dynamic>),
        week: DashboardPeriod.fromJson(j['week'] as Map<String, dynamic>),
        month: DashboardPeriod.fromJson(j['month'] as Map<String, dynamic>),
        recentBookings: (j['recentBookings'] as List<dynamic>? ?? [])
            .map((e) => RecentBooking.fromJson(e as Map<String, dynamic>))
            .toList(),
        courtCount: (j['courtCount'] as num? ?? 0).toInt(),
        pendingPayments: (j['pendingPayments'] as num? ?? 0).toInt(),
      );
}

// ── Provider ──────────────────────────────────────────────────────────────────

final organizerDashboardProvider =
    AsyncNotifierProvider.autoDispose<OrganizerDashboardNotifier, DashboardData>(
  OrganizerDashboardNotifier.new,
);

class OrganizerDashboardNotifier
    extends AutoDisposeAsyncNotifier<DashboardData> {
  @override
  Future<DashboardData> build() => _fetch();

  Future<DashboardData> _fetch() async {
    final api = ref.read(apiClientProvider);
    final res = await api.get('/organizer/dashboard');
    return DashboardData.fromJson(res.data as Map<String, dynamic>);
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(_fetch);
  }
}
