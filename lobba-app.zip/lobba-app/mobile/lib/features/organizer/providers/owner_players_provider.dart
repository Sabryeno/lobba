import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// A single booking a player made *at this owner's courts* (owner only ever
/// sees bookings that belong to their own venue).
class OwnerBooking {
  final String court, when, amount, status; // status: Confirmed | Pending | Cancelled
  const OwnerBooking(this.court, this.when, this.amount, this.status);
}

/// Player as seen from the court-owner side — booking history, cancellation
/// count, payment method and a computed risk verdict for approve decisions.
class OwnerPlayer {
  final String name, phone, email, level, paymentMethod;
  final List<OwnerBooking> history;
  const OwnerPlayer(this.name, this.phone, this.email, this.level, this.paymentMethod, this.history);

  int get done => history.where((b) => b.status == 'Confirmed').length;
  int get cancels => history.where((b) => b.status == 'Cancelled').length;
  int get total => history.length;
  /// Risky to approve when cancellations pile up relative to completed games.
  bool get risky => cancels >= 4 || (total > 0 && cancels > done);
}

/// Owner-visible player directory (bookings scoped to this owner's courts only).
final ownerPlayersProvider = Provider<Map<String, OwnerPlayer>>((ref) => const {
      'Ahmed Mohamed': OwnerPlayer('Ahmed Mohamed', '+20 100 123 4567', 'ahmed@mail.com', 'C+', 'InstaPay', [
        OwnerBooking('Court 1', 'Today · 6:00 PM · 90 min', 'EGP 750', 'Confirmed'),
        OwnerBooking('Court 1', '2 Jul · 7:00 PM · 90 min', 'EGP 750', 'Confirmed'),
        OwnerBooking('Court 2', '24 Jun · 8:00 PM · 60 min', 'EGP 500', 'Confirmed'),
        OwnerBooking('Court 1', '18 Jun · 6:00 PM · 60 min', 'EGP 500', 'Cancelled'),
      ]),
      'Sara Mostafa': OwnerPlayer('Sara Mostafa', '+20 101 555 8890', 'sara@mail.com', 'B', 'Fawry', [
        OwnerBooking('Court 2', 'Today · 8:00 PM · 60 min', 'EGP 500', 'Pending'),
        OwnerBooking('Court 2', '3 Jul · 8:00 PM · 60 min', 'EGP 500', 'Confirmed'),
        OwnerBooking('Court 3', '27 Jun · 9:00 PM · 90 min', 'EGP 750', 'Confirmed'),
        OwnerBooking('Court 1', '20 Jun · 7:00 PM · 90 min', 'EGP 750', 'Confirmed'),
      ]),
      'Karim Adel': OwnerPlayer('Karim Adel', '+20 106 220 1120', 'karim@mail.com', 'C', 'Cash', [
        OwnerBooking('Court 1', '5 Jul · 6:00 PM · 60 min', 'EGP 500', 'Cancelled'),
        OwnerBooking('Court 1', '1 Jul · 6:00 PM · 60 min', 'EGP 500', 'Cancelled'),
        OwnerBooking('Court 2', '28 Jun · 9:00 PM · 90 min', 'EGP 750', 'Cancelled'),
        OwnerBooking('Court 3', '21 Jun · 7:00 PM · 60 min', 'EGP 500', 'Confirmed'),
      ]),
      'Omar Khalil': OwnerPlayer('Omar Khalil', '+20 111 900 4432', 'omar@mail.com', 'C+', 'Cash', [
        OwnerBooking('Court 1', 'Tomorrow · 7:00 PM · 90 min', 'EGP 750', 'Confirmed'),
        OwnerBooking('Court 1', '30 Jun · 7:00 PM · 90 min', 'EGP 750', 'Confirmed'),
        OwnerBooking('Court 4', '22 Jun · 8:00 PM · 60 min', 'EGP 500', 'Cancelled'),
      ]),
    });

/// Resolve a player by name; falls back to a neutral record for names we don't
/// have a full history for so any tapped name still opens a valid profile.
OwnerPlayer resolveOwnerPlayer(WidgetRef ref, String name) {
  final map = ref.read(ownerPlayersProvider);
  return map[name] ??
      OwnerPlayer(name, '+20 100 000 0000', '${name.split(' ').first.toLowerCase()}@mail.com', 'C', 'InstaPay', const [
        OwnerBooking('Court 1', 'Recent · 90 min', 'EGP 750', 'Confirmed'),
      ]);
}

/// Suspended players — shared across the owner app, persisted.
class SuspendedNotifier extends Notifier<Set<String>> {
  @override
  Set<String> build() {
    _load();
    return <String>{};
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      state = (p.getStringList('owner_suspended') ?? const []).toSet();
    } catch (_) {}
  }

  Future<void> _persist() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setStringList('owner_suspended', state.toList());
    } catch (_) {}
  }

  bool isSuspended(String name) => state.contains(name);

  void toggle(String name) {
    final next = {...state};
    next.contains(name) ? next.remove(name) : next.add(name);
    state = next;
    _persist();
  }
}

final ownerSuspendedProvider = NotifierProvider<SuspendedNotifier, Set<String>>(SuspendedNotifier.new);
