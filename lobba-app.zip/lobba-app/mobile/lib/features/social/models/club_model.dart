/// Models for Phase 3 — Clubs & Communities.
/// Hand-written (no freezed) for zero build_runner dependency.

class ClubPreview {
  final String id;
  final String name;
  final String? description;
  final String? logoUrl;
  final String city;
  final int memberCount;
  final bool isPublic;
  final bool isMember;
  final String? userRole; // 'admin' | 'member' | null

  const ClubPreview({
    required this.id,
    required this.name,
    this.description,
    this.logoUrl,
    required this.city,
    required this.memberCount,
    required this.isPublic,
    required this.isMember,
    this.userRole,
  });

  factory ClubPreview.fromJson(Map<String, dynamic> j) => ClubPreview(
        id: j['id'] as String,
        name: j['name'] as String,
        description: j['description'] as String?,
        logoUrl: j['logoUrl'] as String?,
        city: j['city'] as String? ?? 'Cairo',
        memberCount: (j['memberCount'] as num? ?? 0).toInt(),
        isPublic: j['isPublic'] as bool? ?? true,
        isMember: j['isMember'] as bool? ?? false,
        userRole: j['userRole'] as String?,
      );

  ClubPreview copyWith({bool? isMember, String? userRole, int? memberCount}) =>
      ClubPreview(
        id: id,
        name: name,
        description: description,
        logoUrl: logoUrl,
        city: city,
        memberCount: memberCount ?? this.memberCount,
        isPublic: isPublic,
        isMember: isMember ?? this.isMember,
        userRole: userRole ?? this.userRole,
      );

  bool get isAdmin => userRole == 'admin';
}

class ClubMemberPreview {
  final String id;
  final String name;
  final String? photoUrl;
  final String role;
  final DateTime joinedAt;

  const ClubMemberPreview({
    required this.id,
    required this.name,
    this.photoUrl,
    required this.role,
    required this.joinedAt,
  });

  factory ClubMemberPreview.fromJson(Map<String, dynamic> j) =>
      ClubMemberPreview(
        id: j['id'] as String,
        name: j['name'] as String? ?? 'Member',
        photoUrl: j['photoUrl'] as String?,
        role: j['role'] as String? ?? 'member',
        joinedAt: DateTime.tryParse(j['joinedAt'] as String? ?? '') ??
            DateTime.now(),
      );

  bool get isAdmin => role == 'admin';
}

class ClubDetail extends ClubPreview {
  final List<ClubMemberPreview> recentMembers;

  const ClubDetail({
    required super.id,
    required super.name,
    super.description,
    super.logoUrl,
    required super.city,
    required super.memberCount,
    required super.isPublic,
    required super.isMember,
    super.userRole,
    required this.recentMembers,
  });

  factory ClubDetail.fromJson(Map<String, dynamic> j) {
    final members = (j['recentMembers'] as List<dynamic>? ?? [])
        .map((e) => ClubMemberPreview.fromJson(e as Map<String, dynamic>))
        .toList();
    return ClubDetail(
      id: j['id'] as String,
      name: j['name'] as String,
      description: j['description'] as String?,
      logoUrl: j['logoUrl'] as String?,
      city: j['city'] as String? ?? 'Cairo',
      memberCount: (j['memberCount'] as num? ?? 0).toInt(),
      isPublic: j['isPublic'] as bool? ?? true,
      isMember: j['isMember'] as bool? ?? false,
      userRole: j['userRole'] as String?,
      recentMembers: members,
    );
  }
}
