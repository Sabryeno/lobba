import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/network/api_client.dart';
import '../models/club_model.dart';

// ── Discover clubs ─────────────────────────────────────────────────────────────

final discoverClubsProvider =
    AsyncNotifierProvider<DiscoverClubsNotifier, List<ClubPreview>>(
  DiscoverClubsNotifier.new,
);

class DiscoverClubsNotifier extends AsyncNotifier<List<ClubPreview>> {
  String _query = '';
  String _city = '';

  @override
  Future<List<ClubPreview>> build() => _fetch();

  Future<List<ClubPreview>> _fetch() async {
    final api = ref.read(apiClientProvider);
    final res = await api.get('/clubs', queryParameters: {
      if (_query.isNotEmpty) 'q': _query,
      if (_city.isNotEmpty) 'city': _city,
      'limit': 40,
    });
    final data = res.data as Map<String, dynamic>;
    return (data['clubs'] as List<dynamic>)
        .map((e) => ClubPreview.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> search(String query, {String city = ''}) async {
    _query = query;
    _city = city;
    state = const AsyncLoading();
    state = await AsyncValue.guard(_fetch);
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(_fetch);
  }

  /// Optimistically toggle membership in the discover list.
  void patchMembership(String clubId, {required bool isMember}) {
    final clubs = state.valueOrNull ?? [];
    state = AsyncData(
      clubs.map((c) {
        if (c.id != clubId) return c;
        return c.copyWith(
          isMember: isMember,
          userRole: isMember ? 'member' : null,
          memberCount: isMember ? c.memberCount + 1 : c.memberCount - 1,
        );
      }).toList(),
    );
  }
}

// ── My clubs ──────────────────────────────────────────────────────────────────

final myClubsProvider =
    AsyncNotifierProvider<MyClubsNotifier, List<ClubPreview>>(
  MyClubsNotifier.new,
);

class MyClubsNotifier extends AsyncNotifier<List<ClubPreview>> {
  @override
  Future<List<ClubPreview>> build() => _fetch();

  Future<List<ClubPreview>> _fetch() async {
    final api = ref.read(apiClientProvider);
    final res = await api.get('/clubs/my');
    return (res.data as List<dynamic>)
        .map((e) => ClubPreview.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(_fetch);
  }

  void removeClub(String clubId) {
    final clubs = state.valueOrNull ?? [];
    state = AsyncData(clubs.where((c) => c.id != clubId).toList());
  }

  void addClub(ClubPreview club) {
    final clubs = state.valueOrNull ?? [];
    if (clubs.any((c) => c.id == club.id)) return;
    state = AsyncData([club, ...clubs]);
  }
}

// ── Club detail ───────────────────────────────────────────────────────────────

final clubDetailProvider =
    FutureProvider.autoDispose.family<ClubDetail, String>((ref, clubId) async {
  final api = ref.read(apiClientProvider);
  final res = await api.get('/clubs/$clubId');
  return ClubDetail.fromJson(res.data as Map<String, dynamic>);
});

// ── Join / Leave actions ──────────────────────────────────────────────────────

/// Joins a club and patches both discover + my-clubs providers.
Future<void> joinClub(WidgetRef ref, ClubPreview club) async {
  final api = ref.read(apiClientProvider);
  await api.post('/clubs/${club.id}/join');

  ref
      .read(discoverClubsProvider.notifier)
      .patchMembership(club.id, isMember: true);

  ref
      .read(myClubsProvider.notifier)
      .addClub(club.copyWith(isMember: true, userRole: 'member'));

  // Invalidate the detail so it re-fetches fresh data
  ref.invalidate(clubDetailProvider(club.id));
}

/// Leaves a club and patches both providers.
Future<void> leaveClub(WidgetRef ref, String clubId) async {
  final api = ref.read(apiClientProvider);
  await api.delete('/clubs/$clubId/leave');

  ref
      .read(discoverClubsProvider.notifier)
      .patchMembership(clubId, isMember: false);

  ref.read(myClubsProvider.notifier).removeClub(clubId);
  ref.invalidate(clubDetailProvider(clubId));
}
