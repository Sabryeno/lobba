import 'package:flutter_riverpod/flutter_riverpod.dart';

class TribeItem {
  final String name;
  final String meta;
  final bool captain;
  const TribeItem(this.name, this.meta, {this.captain = false});
}

/// In-memory tribes list (demo — survives within a session). New tribes the
/// player creates are added here and show on the Friends → Tribe tab.
final tribesProvider = NotifierProvider<TribesNotifier, List<TribeItem>>(TribesNotifier.new);

class TribesNotifier extends Notifier<List<TribeItem>> {
  @override
  List<TribeItem> build() => const [
        TribeItem('Cairo Smashers', '8 members · member'),
        TribeItem('Maadi Risers', '12 members · captain', captain: true),
      ];

  void add(String name) {
    if (name.trim().isEmpty) return;
    state = [...state, TribeItem(name.trim(), '1 member · captain', captain: true)];
  }
}
