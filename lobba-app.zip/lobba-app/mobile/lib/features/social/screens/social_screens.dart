import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../providers/tribes_provider.dart';
import '../../profile/providers/account_provider.dart';

// ── Friends / Tribe (segmented) ─────────────────────────────────────────────
class FriendsScreen extends ConsumerStatefulWidget {
  const FriendsScreen({super.key});
  @override
  ConsumerState<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends ConsumerState<FriendsScreen> {
  int _tab = 0;
  final _fq = TextEditingController();

  static const _allFriends = [
    ['Sara Mostafa', 'Level 4.0', 'on'],
    ['Omar Khalil', 'Level 3.1', 'on'],
    ['Karim Adel', 'Level 2.0 · last seen 2h', 'off'],
    ['Hana Ali', 'Level 3.0', 'off'],
    ['Youssef Adel', 'Level 2.2', 'on'],
  ];

  @override
  void dispose() { _fq.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: (_tab == 0 ? 'Friends' : 'Tribes').tr(context),
      trailing: GestureDetector(
        onTap: () => context.push(AppRoutes.addFriends),
        child: Container(width: 38, height: 38, decoration: BoxDecoration(color: t.accent, shape: BoxShape.circle), child: Icon(Icons.add_rounded, color: t.onAccent, size: 20)),
      ),
      child: Column(children: [
        // segmented control
        Container(
          margin: const EdgeInsets.fromLTRB(22, 12, 22, 0),
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            _seg(t, 'Friends'.tr(context), 0), _seg(t, 'Tribe'.tr(context), 1),
          ]),
        ),
        Expanded(child: _tab == 0 ? _friends(t) : _tribes(t)),
      ]),
    );
  }

  Widget _seg(LobbaTokens t, String label, int i) => Expanded(child: GestureDetector(
        onTap: () => setState(() => _tab = i),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 9), alignment: Alignment.center,
          decoration: BoxDecoration(color: _tab == i ? t.surface : Colors.transparent, borderRadius: BorderRadius.circular(9)),
          child: Text(label, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: _tab == i ? t.accent : t.ink3)),
        ),
      ));

  Widget _friends(LobbaTokens t) {
    final q = _fq.text.trim().toLowerCase();
    final list = _allFriends.where((f) => q.isEmpty || f[0].toLowerCase().contains(q)).toList();
    return ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
      searchField(context, t, _fq, 'Search friends…'.tr(context), () => setState(() {})),
      const SizedBox(height: 16),
      if (list.isEmpty)
        Padding(padding: const EdgeInsets.only(top: 40), child: Center(child: Text('No friends found'.tr(context), style: TextStyle(fontSize: 12.5, color: t.ink3))))
      else
        for (final f in list) ...[
          _friendRow(t, f[0], f[1], online: f[2] == 'on'),
          const SizedBox(height: 9),
        ],
    ]);
  }

  Widget _tribes(LobbaTokens t) => ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        // discover
        GestureDetector(
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DiscoverTribesScreen())),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(14)),
            child: Row(children: [
              Icon(Icons.travel_explore_rounded, size: 20, color: t.accent),
              const SizedBox(width: 11),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Discover tribes'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.accent)),
                Text('Search by name or city and ask to join'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink2)),
              ])),
              Icon(Icons.chevron_right_rounded, size: 18, color: t.accent),
            ]),
          ),
        ),
        const SizedBox(height: 18),
        Eyebrow('My tribes'.tr(context)),
        const SizedBox(height: 10),
        for (final tribe in ref.watch(tribesProvider)) ...[
          _tribeRow(t, tribe.name, tribe.meta, captain: tribe.captain),
          const SizedBox(height: 9),
        ],
        const SizedBox(height: 7),
        GestureDetector(
          onTap: () => context.push(AppRoutes.createTribe),
          child: Container(
            padding: const EdgeInsets.all(13), alignment: Alignment.center,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line, style: BorderStyle.solid)),
            child: Text('+ Create a tribe'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.accent)),
          ),
        ),
      ]);

  Widget _friendRow(LobbaTokens t, String name, String meta, {required bool online}) => GestureDetector(
        onTap: () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', name)),
        child: Container(
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
        child: Row(children: [
          Stack(children: [
            LAvatar(name[0]),
            if (online) Positioned(right: 0, bottom: 0, child: Container(width: 10, height: 10, decoration: BoxDecoration(color: t.sage, shape: BoxShape.circle, border: Border.all(color: t.surface, width: 2)))),
          ]),
          const SizedBox(width: 11),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
            Text(meta, style: TextStyle(fontSize: 10.5, color: t.ink3)),
          ])),
          Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(10)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.sports_tennis_rounded, size: 13, color: t.onAccent), const SizedBox(width: 5), Text('Invite'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.onAccent))])),
        ]),
      ),
      );

  Widget _tribeRow(LobbaTokens t, String name, String meta, {bool captain = false}) => GestureDetector(
        onTap: () => context.push(AppRoutes.tribeDetail),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
          child: Row(children: [
            Container(width: 40, height: 40, decoration: BoxDecoration(color: captain ? t.accent : t.surface2, borderRadius: BorderRadius.circular(12)), child: Icon(Icons.people_outline_rounded, size: 20, color: captain ? t.onAccent : t.ink2)),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink)),
              Text(meta, style: TextStyle(fontSize: 10.5, color: t.ink3)),
            ])),
            if (captain) LPill('Captain'.tr(context), bg: t.accentSoft, fg: t.accent),
          ]),
        ),
      );
}

// ── Add friends ─────────────────────────────────────────────────────────────
class AddFriendsScreen extends StatefulWidget {
  const AddFriendsScreen({super.key});
  @override
  State<AddFriendsScreen> createState() => _AddFriendsScreenState();
}

class _AddFriendsScreenState extends State<AddFriendsScreen> {
  final _q = TextEditingController();
  // name, meta, phone
  static const _players = [
    ['Hana Ali', 'Level 3.0 · 3.1 km · Maadi', '+20 100 111 2233'],
    ['Youssef Adel', 'Level 2.2 · 4.6 km · Nasr City', '+20 101 555 8890'],
    ['Sara Mostafa', 'Level 4.0 · 5.1 km · Zamalek', '+20 106 220 1120'],
    ['Karim Adel', 'Level 2.0 · 6.0 km · Nasr City', '+20 111 900 4432'],
    ['Omar Khalil', 'Level 3.1 · 2.3 km · New Cairo', '+20 122 700 9080'],
  ];

  @override
  void dispose() { _q.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final q = _q.text.trim().toLowerCase();
    final digits = q.replaceAll(RegExp(r'\D'), '');
    final list = _players.where((p) => q.isEmpty || p[0].toLowerCase().contains(q) || (digits.isNotEmpty && p[2].replaceAll(RegExp(r'\D'), '').contains(digits))).toList();
    return PushScaffold(
      title: 'Add friends'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        searchField(context, t, _q, 'Search by name or phone'.tr(context), () => setState(() {})),
        const SizedBox(height: 18),
        Eyebrow((q.isEmpty ? 'Players near you · your level' : 'Results').tr(context)),
        const SizedBox(height: 10),
        if (list.isEmpty)
          Padding(padding: const EdgeInsets.only(top: 30), child: Center(child: Text('No players found'.tr(context), style: TextStyle(fontSize: 12.5, color: t.ink3))))
        else
          for (final p in list) ...[
            _addRow(context, t, p[0], p[1]),
            const SizedBox(height: 9),
          ],
        const SizedBox(height: 6),
        Container(padding: const EdgeInsets.all(13), alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)), child: Text('Share your invite link · earn credit on a friend’s first booking'.tr(context), textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: t.ink2))),
      ]),
    );
  }

  Widget _addRow(BuildContext context, LobbaTokens t, String name, String meta) => GestureDetector(
        onTap: () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', name)),
        child: Container(
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
        child: Row(children: [
          LAvatar(name[0]),
          const SizedBox(width: 11),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
            Text(meta, style: TextStyle(fontSize: 10.5, color: t.ink3)),
          ])),
          Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(10)), child: Text('Add'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.onAccent))),
        ]),
      ),
      );
}

// ── Tribe detail ────────────────────────────────────────────────────────────
class TribeDetailScreen extends ConsumerWidget {
  const TribeDetailScreen({super.key});

  void _tribeMenu(BuildContext context, LobbaTokens t) {
    showModalBottomSheet(context: context, backgroundColor: t.surface, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))), builder: (ctx) {
      Widget item(IconData ic, String label, Color color, VoidCallback onTap) => ListTile(
            leading: Icon(ic, color: color, size: 20),
            title: Text(label, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: color)),
            onTap: () { Navigator.pop(ctx); onTap(); },
          );
      return SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 8),
        Container(width: 38, height: 4, decoration: BoxDecoration(color: t.line, borderRadius: BorderRadius.circular(99))),
        const SizedBox(height: 8),
        item(Icons.person_add_alt_1_outlined, 'Invite player to tribe'.tr(context), t.ink, () => context.push(AppRoutes.inviteTribe)),
        item(Icons.notifications_off_outlined, 'Mute tribe'.tr(context), t.ink, () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Tribe muted'.tr(context))))),
        item(Icons.logout_rounded, 'Leave tribe'.tr(context), t.clay, () { context.pop(); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Left tribe'.tr(context)))); }),
        const SizedBox(height: 8),
      ]));
    });
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final me = ref.watch(accountProvider).name;
    final members = [
      ['Hassan Tarek', 'Level 5.0', 'captain'],
      ['$me (${'you'.tr(context)})', 'Level 3.0', 'you'],
      ['Sara Mostafa', 'Level 4.0', ''],
      ['Omar Khalil', 'Level 3.1', ''],
    ];
    return Scaffold(
      backgroundColor: t.bg,
      body: ListView(padding: EdgeInsets.zero, children: [
        // green head
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 6, 18, 22),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              GestureDetector(onTap: () => context.pop(), child: Icon(Icons.chevron_left_rounded, color: t.headFg, size: 24)),
              GestureDetector(onTap: () => _tribeMenu(context, t), child: Icon(Icons.more_horiz_rounded, color: t.headFg, size: 22)),
            ]),
            const SizedBox(height: 6),
            Container(width: 72, height: 72, decoration: BoxDecoration(color: t.headFg, borderRadius: BorderRadius.circular(22)), child: Icon(Icons.people_outline_rounded, size: 36, color: t.headBg)),
            const SizedBox(height: 11),
            Text('Cairo Smashers', style: TextStyle(fontFamily: kSerif, fontSize: 22, fontWeight: FontWeight.w500, color: t.headFg)),
            const SizedBox(height: 3),
            Text('8 members · Cairo · you’re a member', style: TextStyle(fontSize: 11.5, color: t.headFg.withOpacity(.85))),
          ]),
        ))),
        Padding(padding: const EdgeInsets.fromLTRB(22, 16, 22, 8), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Eyebrow('Members'.tr(context)), Text('8', style: TextStyle(fontSize: 11, color: t.ink3))])),
        ...members.map((m) => Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 8), child: GestureDetector(
          onTap: m[2] == 'you' ? null : () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', m[0])),
          child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
          child: Row(children: [
            LAvatar(m[0][0], bg: m[2] == 'you' ? t.accent : null, fg: m[2] == 'you' ? t.onAccent : null, size: 36),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Flexible(child: Text(m[0], style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink))), if (m[2] == 'captain') Padding(padding: const EdgeInsets.only(left: 6), child: LPill('Captain'.tr(context), bg: t.accentSoft, fg: t.accent))]),
              Text(m[1], style: TextStyle(fontSize: 10, color: t.ink3)),
            ])),
            if (m[2] == 'you') LPill('You'.tr(context), bg: t.surface2, fg: t.ink3)
            else Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(99)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.sports_tennis_rounded, size: 12, color: t.onAccent), const SizedBox(width: 5), Text('Invite'.tr(context), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: t.onAccent))])),
          ]),
        )))),
        const SizedBox(height: 20),
      ]),
    );
  }
}

// ── Create a tribe ──────────────────────────────────────────────────────────
class CreateTribeScreen extends ConsumerStatefulWidget {
  const CreateTribeScreen({super.key});
  @override
  ConsumerState<CreateTribeScreen> createState() => _CreateTribeScreenState();
}

class _CreateTribeScreenState extends ConsumerState<CreateTribeScreen> {
  final _name = TextEditingController();
  final _city = TextEditingController(text: 'Cairo');
  bool _requestToJoin = true;
  String? _emblem;

  @override
  void dispose() { _name.dispose(); _city.dispose(); super.dispose(); }

  Future<void> _pickEmblem() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 600);
    if (x != null) setState(() => _emblem = x.path);
  }

  void _create() {
    final name = _name.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context)
        ..clearSnackBars()
        ..showSnackBar(SnackBar(content: Text('Tribe name'.tr(context))));
      return;
    }
    ref.read(tribesProvider.notifier).add(name);
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(SnackBar(content: Text('Tribe created'.tr(context))));
    context.pop();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Create a tribe'.tr(context),
      bottomBar: _bottomBtn(t, 'Create tribe'.tr(context), _create),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 20, 22, 24), children: [
        Center(child: GestureDetector(onTap: _pickEmblem, child: Column(children: [
          Stack(children: [
            Container(
              width: 78, height: 78,
              decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(22)),
              clipBehavior: Clip.antiAlias,
              child: _emblem != null ? Image.file(File(_emblem!), fit: BoxFit.cover) : Icon(Icons.people_outline_rounded, size: 34, color: t.accent),
            ),
            Positioned(right: -2, bottom: -2, child: Container(width: 26, height: 26, decoration: BoxDecoration(color: t.accent, shape: BoxShape.circle, border: Border.all(color: t.bg, width: 2)), child: Icon(Icons.add, size: 14, color: t.onAccent))),
          ]),
          const SizedBox(height: 9),
          Text('Add a tribe emblem'.tr(context), style: TextStyle(fontSize: 10, color: t.ink3)),
        ]))),
        const SizedBox(height: 22),
        _label(t, 'Tribe name'.tr(context)),
        _tribeField(t, _name, 'Cairo Smashers'),
        const SizedBox(height: 16),
        _label(t, 'City'.tr(context)),
        _tribeField(t, _city, 'Cairo'),
        const SizedBox(height: 16),
        _label(t, 'Who can join'.tr(context)),
        Row(children: [
          Expanded(child: GestureDetector(onTap: () => setState(() => _requestToJoin = true), child: _opt(t, 'Request to join'.tr(context), _requestToJoin))),
          const SizedBox(width: 8),
          Expanded(child: GestureDetector(onTap: () => setState(() => _requestToJoin = false), child: _opt(t, 'Open'.tr(context), !_requestToJoin))),
        ]),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(11)), child: Text('You’ll be the captain — you approve members and tribe invites.'.tr(context), style: TextStyle(fontSize: 10, color: t.ink2, height: 1.5))),
      ]),
    );
  }

  Widget _tribeField(LobbaTokens t, TextEditingController c, String hint) => TextField(
        controller: c,
        style: TextStyle(color: t.ink, fontSize: 13.5, fontWeight: FontWeight.w600),
        decoration: InputDecoration(
          hintText: hint, hintStyle: TextStyle(color: t.ink3, fontWeight: FontWeight.w400),
          filled: true, fillColor: t.surface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.accent, width: 1.5)),
        ),
      );
}

// ── Invite player to tribe (member → captain approval) ──────────────────────
class InviteToTribeScreen extends StatelessWidget {
  const InviteToTribeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Invite to tribe'.tr(context),
      subtitle: 'Cairo Smashers',
      bottomBar: _bottomBtn(t, 'Send to captain for approval'.tr(context), () => context.pop()),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 14, 22, 24), children: [
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: t.gold.withOpacity(.14), borderRadius: BorderRadius.circular(13), border: Border.all(color: t.gold.withOpacity(.32))), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.star_border_rounded, color: t.gold, size: 16),
          const SizedBox(width: 10),
          Expanded(child: Text('You’re a member, not the captain — your invite is sent to Hassan (captain) to approve before they join.'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink2, height: 1.5))),
        ])),
        const SizedBox(height: 16),
        Eyebrow('Selected'.tr(context)),
        const SizedBox(height: 9),
        _picked(t, 'Mostafa Eid', 'Level 3.0 · Nasr City'),
        const SizedBox(height: 18),
        Eyebrow('Suggested'.tr(context)),
        const SizedBox(height: 9),
        _suggest(t, 'Laila Hassan', 'Level 4.0 · 1 mutual'),
        const SizedBox(height: 8),
        _suggest(t, 'Youssef Adel', 'Level 2.2 · 3 mutual'),
      ]),
    );
  }

  Widget _picked(LobbaTokens t, String name, String meta) => Container(
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.accent, width: 1.5)),
        child: Row(children: [LAvatar(name[0]), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)), Text(meta, style: TextStyle(fontSize: 10, color: t.ink3))])), Container(width: 22, height: 22, decoration: BoxDecoration(color: t.accent, shape: BoxShape.circle), child: Icon(Icons.check, size: 13, color: t.onAccent))]),
      );
  Widget _suggest(LobbaTokens t, String name, String meta) => Container(
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
        child: Row(children: [LAvatar(name[0], size: 36), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)), Text(meta, style: TextStyle(fontSize: 10, color: t.ink3))])), Icon(Icons.add_circle_outline_rounded, size: 22, color: t.ink3)]),
      );
}

// ── Captain review (approve/decline tribe invites) ──────────────────────────
class CaptainReviewScreen extends StatelessWidget {
  const CaptainReviewScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Pending invites'.tr(context),
      subtitle: 'Cairo Smashers',
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 14, 22, 24), children: [
        Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(12)), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline_rounded, size: 15, color: t.accent), const SizedBox(width: 9), Expanded(child: Text('Members can invite players, but only the captain approves who joins.'.tr(context), style: TextStyle(fontSize: 10.5, color: t.accent, height: 1.5)))])),
        const SizedBox(height: 16),
        _review(context, t, 'Mostafa Eid', 'Level 3.0 · Nasr City', 'Invited by Ahmed · 12 min ago'),
        const SizedBox(height: 11),
        _review(context, t, 'Rana Saleh', 'Level 4.2 · Heliopolis', 'Invited by Sara · 1 h ago'),
      ]),
    );
  }

  Widget _review(BuildContext context, LobbaTokens t, String name, String meta, String by) => Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [LAvatar(name[0], size: 42), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)), Text(meta, style: TextStyle(fontSize: 10.5, color: t.ink3))]))]),
          const SizedBox(height: 9),
          Text(by, style: TextStyle(fontSize: 10.5, color: t.ink2)),
          const SizedBox(height: 11),
          Row(children: [
            Expanded(child: Container(padding: const EdgeInsets.symmetric(vertical: 9), alignment: Alignment.center, decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(10)), child: Text('Approve'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.onAccent)))),
            const SizedBox(width: 8),
            Expanded(child: Container(padding: const EdgeInsets.symmetric(vertical: 9), alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: t.line)), child: Text('Decline'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.clay)))),
          ]),
        ]),
      );
}

// helpers shared by the tribe screens above
Widget _bottomBtn(LobbaTokens t, String label, VoidCallback onTap) => Container(
      decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
      child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(onPressed: onTap, style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)))))),
    );
Widget _label(LobbaTokens t, String s) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Eyebrow(s));
Widget _input(LobbaTokens t, String v) => Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)), child: Text(v, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink)));
Widget _opt(LobbaTokens t, String label, bool on) => Container(padding: const EdgeInsets.symmetric(vertical: 11), alignment: Alignment.center, decoration: BoxDecoration(color: on ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: on ? t.accent : t.line, width: on ? 1.5 : 1)), child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: on ? t.accent : t.ink2)));

/// Reusable live search field (used by Friends + Discover tribes).
Widget searchField(BuildContext context, LobbaTokens t, TextEditingController c, String hint, VoidCallback onChanged) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 2),
      decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
      child: Row(children: [
        Icon(Icons.search_rounded, size: 16, color: t.ink3),
        const SizedBox(width: 10),
        Expanded(child: TextField(
          controller: c, onChanged: (_) => onChanged(),
          style: TextStyle(color: t.ink, fontSize: 13),
          decoration: InputDecoration(hintText: hint, hintStyle: TextStyle(color: t.ink3), border: InputBorder.none, isDense: true),
        )),
        if (c.text.isNotEmpty) GestureDetector(onTap: () { c.clear(); onChanged(); }, child: Icon(Icons.close_rounded, size: 16, color: t.ink3)),
      ]),
    );

// ── Discover tribes (search by name/city + request to join) ─────────────────
class DiscoverTribesScreen extends ConsumerStatefulWidget {
  const DiscoverTribesScreen({super.key});
  @override
  ConsumerState<DiscoverTribesScreen> createState() => _DiscoverTribesScreenState();
}

class _DiscoverTribesScreenState extends ConsumerState<DiscoverTribesScreen> {
  final _q = TextEditingController();
  final _requested = <String>{};

  static const _tribes = [
    ['Cairo Smashers', 'Cairo', '24', 'Level 2–4'],
    ['New Cairo Padel Club', 'New Cairo', '18', 'Level 3–5'],
    ['Zamalek Aces', 'Zamalek', '31', 'Level 1–3'],
    ['Maadi Risers', 'Maadi', '12', 'Level 2–4'],
    ['Alexandria Waves', 'Alexandria', '27', 'Level 3–6'],
    ['Giza Padel Crew', 'Giza', '9', 'Level 1–2'],
  ];

  @override
  void dispose() { _q.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final q = _q.text.trim().toLowerCase();
    final list = _tribes.where((tr) => q.isEmpty || tr[0].toLowerCase().contains(q) || tr[1].toLowerCase().contains(q)).toList();
    return PushScaffold(
      title: 'Discover tribes'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 14, 22, 24), children: [
        searchField(context, t, _q, 'Search by name or city'.tr(context), () => setState(() {})),
        const SizedBox(height: 16),
        if (list.isEmpty)
          Padding(padding: const EdgeInsets.only(top: 40), child: Center(child: Text('No tribes found'.tr(context), style: TextStyle(fontSize: 12.5, color: t.ink3))))
        else
          for (final tr in list) Padding(padding: const EdgeInsets.only(bottom: 11), child: _card(t, tr)),
      ]),
    );
  }

  Widget _card(LobbaTokens t, List<String> tr) {
    final requested = _requested.contains(tr[0]);
    return GestureDetector(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TribePublicViewScreen(name: tr[0], city: tr[1], members: int.tryParse(tr[2]) ?? 0, levelRange: tr[3], requested: requested, onRequest: () => setState(() => _requested.add(tr[0]))))),
      child: Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)),
        child: Row(children: [
          Container(width: 44, height: 44, decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(13)), child: Icon(Icons.groups_outlined, size: 22, color: t.accent)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(tr[0], style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.ink)),
            const SizedBox(height: 2),
            Text('${tr[1]} · ${tr[2]} ${'members'.tr(context)} · ${tr[3]}', style: TextStyle(fontSize: 10.5, color: t.ink3)),
          ])),
          const SizedBox(width: 8),
          if (requested)
            LPill('Requested'.tr(context), bg: t.surface2, fg: t.ink3)
          else
            GestureDetector(
              onTap: () {
                setState(() => _requested.add(tr[0]));
                ScaffoldMessenger.of(context)..clearSnackBars()..showSnackBar(SnackBar(content: Text('Request sent'.tr(context))));
              },
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(10)), child: Text('Request to join'.tr(context), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: t.onAccent))),
            ),
        ]),
      ),
    );
  }
}

// ── Public tribe dashboard (view before joining) ─────────────────────────────
class TribePublicViewScreen extends StatefulWidget {
  final String name, city, levelRange;
  final int members;
  final bool requested;
  final VoidCallback onRequest;
  const TribePublicViewScreen({super.key, required this.name, required this.city, required this.members, required this.levelRange, required this.requested, required this.onRequest});
  @override
  State<TribePublicViewScreen> createState() => _TribePublicViewScreenState();
}

class _TribePublicViewScreenState extends State<TribePublicViewScreen> {
  late bool _requested = widget.requested;

  double get _avgLevel {
    final nums = RegExp(r'\d+').allMatches(widget.levelRange).map((m) => double.parse(m.group(0)!)).toList();
    if (nums.length >= 2) return (nums[0] + nums[1]) / 2;
    return nums.isNotEmpty ? nums.first : 3.0;
  }

  List<List<String>> get _players {
    // demo roster spread across the tribe's level range
    const names = ['Hassan Tarek', 'Sara Mostafa', 'Omar Khalil', 'Hana Ali', 'Youssef Adel', 'Karim Adel'];
    final lo = _avgLevel - 1;
    return [for (var i = 0; i < names.length && i < 6; i++) [names[i], 'Level ${(lo + i * 0.4).clamp(0, 7).toStringAsFixed(1)}']];
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final games = widget.members * 14;
    return Scaffold(
      backgroundColor: t.bg,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 12, 22, 12), child: SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
          onPressed: _requested ? null : () { setState(() => _requested = true); widget.onRequest(); ScaffoldMessenger.of(context)..clearSnackBars()..showSnackBar(SnackBar(content: Text('Request sent to join'.tr(context)))); },
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, disabledBackgroundColor: t.surface2, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: Text((_requested ? 'Requested' : 'Request to join').tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )))),
      ),
      body: ListView(padding: EdgeInsets.zero, children: [
        // green header
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 6, 18, 22),
          child: Column(children: [
            Align(alignment: Alignment.centerLeft, child: GestureDetector(onTap: () => Navigator.of(context).pop(), child: Icon(Icons.chevron_left_rounded, color: t.headFg, size: 24))),
            const SizedBox(height: 4),
            Container(width: 72, height: 72, decoration: BoxDecoration(color: t.headFg, borderRadius: BorderRadius.circular(22)), child: Icon(Icons.groups_outlined, size: 36, color: t.headBg)),
            const SizedBox(height: 11),
            Text(widget.name, style: TextStyle(fontFamily: kSerif, fontSize: 22, fontWeight: FontWeight.w500, color: t.headFg)),
            const SizedBox(height: 3),
            Text('${widget.city} · ${widget.levelRange}', style: TextStyle(fontSize: 11.5, color: t.headFg.withOpacity(.85))),
          ]),
        ))),
        const SizedBox(height: 16),
        // dashboard stats
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          _stat(t, '$games', 'Games played'.tr(context)),
          const SizedBox(width: 9),
          _stat(t, '${widget.members}', 'Players'.tr(context)),
        ])),
        const SizedBox(height: 9),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: [
          _stat(t, _avgLevel.toStringAsFixed(1), 'Avg level'.tr(context)),
          const SizedBox(width: 9),
          _stat(t, 'Competitive'.tr(context), 'Top match type'.tr(context)),
        ])),
        const SizedBox(height: 18),
        Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 10), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Eyebrow('Members'.tr(context)), Text('${widget.members}', style: TextStyle(fontSize: 11, color: t.ink3))])),
        ..._players.map((p) => Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 9), child: GestureDetector(
          onTap: () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', p[0])),
          child: Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
            child: Row(children: [
              LAvatar(p[0][0], size: 36),
              const SizedBox(width: 11),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p[0], style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
                Text(p[1], style: TextStyle(fontSize: 10, color: t.ink3)),
              ])),
              Icon(Icons.chevron_right_rounded, size: 18, color: t.ink3),
            ]),
          ),
        ))),
        const SizedBox(height: 16),
      ]),
    );
  }

  Widget _stat(LobbaTokens t, String v, String l) => Expanded(child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)),
        child: Column(children: [
          Text(v, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontFamily: kSerif, fontSize: 18, fontWeight: FontWeight.w600, color: t.accent)),
          const SizedBox(height: 3),
          Text(l, textAlign: TextAlign.center, style: TextStyle(fontSize: 9.5, color: t.ink3)),
        ]),
      ));
}
