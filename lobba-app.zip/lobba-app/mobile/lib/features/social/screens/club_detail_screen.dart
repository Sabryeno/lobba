import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../models/club_model.dart';
import '../providers/clubs_provider.dart';

class ClubDetailScreen extends ConsumerWidget {
  final String clubId;
  const ClubDetailScreen({super.key, required this.clubId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(clubDetailProvider(clubId));

    return async.when(
      loading: () => const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
            child: CircularProgressIndicator(color: AppColors.primary)),
      ),
      error: (e, _) => Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline_rounded,
                  size: 48, color: AppColors.textTertiary),
              const SizedBox(height: 12),
              const Text('Could not load club details'),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () => ref.invalidate(clubDetailProvider(clubId)),
                style: FilledButton.styleFrom(
                    backgroundColor: AppColors.primary),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (club) => _ClubDetailBody(club: club),
    );
  }
}

class _ClubDetailBody extends ConsumerStatefulWidget {
  final ClubDetail club;
  const _ClubDetailBody({required this.club});

  @override
  ConsumerState<_ClubDetailBody> createState() => _ClubDetailBodyState();
}

class _ClubDetailBodyState extends ConsumerState<_ClubDetailBody> {
  bool _actionLoading = false;

  @override
  Widget build(BuildContext context) {
    final club = widget.club;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // ── Hero header ─────────────────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  // Gradient background
                  Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFF0D2E22),
                          AppColors.primary,
                          AppColors.primaryLight,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                  ),
                  // Decorative court lines
                  Positioned.fill(
                    child: CustomPaint(painter: _CourtLinePainter()),
                  ),
                  // Club info overlay
                  Positioned(
                    left: 20,
                    right: 20,
                    bottom: 24,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        // Logo
                        Container(
                          width: 64,
                          height: 64,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.3)),
                          ),
                          child: Center(
                            child: Text(
                              club.name.isNotEmpty
                                  ? club.name[0].toUpperCase()
                                  : '?',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 28,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                club.name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: -0.4,
                                  shadows: [
                                    Shadow(
                                      color: Colors.black26,
                                      blurRadius: 8,
                                    )
                                  ],
                                ),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  const Icon(Icons.location_on_rounded,
                                      size: 12,
                                      color: Colors.white70),
                                  const SizedBox(width: 3),
                                  Text(
                                    club.city,
                                    style: const TextStyle(
                                        color: Colors.white70,
                                        fontSize: 12),
                                  ),
                                  const SizedBox(width: 10),
                                  const Icon(Icons.people_rounded,
                                      size: 12,
                                      color: Colors.white70),
                                  const SizedBox(width: 3),
                                  Text(
                                    '${club.memberCount} members',
                                    style: const TextStyle(
                                        color: Colors.white70,
                                        fontSize: 12),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Body ────────────────────────────────────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // About card
                  if (club.description != null &&
                      club.description!.isNotEmpty) ...[
                    _Card(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const _SectionHeader(
                              icon: Icons.info_outline_rounded,
                              title: 'About'),
                          const SizedBox(height: 8),
                          Text(
                            club.description!,
                            style: const TextStyle(
                              fontSize: 14,
                              color: AppColors.textSecondary,
                              height: 1.55,
                            ),
                          ),
                        ],
                      ),
                    ).animate().fadeIn(duration: 300.ms).slideY(
                        begin: 0.06, end: 0, duration: 300.ms),
                    const SizedBox(height: 12),
                  ],

                  // Stats row
                  Row(
                    children: [
                      Expanded(
                        child: _StatTile(
                          icon: Icons.people_rounded,
                          value: '${club.memberCount}',
                          label: 'Members',
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _StatTile(
                          icon: club.isPublic
                              ? Icons.lock_open_rounded
                              : Icons.lock_rounded,
                          value: club.isPublic ? 'Public' : 'Private',
                          label: 'Visibility',
                        ),
                      ),
                    ],
                  )
                      .animate(delay: 60.ms)
                      .fadeIn(duration: 300.ms)
                      .slideY(begin: 0.06, end: 0, duration: 300.ms),
                  const SizedBox(height: 12),

                  // Members section
                  if (club.recentMembers.isNotEmpty) ...[
                    _Card(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const _SectionHeader(
                              icon: Icons.groups_rounded,
                              title: 'Members'),
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 10,
                            runSpacing: 10,
                            children: club.recentMembers
                                .map((m) => _MemberChip(member: m))
                                .toList(),
                          ),
                        ],
                      ),
                    )
                        .animate(delay: 120.ms)
                        .fadeIn(duration: 300.ms)
                        .slideY(begin: 0.06, end: 0, duration: 300.ms),
                    const SizedBox(height: 24),
                  ],

                  // Join / Leave button
                  _JoinLeaveButton(
                    club: club,
                    loading: _actionLoading,
                    onTap: () => _handleAction(context, club),
                  )
                      .animate(delay: 180.ms)
                      .fadeIn(duration: 300.ms)
                      .slideY(begin: 0.06, end: 0, duration: 300.ms),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _handleAction(BuildContext context, ClubDetail club) async {
    setState(() => _actionLoading = true);
    try {
      if (club.isMember) {
        if (club.isAdmin) {
          // Warn admin before leaving
          final confirm = await showDialog<bool>(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('Leave club?'),
              content: const Text(
                'You are an admin. Make sure another admin exists before leaving.',
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Cancel')),
                FilledButton(
                    style: FilledButton.styleFrom(
                        backgroundColor: AppColors.error),
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Leave')),
              ],
            ),
          );
          if (confirm != true) return;
        }
        await leaveClub(ref, club.id);
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Left ${club.name}'),
              backgroundColor: AppColors.textSecondary,
            ),
          );
          Navigator.pop(context);
        }
      } else {
        await joinClub(ref, club);
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Joined ${club.name}! 🎾'),
              backgroundColor: AppColors.primary,
            ),
          );
          Navigator.pop(context);
        }
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(e.toString().replaceFirst('Exception: ', '')),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _actionLoading = false);
    }
  }
}

// ── Sub-widgets ────────────────────────────────────────────────────────────────

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceElevated,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final IconData icon;
  final String title;
  const _SectionHeader({required this.icon, required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 16, color: AppColors.primary),
        const SizedBox(width: 6),
        Text(
          title,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
            letterSpacing: 0.1,
          ),
        ),
      ],
    );
  }
}

class _StatTile extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  const _StatTile(
      {required this.icon, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.surfaceElevated,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.primary),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              Text(
                label,
                style: const TextStyle(
                    fontSize: 11, color: AppColors.textTertiary),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MemberChip extends StatelessWidget {
  final ClubMemberPreview member;
  const _MemberChip({required this.member});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: member.isAdmin
            ? AppColors.accentLight.withOpacity(0.4)
            : AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color:
              member.isAdmin ? AppColors.accent.withOpacity(0.3) : AppColors.border,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 12,
            backgroundColor: member.isAdmin
                ? AppColors.accent.withOpacity(0.2)
                : AppColors.primarySurface,
            child: Text(
              member.name.isNotEmpty ? member.name[0].toUpperCase() : '?',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: member.isAdmin ? AppColors.accent : AppColors.primary,
              ),
            ),
          ),
          const SizedBox(width: 6),
          Text(
            member.name.split(' ').first,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: AppColors.textPrimary,
            ),
          ),
          if (member.isAdmin) ...[
            const SizedBox(width: 4),
            const Icon(Icons.star_rounded, size: 11, color: AppColors.accent),
          ],
        ],
      ),
    );
  }
}

class _JoinLeaveButton extends StatelessWidget {
  final ClubDetail club;
  final bool loading;
  final VoidCallback onTap;

  const _JoinLeaveButton({
    required this.club,
    required this.loading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isMember = club.isMember;

    return SizedBox(
      width: double.infinity,
      height: 52,
      child: loading
          ? const Center(
              child: CircularProgressIndicator(color: AppColors.primary))
          : FilledButton(
              onPressed: onTap,
              style: FilledButton.styleFrom(
                backgroundColor:
                    isMember ? AppColors.surface : AppColors.primary,
                foregroundColor:
                    isMember ? AppColors.error : Colors.white,
                side: isMember
                    ? const BorderSide(color: AppColors.border)
                    : null,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    isMember
                        ? Icons.logout_rounded
                        : Icons.group_add_rounded,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    isMember ? 'Leave Club' : 'Join Club',
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

// ── Court line decoration painter ─────────────────────────────────────────────

class _CourtLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.06)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    // Centre line
    canvas.drawLine(
        Offset(size.width / 2, 0), Offset(size.width / 2, size.height), paint);
    // Service box lines
    canvas.drawLine(Offset(size.width * 0.25, size.height * 0.4),
        Offset(size.width * 0.75, size.height * 0.4), paint);
    // Outer rectangle
    canvas.drawRect(
      Rect.fromLTRB(size.width * 0.08, size.height * 0.15,
          size.width * 0.92, size.height * 0.92),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
