import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/providers/profile_photo_provider.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../auth/providers/auth_provider.dart';
import '../../profile/providers/account_provider.dart';
import '../../discovery/screens/advanced_search_screen.dart';

/// Player Home — rebuilt to match the Sage Atelier / Ink & Brass mockup.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final photo = ref.watch(profilePhotoProvider);
    final firstName = ref.watch(accountProvider).name.trim().split(' ').first;
    final initial = firstName.isNotEmpty ? firstName[0].toUpperCase() : 'P';
    return Container(
      color: t.bg,
      child: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.only(bottom: 120),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 8, 22, 0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Eyebrow('Good evening'.tr(context)),
                        const SizedBox(height: 4),
                        Text(firstName, style: TextStyle(fontFamily: kSerif, fontSize: 27, fontWeight: FontWeight.w500, color: t.ink, height: 1.05)),
                      ],
                    ),
                  ),
                  _circleIcon(t, Icons.notifications_none_rounded, dot: true, onTap: () => context.push(AppRoutes.notifications)),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: () => context.go(AppRoutes.profile),
                    child: CircleAvatar(
                      radius: 20, backgroundColor: t.accent,
                      backgroundImage: photo != null ? FileImage(File(photo)) : null,
                      child: photo == null ? Text(initial, style: TextStyle(fontFamily: kSerif, fontSize: 17, color: t.onAccent)) : null,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22),
              child: Row(children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AdvancedSearchScreen())),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
                      decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)),
                      child: Row(children: [
                        Icon(Icons.search_rounded, size: 18, color: t.ink3),
                        const SizedBox(width: 10),
                        Text('Search courts, areas…'.tr(context), style: TextStyle(fontSize: 13.5, color: t.ink3, fontFamily: kSans)),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                GestureDetector(
                  onTap: () => context.push(AppRoutes.discoverMap),
                  child: Container(width: 48, height: 48, decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(15)), child: Icon(Icons.map_outlined, color: t.onAccent, size: 20)),
                ),
              ]),
            ),
            const SizedBox(height: 24),
            _sectionHead(context, t, 'Featured courts'.tr(context), onSeeAll: () => context.go(AppRoutes.discovery)),
            const SizedBox(height: 11),
            SizedBox(
              height: 186,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 22),
                children: [
                  _featuredCard(context, t, '1', 'Al-Ahly Padel Club', 'New Cairo · 2.3 km', '500', 'Indoor', '4.9'),
                  const SizedBox(width: 12),
                  _featuredCard(context, t, '2', 'Zamalek Sports Club', 'Zamalek · 5.1 km', '350', 'Outdoor', '4.7'),
                  const SizedBox(width: 12),
                  _featuredCard(context, t, '3', 'Maadi Padel Lounge', 'Maadi · 7.8 km', '450', 'Indoor', '4.8'),
                ],
              ),
            ),
            const SizedBox(height: 22),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22),
              child: Row(children: [
                _quickAction(t, Icons.calendar_today_outlined, 'Book'.tr(context), () => context.go(AppRoutes.discovery)),
                _quickAction(t, Icons.sports_tennis_outlined, 'Match'.tr(context), () => context.go(AppRoutes.matches)),
                _quickAction(t, Icons.school_outlined, 'Learn to play'.tr(context), () => context.push(AppRoutes.coaches)),
                _quickAction(t, Icons.local_offer_outlined, 'Deals'.tr(context), () => context.push(AppRoutes.deals)),
              ]),
            ),
            const SizedBox(height: 24),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Open matches around you'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 16, color: t.ink, fontWeight: FontWeight.w500)),
                  GestureDetector(onTap: () => context.go(AppRoutes.matches), child: Text('See all'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.accent))),
                ]),
                const SizedBox(height: 3),
                Row(children: [
                  Icon(Icons.search_rounded, size: 12, color: t.ink3),
                  const SizedBox(width: 5),
                  Text('Your level (C+) · within 10 km'.tr(context), style: TextStyle(fontSize: 10, color: t.ink3)),
                ]),
                const SizedBox(height: 12),
                _matchCard(context, t, 'Al-Ahly Padel Club', 'C – C+', 'New Cairo · 2.3 km · Today 6:00 PM', '1 spot left'),
                const SizedBox(height: 11),
                _matchCard(context, t, 'Maadi Padel Lounge', 'C+ – B', 'Maadi · 7.8 km · Tomorrow 8:00 PM', '2 spots'),
              ]),
            ),
            const SizedBox(height: 24),
            // people you play most with — moved here from the profile
            Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 10), child: Eyebrow('People you play most with'.tr(context))),
            SizedBox(height: 150, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 22), children: [
              _playmate(context, t, 'Hassan Tarek', 5.0, 8),
              const SizedBox(width: 11),
              _playmate(context, t, 'Sara Mostafa', 4.0, 7),
              const SizedBox(width: 11),
              _playmate(context, t, 'Omar Khalil', 3.1, 5),
            ])),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _circleIcon(LobbaTokens t, IconData ic, {bool dot = false, VoidCallback? onTap}) => GestureDetector(
        onTap: onTap,
        child: Stack(children: [
          Container(width: 40, height: 40, decoration: BoxDecoration(color: t.surface, shape: BoxShape.circle, border: Border.all(color: t.line)), child: Icon(ic, size: 18, color: t.ink2)),
          if (dot) Positioned(right: 9, top: 9, child: Container(width: 7, height: 7, decoration: BoxDecoration(color: t.accent, shape: BoxShape.circle, border: Border.all(color: t.surface, width: 1.5)))),
        ]),
      );

  Widget _sectionHead(BuildContext c, LobbaTokens t, String title, {VoidCallback? onSeeAll}) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.end, children: [
          Eyebrow(title),
          if (onSeeAll != null) GestureDetector(onTap: onSeeAll, child: Text('See all'.tr(c), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.accent))),
        ]),
      );

  Widget _featuredCard(BuildContext c, LobbaTokens t, String id, String name, String loc, String price, String type, String rating) => GestureDetector(
        onTap: () => c.push(AppRoutes.courtDetail.replaceFirst(':courtId', id)),
        child: Container(
          width: 236,
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: t.line)),
          clipBehavior: Clip.antiAlias,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Stack(children: [
              Container(height: 118, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [t.accentSoft, t.surface2]))),
              Positioned(top: 12, left: 12, child: _pill(t, type, bg: t.surface, fg: t.ink2)),
              Positioned(top: 12, right: 12, child: _pill(t, '★ $rating', bg: Colors.black.withOpacity(.5), fg: Colors.white)),
            ]),
            Padding(
              padding: const EdgeInsets.fromLTRB(13, 12, 13, 13),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name, style: TextStyle(fontFamily: kSerif, fontSize: 16, color: t.ink, fontWeight: FontWeight.w500)),
                const SizedBox(height: 6),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Flexible(child: Text(loc, style: TextStyle(fontSize: 11, color: t.ink3))),
                  Text.rich(TextSpan(children: [
                    TextSpan(text: price, style: TextStyle(fontFamily: kSerif, fontSize: 15, fontWeight: FontWeight.w600, color: t.accent)),
                    TextSpan(text: ' EGP', style: TextStyle(fontSize: 11, color: t.ink2)),
                  ])),
                ]),
              ]),
            ),
          ]),
        ),
      );

  Widget _playmate(BuildContext context, LobbaTokens t, String name, double lvl, int common) => GestureDetector(
        onTap: () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', name)),
        child: Container(
          width: 130,
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          clipBehavior: Clip.antiAlias,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(height: 70, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [t.accentSoft, t.surface2])), alignment: Alignment.center, child: Text(name[0], style: TextStyle(fontFamily: kSerif, fontSize: 26, color: t.accent))),
            Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: t.ink)),
              Text('${'Level'.tr(context)} ${lvl.toStringAsFixed(1)}', style: TextStyle(fontSize: 10.5, color: t.accent)),
              Text('$common ${'matches in common'.tr(context)}', style: TextStyle(fontSize: 9, color: t.ink3)),
            ])),
          ]),
        ),
      );

  Widget _quickAction(LobbaTokens t, IconData ic, String label, VoidCallback onTap) => Expanded(
        child: GestureDetector(
          onTap: onTap,
          behavior: HitTestBehavior.opaque,
          child: Column(children: [
            Container(width: 46, height: 46, decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(16)), child: Icon(ic, size: 20, color: t.onAccent)),
            const SizedBox(height: 7),
            Text(label, style: TextStyle(fontSize: 11, color: t.ink2, fontWeight: FontWeight.w500)),
          ]),
        ),
      );

  Widget _matchCard(BuildContext c, LobbaTokens t, String name, String skill, String meta, String spots) => Container(
        padding: const EdgeInsets.fromLTRB(14, 13, 14, 13),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
            _pill(t, skill, bg: t.accentSoft, fg: t.accent),
          ]),
          const SizedBox(height: 5),
          Text(meta, style: TextStyle(fontSize: 10.5, color: t.ink3)),
          const SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Row(children: [
              _miniAvatar(t, 'A', t.accent, t.onAccent),
              Transform.translate(offset: const Offset(-7, 0), child: _miniAvatar(t, 'S', t.surface2, t.ink2)),
              Padding(padding: const EdgeInsets.only(left: 2), child: Text(spots, style: TextStyle(fontSize: 10, color: t.ink3))),
            ]),
            GestureDetector(
              onTap: () => c.push(AppRoutes.matches),
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(10)), child: Text('Join'.tr(c), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.onAccent))),
            ),
          ]),
        ]),
      );

  Widget _miniAvatar(LobbaTokens t, String ch, Color bg, Color fg) => Container(
        width: 24, height: 24, alignment: Alignment.center,
        decoration: BoxDecoration(color: bg, shape: BoxShape.circle, border: Border.all(color: t.surface, width: 2)),
        child: Text(ch, style: TextStyle(fontFamily: kSerif, fontSize: 9, fontWeight: FontWeight.w600, color: fg)),
      );

  Widget _pill(LobbaTokens t, String txt, {required Color bg, required Color fg}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(99)),
        child: Text(txt, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: fg)),
      );
}
