import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../booking/providers/bookings_provider.dart';
import '../../discovery/data/courts_catalog.dart';

class _Match {
  final String name, skill, area, time, dur, spots;
  final int day; // 0 = today, 1 = tomorrow, ...
  final bool mine; // matches my level
  final double km;
  final bool live; // came from a real posted booking
  final int court; // court number (0 = unknown)
  const _Match(this.name, this.skill, this.area, this.day, this.time, this.dur, this.spots, this.mine, this.km, {this.live = false, this.court = 0});
}

// Format minutes-from-midnight as "6:00 PM".
String _fmtTime(int min) {
  final h24 = min ~/ 60;
  final m = min % 60;
  final ampm = h24 >= 12 ? 'PM' : 'AM';
  final h = h24 % 12 == 0 ? 12 : h24 % 12;
  return '$h:${m.toString().padLeft(2, '0')} $ampm';
}

class MatchesScreen extends ConsumerStatefulWidget {
  const MatchesScreen({super.key});
  @override
  ConsumerState<MatchesScreen> createState() => _MatchesScreenState();
}

class _MatchesScreenState extends ConsumerState<MatchesScreen> {
  int _date = 0;
  int _filter = 0; // 0 all · 1 my level · 2 near me
  static const _filters = ['All', 'My level', 'Near me'];
  static const _wk = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  static const _matches = [
    _Match('Al-Ahly Padel Club', 'C – C+', 'New Cairo', 0, '6:00 PM', '90 min', '1 spot left', true, 2.3, court: 3),
    _Match('Zamalek Sports Club', 'C – C+', 'Zamalek', 0, '7:00 PM', '90 min', '2 spots', true, 5.1, court: 1),
    _Match('Heliopolis Club', 'B – A', 'Heliopolis', 0, '9:00 PM', '60 min', '3 spots', false, 9.2, court: 2),
    _Match('Maadi Padel Lounge', 'C+ – B', 'Maadi', 1, '8:00 PM', '60 min', '2 spots', false, 7.8, court: 4),
    _Match('New Cairo Padel', 'C – C+', 'New Cairo', 1, '6:00 PM', '90 min', '1 spot left', true, 3.1, court: 2),
    _Match('Nasr City Arena', 'B – A', 'Nasr City', 2, '9:00 PM', '90 min', '3 spots', false, 4.6, court: 1),
    _Match('Sheikh Zayed Padel', 'C+ – B', 'Sheikh Zayed', 2, '7:00 PM', '90 min', '2 spots', true, 12.4, court: 3),
  ];

  String _dateLabel(int i) {
    if (i == 0) return 'Today'.tr(context);
    if (i == 1) return 'Tomorrow'.tr(context);
    return _wk[DateTime.now().add(Duration(days: i)).weekday - 1];
  }

  List<_Match> get _results {
    var list = _matches.where((m) => m.day == _date).toList();
    if (_filter == 1) list = list.where((m) => m.mine).toList();
    if (_filter == 2) {
      list = list.where((m) => m.km <= 6).toList();
      list.sort((a, b) => a.km.compareTo(b.km));
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    // Real posted bookings appear as live open matches, reflecting the exact
    // court, court number, day, time and duration the player selected.
    final live = ref.watch(bookingsProvider).where((b) => b.isPublic && b.day == _date).map((b) {
      final c = courtById(b.courtId);
      final km = double.tryParse(c.distance.split(' ').first) ?? 0;
      return _Match(c.name, 'C – C+', c.area, b.day, _fmtTime(b.startMin), '${b.durMin} ${'min'.tr(context)}', 'open'.tr(context), true, km, live: true, court: b.subCourt);
    }).toList();
    final results = [...live, ..._results];
    return Container(
      color: t.bg,
      child: ListView(padding: const EdgeInsets.only(bottom: 120), children: [
        Container(color: t.headBg, child: SafeArea(bottom: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 8, 22, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Open matches'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w500, color: t.headFg)),
            const SizedBox(height: 12),
            // date row
            SizedBox(height: 52, child: ListView.separated(
              scrollDirection: Axis.horizontal, itemCount: 6,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (c, i) {
                final on = i == _date;
                final d = DateTime.now().add(Duration(days: i));
                return GestureDetector(onTap: () => setState(() => _date = i), child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 13),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: on ? t.headFg : t.headChipBg, borderRadius: BorderRadius.circular(13), border: Border.all(color: on ? t.headFg : t.headChipBd)),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(_dateLabel(i), style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: on ? t.headBg : t.headFg)),
                    Text('${d.day}', style: TextStyle(fontFamily: kSerif, fontSize: 13, fontWeight: FontWeight.w700, color: on ? t.headBg : t.headFg)),
                  ]),
                ));
              },
            )),
            const SizedBox(height: 10),
            // filter chips
            Row(children: List.generate(_filters.length, (i) {
              final on = i == _filter;
              return Padding(padding: const EdgeInsets.only(right: 7), child: GestureDetector(
                onTap: () => setState(() => _filter = i),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(color: on ? t.headFg : t.headChipBg, borderRadius: BorderRadius.circular(99), border: Border.all(color: on ? t.headFg : t.headChipBd)),
                  child: Text(_filters[i].tr(context), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: on ? t.headBg : t.headFg)),
                ),
              ));
            })),
          ]),
        ))),
        const SizedBox(height: 16),
        if (results.isEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(22, 30, 22, 30), child: Center(child: Column(children: [
            Icon(Icons.event_busy_rounded, size: 40, color: t.ink3),
            const SizedBox(height: 10),
            Text('No open matches for this day'.tr(context), style: TextStyle(fontSize: 12.5, color: t.ink3)),
          ])))
        else
          ...results.map((m) => Padding(padding: const EdgeInsets.only(bottom: 12), child: _matchCard(t, m))),
        // create-from-booking
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Have a booking?'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.accent)),
              const SizedBox(height: 2),
              Text('Post it open — players at your level within 10 km get pinged'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink2, height: 1.4)),
            ])),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: () => context.push(AppRoutes.discovery),
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(11)), child: Text('Create'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.onAccent))),
            ),
          ]),
        )),
      ]),
    );
  }

  Widget _matchCard(LobbaTokens t, _Match m) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22),
        child: GestureDetector(
          onTap: () {
            final q = Uri(queryParameters: {
              'name': m.name, 'area': m.area, 'court': '${m.court}',
              'date': _dateLabel(m.day), 'time': m.time, 'dur': m.dur,
              'skill': m.skill, 'spots': m.spots,
            }).query;
            context.push('${AppRoutes.matchDetail.replaceFirst(':matchId', '1')}?$q');
          },
          child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Expanded(child: Row(children: [
                Flexible(child: Text(m.name, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink))),
                if (m.live) Padding(padding: const EdgeInsets.only(left: 6), child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: t.sage.withOpacity(.18), borderRadius: BorderRadius.circular(6)), child: Text('New'.tr(context), style: TextStyle(fontSize: 8.5, fontWeight: FontWeight.w700, color: t.sage)))),
              ])),
              const SizedBox(width: 8),
              Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4), decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(99)), child: Text(m.skill, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: t.accent))),
            ]),
            const SizedBox(height: 6),
            Row(children: [
              if (m.court > 0) Padding(padding: const EdgeInsets.only(right: 7), child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(6)), child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.sports_tennis_rounded, size: 10, color: t.onAccent),
                const SizedBox(width: 3),
                Text('${'Court'.tr(context)} ${m.court}', style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, color: t.onAccent)),
              ]))),
              Expanded(child: Text('${m.area} · ${_dateLabel(m.day)} ${m.time} · ${m.dur} · ${m.km} km', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: t.ink3))),
            ]),
            const SizedBox(height: 11),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Row(children: [
                _av(t, 'A', t.accent, t.onAccent),
                Transform.translate(offset: const Offset(-7, 0), child: _av(t, 'S', t.surface2, t.ink2)),
                Padding(padding: const EdgeInsets.only(left: 2), child: Text(m.spots.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink3))),
              ]),
              Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(11)), child: Text('Join'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.onAccent))),
            ]),
          ]),
        )),
      );

  Widget _av(LobbaTokens t, String ch, Color bg, Color fg) => Container(width: 26, height: 26, alignment: Alignment.center, decoration: BoxDecoration(color: bg, shape: BoxShape.circle, border: Border.all(color: t.surface, width: 2)), child: Text(ch, style: TextStyle(fontFamily: kSerif, fontSize: 10, fontWeight: FontWeight.w600, color: fg)));
}
