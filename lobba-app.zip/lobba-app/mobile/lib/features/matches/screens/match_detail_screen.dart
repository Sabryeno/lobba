import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';

/// Open-match details: court + time + the players (with levels), each clickable
/// to their profile, plus the cost breakdown and Join.
class MatchDetailScreen extends ConsumerWidget {
  final String matchId;
  final String? name, area, date, time, dur, skill, spots;
  final int court;
  const MatchDetailScreen({super.key, required this.matchId, this.name, this.area, this.court = 0, this.date, this.time, this.dur, this.skill, this.spots});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final venue = name ?? 'Al-Ahly Padel Club';
    final skillBand = skill ?? 'C – C+';
    final whenDate = date ?? 'Today';
    final whenTime = time ?? '6:00 PM';
    final durLabel = dur ?? '90 min';
    final spotsLabel = spots ?? '1 spot left';
    final players = [
      ['Ahmed', 'Level 3.0', 'host'],
      ['Sara M.', 'Level 4.0', ''],
      ['Omar K.', 'Level 3.1', ''],
    ];
    return PushScaffold(
      title: 'Join match'.tr(context),
      bottomBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
            onPressed: () => context.push(AppRoutes.joinPending),
            style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            child: Text('Confirm & join'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          )),
          const SizedBox(height: 9),
          Text('The host confirms · you’re notified instantly'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink3)),
        ]))),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 20), children: [
        // court card
        Container(
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: t.line)),
          clipBehavior: Clip.antiAlias,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Stack(children: [
              Container(height: 96, decoration: BoxDecoration(gradient: LinearGradient(colors: [t.accentSoft, t.surface2]))),
              Positioned(top: 12, left: 12, child: LPill(skillBand, bg: t.accentSoft, fg: t.accent)),
              if (court > 0) Positioned(top: 12, right: 12, child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(99)), child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.sports_tennis_rounded, size: 11, color: t.onAccent),
                const SizedBox(width: 4),
                Text('${'Court'.tr(context)} $court', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: t.onAccent)),
              ]))),
            ]),
            Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(venue, style: TextStyle(fontFamily: kSerif, fontSize: 17, fontWeight: FontWeight.w500, color: t.ink)),
              if (area != null) ...[
                const SizedBox(height: 2),
                Text(area!, style: TextStyle(fontSize: 11, color: t.ink3)),
              ],
              const SizedBox(height: 8),
              Row(children: [
                Icon(Icons.calendar_today_outlined, size: 13, color: t.ink2), const SizedBox(width: 5),
                Text('$whenDate · $whenTime', style: TextStyle(fontSize: 11.5, color: t.ink2)),
                const SizedBox(width: 14),
                Icon(Icons.schedule_rounded, size: 13, color: t.ink2), const SizedBox(width: 5),
                Text(durLabel, style: TextStyle(fontSize: 11.5, color: t.ink2)),
              ]),
            ])),
          ]),
        ),
        const SizedBox(height: 20),
        Eyebrow('${'Players'.tr(context)} · $spotsLabel'),
        const SizedBox(height: 11),
        ...players.map((p) => Padding(padding: const EdgeInsets.only(bottom: 9), child: GestureDetector(
          onTap: () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', p[0])),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
            child: Row(children: [
              LAvatar(p[0][0], size: 34, bg: p[2] == 'host' ? t.accent : null, fg: p[2] == 'host' ? t.onAccent : null),
              const SizedBox(width: 11),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Text(p[0], style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)), if (p[2] == 'host') Padding(padding: const EdgeInsets.only(left: 6), child: LPill('Host'.tr(context), bg: t.accentSoft, fg: t.accent))]),
                Text(p[1], style: TextStyle(fontSize: 10, color: t.ink3)),
              ])),
              Icon(Icons.chevron_right_rounded, size: 18, color: t.ink3),
            ]),
          ),
        ))),
        const SizedBox(height: 8),
        // cost
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(14)), child: Column(children: [
          _cost(t, 'Your share'.tr(context), 'EGP 188'),
          const SizedBox(height: 7),
          _cost(t, 'Split fee'.tr(context), 'EGP 5'),
          Divider(color: t.line, height: 20),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('You pay'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
            Text('EGP 193', style: TextStyle(fontFamily: kSerif, fontSize: 19, fontWeight: FontWeight.w600, color: t.accent)),
          ]),
        ])),
      ]),
    );
  }

  Widget _cost(LobbaTokens t, String k, String v) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(k, style: TextStyle(fontSize: 12, color: t.ink3)), Text(v, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.ink))]);
}
