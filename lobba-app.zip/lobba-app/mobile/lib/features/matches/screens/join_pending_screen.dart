import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';

/// Shown right after "Confirm & join": the request is sent to the host for
/// approval. The team chat stays locked until the host approves — then the
/// chat icon activates and opens the game group chat.
class JoinPendingScreen extends StatefulWidget {
  const JoinPendingScreen({super.key});
  @override
  State<JoinPendingScreen> createState() => _JoinPendingScreenState();
}

class _JoinPendingScreenState extends State<JoinPendingScreen> {
  bool _approved = false;

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Join match'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 24, 22, 24), children: [
        Center(child: Column(children: [
          Container(
            width: 88, height: 88,
            decoration: BoxDecoration(color: _approved ? t.accentSoft : t.gold.withOpacity(.14), shape: BoxShape.circle, border: Border.all(color: _approved ? t.accent : t.gold, width: 2)),
            child: Icon(_approved ? Icons.check_rounded : Icons.schedule_rounded, size: 42, color: _approved ? t.accent : t.gold),
          ),
          const SizedBox(height: 20),
          Text((_approved ? 'You’re in!' : 'Request sent').tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 24, fontWeight: FontWeight.w500, color: t.ink)),
          const SizedBox(height: 6),
          Text((_approved
              ? 'The host approved you — say hi to the team.'
              : 'Sent to the host for approval. You’ll be notified the moment they confirm.').tr(context),
              textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: t.ink2, height: 1.5)),
        ])),
        const SizedBox(height: 22),
        // match summary
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
          child: Row(children: [
            Container(width: 46, height: 46, decoration: BoxDecoration(gradient: LinearGradient(colors: [t.accentSoft, t.surface2]), borderRadius: BorderRadius.circular(12))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Al-Ahly Padel Club · Court A', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
              const SizedBox(height: 2),
              Text('Today 6:00 PM · 90 min · 4 players', style: TextStyle(fontSize: 10.5, color: t.ink3)),
            ])),
            LPill((_approved ? 'Joined' : 'Pending').tr(context), bg: (_approved ? t.sage : t.gold).withOpacity(.16), fg: _approved ? t.sage : t.gold),
          ]),
        ),
        const SizedBox(height: 14),
        // team chat — locked until approved
        GestureDetector(
          onTap: _approved ? () => context.push(AppRoutes.chatDetail.replaceFirst(':chatId', '1')) : null,
          child: Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: _approved ? t.accent : t.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _approved ? t.accent : t.line),
            ),
            child: Row(children: [
              Icon(_approved ? Icons.chat_bubble_rounded : Icons.lock_outline_rounded, size: 20, color: _approved ? t.onAccent : t.ink3),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Team chat'.tr(context), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: _approved ? t.onAccent : t.ink3)),
                Text((_approved ? 'Open the group chat for this game’s players' : 'Unlocks once the host approves you').tr(context), style: TextStyle(fontSize: 10.5, color: _approved ? t.onAccent.withOpacity(.85) : t.ink3)),
              ])),
              if (_approved) Icon(Icons.chevron_right_rounded, color: t.onAccent),
            ]),
          ),
        ),
        const SizedBox(height: 22),
        if (!_approved)
          // Demo control (no backend): simulate the host approving.
          Center(child: GestureDetector(
            onTap: () => setState(() => _approved = true),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(99), border: Border.all(color: t.line)),
              child: Text('Simulate: host approves'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.ink2)),
            ),
          )),
      ]),
    );
  }
}
