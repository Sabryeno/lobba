import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';

class RecordScoreScreen extends StatefulWidget {
  const RecordScoreScreen({super.key});
  @override
  State<RecordScoreScreen> createState() => _RecordScoreScreenState();
}

class _RecordScoreScreenState extends State<RecordScoreScreen> {
  final _us = [6, 4, 6];
  final _them = [4, 6, 3];
  bool _submitted = false;

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    if (_submitted) return _submittedView(t);
    return PushScaffold(
      title: 'Record score'.tr(context),
      bottomBar: _bottom(t, 'Submit score'.tr(context), 'Both teams confirm · then your grade updates'.tr(context), () => setState(() => _submitted = true)),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 14, 22, 20), children: [
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(13)), child: Text('Al-Ahly Padel Club · Today 6:00 PM · Competitive', style: TextStyle(fontSize: 11, color: t.ink2))),
        const SizedBox(height: 16),
        _teamHeader(t),
        const SizedBox(height: 14),
        for (var s = 0; s < _us.length; s++) ...[
          editableSetRow(context, t, s, _us, _them, () => setState(() {})),
          const SizedBox(height: 9),
        ],
        if (_us.length < 5) addSetButton(context, t, () => setState(() { _us.add(0); _them.add(0); })),
        const SizedBox(height: 16),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(13)), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Level update preview'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.accent)),
          Row(children: [
            Text('3.0 → 3.1 ', style: TextStyle(fontFamily: kSerif, fontSize: 16, fontWeight: FontWeight.w600, color: t.ink)),
            Text('+0.1', style: TextStyle(fontSize: 11, color: t.sage)),
          ]),
        ])),
      ]),
    );
  }

  Widget _teamHeader(LobbaTokens t) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Row(children: [_av(t, 'A', t.accent, t.onAccent), Transform.translate(offset: const Offset(-7, 0), child: _av(t, 'S', t.surface2, t.ink2)), const SizedBox(width: 5), Text('You & Sara'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.ink))]),
        LPill('Winners'.tr(context), bg: t.accentSoft, fg: t.accent),
      ]);

  Widget _av(LobbaTokens t, String c, Color bg, Color fg) => Container(width: 28, height: 28, alignment: Alignment.center, decoration: BoxDecoration(color: bg, shape: BoxShape.circle, border: Border.all(color: t.bg, width: 2)), child: Text(c, style: TextStyle(fontFamily: kSerif, fontSize: 10, fontWeight: FontWeight.w600, color: fg)));

  Widget _submittedView(LobbaTokens t) => PushScaffold(
        title: 'Record score'.tr(context),
        child: ListView(padding: const EdgeInsets.fromLTRB(22, 40, 22, 24), children: [
          Center(child: Column(children: [
            Container(width: 88, height: 88, decoration: BoxDecoration(color: t.gold.withOpacity(.14), shape: BoxShape.circle, border: Border.all(color: t.gold, width: 2)), child: Icon(Icons.hourglass_top_rounded, size: 40, color: t.gold)),
            const SizedBox(height: 18),
            Text('Score submitted'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 22, fontWeight: FontWeight.w500, color: t.ink)),
            const SizedBox(height: 7),
            Text('Waiting for the other team to confirm the score.'.tr(context), textAlign: TextAlign.center, style: TextStyle(fontSize: 12.5, color: t.ink2, height: 1.5)),
          ])),
          const SizedBox(height: 22),
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)), child: Column(children: [
            for (var s = 0; s < _us.length; s++) Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${'Set'.tr(context)} ${s + 1}', style: TextStyle(fontSize: 11.5, color: t.ink3)),
              Text('${_us[s]} – ${_them[s]}', style: TextStyle(fontFamily: kSerif, fontSize: 15, fontWeight: FontWeight.w600, color: t.ink)),
            ])),
          ])),
          const SizedBox(height: 20),
          SizedBox(height: 50, child: ElevatedButton(
            onPressed: () => context.push(AppRoutes.rateMatch),
            style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            child: Text('Rate the match'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          )),
          const SizedBox(height: 10),
          SizedBox(height: 46, child: TextButton.icon(onPressed: () => context.go(AppRoutes.home), icon: Icon(Icons.home_rounded, size: 18, color: t.ink2), label: Text('Back to home'.tr(context), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink2)))),
        ]),
      );
}

/// Editable best-of-5 set row — both teams' scores adjustable with +/- steppers.
/// Shared by Record and Confirm so either player can correct the score.
/// "+ Add set" button — appends a set (used by Record and Confirm, up to 5).
Widget addSetButton(BuildContext context, LobbaTokens t, VoidCallback onTap) => GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        alignment: Alignment.center,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: t.line)),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.add_rounded, size: 16, color: t.accent),
          const SizedBox(width: 7),
          Text('Add set'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.accent)),
        ]),
      ),
    );

Widget editableSetRow(BuildContext context, LobbaTokens t, int s, List<int> us, List<int> them, VoidCallback onChanged) {
  Widget step(VoidCallback onTap, bool plus) => GestureDetector(onTap: () { onTap(); onChanged(); }, child: Container(width: 26, height: 26, alignment: Alignment.center, decoration: BoxDecoration(color: plus ? t.accent : t.surface2, borderRadius: BorderRadius.circular(7)), child: Icon(plus ? Icons.add : Icons.remove, size: 15, color: plus ? t.onAccent : t.ink2)));
  Widget cell(List<int> arr) => Row(mainAxisSize: MainAxisSize.min, children: [
        step(() => arr[s] = (arr[s] - 1).clamp(0, 9), false),
        SizedBox(width: 26, child: Text('${arr[s]}', textAlign: TextAlign.center, style: TextStyle(fontFamily: kSerif, fontSize: 18, fontWeight: FontWeight.w600, color: t.ink))),
        step(() => arr[s] = (arr[s] + 1).clamp(0, 9), true),
      ]);
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
    decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: t.line)),
    child: Row(children: [
      SizedBox(width: 46, child: Text('${'Set'.tr(context)} ${s + 1}', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: t.ink3))),
      Expanded(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        cell(us),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Text('–', style: TextStyle(color: t.ink3))),
        cell(them),
      ])),
    ]),
  );
}

/// The opponent's side — review, correct if needed, then confirm or dispute.
class ScoreConfirmScreen extends StatefulWidget {
  const ScoreConfirmScreen({super.key});
  @override
  State<ScoreConfirmScreen> createState() => _ScoreConfirmScreenState();
}

class _ScoreConfirmScreenState extends State<ScoreConfirmScreen> {
  final _us = [4, 6, 3]; // opponent's view of the submitted score (editable)
  final _them = [6, 4, 6];
  String _state = 'pending'; // pending | confirmed | disputed

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Confirm the score'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(13)), child: Text('Al-Ahly Padel Club · Today 6:00 PM · Competitive', style: TextStyle(fontSize: 11, color: t.ink2))),
        const SizedBox(height: 14),
        Row(children: [
          CircleAvatar(radius: 16, backgroundColor: t.accentSoft, child: Text('A', style: TextStyle(color: t.accent, fontFamily: kSerif))),
          const SizedBox(width: 10),
          Expanded(child: Text('Ahmed ${'submitted the score'.tr(context)}', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink))),
        ]),
        const SizedBox(height: 6),
        Text('Correct any set below if it’s wrong.'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink3)),
        const SizedBox(height: 12),
        if (_state == 'pending')
          Column(children: [
            for (var s = 0; s < _us.length; s++) ...[
              editableSetRow(context, t, s, _us, _them, () => setState(() {})),
              const SizedBox(height: 9),
            ],
            if (_us.length < 5) addSetButton(context, t, () => setState(() { _us.add(0); _them.add(0); })),
          ])
        else
          Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)), child: Column(children: [
            for (var s = 0; s < _us.length; s++) Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${'Set'.tr(context)} ${s + 1}', style: TextStyle(fontSize: 12, color: t.ink3)),
              Text('${_us[s]} – ${_them[s]}', style: TextStyle(fontFamily: kSerif, fontSize: 17, fontWeight: FontWeight.w600, color: t.ink)),
            ])),
          ])),
        const SizedBox(height: 18),
        if (_state == 'pending') ...[
          Center(child: Text('Is this score correct?'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink2))),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: GestureDetector(
              onTap: () => setState(() => _state = 'disputed'),
              child: Container(padding: const EdgeInsets.symmetric(vertical: 13), alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(13), border: Border.all(color: t.clay)), child: Text('Report as wrong'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.clay))),
            )),
            const SizedBox(width: 10),
            Expanded(child: GestureDetector(
              onTap: () => setState(() => _state = 'confirmed'),
              child: Container(padding: const EdgeInsets.symmetric(vertical: 13), alignment: Alignment.center, decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(13)), child: Text('Score is accurate'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.onAccent))),
            )),
          ]),
        ] else ...[
          Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(color: (_state == 'confirmed' ? t.sage : t.clay).withOpacity(.14), borderRadius: BorderRadius.circular(14)),
            child: Row(children: [
              Icon(_state == 'confirmed' ? Icons.verified_rounded : Icons.report_gmailerrorred_rounded, color: _state == 'confirmed' ? t.sage : t.clay, size: 22),
              const SizedBox(width: 11),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text((_state == 'confirmed' ? 'Score confirmed' : 'Sent back to re-check').tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: _state == 'confirmed' ? t.sage : t.clay)),
                Text((_state == 'confirmed' ? 'Ratings & level updated.' : 'The score was sent back to re-check.').tr(context), style: TextStyle(fontSize: 10.5, color: t.ink2)),
              ])),
            ]),
          ),
          const SizedBox(height: 16),
          if (_state == 'confirmed')
            SizedBox(height: 50, child: ElevatedButton(onPressed: () => context.push(AppRoutes.rateMatch), style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: Text('Rate the match'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)))),
          SizedBox(height: 46, child: TextButton.icon(onPressed: () => context.go(AppRoutes.home), icon: Icon(Icons.home_rounded, size: 18, color: t.ink2), label: Text('Back to home'.tr(context), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink2)))),
        ],
      ]),
    );
  }
}

class RateMatchScreen extends StatelessWidget {
  const RateMatchScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Rate your match'.tr(context),
      bottomBar: _bottom(t, 'Submit ratings'.tr(context), null, () => context.go(AppRoutes.home)),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 20), children: [
        Eyebrow('Players'.tr(context)),
        const SizedBox(height: 10),
        _ratePlayer(t, 'Sara M.', 4),
        const SizedBox(height: 9),
        _ratePlayer(t, 'Omar K.', 5),
        const SizedBox(height: 22),
        Eyebrow('Court'.tr(context)),
        const SizedBox(height: 10),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Al-Ahly Padel Club', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)), _stars(t, 5)]),
          const SizedBox(height: 11),
          Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(10)), child: Text('Add a short review… courts, lighting, staff.'.tr(context), style: TextStyle(fontSize: 11, color: t.ink3))),
        ])),
      ]),
    );
  }

  Widget _ratePlayer(LobbaTokens t, String name, int stars) => Container(
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)),
        child: Row(children: [LAvatar(name[0], size: 34), const SizedBox(width: 11), Expanded(child: Text(name, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink))), _stars(t, stars)]),
      );
  Widget _stars(LobbaTokens t, int n) => Row(children: List.generate(5, (i) => Icon(i < n ? Icons.star_rounded : Icons.star_outline_rounded, size: 16, color: i < n ? t.gold : t.line)));
}

Widget _bottom(LobbaTokens t, String label, String? note, VoidCallback onTap) => Container(
      decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
      child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(22, 14, 22, 14), child: Column(mainAxisSize: MainAxisSize.min, children: [
        SizedBox(height: 50, width: double.infinity, child: ElevatedButton(onPressed: onTap, style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)))),
        if (note != null) Padding(padding: const EdgeInsets.only(top: 9), child: Text(note, style: TextStyle(fontSize: 10, color: t.ink3))),
      ]))),
    );
