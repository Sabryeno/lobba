import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../providers/matches_provider.dart';

class CreateMatchScreen extends ConsumerStatefulWidget {
  const CreateMatchScreen({super.key});

  @override
  ConsumerState<CreateMatchScreen> createState() => _CreateMatchScreenState();
}

class _CreateMatchScreenState extends ConsumerState<CreateMatchScreen> {
  final _formKey = GlobalKey<FormState>();
  DateTime _date = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _time = const TimeOfDay(hour: 18, minute: 0);
  int _duration = 90;
  String _format = 'DOUBLES';
  String? _minLevel;
  String? _maxLevel;
  bool _isLoading = false;

  // In a real app, you'd pick a court from discovery
  final String _courtId = 'demo-court-id';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Create Match'.tr(context)),
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _SectionHeader(title: 'Date & Time'.tr(context)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _PickerCard(
                    icon: Icons.calendar_today,
                    label: 'Date'.tr(context),
                    value: DateFormat('EEE, MMM d').format(_date),
                    onTap: () async {
                      final d = await showDatePicker(
                        context: context,
                        initialDate: _date,
                        firstDate: DateTime.now(),
                        lastDate: DateTime.now().add(const Duration(days: 30)),
                        builder: (ctx, child) => Theme(
                          data: Theme.of(ctx).copyWith(
                            colorScheme: ColorScheme.light(primary: AppColors.primary),
                          ),
                          child: child!,
                        ),
                      );
                      if (d != null) setState(() => _date = d);
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _PickerCard(
                    icon: Icons.access_time,
                    label: 'Time'.tr(context),
                    value: _time.format(context),
                    onTap: () async {
                      final t = await showTimePicker(
                        context: context,
                        initialTime: _time,
                      );
                      if (t != null) setState(() => _time = t);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _SectionHeader(title: 'Match Details'.tr(context)),
            const SizedBox(height: 12),

            // Duration
            Text('Duration'.tr(context), style: TextStyle(color: AppColors.textSecondary, fontSize: 14)),
            const SizedBox(height: 8),
            Row(
              children: [60, 90, 120].map((d) {
                final selected = _duration == d;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text('${d}m'),
                    selected: selected,
                    onSelected: (_) => setState(() => _duration = d),
                    selectedColor: AppColors.primary,
                    labelStyle: TextStyle(
                      color: selected ? AppColors.white : AppColors.textPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 16),

            // Format
            Text('Format'.tr(context), style: TextStyle(color: AppColors.textSecondary, fontSize: 14)),
            const SizedBox(height: 8),
            Row(
              children: ['DOUBLES', 'SINGLES', 'AMERICANO'].map((f) {
                final selected = _format == f;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(f.tr(context)),
                    selected: selected,
                    onSelected: (_) => setState(() => _format = f),
                    selectedColor: AppColors.primary,
                    labelStyle: TextStyle(
                      color: selected ? AppColors.white : AppColors.textPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            _SectionHeader(title: 'Skill Requirements (optional)'.tr(context)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      labelText: 'Min Level'.tr(context),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                    ),
                    value: _minLevel,
                    items: [
                      DropdownMenuItem(value: null, child: Text('Any'.tr(context))),
                      DropdownMenuItem(value: 'BEGINNER', child: Text('Beginner'.tr(context))),
                      DropdownMenuItem(value: 'INTERMEDIATE', child: Text('Intermediate'.tr(context))),
                      DropdownMenuItem(value: 'ADVANCED', child: Text('Advanced'.tr(context))),
                    ],
                    onChanged: (v) => setState(() => _minLevel = v),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      labelText: 'Max Level'.tr(context),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                    ),
                    value: _maxLevel,
                    items: [
                      DropdownMenuItem(value: null, child: Text('Any'.tr(context))),
                      DropdownMenuItem(value: 'INTERMEDIATE', child: Text('Intermediate'.tr(context))),
                      DropdownMenuItem(value: 'ADVANCED', child: Text('Advanced'.tr(context))),
                      DropdownMenuItem(value: 'EXPERT', child: Text('Expert'.tr(context))),
                      DropdownMenuItem(value: 'ELITE', child: Text('Elite'.tr(context))),
                    ],
                    onChanged: (v) => setState(() => _maxLevel = v),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: FilledButton(
                onPressed: _isLoading ? null : _submit,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: _isLoading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : Text('Create Match'.tr(context),
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit() async {
    final scheduled = DateTime(
      _date.year, _date.month, _date.day, _time.hour, _time.minute,
    );
    setState(() => _isLoading = true);
    final id = await ref.read(matchesProvider.notifier).createMatch({
      'courtId': _courtId,
      'scheduledAt': scheduled.toIso8601String(),
      'durationMinutes': _duration,
      'format': _format,
      if (_minLevel != null) 'minLevel': _minLevel,
      if (_maxLevel != null) 'maxLevel': _maxLevel,
    });
    setState(() => _isLoading = false);
    if (id != null && mounted) {
      context.pop();
    }
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
          fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
    );
  }
}

class _PickerCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final VoidCallback onTap;

  const _PickerCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.grey300),
          borderRadius: BorderRadius.circular(12),
          color: AppColors.white,
        ),
        child: Row(
          children: [
            Icon(icon, size: 18, color: AppColors.primary),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                Text(value,
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w600)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
