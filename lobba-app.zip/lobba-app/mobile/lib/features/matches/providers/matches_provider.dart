import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/services/api_service.dart';

// ── Models ───────────────────────────────────────────────────────────────────
class MatchModel {
  final String id;
  final String courtId;
  final String courtName;
  final String venueName;
  final String venueCity;
  final DateTime scheduledAt;
  final int durationMinutes;
  final int currentPlayers;
  final int maxPlayers;
  final String status;
  final String format;
  final String? minLevel;
  final String? maxLevel;
  final bool isOpen;
  final String? hostId;
  final String? hostName;
  final double? hostElo;
  final String? hostAvatar;
  final double pricePerPlayer;

  const MatchModel({
    required this.id,
    required this.courtId,
    required this.courtName,
    required this.venueName,
    required this.venueCity,
    required this.scheduledAt,
    required this.durationMinutes,
    required this.currentPlayers,
    required this.maxPlayers,
    required this.status,
    required this.format,
    this.minLevel,
    this.maxLevel,
    required this.isOpen,
    this.hostId,
    this.hostName,
    this.hostElo,
    this.hostAvatar,
    required this.pricePerPlayer,
  });

  factory MatchModel.fromJson(Map<String, dynamic> json) => MatchModel(
        id: json['id'],
        courtId: json['courtId'] ?? '',
        courtName: json['court']?['name'] ?? '',
        venueName: json['court']?['venue']?['name'] ?? '',
        venueCity: json['court']?['venue']?['city'] ?? '',
        scheduledAt: DateTime.parse(json['scheduledAt']),
        durationMinutes: json['durationMinutes'] ?? 60,
        currentPlayers: json['currentPlayers'] ?? 1,
        maxPlayers: json['maxPlayers'] ?? 4,
        status: json['status'] ?? 'OPEN',
        format: json['format'] ?? 'DOUBLES',
        minLevel: json['minLevel'],
        maxLevel: json['maxLevel'],
        isOpen: json['isOpen'] ?? true,
        hostId: json['host']?['id'],
        hostName: json['host']?['profile']?['fullName'],
        hostElo: (json['host']?['profile']?['eloRating'] as num?)?.toDouble(),
        hostAvatar: json['host']?['profile']?['avatarUrl'],
        pricePerPlayer: (json['pricePerPlayer'] as num?)?.toDouble() ?? 0,
      );

  bool get isFull => currentPlayers >= maxPlayers;
  int get spotsLeft => maxPlayers - currentPlayers;
}

// ── State ─────────────────────────────────────────────────────────────────────
class MatchesState {
  final List<MatchModel> openMatches;
  final List<MatchModel> myMatches;
  final bool isLoading;
  final String? error;

  const MatchesState({
    this.openMatches = const [],
    this.myMatches = const [],
    this.isLoading = false,
    this.error,
  });

  MatchesState copyWith({
    List<MatchModel>? openMatches,
    List<MatchModel>? myMatches,
    bool? isLoading,
    String? error,
  }) =>
      MatchesState(
        openMatches: openMatches ?? this.openMatches,
        myMatches: myMatches ?? this.myMatches,
        isLoading: isLoading ?? this.isLoading,
        error: error,
      );
}

// ── Notifier ──────────────────────────────────────────────────────────────────
class MatchesNotifier extends StateNotifier<MatchesState> {
  final Ref _ref;

  MatchesNotifier(this._ref) : super(const MatchesState());

  Future<void> loadOpenMatches({String? city, String? level}) async {
    state = state.copyWith(isLoading: true);
    try {
      final dio = _ref.read(dioProvider);
      final resp = await dio.get('/matches/open', queryParameters: {
        if (city != null) 'city': city,
        if (level != null) 'level': level,
      });
      final items = (_extractList(resp.data))
          .map((e) => MatchModel.fromJson(e))
          .toList();
      state = state.copyWith(openMatches: items, isLoading: false);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<void> loadMyMatches() async {
    try {
      final dio = _ref.read(dioProvider);
      final resp = await dio.get('/matches/me');
      final items = (_extractList(resp.data))
          .map((e) => MatchModel.fromJson(e))
          .toList();
      state = state.copyWith(myMatches: items);
    } catch (_) {}
  }

  Future<bool> joinMatch(String matchId) async {
    try {
      final dio = _ref.read(dioProvider);
      await dio.post('/matches/$matchId/join');
      await loadOpenMatches();
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<String?> createMatch(Map<String, dynamic> data) async {
    try {
      final dio = _ref.read(dioProvider);
      final resp = await dio.post('/matches', data: data);
      await loadOpenMatches();
      final body = resp.data;
      final match = body is Map<String, dynamic> && body['data'] is Map
          ? body['data'] as Map<String, dynamic>
          : body as Map<String, dynamic>;
      return match['id'] as String?;
    } catch (e) {
      return null;
    }
  }

  List<dynamic> _extractList(dynamic body) {
    if (body is List) return body;
    if (body is Map<String, dynamic> && body['data'] is List) {
      return body['data'] as List;
    }
    return const [];
  }
}

final matchesProvider =
    StateNotifierProvider<MatchesNotifier, MatchesState>((ref) {
  return MatchesNotifier(ref);
});
