import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:go_router/go_router.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../../core/navigation/app_routes.dart';

class NotificationsScreen extends ConsumerStatefulWidget {
  const NotificationsScreen({super.key});
  @override
  ConsumerState<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends ConsumerState<NotificationsScreen> {
  final _handled = <int>{};

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'Notifications'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        // friend request with Accept/Decline
        if (!_handled.contains(0))
          _card(t, child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            LAvatar('K'),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Karim wants to add you'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
              Text('Level 2.0 · Cairo · 2 mutual friends', style: TextStyle(fontSize: 10.5, color: t.ink2)),
              const SizedBox(height: 9),
              Row(children: [
                Expanded(child: _btn(t, 'Accept'.tr(context), filled: true, onTap: () => setState(() => _handled.add(0)))),
                const SizedBox(width: 8),
                Expanded(child: _btn(t, 'Decline'.tr(context), filled: false, onTap: () => setState(() => _handled.add(0)))),
              ]),
            ])),
          ])),
        if (!_handled.contains(0)) const SizedBox(height: 10),
        // friend accepted → open their profile / invite to tribe
        _card(t, child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          GestureDetector(onTap: () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', 'Sara Mostafa')), child: LAvatar('S')),
          const SizedBox(width: 11),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            GestureDetector(
              onTap: () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', 'Sara Mostafa')),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Sara accepted your request'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
                Text('You’re now friends — invite her to play or to a tribe.'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink2, height: 1.4)),
              ]),
            ),
            const SizedBox(height: 9),
            Row(children: [
              Expanded(child: _btn(t, 'View profile'.tr(context), filled: true, onTap: () => context.push(AppRoutes.playerDetail.replaceFirst(':playerId', 'Sara Mostafa')))),
              const SizedBox(width: 8),
              Expanded(child: _btn(t, 'Invite to tribe'.tr(context), filled: false, onTap: () => context.push(AppRoutes.inviteTribe))),
            ]),
          ])),
        ])),
        const SizedBox(height: 10),
        _info(t, Icons.sports_tennis_rounded, 'Open match near you · your level'.tr(context), 'Al-Ahly · 2.3 km · Today 6 PM · C–C+ · 1 spot left.', 'View & join →'.tr(context), soft: true, onTap: () => context.push(AppRoutes.matchDetail.replaceFirst(':matchId', '1'))),
        const SizedBox(height: 10),
        _info(t, Icons.emoji_flags_outlined, 'Match ended'.tr(context), 'Al-Ahly · Today 6 PM was competitive — record the result.', 'Add score →'.tr(context), onTap: () => context.push(AppRoutes.recordScore)),
        const SizedBox(height: 10),
        _info(t, Icons.fact_check_outlined, 'Confirm the score'.tr(context), 'Ahmed submitted 6-4, 4-6, 6-3 — is it correct?', 'View score →'.tr(context), soft: true, onTap: () => context.push(AppRoutes.confirmScore)),
        const SizedBox(height: 10),
        _info(t, Icons.star_border_rounded, 'Rate your match & court'.tr(context), 'How was your game with Sara & Omar at Al-Ahly?', 'Leave a rating →'.tr(context), gold: true, onTap: () => context.push(AppRoutes.rateMatch)),
        const SizedBox(height: 10),
        // booking lifecycle notifications
        _info(t, Icons.check_circle_outline_rounded, 'Booking confirmed'.tr(context), 'Al-Ahly · Court 3 · Today 6:00 PM · 90 min.', 'View booking →'.tr(context), onTap: () => context.push(AppRoutes.myBookings)),
        const SizedBox(height: 10),
        _info(t, Icons.alarm_rounded, 'Upcoming game reminder'.tr(context), 'Your match at Al-Ahly starts in 2 hours.', 'View booking →'.tr(context), soft: true, onTap: () => context.push(AppRoutes.myBookings)),
        const SizedBox(height: 10),
        _info(t, Icons.local_offer_outlined, 'A deal near you'.tr(context), 'Al-Ahly · Court 2 · 30% off 3–5 PM today.', 'See deal →'.tr(context), gold: true, onTap: () => context.push(AppRoutes.deals)),
        // invite-to-play received with Accept/Decline
        if (!_handled.contains(1)) ...[
          const SizedBox(height: 10),
          _card(t, child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.sports_tennis_rounded, color: t.accent, size: 18),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Ahmed invited you to play'.tr(context), style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
              Text('Al-Ahly · Court 3 · Today 6:00 PM · 90 min · 2 slots open', style: TextStyle(fontSize: 10.5, color: t.ink2)),
              const SizedBox(height: 9),
              Row(children: [
                Expanded(child: _btn(t, 'Accept & join'.tr(context), filled: true, onTap: () => setState(() => _handled.add(1)))),
                const SizedBox(width: 8),
                Expanded(child: _btn(t, 'Decline'.tr(context), filled: false, onTap: () => setState(() => _handled.add(1)))),
              ]),
            ])),
          ])),
        ],
      ]),
    );
  }

  Widget _card(LobbaTokens t, {required Widget child}) => Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
        child: child,
      );

  Widget _info(LobbaTokens t, IconData ic, String title, String body, String cta, {bool soft = false, bool gold = false, VoidCallback? onTap}) => GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: soft ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: soft ? t.accentSoft : t.line)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(ic, size: 18, color: gold ? t.gold : t.accent),
          const SizedBox(width: 11),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
            const SizedBox(height: 2),
            Text(body, style: TextStyle(fontSize: 10.5, color: t.ink2, height: 1.4)),
            const SizedBox(height: 7),
            Text(cta, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: t.accent)),
          ])),
        ]),
      ),
      );

  Widget _btn(LobbaTokens t, String label, {required bool filled, required VoidCallback onTap}) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8), alignment: Alignment.center,
          decoration: BoxDecoration(color: filled ? t.accent : t.surface, borderRadius: BorderRadius.circular(9), border: filled ? null : Border.all(color: t.line)),
          child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: filled ? t.onAccent : t.ink2)),
        ),
      );
}
