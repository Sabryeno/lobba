class PlayerSearchResult {
  final String id;
  final String name;
  final String? phone;
  final int skillLevel;
  final String? city;
  final String? photoUrl;

  const PlayerSearchResult({
    required this.id,
    required this.name,
    this.phone,
    required this.skillLevel,
    this.city,
    this.photoUrl,
  });

  factory PlayerSearchResult.fromJson(Map<String, dynamic> json) {
    return PlayerSearchResult(
      id: json['id'] as String,
      name: (json['name'] as String?) ?? '',
      phone: json['phone'] as String?,
      skillLevel: (json['skillLevelNumeric'] as num?)?.toInt() ?? 1,
      city: json['city'] as String?,
      photoUrl: json['photoUrl'] as String?,
    );
  }

  String get initials {
    final parts = name.trim().split(' ').where((s) => s.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts[0][0].toUpperCase();
    return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
  }

  String get skillLabel => switch (skillLevel) {
        1 => 'Beginner',
        2 => 'Novice',
        3 => 'Intermediate',
        4 => 'Advanced',
        5 => 'Expert',
        6 => 'Pro',
        7 => 'Elite',
        _ => 'Player',
      };
}
