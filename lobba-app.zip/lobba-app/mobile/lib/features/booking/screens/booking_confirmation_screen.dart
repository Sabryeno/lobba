import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/models/court_detail.dart';

class BookingConfirmationScreen extends StatefulWidget {
  final Booking booking;
  const BookingConfirmationScreen({super.key, required this.booking});

  @override
  State<BookingConfirmationScreen> createState() =>
      _BookingConfirmationScreenState();
}

class _BookingConfirmationScreenState
    extends State<BookingConfirmationScreen> {
  bool _codeCopied = false;

  Booking get b => widget.booking;

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          // Decorative top arc
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: CustomPaint(
              painter: _ArcPainter(color: AppColors.primary),
              size: Size(MediaQuery.of(context).size.width, 260),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
              child: Column(
                children: [
                  const SizedBox(height: 24),
                  // Success icon
                  _SuccessIcon()
                      .animate()
                      .scale(
                        begin: const Offset(.3, .3),
                        end: const Offset(1, 1),
                        duration: 600.ms,
                        curve: Curves.elasticOut,
                      ),
                  const SizedBox(height: 20),
                  Text(
                    'Booking Confirmed!',
                    style: AppTypography.headlineMedium(locale).copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                    ),
                    textAlign: TextAlign.center,
                  ).animate().fadeIn(delay: 300.ms, duration: 400.ms),
                  const SizedBox(height: 6),
                  Text(
                    b.venueName,
                    style: AppTypography.bodyMedium(locale)
                        .copyWith(color: Colors.white70),
                    textAlign: TextAlign.center,
                  ).animate().fadeIn(delay: 400.ms, duration: 400.ms),
                  const SizedBox(height: 32),

                  // Details card
                  _DetailsCard(booking: b)
                      .animate()
                      .fadeIn(delay: 500.ms, duration: 400.ms)
                      .slideY(begin: .1, end: 0),

                  const SizedBox(height: 20),

                  // QR / Fawry reference
                  _QrSection(booking: b, onCopied: _handleCopy)
                      .animate()
                      .fadeIn(delay: 650.ms, duration: 400.ms)
                      .slideY(begin: .1, end: 0),

                  if (_codeCopied)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        'Reference code copied!',
                        style: AppTypography.bodySmall(locale)
                            .copyWith(color: AppColors.primary),
                      ),
                    ).animate().fadeIn(),

                  const SizedBox(height: 28),

                  // Actions
                  _ActionRow(booking: b)
                      .animate()
                      .fadeIn(delay: 800.ms, duration: 400.ms),

                  const SizedBox(height: 32),

                  // Go home
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => context.go('/home'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        side:
                            BorderSide(color: AppColors.primary, width: 1.5),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: Text(
                        'Back to Home',
                        style: AppTypography.titleMedium(locale).copyWith(
                          color: AppColors.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ).animate().fadeIn(delay: 900.ms),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleCopy() {
    setState(() => _codeCopied = true);
    Future.delayed(const Duration(seconds: 3),
        () => mounted ? setState(() => _codeCopied = false) : null);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Widgets
// ─────────────────────────────────────────────────────────────────────────────

class _SuccessIcon extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 80,
      height: 80,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.12),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Icon(Icons.check_rounded, color: AppColors.primary, size: 42),
    );
  }
}

class _DetailsCard extends StatelessWidget {
  final Booking booking;
  const _DetailsCard({required this.booking});

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    final b = booking;
    final start = b.startTime;
    final end = start.add(Duration(minutes: b.durationMinutes));

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Booking ID',
                style: AppTypography.labelSmall(locale)
                    .copyWith(color: AppColors.textSecondary),
              ),
              Text(
                '#${b.id.substring(0, 8).toUpperCase()}',
                style: AppTypography.titleMedium(locale).copyWith(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          Divider(height: 24, color: AppColors.divider),
          _DetailRow(
            icon: Icons.calendar_today_rounded,
            label: 'Date',
            value:
                '${start.day}/${start.month}/${start.year}',
          ),
          const SizedBox(height: 12),
          _DetailRow(
            icon: Icons.access_time_rounded,
            label: 'Time',
            value:
                '${_hm(start)} – ${_hm(end)}',
          ),
          const SizedBox(height: 12),
          _DetailRow(
            icon: Icons.timer_outlined,
            label: 'Duration',
            value: '${b.durationMinutes} min',
          ),
          const SizedBox(height: 12),
          _DetailRow(
            icon: Icons.payments_rounded,
            label: 'Payment',
            value: _paymentName(b.paymentMethod),
          ),
          Divider(height: 24, color: AppColors.divider),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total Paid',
                style: AppTypography.titleMedium(locale).copyWith(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                'EGP ${b.totalPrice}',
                style: AppTypography.titleLarge(locale).copyWith(
                  color: AppColors.accent,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          // Status badge
          const SizedBox(height: 14),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: _statusColor(b.status).withOpacity(.12),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.circle,
                    size: 8, color: _statusColor(b.status)),
                const SizedBox(width: 6),
                Text(
                  _statusLabel(b.status),
                  style: AppTypography.labelSmall(context.locale()).copyWith(
                    color: _statusColor(b.status),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _hm(DateTime dt) =>
      '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';

  String _paymentName(PaymentMethod m) => switch (m) {
        PaymentMethod.fawry => 'Fawry',
        PaymentMethod.instapay => 'InstaPay',
        PaymentMethod.cash => 'Cash on Arrival',
      };

  Color _statusColor(BookingStatus s) => switch (s) {
        BookingStatus.confirmed => const Color(0xFF1A4D3C),
        BookingStatus.pending => const Color(0xFFC9933A),
        BookingStatus.completed => Colors.blue,
        BookingStatus.cancelled => Colors.red,
      };

  String _statusLabel(BookingStatus s) => switch (s) {
        BookingStatus.confirmed => 'Confirmed',
        BookingStatus.pending => 'Pending',
        BookingStatus.completed => 'Completed',
        BookingStatus.cancelled => 'Cancelled',
      };
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _DetailRow(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    return Row(
      children: [
        Icon(icon, size: 16, color: AppColors.primary),
        const SizedBox(width: 10),
        Text(label,
            style: AppTypography.bodySmall(locale)
                .copyWith(color: AppColors.textSecondary)),
        const Spacer(),
        Text(value,
            style: AppTypography.bodyMedium(locale).copyWith(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w600,
            )),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// QR / Fawry reference section
// ─────────────────────────────────────────────────────────────────────────────

class _QrSection extends StatelessWidget {
  final Booking booking;
  final VoidCallback onCopied;
  const _QrSection({required this.booking, required this.onCopied});

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    final b = booking;

    if (b.paymentMethod == PaymentMethod.instapay) {
      return _InstapayInstructionsCard(booking: b);
    }

    if (b.paymentMethod == PaymentMethod.fawry &&
        b.fawryReference != null) {
      return _FawryReferenceCard(
        reference: b.fawryReference!,
        onCopy: onCopied,
      );
    }

    if (b.qrData != null) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.06),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            Text(
              'Your Entry QR Code',
              style: AppTypography.titleMedium(locale).copyWith(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Show this at the venue entrance',
              style: AppTypography.bodySmall(locale)
                  .copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: QrImageView(
                data: b.qrData!,
                version: QrVersions.auto,
                size: 180,
                eyeStyle: const QrEyeStyle(
                  eyeShape: QrEyeShape.square,
                  color: Color(0xFF1A4D3C),
                ),
                dataModuleStyle: const QrDataModuleStyle(
                  dataModuleShape: QrDataModuleShape.square,
                  color: Color(0xFF1A4D3C),
                ),
              ),
            ),
          ],
        ),
      );
    }

    // Cash — no QR needed, just a note
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.accent.withOpacity(.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.accent.withOpacity(.25)),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline_rounded,
              color: AppColors.accent, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Please arrive 10 minutes early and pay cash at the venue reception.',
              style: AppTypography.bodySmall(locale).copyWith(
                color: AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FawryReferenceCard extends StatelessWidget {
  final String reference;
  final VoidCallback onCopy;
  const _FawryReferenceCard({required this.reference, required this.onCopy});

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Fawry Reference Code',
            style: AppTypography.titleMedium(locale).copyWith(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Use this code at any Fawry outlet to complete payment',
            style: AppTypography.bodySmall(locale)
                .copyWith(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: reference));
              onCopy();
            },
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(.06),
                borderRadius: BorderRadius.circular(12),
                border:
                    Border.all(color: AppColors.primary.withOpacity(.2)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      reference,
                      style: AppTypography.titleLarge(locale).copyWith(
                        color: AppColors.primary,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Icon(Icons.copy_rounded,
                      size: 18, color: AppColors.primary),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            '⚠ This code expires 24 hours before your session',
            style: AppTypography.labelSmall(locale)
                .copyWith(color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Action row (share / add to calendar)
// ─────────────────────────────────────────────────────────────────────────────

class _ActionRow extends StatelessWidget {
  final Booking booking;
  const _ActionRow({required this.booking});

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    return Row(
      children: [
        Expanded(
          child: _ActionButton(
            icon: Icons.share_rounded,
            label: 'Share',
            onTap: () => _share(context),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ActionButton(
            icon: Icons.calendar_month_rounded,
            label: 'Add to Calendar',
            onTap: () => _addToCalendar(context),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ActionButton(
            icon: Icons.my_library_books_rounded,
            label: 'My Bookings',
            onTap: () => context.go('/profile'),
          ),
        ),
      ],
    );
  }

  void _share(BuildContext context) {
    final b = booking;
    final text =
        'I just booked a padel court at ${b.venueName}!\n'
        '${b.startTime.day}/${b.startTime.month}/${b.startTime.year} · ${_hm(b.startTime)}\n'
        '${b.durationMinutes} min · EGP ${b.totalPrice}\n'
        'Booking ID: #${b.id.substring(0, 8).toUpperCase()}';
    Share.share(text, subject: 'Lobba booking ${b.id.substring(0, 8).toUpperCase()}');
  }

  Future<void> _addToCalendar(BuildContext context) async {
    final b = booking;
    final end = b.startTime.add(Duration(minutes: b.durationMinutes));
    String fmt(DateTime dt) => '${dt.toUtc().toIso8601String()
            .replaceAll('-', '')
            .replaceAll(':', '')
            .split('.')
            .first}Z';
    final uri = Uri.https('calendar.google.com', '/calendar/render', {
      'action': 'TEMPLATE',
      'text': 'Padel booking at ${b.venueName}',
      'dates': '${fmt(b.startTime)}/${fmt(end)}',
      'details': 'Lobba booking ID: ${b.id.substring(0, 8).toUpperCase()}',
      'location': b.venueName,
    });
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Could not open calendar'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  String _hm(DateTime dt) =>
      '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _ActionButton(
      {required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.divider),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: AppColors.primary, size: 22),
            const SizedBox(height: 6),
            Text(
              label,
              style: AppTypography.labelSmall(locale).copyWith(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// InstaPay instructions card
// ─────────────────────────────────────────────────────────────────────────────

class _InstapayInstructionsCard extends StatefulWidget {
  final Booking booking;
  const _InstapayInstructionsCard({required this.booking});

  @override
  State<_InstapayInstructionsCard> createState() =>
      _InstapayInstructionsCardState();
}

class _InstapayInstructionsCardState
    extends State<_InstapayInstructionsCard> {
  bool _refCopied = false;

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    final b = widget.booking;
    final ref = b.bookingRef ?? 'PD-${b.id.substring(0, 8).toUpperCase()}';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: const Color(0xFF5B4FCF).withOpacity(.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.account_balance_rounded,
                  color: Color(0xFF5B4FCF),
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Complete via InstaPay',
                      style: AppTypography.titleMedium(locale).copyWith(
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      'Transfer EGP ${b.totalPrice} to confirm your slot',
                      style: AppTypography.bodySmall(locale).copyWith(
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Steps
          _InstapayStep(
            number: '1',
            title: 'Open your banking app',
            body: 'Use any Egyptian bank app that supports InstaPay (CIB, NBE, Banque Misr, etc.)',
          ),
          const SizedBox(height: 12),
          _InstapayStep(
            number: '2',
            title: 'Transfer the amount',
            body: 'Send EGP ${b.totalPrice} to the venue\'s InstaPay ID. You\'ll find it in your booking email or the venue\'s profile.',
          ),
          const SizedBox(height: 12),
          _InstapayStep(
            number: '3',
            title: 'Include your booking reference',
            body: 'Add your reference number in the transfer note so the venue can identify your payment.',
          ),

          const SizedBox(height: 16),

          // Booking ref — copyable
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: ref));
              setState(() => _refCopied = true);
              Future.delayed(const Duration(seconds: 3),
                  () => mounted ? setState(() => _refCopied = false) : null);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              decoration: BoxDecoration(
                color: const Color(0xFF5B4FCF).withOpacity(.07),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: const Color(0xFF5B4FCF).withOpacity(.25)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Your booking reference',
                        style: AppTypography.labelSmall(locale).copyWith(
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        ref,
                        style: AppTypography.titleMedium(locale).copyWith(
                          color: const Color(0xFF5B4FCF),
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                  Icon(
                    _refCopied
                        ? Icons.check_circle_rounded
                        : Icons.copy_rounded,
                    size: 18,
                    color: _refCopied
                        ? AppColors.primary
                        : const Color(0xFF5B4FCF),
                  ),
                ],
              ),
            ),
          ),

          if (_refCopied) ...[
            const SizedBox(height: 6),
            Text(
              'Reference copied!',
              style: AppTypography.labelSmall(locale)
                  .copyWith(color: AppColors.primary),
            ),
          ],

          const SizedBox(height: 16),

          // Warning
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.warning.withOpacity(.07),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.warning.withOpacity(.25)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.info_outline_rounded,
                    size: 15, color: AppColors.warning),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Your slot is reserved. The organizer will confirm your booking once payment is received. '
                    'Unconfirmed bookings may be released after 2 hours.',
                    style: AppTypography.bodySmall(locale).copyWith(
                      color: AppColors.textPrimary,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InstapayStep extends StatelessWidget {
  final String number;
  final String title;
  final String body;
  const _InstapayStep(
      {required this.number, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 24,
          height: 24,
          decoration: const BoxDecoration(
            color: Color(0xFF5B4FCF),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              number,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: AppTypography.titleMedium(locale).copyWith(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                body,
                style: AppTypography.bodySmall(locale).copyWith(
                  color: AppColors.textSecondary,
                  height: 1.45,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Decorative arc painter
// ─────────────────────────────────────────────────────────────────────────────

class _ArcPainter extends CustomPainter {
  final Color color;
  const _ArcPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final path = Path()
      ..lineTo(0, size.height - 60)
      ..quadraticBezierTo(
          size.width / 2, size.height + 20, size.width, size.height - 60)
      ..lineTo(size.width, 0)
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_ArcPainter old) => old.color != color;
}

// ─────────────────────────────────────────────────────────────────────────────
// Extension for locale shorthand
// ─────────────────────────────────────────────────────────────────────────────

extension _LocaleExt on BuildContext {
  Locale locale() => Localizations.localeOf(this);
}
