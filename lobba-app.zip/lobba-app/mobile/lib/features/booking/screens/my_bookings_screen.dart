import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';

class MyBookingsScreen extends ConsumerStatefulWidget {
  const MyBookingsScreen({super.key});
  @override
  ConsumerState<MyBookingsScreen> createState() => _MyBookingsScreenState();
}

class _MyBookingsScreenState extends ConsumerState<MyBookingsScreen> {
  int _tab = 0;
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return PushScaffold(
      title: 'My bookings'.tr(context),
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        Row(children: [
          _tabChip(t, 'Upcoming'.tr(context), 0), const SizedBox(width: 8), _tabChip(t, 'Past'.tr(context), 1),
        ]),
        const SizedBox(height: 16),
        if (_tab == 0) ...[
          _booking(t, 'Al-Ahly Padel Club', 'Today · 6:00 PM · Court 1', 'Confirmed'.tr(context), t.sage, showTicket: true),
          const SizedBox(height: 11),
          _pending(t, 'Maadi Padel Lounge', 'Sat Jun 21 · 8:00 PM · Court 2'),
        ] else ...[
          _pastMatch(t, 'Al-Ahly Padel Club', 'Yesterday · 6:00 PM · Court 1', 'add'),
          const SizedBox(height: 11),
          _pastMatch(t, 'Maadi Padel Lounge', 'Sun Jun 15 · 8:00 PM · Court 2', 'confirm'),
          const SizedBox(height: 11),
          _pastMatch(t, 'Zamalek Sports Club', 'Sat Jun 7 · 7:00 PM · Court 1', 'done'),
        ],
      ]),
    );
  }

  Widget _pastMatch(LobbaTokens t, String name, String meta, String mode) => Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink)),
              const SizedBox(height: 3),
              Text(meta, style: TextStyle(fontSize: 11, color: t.ink3)),
            ]),
            LPill('Match ended'.tr(context), bg: t.ink3.withOpacity(.14), fg: t.ink2),
          ]),
          const SizedBox(height: 13),
          if (mode == 'done')
            Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(10)), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${'Score confirmed'.tr(context)} · 6-4 4-6 6-3', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.sage)),
              Icon(Icons.verified_rounded, size: 15, color: t.sage),
            ]))
          else
            SizedBox(width: double.infinity, height: 42, child: ElevatedButton(
              onPressed: () => context.push(mode == 'add' ? AppRoutes.recordScore : AppRoutes.confirmScore),
              style: ElevatedButton.styleFrom(
                backgroundColor: mode == 'add' ? t.accent : t.surface,
                foregroundColor: mode == 'add' ? t.onAccent : t.accent,
                elevation: 0,
                side: mode == 'add' ? null : BorderSide(color: t.accent),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text((mode == 'add' ? 'Add score' : 'Confirm score').tr(context), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            )),
        ]),
      );

  Widget _tabChip(LobbaTokens t, String label, int i) {
    final on = i == _tab;
    return GestureDetector(onTap: () => setState(() => _tab = i), child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(99), border: Border.all(color: on ? t.accent : t.line)),
      child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: on ? t.onAccent : t.ink2)),
    ));
  }

  Widget _booking(LobbaTokens t, String name, String meta, String status, Color statusColor, {bool showTicket = false}) => Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink)),
              const SizedBox(height: 3),
              Text(meta, style: TextStyle(fontSize: 11, color: t.ink3)),
            ]),
            LPill(status, bg: statusColor.withOpacity(.16), fg: statusColor),
          ]),
          if (showTicket) ...[
            const SizedBox(height: 13),
            Row(children: [
              Expanded(child: GestureDetector(onTap: () => context.push(AppRoutes.qrTicket.replaceFirst(':reference', 'LB-2026-4829')), child: _act(t, 'View ticket'.tr(context), accent: true))),
              const SizedBox(width: 9),
              Expanded(child: GestureDetector(onTap: () => Share.share('My Lobba booking — $name, $meta. Ref LB-2026-4829.'), child: _act(t, 'Share'.tr(context), accent: false))),
            ]),
          ],
        ]),
      );

  Widget _pending(LobbaTokens t, String name, String meta) => Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: t.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink)),
              const SizedBox(height: 3),
              Text(meta, style: TextStyle(fontSize: 11, color: t.ink3)),
            ]),
            LPill('Pending pay'.tr(context), bg: t.gold.withOpacity(.18), fg: t.gold),
          ]),
          const SizedBox(height: 12),
          Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(10)), child: Text('Fawry code 8842-1190-3375 · pay within 24h', style: TextStyle(fontSize: 10.5, color: t.accent))),
        ]),
      );

  Widget _act(LobbaTokens t, String label, {required bool accent}) => Container(
        padding: const EdgeInsets.symmetric(vertical: 9), alignment: Alignment.center,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: t.line)),
        child: Text(label, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: accent ? t.accent : t.ink2)),
      );
}
