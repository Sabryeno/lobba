import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../discovery/data/courts_catalog.dart';
import '../../profile/providers/account_provider.dart';
import '../data/booking_options.dart';

class QrTicketScreen extends ConsumerWidget {
  final String reference;
  final String? courtId;
  final int subCourt, day, slot, dur, players;
  const QrTicketScreen({super.key, required this.reference, this.courtId, this.subCourt = 1, this.day = 1, this.slot = 1, this.dur = 1, this.players = 4});

  void _share(String booker, Court court) {
    Share.share('Lobba ticket $reference — ${court.name}, ${'Court'} $subCourt, ${BookingOptions.dateLabel(day)} ${BookingOptions.slotLabel(slot)} · Booked by $booker.');
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    final court = courtById(courtId);
    final booker = ref.watch(accountProvider).name;
    return PushScaffold(
      title: 'My ticket'.tr(context),
      trailing: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => _share(booker, court),
        child: Icon(Icons.ios_share_rounded, size: 20, color: t.ink2),
      ),
      child: ListView(padding: const EdgeInsets.fromLTRB(24, 20, 24, 24), children: [
        Container(
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: t.line)),
          clipBehavior: Clip.antiAlias,
          child: Column(children: [
            Container(width: double.infinity, color: t.accent, padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(court.name, style: TextStyle(fontFamily: kSerif, fontSize: 18, color: t.onAccent)),
              const SizedBox(height: 2),
              Text('${court.area} · ${'Court'.tr(context)} $subCourt — ${(court.indoor ? 'Indoor' : 'Outdoor').tr(context)}', style: TextStyle(fontSize: 11, color: t.onAccent.withOpacity(.8))),
            ])),
            Padding(padding: const EdgeInsets.all(18), child: Column(children: [
              Row(children: [
                _mini(t, 'DATE'.tr(context), BookingOptions.dateLabel(day)), const SizedBox(width: 8),
                _mini(t, 'TIME'.tr(context), BookingOptions.slotLabel(slot)), const SizedBox(width: 8),
                _mini(t, 'DUR'.tr(context), BookingOptions.durShortLabel(dur)),
              ]),
              const SizedBox(height: 18),
              Text('Scan at entrance'.tr(context), style: TextStyle(fontSize: 10, color: t.ink3)),
              const SizedBox(height: 10),
              Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
                child: QrImageView(data: reference, size: 128, version: QrVersions.auto)),
              const SizedBox(height: 10),
              Text(reference, style: TextStyle(fontFamily: kSerif, fontSize: 13, letterSpacing: 2, color: t.ink)),
              const SizedBox(height: 12),
              Divider(color: t.line),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(booker, style: TextStyle(fontSize: 11, color: t.ink3)),
                Text('$players ${'players'.tr(context)}', style: TextStyle(fontSize: 11, color: t.ink3)),
              ]),
            ])),
          ]),
        ),
        const SizedBox(height: 12),
        Center(child: Text('Brightness maximises automatically on this screen'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink3))),
      ]),
    );
  }

  Widget _mini(LobbaTokens t, String k, String v) => Expanded(child: Container(
        padding: const EdgeInsets.symmetric(vertical: 9), alignment: Alignment.center,
        decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(10)),
        child: Column(children: [
          Text(k, style: TextStyle(fontSize: 8.5, letterSpacing: .6, color: t.accent)),
          const SizedBox(height: 2),
          Text(v, style: TextStyle(fontFamily: kSerif, fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
        ]),
      ));
}
