import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../profile/providers/wallet_provider.dart';
import '../../profile/screens/wallet_screens.dart';
import '../../discovery/data/courts_catalog.dart';
import '../data/booking_options.dart';
import '../providers/bookings_provider.dart';

class BookingFlowScreen extends ConsumerStatefulWidget {
  final String courtId;
  final int? dealPercent; // discount %, applied to the selected duration price
  final int? initialDur;
  const BookingFlowScreen({super.key, required this.courtId, this.dealPercent, this.initialDur});
  @override
  ConsumerState<BookingFlowScreen> createState() => _BookingFlowScreenState();
}

class _BookingFlowScreenState extends ConsumerState<BookingFlowScreen> {
  int _step = 0;
  int _day = 1, _dur = 1, _slot = 6, _players = 1, _pay = 0, _matchType = 2; // slot 6 = 6:00 PM
  int? _subCourt; // chosen physical court (1..N) — must be free for the slot
  bool _public = false, _split = false;
  final _invited = <String>{};

  Court get _court => courtById(widget.courtId);
  int get _startMin => BookingOptions.startMinFor(_slot);
  int get _durMin => BookingOptions.durMinutesFor(_dur);

  @override
  void initState() {
    super.initState();
    if (widget.initialDur != null) _dur = widget.initialDur!.clamp(0, 2);
  }

  // Availability changes whenever day/slot/duration change → clear the pick.
  void _resetCourt() => _subCourt = null;

  // 4 players max on 60 min; 90/120 min unlocks up to 6.
  int get _maxPlayers => _dur == 0 ? 4 : 6;
  static const int _serviceFee = 25;
  // Court fee follows the selected duration, discounted by the deal percentage.
  int get _basePrice => _court.priceFor(_dur);
  int get _courtFee => widget.dealPercent != null ? (_basePrice * (100 - widget.dealPercent!) / 100).round() : _basePrice;
  int get _vat => ((_courtFee + _serviceFee) * 0.14).round();
  int get _total => _courtFee + _serviceFee + _vat;
  // Per-player share when splitting; the booker only ever pays their own share.
  int get _perShare => (_total / _players).round();
  int get _payNow => _split && _players > 1 ? _perShare : _total;

  static const _days = [['Thu', '19'], ['Fri', '20'], ['Sat', '21'], ['Sun', '22'], ['Mon', '23']];
  List<String> get _slots => BookingOptions.slots; // 30-min grid
  static const _durLabels = ['60 min', '90 min', '120 min'];
  static const _pays = ['Fawry', 'InstaPay', 'Apple Pay', 'G Pay', 'Cash'];
  static const _contacts = ['Sara Mostafa', 'Omar Khalil', 'Karim Adel', 'Hana Ali', 'Youssef Adel'];

  void _inviteContacts(LobbaTokens t) {
    showModalBottomSheet(context: context, backgroundColor: t.surface, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))), builder: (ctx) {
      return StatefulBuilder(builder: (ctx, setSheet) => SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(20, 12, 20, 20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 38, height: 4, decoration: BoxDecoration(color: t.line, borderRadius: BorderRadius.circular(99)))),
        const SizedBox(height: 14),
        Text('Invite from contacts'.tr(context), style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: t.ink)),
        const SizedBox(height: 12),
        ..._contacts.map((c) {
          final sel = _invited.contains(c);
          return ListTile(
            contentPadding: EdgeInsets.zero,
            leading: CircleAvatar(radius: 18, backgroundColor: t.accentSoft, child: Text(c[0], style: TextStyle(color: t.accent, fontFamily: kSerif))),
            title: Text(c, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
            trailing: Icon(sel ? Icons.check_circle_rounded : Icons.add_circle_outline_rounded, color: sel ? t.accent : t.ink3),
            onTap: () { setState(() { sel ? _invited.remove(c) : _invited.add(c); }); setSheet(() {}); },
          );
        }),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, height: 46, child: ElevatedButton(
          onPressed: () => Navigator.pop(ctx),
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))),
          child: Text('${'Done'.tr(context)} (${_invited.length})', style: const TextStyle(fontWeight: FontWeight.w600)),
        )),
      ]))));
    });
  }

  void _next() {
    if (_step == 0 && _subCourt == null) {
      ScaffoldMessenger.of(context)
        ..clearSnackBars()
        ..showSnackBar(SnackBar(content: Text('Select an available court to continue'.tr(context))));
      return;
    }
    if (_step < 2) {
      setState(() => _step++);
    } else {
      _showSummarySheet();
    }
  }

  /// Pre-confirmation sheet: fee breakdown, tax, service fee + cancellation
  /// policy, gated behind an agreement checkbox.
  void _showSummarySheet() {
    final t = context.t;
    final court = _courtFee;
    const service = _serviceFee;
    final vat = _vat;
    final total = _total;
    final splitting = _split && _players > 1;
    final payNow = _payNow;
    bool agreed = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: t.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) => SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(22, 12, 22, 18),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 38, height: 4, decoration: BoxDecoration(color: t.line, borderRadius: BorderRadius.circular(99)))),
          const SizedBox(height: 16),
          Text('Review your booking'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 19, fontWeight: FontWeight.w500, color: t.ink)),
          const SizedBox(height: 4),
          Text('${_court.name} · ${_slots[_slot]} · ${_durLabels[_dur].tr(context)}', style: TextStyle(fontSize: 11, color: t.ink3)),
          const SizedBox(height: 16),
          // breakdown
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(14)), child: Column(children: [
            _line(t, 'Court fee'.tr(context), 'EGP $court'),
            const SizedBox(height: 8),
            _line(t, 'Service fee'.tr(context), 'EGP $service'),
            const SizedBox(height: 8),
            _line(t, 'VAT (14%)'.tr(context), 'EGP $vat'),
            Divider(color: t.line, height: 22),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Total'.tr(context), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: t.ink)),
              Text('EGP $total', style: TextStyle(fontFamily: kSerif, fontSize: 20, fontWeight: FontWeight.w700, color: t.accent)),
            ]),
            if (splitting) ...[
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('You pay now'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.ink2)),
                Text('EGP $payNow', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.sage)),
              ]),
              const SizedBox(height: 3),
              Text('${'Split across'.tr(context)} $_players · ${'others pay their share after joining'.tr(context)}', style: TextStyle(fontSize: 10, color: t.ink3)),
            ],
          ])),
          const SizedBox(height: 14),
          // cancellation policy
          Text('Cancellation policy'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: t.ink)),
          const SizedBox(height: 5),
          Text('Free cancellation up to 12 hours before your slot. Cancel within 12 hours and the deposit is non-refundable.'.tr(context), style: TextStyle(fontSize: 11, color: t.ink2, height: 1.5)),
          const SizedBox(height: 14),
          // agree
          GestureDetector(
            onTap: () => setSheet(() => agreed = !agreed),
            child: Row(children: [
              Icon(agreed ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded, size: 20, color: agreed ? t.accent : t.ink3),
              const SizedBox(width: 9),
              Expanded(child: Text('I agree to the cancellation policy'.tr(context), style: TextStyle(fontSize: 12, color: t.ink2))),
            ]),
          ),
          const SizedBox(height: 14),
          SizedBox(height: 50, width: double.infinity, child: ElevatedButton(
            onPressed: agreed ? () async {
              final sub = _subCourt ?? 1;
              // Backend-style validation: reject if the court is no longer free.
              final res = await ref.read(bookingsProvider.notifier).book(Booking(
                courtId: widget.courtId, subCourt: sub, day: _day, startMin: _startMin,
                durMin: _durMin, reference: 'LB-2026-4829', isPublic: _public, player: 'You'));
              if (!mounted || !ctx.mounted) return;
              Navigator.pop(ctx);
              if (!res.ok) {
                setState(_resetCourt);
                ScaffoldMessenger.of(context)
                  ..clearSnackBars()
                  ..showSnackBar(SnackBar(content: Text(res.message.tr(context))));
                return;
              }
              final reference = res.reference ?? 'PENDING';
              final q = 'court=${widget.courtId}&sub=$sub&day=$_day&slot=$_slot&durIdx=$_dur&price=$_courtFee&players=$_players';
              context.push('${AppRoutes.bookingConfirmed.replaceFirst(':reference', reference)}?$q');
            } : null,
            style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, disabledBackgroundColor: t.line, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            child: Text('${'Confirm & pay'.tr(context)} · EGP $payNow', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          )),
        ]),
      ))),
    );
  }

  Widget _line(LobbaTokens t, String k, String v) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(k, style: TextStyle(fontSize: 12, color: t.ink2)),
        Text(v, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
      ]);

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    const titles = ['Date & time', 'Players', 'Review & pay'];
    final ctas = ['Continue · Players', 'Continue · Payment', '${'Confirm booking'.tr(context)} · EGP $_payNow'];
    return PopScope(
      // Hardware back steps through the booking, only exits from step 1.
      canPop: _step == 0,
      onPopInvoked: (didPop) {
        if (!didPop && _step > 0) setState(() => _step--);
      },
      child: Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        bottom: false,
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 8, 22, 0),
            child: Row(children: [
              GestureDetector(onTap: () => _step == 0 ? context.pop() : setState(() => _step--), child: _circleBack(t)),
              const SizedBox(width: 12),
              Text(titles[_step].tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 18, fontWeight: FontWeight.w500, color: t.ink)),
            ]),
          ),
          const SizedBox(height: 16),
          // progress
          Padding(padding: const EdgeInsets.symmetric(horizontal: 22), child: Row(children: List.generate(3, (i) => Expanded(child: Container(
            height: 3, margin: EdgeInsets.only(right: i < 2 ? 6 : 0),
            decoration: BoxDecoration(color: i <= _step ? t.accent : t.line, borderRadius: BorderRadius.circular(2)),
          ))))),
          Padding(padding: const EdgeInsets.fromLTRB(22, 6, 22, 0), child: Align(alignment: Alignment.centerLeft, child: Text('Step ${_step + 1} of 3', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: t.ink3)))),
          Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(22, 18, 22, 20), children: [
            if (_step == 0) ..._stepDate(t),
            if (_step == 1) ..._stepPlayers(t),
            if (_step == 2) ..._stepPay(t),
          ])),
          Container(
            decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
            child: SafeArea(top: false, child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 14, 22, 14),
              child: SizedBox(height: 50, child: ElevatedButton(
                onPressed: _next,
                style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                child: Text(ctas[_step].tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
              )),
            )),
          ),
        ]),
      ),
    ),
    );
  }

  Widget _circleBack(LobbaTokens t) => Container(width: 34, height: 34, decoration: BoxDecoration(color: t.surface, shape: BoxShape.circle, border: Border.all(color: t.line)), child: Icon(Icons.chevron_left_rounded, size: 20, color: t.ink2));

  List<Widget> _stepDate(LobbaTokens t) => [
        _eyebrow(t, 'Select day'.tr(context)),
        const SizedBox(height: 10),
        SizedBox(height: 58, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: _days.length, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (c, i) {
          final on = i == _day;
          return GestureDetector(onTap: () => setState(() { _day = i; _resetCourt(); }), child: Container(
            width: 46, alignment: Alignment.center,
            decoration: BoxDecoration(color: on ? t.accent : t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: on ? t.accent : t.line)),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(_days[i][0], style: TextStyle(fontSize: 9.5, color: on ? Colors.white70 : t.ink3)),
              const SizedBox(height: 2),
              Text(_days[i][1], style: TextStyle(fontFamily: kSerif, fontSize: 16, fontWeight: FontWeight.w600, color: on ? Colors.white : t.ink)),
            ]),
          ));
        })),
        const SizedBox(height: 22), _eyebrow(t, 'Duration'.tr(context)), const SizedBox(height: 10),
        Row(children: [for (var i = 0; i < 3; i++) ...[
          if (i > 0) const SizedBox(width: 9),
          Expanded(child: GestureDetector(onTap: () => setState(() { _dur = i; if (_players > _maxPlayers) _players = _maxPlayers; _resetCourt(); }), child: Container(
            padding: const EdgeInsets.symmetric(vertical: 11), alignment: Alignment.center,
            decoration: BoxDecoration(color: _dur == i ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _dur == i ? t.accent : t.line, width: _dur == i ? 1.5 : 1)),
            child: Text(['60 min', '90 min', '120 min'][i].tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: _dur == i ? t.accent : t.ink)),
          ))),
        ]]),
        const SizedBox(height: 22), _eyebrow(t, 'Available slots'.tr(context)), const SizedBox(height: 10),
        // A slot is only taken when EVERY court at the venue is booked for the
        // whole requested duration — real-time from the bookings engine.
        Builder(builder: (context) {
          final store = ref.watch(bookingsProvider.notifier);
          ref.watch(bookingsProvider);
          return GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 3, mainAxisSpacing: 9, crossAxisSpacing: 9, childAspectRatio: 2.6, children: List.generate(_slots.length, (i) {
            final start = BookingOptions.startMinFor(i);
            final taken = !store.anyCourtFree(_court.id, _court.courtCount, _day, start, _durMin);
            final on = i == _slot;
            return GestureDetector(onTap: taken ? null : () => setState(() { _slot = i; _resetCourt(); }), child: Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(color: taken ? t.surface2 : (on ? t.accent : t.accentSoft), borderRadius: BorderRadius.circular(11)),
              child: Text(_slots[i], style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, decoration: taken ? TextDecoration.lineThrough : null, color: taken ? t.ink3 : (on ? t.onAccent : t.accent))),
            ));
          }));
        }),
        const SizedBox(height: 22),
        Row(children: [
          Expanded(child: _eyebrow(t, 'Choose a court'.tr(context))),
          Text('${_court.courtCount} ${'courts'.tr(context)}', style: TextStyle(fontSize: 10.5, color: t.ink3)),
        ]),
        const SizedBox(height: 10),
        Builder(builder: (context) {
          final store = ref.watch(bookingsProvider.notifier);
          ref.watch(bookingsProvider);
          final free = store.availableSubCourts(_court.id, _court.courtCount, _day, _startMin, _durMin);
          if (free.isEmpty) {
            return Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: t.clay.withOpacity(.1), borderRadius: BorderRadius.circular(13), border: Border.all(color: t.clay.withOpacity(.4))),
              child: Row(children: [
                Icon(Icons.event_busy_rounded, size: 18, color: t.clay),
                const SizedBox(width: 10),
                Expanded(child: Text('No courts free for this time — change the slot or duration.'.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: t.clay))),
              ]),
            );
          }
          return Wrap(spacing: 9, runSpacing: 9, children: List.generate(_court.courtCount, (idx) {
            final c = idx + 1;
            final available = free.contains(c);
            final on = _subCourt == c;
            return GestureDetector(
              onTap: available ? () => setState(() => _subCourt = c) : null,
              child: Container(
                width: 92,
                padding: const EdgeInsets.symmetric(vertical: 12),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: !available ? t.surface2 : (on ? t.accent : t.surface),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: on ? t.accent : (available ? t.line : t.surface2), width: on ? 1.5 : 1),
                ),
                child: Column(children: [
                  Icon(available ? Icons.sports_tennis_rounded : Icons.lock_rounded, size: 18, color: !available ? t.ink3 : (on ? t.onAccent : t.accent)),
                  const SizedBox(height: 5),
                  Text('${'Court'.tr(context)} $c', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: !available ? t.ink3 : (on ? t.onAccent : t.ink))),
                  Text(available ? 'Available'.tr(context) : 'Booked'.tr(context), style: TextStyle(fontSize: 9, color: !available ? t.ink3 : (on ? t.onAccent.withOpacity(.85) : t.sage))),
                ]),
              ),
            );
          }));
        }),
      ];

  List<Widget> _stepPlayers(LobbaTokens t) => [
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: _public ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: _public ? t.accent.withOpacity(.3) : t.line)), child: Row(children: [
          Icon(_public ? Icons.public_rounded : Icons.lock_outline_rounded, size: 20, color: _public ? t.accent : t.ink3),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_public ? 'Public match'.tr(context) : 'Private match'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
            const SizedBox(height: 3),
            Text(_public ? 'Players at your level within 10 km get notified and can join.'.tr(context) : 'Only people you invite can join. Turn on to make it public.'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink2, height: 1.4)),
          ])),
          Switch(value: _public, activeColor: t.accent, onChanged: (v) => setState(() => _public = v)),
        ])),
        const SizedBox(height: 20), _eyebrow(t, 'How many players?'.tr(context)), const SizedBox(height: 14),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          _counterBtn(t, Icons.remove, () => setState(() => _players = (_players - 1).clamp(1, _maxPlayers)), filled: false),
          SizedBox(width: 56, child: Text('$_players', textAlign: TextAlign.center, style: TextStyle(fontFamily: kSerif, fontSize: 38, fontWeight: FontWeight.w600, color: t.accent))),
          _counterBtn(t, Icons.add, () => setState(() => _players = (_players + 1).clamp(1, _maxPlayers)), filled: true),
        ]),
        const SizedBox(height: 12),
        Center(child: Text(_dur == 0 ? 'Up to 4 players. Select 90 or 120 min to unlock 6.'.tr(context) : 'Up to 6 players on 90 min or longer.'.tr(context), textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: t.ink3))),
        const SizedBox(height: 18),
        // Invite is only available once you add player slots (more than yourself).
        Opacity(
          opacity: _players > 1 ? 1 : .45,
          child: GestureDetector(
            onTap: _players > 1 ? () => _inviteContacts(t) : null,
            child: Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: t.line)), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.person_add_alt_1_outlined, size: 16, color: t.accent), const SizedBox(width: 8),
              Text(_invited.isEmpty ? 'Invite from contacts'.tr(context) : '${'Invite from contacts'.tr(context)} · ${_invited.length}', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.accent)),
            ])),
          ),
        ),
        if (_players <= 1) Padding(padding: const EdgeInsets.only(top: 8), child: Center(child: Text('Add a player slot to invite others.'.tr(context), style: TextStyle(fontSize: 10, color: t.ink3)))),
        const SizedBox(height: 22), _eyebrow(t, 'Match type'.tr(context)), const SizedBox(height: 10),
        Row(children: [for (var i = 0; i < 3; i++) ...[
          if (i > 0) const SizedBox(width: 8),
          Expanded(child: GestureDetector(
            onTap: () => setState(() => _matchType = i),
            child: Container(padding: const EdgeInsets.symmetric(vertical: 11), alignment: Alignment.center,
              decoration: BoxDecoration(color: _matchType == i ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: _matchType == i ? t.accent : t.line, width: _matchType == i ? 1.5 : 1)),
              child: Text(['Casual', 'Friendly', 'Competitive'][i].tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: _matchType == i ? t.accent : t.ink2))))),
        ]]),
      ];

  List<Widget> _stepPay(LobbaTokens t) => [
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(18)), child: Column(children: [
          _row(t, 'Court'.tr(context), _court.name),
          _row(t, 'Date'.tr(context), '${_days[_day][0]} ${_days[_day][1]}'),
          _row(t, 'Time'.tr(context), '${_slots[_slot]} · ${_durLabels[_dur].tr(context)}'),
          _row(t, 'Players'.tr(context), '$_players'),
          Divider(color: t.line, height: 22),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Total'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
            Text('EGP $_total', style: TextStyle(fontFamily: kSerif, fontSize: 23, fontWeight: FontWeight.w600, color: t.accent)),
          ]),
        ])),
        const SizedBox(height: 16),
        // Split — only meaningful with more than one player.
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)), child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Split with players'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink)),
            const SizedBox(height: 2),
            Text(_players <= 1
                ? 'Add players to split the cost'.tr(context)
                : (_split ? '${'Each of'.tr(context)} $_players · EGP $_perShare' : '${'You pay the full'.tr(context)} EGP $_total'),
              style: TextStyle(fontSize: 11, color: t.ink3)),
          ])),
          Switch(value: _split && _players > 1, activeColor: t.accent, onChanged: _players > 1 ? (v) => setState(() => _split = v) : null),
        ])),
        const SizedBox(height: 14),
        // Player slots laid out as a padel court — 2 vs 2 (+2 subs on 6).
        _eyebrow(t, 'Players'.tr(context)), const SizedBox(height: 10),
        _playerCourt(t),
        const SizedBox(height: 18), _eyebrow(t, 'Pay with'.tr(context)), const SizedBox(height: 11),
        // Wallet — primary, on its own line
        Builder(builder: (context) {
          final w = ref.watch(walletProvider);
          final enough = w.balance >= _payNow;
          final on = _pay == 0;
          return GestureDetector(
            onTap: () => setState(() => _pay = 0),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: on ? t.accent : t.line, width: on ? 1.5 : 1)),
              child: Column(children: [
                Row(children: [
                  Container(width: 40, height: 40, decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(12)), child: Icon(Icons.account_balance_wallet_rounded, color: t.accent, size: 20)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('My wallet'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.ink)),
                    Text('${'Balance'.tr(context)} · EGP ${w.balance}', style: TextStyle(fontSize: 10.5, color: t.ink3)),
                  ])),
                  Icon(on ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded, size: 20, color: on ? t.accent : t.line),
                ]),
                if (on && !enough) ...[
                  const SizedBox(height: 11),
                  Row(children: [
                    Expanded(child: Text('Insufficient balance — top up first'.tr(context), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: t.clay))),
                    GestureDetector(
                      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const TopUpScreen())),
                      child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8), decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(10)), child: Text('Top up'.tr(context), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.onAccent))),
                    ),
                  ]),
                ],
              ]),
            ),
          );
        }),
        const SizedBox(height: 11),
        // Other options — side by side, below wallet
        Row(children: [
          _payMethodTile(t, 1, Icons.apple, 'Apple Pay'),
          const SizedBox(width: 10),
          _payMethodTile(t, 2, Icons.g_mobiledata_rounded, 'Google Pay'),
          const SizedBox(width: 10),
          _payMethodTile(t, 3, Icons.payments_outlined, 'Cash'.tr(context)),
        ]),
        const SizedBox(height: 14),
        Center(child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.schedule_rounded, size: 12, color: t.ink3),
          const SizedBox(width: 6),
          Text('Soon: pay by InstaPay & Fawry'.tr(context), style: TextStyle(fontSize: 10.5, color: t.ink3)),
        ])),
      ];

  Widget _payMethodTile(LobbaTokens t, int i, IconData ic, String label) {
    final on = _pay == i;
    return Expanded(child: GestureDetector(
      onTap: () => setState(() => _pay = i),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
        decoration: BoxDecoration(color: on ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: on ? t.accent : t.line, width: on ? 1.5 : 1)),
        child: Column(children: [
          Icon(ic, size: 26, color: t.ink),
          const SizedBox(height: 7),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: on ? t.accent : t.ink2)),
        ]),
      ),
    ));
  }

  // Padel-court layout of the player slots: Team A (2) vs Team B (2), plus up
  // to 2 subs when the match is 6. Positions 0,2 = Team A · 1,3 = Team B ·
  // 4,5 = subs. Slot 0 is always the booker.
  Widget _playerCourt(LobbaTokens t) {
    final courtCount = _players.clamp(0, 4);
    final subsCount = (_players - 4).clamp(0, 2);
    final teamA = [for (final p in [0, 2]) if (p < courtCount) p];
    final teamB = [for (final p in [1, 3]) if (p < courtCount) p];
    final subs = [for (final p in [4, 5]) if (p - 4 < subsCount) p];

    Widget teamCol(List<int> positions) => Expanded(child: Column(children: [
          for (final p in positions) Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: _courtSlot(t, p)),
        ]));

    return Column(children: [
      Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
        decoration: BoxDecoration(
          color: t.accentSoft.withOpacity(.5),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: t.accent.withOpacity(.25)),
        ),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          teamCol(teamA),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Column(children: [
            const SizedBox(height: 22),
            Container(width: 2, height: 30, color: t.accent.withOpacity(.3)),
            const SizedBox(height: 6),
            Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(99), border: Border.all(color: t.line)), child: Text('VS'.tr(context), style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: t.ink3))),
            const SizedBox(height: 6),
            Container(width: 2, height: 30, color: t.accent.withOpacity(.3)),
          ])),
          teamCol(teamB),
        ]),
      ),
      if (subs.isNotEmpty) ...[
        const SizedBox(height: 12),
        Row(children: [Expanded(child: Divider(color: t.line)), Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: Text('Subs'.tr(context).toUpperCase(), style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, letterSpacing: 1.2, color: t.ink3))), Expanded(child: Divider(color: t.line))]),
        const SizedBox(height: 10),
        Row(children: [
          for (var k = 0; k < subs.length; k++) ...[
            if (k > 0) const SizedBox(width: 10),
            Expanded(child: _courtSlot(t, subs[k])),
          ],
          if (subs.length == 1) const Expanded(child: SizedBox()),
        ]),
      ],
    ]);
  }

  /// A single court position — filled player (with pay/join status) or an
  /// open slot whose "+" opens the add-friend / invite-by-link options.
  Widget _courtSlot(LobbaTokens t, int p) {
    final invited = _invited.toList();
    final isYou = p == 0;
    final filled = isYou || (p - 1 < invited.length);
    final name = isYou ? 'You'.tr(context) : (p - 1 < invited.length ? invited[p - 1] : '');

    if (!filled) {
      return GestureDetector(
        onTap: () => _addPlayerSheet(t),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: t.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: t.accent.withOpacity(.4), width: 1.2, style: BorderStyle.solid),
          ),
          child: Column(children: [
            Container(width: 38, height: 38, decoration: BoxDecoration(color: t.accentSoft, shape: BoxShape.circle), child: Icon(Icons.add_rounded, size: 22, color: t.accent)),
            const SizedBox(height: 6),
            Text('Add player'.tr(context), style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: t.accent)),
          ]),
        ),
      );
    }

    String status;
    Color color;
    if (isYou) {
      status = '${'Paying now'.tr(context)} · EGP $_payNow';
      color = t.sage;
    } else if (_split) {
      status = '${'Pending payment'.tr(context)} · EGP $_perShare';
      color = t.gold;
    } else {
      status = 'Pending join'.tr(context);
      color = t.gold;
    }

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: isYou ? t.accent : t.line, width: isYou ? 1.4 : 1)),
      child: Column(children: [
        CircleAvatar(radius: 19, backgroundColor: t.accentSoft, child: Text(name[0], style: TextStyle(fontFamily: kSerif, color: t.accent, fontWeight: FontWeight.w600, fontSize: 16))),
        const SizedBox(height: 6),
        Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: t.ink)),
        const SizedBox(height: 2),
        Text(status, textAlign: TextAlign.center, maxLines: 2, style: TextStyle(fontSize: 9, fontWeight: FontWeight.w600, color: color)),
      ]),
    );
  }

  /// Open-slot options: add a friend from contacts, or invite by shareable link.
  void _addPlayerSheet(LobbaTokens t) {
    showModalBottomSheet(
      context: context, backgroundColor: t.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(20, 12, 20, 18), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 38, height: 4, decoration: BoxDecoration(color: t.line, borderRadius: BorderRadius.circular(99)))),
        const SizedBox(height: 16),
        Text('Add a player'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 18, fontWeight: FontWeight.w600, color: t.ink)),
        const SizedBox(height: 14),
        _addOption(t, Icons.contacts_outlined, 'Add friend to play'.tr(context), 'Pick from your Lobba contacts'.tr(context), () { Navigator.pop(ctx); _inviteContacts(t); }),
        const SizedBox(height: 10),
        _addOption(t, Icons.link_rounded, 'Invite by link'.tr(context), 'Share a join link on WhatsApp or SMS'.tr(context), () {
          Navigator.pop(ctx);
          Share.share('Join my Lobba padel match — ${_court.name}, ${_days[_day][0]} ${_days[_day][1]}, ${_slots[_slot]}. Tap to join: https://lobba.app/join/LB-2026-4829');
        }),
      ]))),
    );
  }

  Widget _addOption(LobbaTokens t, IconData ic, String title, String sub, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
          child: Row(children: [
            Container(width: 40, height: 40, decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(12)), child: Icon(ic, size: 20, color: t.accent)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: t.ink)),
              const SizedBox(height: 2),
              Text(sub, style: TextStyle(fontSize: 10.5, color: t.ink3)),
            ])),
            Icon(Icons.chevron_right_rounded, size: 18, color: t.ink3),
          ]),
        ),
      );

  Widget _eyebrow(LobbaTokens t, String s) => Text(s.toUpperCase(), style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, letterSpacing: 1.6, color: t.ink3));
  Widget _row(LobbaTokens t, String k, String v) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(k, style: TextStyle(fontSize: 12.5, color: t.ink3)), Text(v, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink))]));
  Widget _counterBtn(LobbaTokens t, IconData ic, VoidCallback onTap, {required bool filled}) => GestureDetector(onTap: onTap, child: Container(width: 46, height: 46, decoration: BoxDecoration(color: filled ? t.accent : t.surface, shape: BoxShape.circle, border: filled ? null : Border.all(color: t.line)), child: Icon(ic, color: filled ? t.onAccent : t.ink2, size: 22)));
}
