import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../discovery/data/courts_catalog.dart';

class CourtDetailScreen extends ConsumerStatefulWidget {
  final String courtId;
  final int? dealPercent;
  const CourtDetailScreen({super.key, required this.courtId, this.dealPercent});
  @override
  ConsumerState<CourtDetailScreen> createState() => _CourtDetailScreenState();
}

class _CourtDetailScreenState extends ConsumerState<CourtDetailScreen> {
  int _dur = 1; // 0=60, 1=90, 2=120
  bool _fav = false;

  // Percentage discount applied to whichever duration price is shown.
  int _discounted(int base) => widget.dealPercent != null ? (base * (100 - widget.dealPercent!) / 100).round() : base;

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final court = courtById(widget.courtId);
    final fromPrice = _discounted(court.prices.first);
    return Scaffold(
      backgroundColor: t.bg,
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          // hero
          Stack(children: [
            Container(height: 230, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [t.accentSoft, t.surface2]))),
            Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.center, colors: [Colors.black.withOpacity(.55), Colors.transparent])))),
            SafeArea(child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                _round(t, Icons.chevron_left_rounded, () => context.pop()),
                _round(t, _fav ? Icons.favorite_rounded : Icons.favorite_border_rounded, () {
                  setState(() => _fav = !_fav);
                  ScaffoldMessenger.of(context)
                    ..clearSnackBars()
                    ..showSnackBar(SnackBar(content: Text((_fav ? 'Added to saved courts' : 'Removed from saved courts').tr(context))));
                }),
              ]),
            )),
            Positioned(left: 18, right: 18, bottom: 15, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(court.name, style: const TextStyle(fontFamily: kSerif, fontSize: 21, fontWeight: FontWeight.w500, color: Colors.white)),
              const SizedBox(height: 5),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('${court.area} · ${court.distance}', style: const TextStyle(fontSize: 12, color: Colors.white)),
                Text('★ ${court.rating.toStringAsFixed(1)} · ${court.ratingCount}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white)),
              ]),
            ])),
          ]),
          // amenities
          Padding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 0), child: Wrap(spacing: 8, runSpacing: 8, children: [
            for (final a in ['A/C', 'Parking', 'Showers', 'Lighting']) _amenity(t, a),
          ])),
          // pricing
          _sec(t, 'Pricing'.tr(context)),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Row(children: [
            _priceTile(t, court.prices[0], '60 min'.tr(context), 0),
            const SizedBox(width: 9),
            _priceTile(t, court.prices[1], '90 min'.tr(context), 1),
            const SizedBox(width: 9),
            _priceTile(t, court.prices[2], '120 min'.tr(context), 2),
          ])),
          if (widget.dealPercent != null) Padding(padding: const EdgeInsets.fromLTRB(20, 12, 20, 0), child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: t.clay.withOpacity(.12), borderRadius: BorderRadius.circular(13), border: Border.all(color: t.clay.withOpacity(.4))),
            child: Row(children: [
              Icon(Icons.local_offer_rounded, size: 16, color: t.clay),
              const SizedBox(width: 10),
              Expanded(child: Text('${'Deal applied'.tr(context)} · ${widget.dealPercent}% ${'off'.tr(context)}', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: t.clay))),
            ]),
          )),
          // location — tap to open the location on a map
          _sec(t, 'Location'.tr(context)),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: GestureDetector(
            onTap: () => launchUrl(Uri.parse('https://www.google.com/maps/search/?api=1&query=${court.lat},${court.lng}'), mode: LaunchMode.externalApplication),
            child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
            child: Row(children: [
              Icon(Icons.location_on_outlined, color: t.accent, size: 20),
              const SizedBox(width: 11),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${court.area}, Cairo', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: t.ink)),
                const SizedBox(height: 2),
                Text('${court.address} · ${court.distance} away', style: TextStyle(fontSize: 10.5, color: t.ink3)),
              ])),
              Icon(Icons.map_outlined, color: t.accent, size: 18),
            ]),
          ))),
          // call us
          Padding(padding: const EdgeInsets.fromLTRB(20, 10, 20, 0), child: GestureDetector(
            onTap: () => launchUrl(Uri.parse('tel:${court.phone}')),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 13),
              alignment: Alignment.center,
              decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.call_outlined, size: 17, color: t.accent),
                const SizedBox(width: 9),
                Text('Call us · court assistance'.tr(context), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.accent)),
              ]),
            ),
          )),
          // cancellation policy
          _sec(t, 'Cancellation policy'.tr(context)),
          Padding(padding: const EdgeInsets.fromLTRB(20, 0, 20, 24), child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(13)),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.verified_user_outlined, color: t.accent, size: 18),
              const SizedBox(width: 11),
              Expanded(child: Text('Free cancellation up to 12 hours before your slot. Cancel within 12 hours and the deposit is non-refundable.'.tr(context),
                  style: TextStyle(fontSize: 11.5, color: t.ink2, height: 1.5))),
            ]),
          )),
        ],
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(color: t.surface, border: Border(top: BorderSide(color: t.line))),
        child: SafeArea(top: false, child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
          child: Row(children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text('FROM'.tr(context), style: TextStyle(fontSize: 10, letterSpacing: 1, color: t.ink3)),
              Text('EGP $fromPrice', style: TextStyle(fontFamily: kSerif, fontSize: 19, fontWeight: FontWeight.w600, color: t.accent)),
            ]),
            const SizedBox(width: 13),
            Expanded(child: SizedBox(height: 50, child: ElevatedButton(
              onPressed: () {
                final q = <String, String>{'dur': '$_dur', if (widget.dealPercent != null) 'deal': '${widget.dealPercent}'};
                final qs = q.entries.map((e) => '${e.key}=${e.value}').join('&');
                context.push('${AppRoutes.booking.replaceFirst(':courtId', widget.courtId)}?$qs');
              },
              style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: Text('Reserve'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ))),
          ]),
        )),
      ),
    );
  }

  Widget _round(LobbaTokens t, IconData ic, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(width: 36, height: 36, decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle), child: Icon(ic, size: 19, color: const Color(0xFF2b2520))),
      );

  Widget _sec(LobbaTokens t, String s) => Padding(padding: const EdgeInsets.fromLTRB(20, 20, 20, 11), child: Text(s, style: TextStyle(fontFamily: kSerif, fontSize: 15, fontWeight: FontWeight.w500, color: t.ink)));

  Widget _amenity(LobbaTokens t, String label) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(99), border: Border.all(color: t.line)),
        child: Text(label.tr(context), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w500, color: t.ink2)),
      );

  Widget _priceTile(LobbaTokens t, int base, String dur, int i) {
    final on = i == _dur;
    final price = _discounted(base);
    final hasDeal = widget.dealPercent != null;
    return Expanded(child: GestureDetector(
      onTap: () => setState(() => _dur = i),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(color: on ? t.accentSoft : t.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: on ? t.accent : t.line, width: on ? 1.5 : 1)),
        child: Column(children: [
          if (hasDeal) Text('$base', style: TextStyle(fontSize: 10, color: t.ink3, decoration: TextDecoration.lineThrough)),
          Text('$price', style: TextStyle(fontFamily: kSerif, fontSize: 16, fontWeight: FontWeight.w600, color: hasDeal ? t.clay : (on ? t.accent : t.ink))),
          const SizedBox(height: 2),
          Text(dur, style: TextStyle(fontSize: 10, color: on ? t.accent : t.ink3)),
        ]),
      ),
    ));
  }
}
