import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/navigation/app_routes.dart';
import '../../../core/i18n/lobba_i18n.dart';
import '../../discovery/data/courts_catalog.dart';
import '../data/booking_options.dart';

class BookingConfirmedScreen extends StatelessWidget {
  final String reference;
  final String? courtId;
  final int subCourt, day, slot, dur, players;
  final int? price;
  const BookingConfirmedScreen({super.key, required this.reference, this.courtId, this.subCourt = 1, this.day = 1, this.slot = 1, this.dur = 1, this.players = 4, this.price});

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final court = courtById(courtId);
    final when = '${BookingOptions.dateLabel(day)} · ${BookingOptions.slotLabel(slot)}';
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        child: Column(children: [
          Expanded(child: Center(child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 88, height: 88, decoration: BoxDecoration(color: t.accentSoft, shape: BoxShape.circle, border: Border.all(color: t.accent, width: 2)), child: Icon(Icons.check_rounded, size: 42, color: t.accent)),
              const SizedBox(height: 20),
              Text('Booking confirmed'.tr(context), style: TextStyle(fontFamily: kSerif, fontSize: 25, fontWeight: FontWeight.w500, color: t.ink)),
              const SizedBox(height: 6),
              Text('${court.name} · $when', textAlign: TextAlign.center, style: TextStyle(fontSize: 13.5, color: t.ink2)),
              const SizedBox(height: 22),
              Container(
                width: double.infinity, padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: t.line)),
                child: Column(children: [
                  _row(t, 'Reference'.tr(context), reference),
                  const SizedBox(height: 9),
                  _row(t, 'Court'.tr(context), '${'Court'.tr(context)} $subCourt · ${BookingOptions.durLabel(dur)}'),
                  if (price != null) ...[
                    const SizedBox(height: 9),
                    _row(t, 'Total'.tr(context), 'EGP $price'),
                  ],
                  const SizedBox(height: 9),
                  _row(t, 'Fawry code'.tr(context), '8842-1190-3375', mono: true),
                ]),
              ),
            ]),
          ))),
          Padding(padding: const EdgeInsets.fromLTRB(24, 0, 24, 28), child: Column(children: [
            SizedBox(height: 52, width: double.infinity, child: ElevatedButton(
              onPressed: () {
                final q = 'court=${court.id}&sub=$subCourt&day=$day&slot=$slot&durIdx=$dur&players=$players';
                context.push('${AppRoutes.qrTicket.replaceFirst(':reference', reference)}?$q');
              },
              style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: Text('View QR ticket'.tr(context), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            )),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: GestureDetector(onTap: _addToCalendar, child: _outline(t, 'Add to calendar'.tr(context)))),
              const SizedBox(width: 10),
              Expanded(child: GestureDetector(onTap: _share, child: _outline(t, 'Share'.tr(context)))),
            ]),
            const SizedBox(height: 10),
            SizedBox(height: 48, width: double.infinity, child: TextButton.icon(
              onPressed: () => context.go(AppRoutes.home),
              icon: Icon(Icons.home_rounded, size: 18, color: t.ink2),
              label: Text('Back to home'.tr(context), style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink2)),
            )),
          ])),
        ]),
      ),
    );
  }

  void _share() {
    final court = courtById(courtId);
    final when = '${BookingOptions.dateLabel(day)} ${BookingOptions.slotLabel(slot)}';
    Share.share('My Lobba booking $reference — ${court.name}, $when, Court A. Fawry code 8842-1190-3375.');
  }

  Future<void> _addToCalendar() async {
    final court = courtById(courtId);
    final uri = Uri.parse(
      'https://calendar.google.com/calendar/render?action=TEMPLATE'
      '&text=${Uri.encodeComponent('Padel at ${court.name}')}'
      '&details=${Uri.encodeComponent('Lobba booking $reference - Court A')}'
      '&location=${Uri.encodeComponent('${court.name}, ${court.area}')}',
    );
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Widget _row(LobbaTokens t, String k, String v, {bool mono = false}) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(k, style: TextStyle(fontSize: 12.5, color: t.ink3)),
        Text(v, style: TextStyle(fontSize: mono ? 14 : 12.5, fontFamily: mono ? kSerif : null, fontWeight: FontWeight.w600, color: mono ? t.accent : t.ink)),
      ]);
  Widget _outline(LobbaTokens t, String label) => Container(padding: const EdgeInsets.symmetric(vertical: 13), alignment: Alignment.center, decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: t.line)), child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: t.ink2)));
}
