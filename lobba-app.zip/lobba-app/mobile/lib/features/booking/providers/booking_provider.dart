import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/network/api_client.dart';
import '../../../shared/models/court_detail.dart';
import '../models/player_search_model.dart';

// ── Payment mode ───────────────────────────────────────────────────────────────

enum PaymentMode { full, split }

// ── Booking draft (plain Dart — no freezed/build_runner needed) ───────────────

class BookingDraft {
  final String courtId;
  final String venueId;
  final CourtPricing pricing;
  final DateTime? selectedDate;
  final int? selectedDuration;
  final TimeSlot? selectedTimeSlot;
  final List<PlayerSearchResult> players; // max 3 additional players
  final PaymentMode paymentMode;
  final PaymentMethod? paymentMethod;

  static const int serviceFeeEgp = 5; // per-player service charge on split

  const BookingDraft({
    required this.courtId,
    required this.venueId,
    required this.pricing,
    this.selectedDate,
    this.selectedDuration,
    this.selectedTimeSlot,
    this.players = const [],
    this.paymentMode = PaymentMode.full,
    this.paymentMethod,
  });

  BookingDraft copyWith({
    DateTime? selectedDate,
    int? selectedDuration,
    TimeSlot? selectedTimeSlot,
    List<PlayerSearchResult>? players,
    PaymentMode? paymentMode,
    PaymentMethod? paymentMethod,
    bool clearTimeSlot = false,
  }) {
    return BookingDraft(
      courtId: courtId,
      venueId: venueId,
      pricing: pricing,
      selectedDate: selectedDate ?? this.selectedDate,
      selectedDuration: selectedDuration ?? this.selectedDuration,
      selectedTimeSlot:
          clearTimeSlot ? null : (selectedTimeSlot ?? this.selectedTimeSlot),
      players: players ?? this.players,
      paymentMode: paymentMode ?? this.paymentMode,
      paymentMethod: paymentMethod ?? this.paymentMethod,
    );
  }

  // ── Price calculations ─────────────────────────────────────────────────────

  /// Total court fee (before any split)
  int get totalPrice =>
      selectedDuration != null ? pricing.priceFor(selectedDuration!) : 0;

  /// Total number of players including the booker
  int get playerCount => players.length + 1;

  /// Each player's share of the court cost (ceiling to avoid fractions)
  int get perPlayerAmount =>
      totalPrice > 0 ? (totalPrice / playerCount).ceil() : 0;

  /// What the current user actually pays
  int get myPayAmount {
    if (paymentMode == PaymentMode.split && players.isNotEmpty) {
      return perPlayerAmount + serviceFeeEgp;
    }
    return totalPrice;
  }

  // ── Wizard validation ──────────────────────────────────────────────────────
  bool get canProceedFromDate => selectedDate != null;
  bool get canProceedFromDuration => selectedDuration != null;
  bool get canProceedFromSlot => selectedTimeSlot != null;
  // Step 2 (Players) is always optional — can proceed even with 0 added players
  bool get canProceedFromPlayers => true;
  bool get canConfirm => paymentMethod != null && selectedTimeSlot != null;
}

// ── Draft notifier (drives the 4-step wizard) ─────────────────────────────────

final bookingDraftProvider =
    NotifierProvider.autoDispose<BookingDraftNotifier, BookingDraft?>(
  BookingDraftNotifier.new,
);

class BookingDraftNotifier extends AutoDisposeNotifier<BookingDraft?> {
  @override
  BookingDraft? build() => null;

  void init(String courtId, String venueId, CourtPricing pricing) {
    state = BookingDraft(
      courtId: courtId,
      venueId: venueId,
      pricing: pricing,
      selectedDate: DateTime.now(),
      selectedDuration: 60,
    );
  }

  void setDate(DateTime date) =>
      state = state?.copyWith(selectedDate: date, clearTimeSlot: true);

  void setDuration(int minutes) =>
      state = state?.copyWith(selectedDuration: minutes, clearTimeSlot: true);

  void setTimeSlot(TimeSlot slot) =>
      state = state?.copyWith(selectedTimeSlot: slot);

  void addPlayer(PlayerSearchResult player) {
    if (state == null) return;
    final current = List<PlayerSearchResult>.from(state!.players);
    if (current.length >= 3 || current.any((p) => p.id == player.id)) return;
    state = state?.copyWith(players: [...current, player]);
  }

  void removePlayer(String playerId) {
    if (state == null) return;
    final updated =
        state!.players.where((p) => p.id != playerId).toList();
    // Reset to full payment if no co-players remain
    final newMode =
        updated.isEmpty ? PaymentMode.full : state!.paymentMode;
    state = state?.copyWith(players: updated, paymentMode: newMode);
  }

  void setPaymentMode(PaymentMode mode) =>
      state = state?.copyWith(paymentMode: mode);

  void setPaymentMethod(PaymentMethod method) =>
      state = state?.copyWith(paymentMethod: method);
}

// ── Available slots provider ──────────────────────────────────────────────────

final availableSlotsProvider =
    FutureProvider.autoDispose.family<List<TimeSlot>, SlotParams>(
  (ref, params) async {
    final api = ref.read(apiClientProvider);
    final response = await api.get(
      '/courts/${params.courtId}/availability',
      queryParameters: {
        'date': params.date.toIso8601String().substring(0, 10),
        'duration': params.duration,
      },
    );
    final list = response.data as List<dynamic>;
    return list.map((raw) {
      final item = raw as Map<String, dynamic>;
      final day = DateTime(
        params.date.year,
        params.date.month,
        params.date.day,
      );
      DateTime at(String value) {
        final parts = value.split(':').map(int.parse).toList();
        return DateTime(day.year, day.month, day.day, parts[0], parts[1]);
      }
      final start = at(item['startTime'] as String);
      final end = at(item['endTime'] as String);
      return TimeSlot(
        id: '${params.courtId}-${start.toIso8601String()}',
        startTime: start,
        endTime: end,
        isAvailable: item['available'] as bool? ?? false,
      );
    }).toList();
  },
);

class SlotParams {
  final String courtId;
  final DateTime date;
  final int duration;

  const SlotParams({
    required this.courtId,
    required this.date,
    required this.duration,
  });

  @override
  bool operator ==(Object other) =>
      other is SlotParams &&
      courtId == other.courtId &&
      date == other.date &&
      duration == other.duration;

  @override
  int get hashCode => Object.hash(courtId, date, duration);
}

// ── Confirm booking ───────────────────────────────────────────────────────────

final confirmBookingProvider =
    AsyncNotifierProvider.autoDispose<ConfirmBookingNotifier, Booking?>(
  ConfirmBookingNotifier.new,
);

class ConfirmBookingNotifier extends AutoDisposeAsyncNotifier<Booking?> {
  @override
  Future<Booking?> build() async => null;

  Future<Booking> confirm(BookingDraft draft) async {
    state = const AsyncLoading();
    final api = ref.read(apiClientProvider);

    final slot = draft.selectedTimeSlot!;
    final date = slot.startTime.toIso8601String().substring(0, 10);
    final startTime =
        '${slot.startTime.hour.toString().padLeft(2, '0')}:${slot.startTime.minute.toString().padLeft(2, '0')}';

    final response = await api.post('/bookings', data: {
      'courtId': draft.courtId,
      'date': date,
      'startTime': startTime,
      'durationMinutes': draft.selectedDuration,
      'paymentMethod': switch (draft.paymentMethod!) {
        PaymentMethod.fawry => 'FAWRY',
        PaymentMethod.instapay => 'INSTAPAY',
        PaymentMethod.cash => 'CASH_ON_ARRIVAL',
      },
      'numberOfPlayers': draft.playerCount,
      'playerNames': draft.players.map((p) => p.name).toList(),
    });

    final json = response.data as Map<String, dynamic>;
    final venue = (json['court'] as Map<String, dynamic>?)?['venue']
        as Map<String, dynamic>?;
    final backendStatus = json['status'] as String? ?? 'PENDING_PAYMENT';
    final booking = Booking(
      id: json['id'] as String,
      courtId: json['courtId'] as String,
      venueName: venue?['name'] as String? ?? '',
      startTime: slot.startTime,
      durationMinutes: json['durationMinutes'] as int,
      totalPrice: (json['total'] as num).round(),
      paymentMethod: draft.paymentMethod!,
      status: switch (backendStatus) {
        'CONFIRMED' => BookingStatus.confirmed,
        'COMPLETED' => BookingStatus.completed,
        'CANCELLED' || 'EXPIRED' => BookingStatus.cancelled,
        _ => BookingStatus.pending,
      },
      bookingRef: json['reference'] as String?,
      fawryReference: json['fawryReference'] as String?,
      qrData: json['reference'] as String?,
    );
    state = AsyncData(booking);
    return booking;
  }
}
