import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';
import '../../../core/services/api_service.dart';
import '../../discovery/data/courts_catalog.dart';

/// A confirmed court booking. This is the in-app mirror of the central booking
/// database — the single real-time source of truth shared by the player and the
/// court-owner screens. Swap the persistence layer for a real backend + the
/// overlap logic below maps 1:1 to the documented API (see docs/backend-spec).
class Booking {
  final String courtId;   // venue id (courts_catalog)
  final int subCourt;     // Court 1..N within the venue
  final int day;          // day index (booking_options)
  final int startMin;     // minutes-from-midnight
  final int durMin;       // 60 / 90 / 120
  final String reference; // LB-...
  final String? id;       // backend UUID
  final bool isPublic;    // posted as an open match
  final String player;

  const Booking({
    required this.courtId,
    required this.subCourt,
    required this.day,
    required this.startMin,
    required this.durMin,
    required this.reference,
    this.id,
    this.isPublic = false,
    this.player = 'You',
  });

  int get endMin => startMin + durMin;

  /// Two bookings clash when they are the same physical court on the same day
  /// and their [start, end) intervals intersect at all.
  bool clashesWith(Booking o) =>
      courtId == o.courtId && subCourt == o.subCourt && day == o.day && startMin < o.endMin && o.startMin < endMin;

  String encode() => [courtId, subCourt, day, startMin, durMin, reference, isPublic ? 1 : 0, player, id ?? ''].join('|');

  static Booking? decode(String s) {
    final p = s.split('|');
    if (p.length < 6) return null;
    return Booking(
      courtId: p[0],
      subCourt: int.tryParse(p[1]) ?? 1,
      day: int.tryParse(p[2]) ?? 0,
      startMin: int.tryParse(p[3]) ?? 0,
      durMin: int.tryParse(p[4]) ?? 60,
      reference: p[5],
      isPublic: p.length > 6 && p[6] == '1',
      player: p.length > 7 ? p[7] : 'You',
      id: p.length > 8 && p[8].isNotEmpty ? p[8] : null,
    );
  }
}

/// Result returned to the player when they try to book.
class BookingResult {
  final bool ok;
  final String message;
  final String? reference;
  const BookingResult(this.ok, this.message, {this.reference});
}

class BookingsNotifier extends Notifier<List<Booking>> {
  @override
  List<Booking> build() {
    _load();
    return const [];
  }

  Future<void> _load() async {
    if (await _syncOwnerBookings()) return;
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getStringList('bookings_store_v2');
      if (raw != null && raw.isNotEmpty) {
        state = raw.map(Booking.decode).whereType<Booking>().toList();
      }
    } catch (_) {}
  }

  Future<bool> _syncOwnerBookings() async {
    try {
      final dio = ref.read(dioProvider);
      final venuesResponse = await dio.get('/venues/owner/my-venues');
      final venues = venuesResponse.data as List<dynamic>;
      final remote = <Booking>[];
      for (final venueRaw in venues) {
        final venue = venueRaw as Map<String, dynamic>;
        final legacy = kCourts.firstWhere(
          (item) => item.name.toLowerCase() == (venue['name'] as String).toLowerCase(),
          orElse: () => kCourts.first,
        );
        final response = await dio.get('/bookings/venue/${venue['id']}', queryParameters: {'limit': 100});
        final items = (response.data as Map<String, dynamic>)['data'] as List<dynamic>;
        for (final raw in items) {
          final item = raw as Map<String, dynamic>;
          final court = item['court'] as Map<String, dynamic>;
          final date = DateTime.parse(item['date'] as String);
          final today = DateTime.now();
          final day = DateTime(date.year, date.month, date.day)
              .difference(DateTime(today.year, today.month, today.day))
              .inDays;
          final parts = (item['startTime'] as String).split(':').map(int.parse).toList();
          remote.add(Booking(
            courtId: legacy.id,
            subCourt: court['courtNumber'] as int? ?? 1,
            day: day,
            startMin: parts[0] * 60 + parts[1],
            durMin: item['durationMinutes'] as int,
            reference: item['reference'] as String,
            id: item['id'] as String,
            player: ((item['player'] as Map<String, dynamic>?)?['profile']
                    as Map<String, dynamic>?)?['fullName'] as String? ?? 'Player',
          ));
        }
      }
      state = remote;
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _persist() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setStringList('bookings_store_v2', state.map((b) => b.encode()).toList());
    } catch (_) {}
  }

  /// A physical court is free only if the WHOLE requested interval is open.
  bool isCourtFree(String courtId, int subCourt, int day, int startMin, int durMin) {
    final probe = Booking(courtId: courtId, subCourt: subCourt, day: day, startMin: startMin, durMin: durMin, reference: '');
    return !state.any((b) => b.clashesWith(probe));
  }

  /// Which sub-courts (1..courtCount) are free for the requested slot+duration.
  List<int> availableSubCourts(String courtId, int courtCount, int day, int startMin, int durMin) => [
        for (var c = 1; c <= courtCount; c++)
          if (isCourtFree(courtId, c, day, startMin, durMin)) c,
      ];

  /// True if at least one sub-court is free for this slot+duration.
  bool anyCourtFree(String courtId, int courtCount, int day, int startMin, int durMin) =>
      availableSubCourts(courtId, courtCount, day, startMin, durMin).isNotEmpty;

  /// Validate then commit. Rejected if the exact court is no longer free.
  Future<BookingResult> book(Booking b) async {
    if (!isCourtFree(b.courtId, b.subCourt, b.day, b.startMin, b.durMin)) {
      return const BookingResult(false, 'That court just got taken — pick another time or court.');
    }
    try {
      final catalogVenue = kCourts.firstWhere((court) => court.id == b.courtId);
      final dio = ref.read(dioProvider);
      final venuesResponse = await dio.get('/venues', queryParameters: {'search': catalogVenue.name, 'limit': 10});
      final venues = (venuesResponse.data as Map<String, dynamic>)['data'] as List<dynamic>;
      if (venues.isEmpty) return const BookingResult(false, 'Venue is not available online yet.');
      final venue = venues.firstWhere(
        (raw) => (raw as Map<String, dynamic>)['name'] == catalogVenue.name,
        orElse: () => venues.first,
      ) as Map<String, dynamic>;
      final physicalCourts = venue['courts'] as List<dynamic>;
      final physical = physicalCourts.firstWhere(
        (raw) => (raw as Map<String, dynamic>)['courtNumber'] == b.subCourt,
        orElse: () => physicalCourts.first,
      ) as Map<String, dynamic>;
      final date = DateTime.now().add(Duration(days: b.day));
      final response = await dio.post('/bookings', data: {
        'courtId': physical['id'],
        'date': '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}',
        'startTime': '${(b.startMin ~/ 60).toString().padLeft(2, '0')}:${(b.startMin % 60).toString().padLeft(2, '0')}',
        'durationMinutes': b.durMin,
        'numberOfPlayers': 1,
        'paymentMethod': 'CASH_ON_ARRIVAL',
      });
      final created = response.data as Map<String, dynamic>;
      final saved = Booking(
        courtId: b.courtId,
        subCourt: b.subCourt,
        day: b.day,
        startMin: b.startMin,
        durMin: b.durMin,
        reference: created['reference'] as String,
        id: created['id'] as String,
        isPublic: b.isPublic,
        player: b.player,
      );
      state = [...state, saved];
      await _persist();
      return BookingResult(true, 'Booking pending owner approval', reference: saved.reference);
    } on DioException catch (error) {
      final body = error.response?.data;
      final message = body is Map
          ? (body['message'] is Map ? body['message']['message'] : body['message'])
          : null;
      return BookingResult(false, message?.toString() ?? 'Could not create booking. Please try again.');
    } catch (_) {
      return const BookingResult(false, 'Could not connect to the booking service.');
    }
  }

  /// Bookings for a given venue (owner view), earliest first.
  List<Booking> forVenue(String courtId) =>
      (state.where((b) => b.courtId == courtId).toList()..sort((a, b) => a.day != b.day ? a.day.compareTo(b.day) : a.startMin.compareTo(b.startMin)));

  /// Bookings on one physical court of a venue.
  List<Booking> forVenueCourt(String courtId, int subCourt) => forVenue(courtId).where((b) => b.subCourt == subCourt).toList();

  /// Remove a booking (e.g. owner unlocks a WhatsApp slot).
  Future<void> remove(String reference) async {
    Booking? booking;
    for (final item in state) {
      if (item.reference == reference) {
        booking = item;
        break;
      }
    }
    if (booking?.id != null) {
      await ref.read(dioProvider).patch(
        '/bookings/venue/${booking!.id}/status',
        data: {'status': 'CANCELLED', 'reason': 'Cancelled by venue staff'},
      );
    }
    state = state.where((b) => b.reference != reference).toList();
    await _persist();
  }

  /// Public bookings become open matches.
  List<Booking> get publicMatches => state.where((b) => b.isPublic).toList();
}

final bookingsProvider = NotifierProvider<BookingsNotifier, List<Booking>>(BookingsNotifier.new);
