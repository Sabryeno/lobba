import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/network/api_client.dart';

// ── Model ─────────────────────────────────────────────────────────────────────

class MyBooking {
  final String id;
  final String bookingRef;
  final String courtId;
  final String courtName;
  final String venueName;
  final String venueCity;
  final String date;
  final String startTime;
  final String endTime;
  final int totalAmountEgp;
  final String status;
  final String paymentStatus;
  final String paymentMode; // 'full' | 'split'

  const MyBooking({
    required this.id,
    required this.bookingRef,
    required this.courtId,
    required this.courtName,
    required this.venueName,
    required this.venueCity,
    required this.date,
    required this.startTime,
    required this.endTime,
    required this.totalAmountEgp,
    required this.status,
    required this.paymentStatus,
    required this.paymentMode,
  });

  factory MyBooking.fromJson(Map<String, dynamic> j) {
    final court = j['court'] as Map<String, dynamic>? ?? {};
    final venue = court['venue'] as Map<String, dynamic>? ?? {};
    return MyBooking(
      id: j['id'] as String,
      bookingRef: j['reference'] as String? ?? '',
      courtId: j['courtId'] as String? ?? court['id'] as String? ?? '',
      courtName: court['name'] as String? ?? 'Court',
      venueName: venue['name'] as String? ?? 'Venue',
      venueCity: venue['city'] as String? ?? '',
      date: j['date'] as String? ?? '',
      startTime: j['startTime'] as String? ?? '',
      endTime: j['endTime'] as String? ?? '',
      totalAmountEgp: (j['total'] as num? ?? 0).toInt(),
      status: (j['status'] as String? ?? 'PENDING_PAYMENT').toLowerCase(),
      paymentStatus: (j['paymentStatus'] as String? ?? 'PENDING').toLowerCase(),
      paymentMode: j['paymentMode'] as String? ?? 'full',
    );
  }

  bool get isConfirmed => status == 'confirmed';
  bool get isCancelled => status == 'cancelled';
  bool get isPending => status == 'pending_payment';
  bool get isSplit => paymentMode == 'split';

  /// Returns true if the booking date+time is in the future.
  bool get isUpcoming {
    try {
      final parts = date.split('-');
      final timeParts = startTime.split(':');
      final dt = DateTime(
        int.parse(parts[0]),
        int.parse(parts[1]),
        int.parse(parts[2]),
        int.parse(timeParts[0]),
        int.parse(timeParts[1]),
      );
      return dt.isAfter(DateTime.now());
    } catch (_) {
      return false;
    }
  }
}

// ── Provider ──────────────────────────────────────────────────────────────────

final myBookingsProvider =
    AsyncNotifierProvider.autoDispose<MyBookingsNotifier, List<MyBooking>>(
  MyBookingsNotifier.new,
);

class MyBookingsNotifier extends AutoDisposeAsyncNotifier<List<MyBooking>> {
  @override
  Future<List<MyBooking>> build() => _fetch();

  Future<List<MyBooking>> _fetch() async {
    final api = ref.read(apiClientProvider);
    final res = await api.get('/bookings/my', queryParameters: {'limit': 50});
    final data = res.data;
    final list = (data is Map ? data['data'] ?? const [] : data)
        as List<dynamic>;
    return list
        .map((e) => MyBooking.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(_fetch);
  }

  Future<void> cancelBooking(String bookingId) async {
    final api = ref.read(apiClientProvider);
    await api.patch('/bookings/$bookingId/cancel', data: {});
    await refresh();
  }
}
