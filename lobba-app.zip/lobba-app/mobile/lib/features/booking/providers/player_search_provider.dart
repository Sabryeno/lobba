import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/network/api_client.dart';
import '../models/player_search_model.dart';

/// Searches registered players by name or phone fragment.
/// Returns an empty list when the query is blank.
final playerSearchProvider =
    FutureProvider.autoDispose.family<List<PlayerSearchResult>, String>(
  (ref, q) async {
    if (q.trim().isEmpty) return [];
    final api = ref.read(apiClientProvider);
    final res = await api.get(
      '/users/search',
      queryParameters: {'q': q.trim()},
    );
    return (res.data as List<dynamic>)
        .map((e) => PlayerSearchResult.fromJson(e as Map<String, dynamic>))
        .toList();
  },
);
