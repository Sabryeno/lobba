import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/network/api_client.dart';
import '../../../shared/models/court_detail.dart';

final courtDetailProvider =
    FutureProvider.autoDispose.family<CourtDetail, String>((ref, courtId) async {
  final api = ref.read(apiClientProvider);
  final response = await api.get('/courts/$courtId');
  return CourtDetail.fromJson(response.data as Map<String, dynamic>);
});

final courtReviewsProvider =
    FutureProvider.autoDispose.family<List<CourtReview>, String>(
  (ref, courtId) async {
    final api = ref.read(apiClientProvider);
    final response = await api.get(
      '/reviews/courts/$courtId',
      queryParameters: {'limit': 10, 'offset': 0},
    );
    final list = response.data['reviews'] as List<dynamic>;
    return list
        .map((e) => CourtReview.fromJson(e as Map<String, dynamic>))
        .toList();
  },
);
