/// Shared date/time/duration options for the booking flow so the confirmation
/// screen and ticket format the *same* selected values (passed as indices).
class BookingOptions {
  // [weekday, day-of-month] — a rolling few days.
  static const days = [
    ['Thu', '19'], ['Fri', '20'], ['Sat', '21'], ['Sun', '22'], ['Mon', '23'],
  ];
  static const months = ['Jun', 'Jun', 'Jun', 'Jun', 'Jun'];
  // 30-minute grid from 3:00 PM to 10:30 PM so a 90-min booking never leaves an
  // unbookable 30-min gap. Start times as minutes-from-midnight (overlap math).
  static final List<int> slotStartMin = [for (int m = 15 * 60; m <= 22 * 60 + 30; m += 30) m];
  static final List<String> slots = slotStartMin.map(clockLabel).toList();

  /// "3:00 PM" from minutes-from-midnight.
  static String clockLabel(int min) {
    final h24 = min ~/ 60;
    final m = min % 60;
    final ampm = h24 >= 12 ? 'PM' : 'AM';
    final h = h24 % 12 == 0 ? 12 : h24 % 12;
    return '$h:${m.toString().padLeft(2, '0')} $ampm';
  }

  static const durLabels = ['60 min', '90 min', '120 min'];
  static const durShort = ['60m', '90m', '120m'];
  static const durMinutes = [60, 90, 120];

  static int startMinFor(int slot) => slotStartMin[_i(slot, slotStartMin.length)];
  static int durMinutesFor(int dur) => durMinutes[_i(dur, durMinutes.length)];

  static int _i(int v, int len) => v.clamp(0, len - 1);

  /// e.g. "Fri, Jun 20"
  static String dateLabel(int day) {
    final d = _i(day, days.length);
    return '${days[d][0]}, ${months[d]} ${days[d][1]}';
  }

  static String slotLabel(int slot) => slots[_i(slot, slots.length)];
  static String durLabel(int dur) => durLabels[_i(dur, durLabels.length)];
  static String durShortLabel(int dur) => durShort[_i(dur, durShort.length)];
}
