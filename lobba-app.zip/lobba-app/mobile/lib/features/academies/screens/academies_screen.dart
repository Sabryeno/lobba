import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/services/api_service.dart';

class AcademyModel {
  final String id;
  final String name;
  final String? logoUrl;
  final String? description;
  final String city;
  final double hourlyRate;
  final double averageRating;
  final int totalReviews;
  final int totalStudents;
  final List<String> programs;

  const AcademyModel({
    required this.id,
    required this.name,
    this.logoUrl,
    this.description,
    required this.city,
    required this.hourlyRate,
    required this.averageRating,
    required this.totalReviews,
    required this.totalStudents,
    required this.programs,
  });

  factory AcademyModel.fromJson(Map<String, dynamic> j) => AcademyModel(
        id: j['id'],
        name: j['name'] ?? 'Academy',
        logoUrl: j['logoUrl'],
        description: j['description'],
        city: j['city'] ?? '',
        hourlyRate: (j['hourlyRate'] as num?)?.toDouble() ?? 0,
        averageRating: (j['averageRating'] as num?)?.toDouble() ?? 0,
        totalReviews: j['totalReviews'] ?? 0,
        totalStudents: j['totalStudents'] ?? 0,
        programs: List<String>.from(j['programs'] ?? []),
      );
}

final academiesProvider = FutureProvider<List<AcademyModel>>((ref) async {
  final dio = ref.read(dioProvider);
  final resp = await dio.get('/academies');
  final body = resp.data;
  final list = body is Map<String, dynamic> && body['data'] is List
      ? body['data'] as List
      : body as List;
  return list
      .map((e) => AcademyModel.fromJson(e))
      .toList();
});

class AcademiesScreen extends ConsumerWidget {
  const AcademiesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final academiesAsync = ref.watch(academiesProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
        title: const Text('Academies', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: academiesAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (academies) => academies.isEmpty
            ? Center(
                child: Text('No academies available',
                    style: TextStyle(color: AppColors.textSecondary)),
              )
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: academies.length,
                itemBuilder: (context, i) => _AcademyCard(academy: academies[i]),
              ),
      ),
    );
  }
}

class _AcademyCard extends StatelessWidget {
  final AcademyModel academy;
  const _AcademyCard({required this.academy});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: AppColors.grey200),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => context.push('/academies/${academy.id}'),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: AppColors.primarySurface,
                  image: academy.logoUrl != null
                      ? DecorationImage(
                          image: NetworkImage(academy.logoUrl!),
                          fit: BoxFit.cover,
                        )
                      : null,
                ),
                child: academy.logoUrl == null
                    ? const Icon(Icons.school, color: AppColors.primary, size: 32)
                    : null,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(academy.name,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 2),
                    Text(academy.city,
                        style: TextStyle(
                            fontSize: 13, color: AppColors.textSecondary)),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        const Icon(Icons.star, size: 13, color: Color(0xFFF5A623)),
                        const SizedBox(width: 2),
                        Text(
                          '${academy.averageRating.toStringAsFixed(1)} · ${academy.totalStudents} students',
                          style: TextStyle(
                              fontSize: 12, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'EGP ${academy.hourlyRate.toStringAsFixed(0)}/hr',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: AppColors.primary,
                          fontSize: 14),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: AppColors.grey400),
            ],
          ),
        ),
      ),
    );
  }
}
