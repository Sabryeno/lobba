import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/services/api_service.dart';
import '../../../core/theme/app_colors.dart';
import 'academies_screen.dart';

final academyDetailProvider =
    FutureProvider.family<AcademyModel, String>((ref, id) async {
  final dio = ref.read(dioProvider);
  final resp = await dio.get('/academies/$id');
  final body = resp.data;
  return AcademyModel.fromJson(
    body is Map<String, dynamic> && body['data'] is Map<String, dynamic>
        ? body['data'] as Map<String, dynamic>
        : body as Map<String, dynamic>,
  );
});

class AcademyDetailScreen extends ConsumerWidget {
  final String id;
  const AcademyDetailScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final academyAsync = ref.watch(academyDetailProvider(id));

    return Scaffold(
      backgroundColor: AppColors.background,
      body: academyAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (academy) => CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              expandedHeight: 220,
              backgroundColor: AppColors.primary,
              foregroundColor: AppColors.white,
              flexibleSpace: FlexibleSpaceBar(
                title: Text(
                  academy.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: AppColors.primaryGradient,
                  ),
                  child: Center(
                    child: Container(
                      width: 92,
                      height: 92,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.16),
                        borderRadius: BorderRadius.circular(22),
                        image: academy.logoUrl != null
                            ? DecorationImage(
                                image: NetworkImage(academy.logoUrl!),
                                fit: BoxFit.cover,
                              )
                            : null,
                      ),
                      child: academy.logoUrl == null
                          ? const Icon(
                              Icons.school,
                              color: Colors.white,
                              size: 46,
                            )
                          : null,
                    ),
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: _InfoCard(
                            icon: Icons.location_on_outlined,
                            label: 'City',
                            value: academy.city.isEmpty ? 'Egypt' : academy.city,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _InfoCard(
                            icon: Icons.star,
                            label: 'Rating',
                            value:
                                '${academy.averageRating.toStringAsFixed(1)} (${academy.totalReviews})',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _InfoCard(
                            icon: Icons.groups_outlined,
                            label: 'Students',
                            value: '${academy.totalStudents}',
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _InfoCard(
                            icon: Icons.payments_outlined,
                            label: 'Rate',
                            value:
                                'EGP ${academy.hourlyRate.toStringAsFixed(0)}/hr',
                          ),
                        ),
                      ],
                    ),
                    if (academy.description != null &&
                        academy.description!.trim().isNotEmpty) ...[
                      const SizedBox(height: 24),
                      const Text(
                        'About',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        academy.description!,
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          height: 1.5,
                        ),
                      ),
                    ],
                    if (academy.programs.isNotEmpty) ...[
                      const SizedBox(height: 24),
                      const Text(
                        'Programs',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: academy.programs
                            .map(
                              (program) => Chip(
                                label: Text(program),
                                backgroundColor: AppColors.primarySurface,
                                labelStyle: const TextStyle(
                                  color: AppColors.primary,
                                ),
                              ),
                            )
                            .toList(),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoCard({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.grey200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: AppColors.primary, size: 20),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
