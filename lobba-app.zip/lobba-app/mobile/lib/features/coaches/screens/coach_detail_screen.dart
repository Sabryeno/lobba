import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';

class CoachDetailScreen extends ConsumerWidget {
  final String id;
  const CoachDetailScreen({super.key, required this.id});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    return PushScaffold(
      title: 'Coach',
      child: Center(child: Text('Request a coach from the Coaches list.', style: TextStyle(color: t.ink3))),
    );
  }
}
