import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';

class CoachesScreen extends ConsumerWidget {
  const CoachesScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    return PushScaffold(
      title: 'Learn to play',
      subtitle: 'Coaches near you',
      child: ListView(padding: const EdgeInsets.fromLTRB(22, 16, 22, 24), children: [
        _coach(context, t, 'Coach Tarek', 'Technique · Strategy · ★ 4.9', '350'),
        const SizedBox(height: 11),
        _coach(context, t, 'Coach Nadia', 'Beginners · Fitness · ★ 4.8', '300'),
        const SizedBox(height: 11),
        _coach(context, t, 'Coach Hossam', 'Junior academy · ★ 4.7', '280'),
      ]),
    );
  }

  Widget _coach(BuildContext c, LobbaTokens t, String name, String meta, String price) => Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: t.line)),
        child: Row(children: [
          Container(width: 48, height: 48, alignment: Alignment.center, decoration: BoxDecoration(color: t.accent, borderRadius: BorderRadius.circular(14)), child: Text(name.split(' ').last[0], style: TextStyle(fontFamily: kSerif, fontSize: 18, color: t.onAccent))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: t.ink)),
            const SizedBox(height: 2),
            Text(meta, style: TextStyle(fontSize: 10.5, color: t.ink3)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('~EGP $price', style: TextStyle(fontFamily: kSerif, fontSize: 14, fontWeight: FontWeight.w600, color: t.accent)),
            Text('avg /hr', style: TextStyle(fontSize: 9, color: t.ink3)),
            const SizedBox(height: 6),
            GestureDetector(
              onTap: () => _request(c, t, name),
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: t.accentSoft, borderRadius: BorderRadius.circular(99)), child: Text('Request', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: t.accent))),
            ),
          ]),
        ]),
      );

  void _request(BuildContext c, LobbaTokens t, String name) {
    showModalBottomSheet(context: c, backgroundColor: t.surface, isScrollControlled: true, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))), builder: (ctx) {
      return Padding(padding: EdgeInsets.only(left: 22, right: 22, top: 18, bottom: MediaQuery.of(ctx).viewInsets.bottom + 24), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 38, height: 4, decoration: BoxDecoration(color: t.line, borderRadius: BorderRadius.circular(99)))),
        const SizedBox(height: 16),
        Text('Request $name', style: TextStyle(fontFamily: kSerif, fontSize: 18, fontWeight: FontWeight.w500, color: t.ink)),
        const SizedBox(height: 6),
        Text('Leave your number and the coach will contact you shortly to agree a time & price.', style: TextStyle(fontSize: 12, color: t.ink2, height: 1.5)),
        const SizedBox(height: 16),
        TextField(keyboardType: TextInputType.phone, style: TextStyle(color: t.ink), decoration: InputDecoration(hintText: '🇪🇬 +20 10 1234 5678', filled: true, fillColor: t.bg, hintStyle: TextStyle(color: t.ink3), border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)))),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, height: 50, child: ElevatedButton(
          onPressed: () { Navigator.pop(ctx); ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('Request sent — $name will contact you shortly'))); },
          style: ElevatedButton.styleFrom(backgroundColor: t.accent, foregroundColor: t.onAccent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: const Text('Send request', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        )),
      ]));
    });
  }
}
