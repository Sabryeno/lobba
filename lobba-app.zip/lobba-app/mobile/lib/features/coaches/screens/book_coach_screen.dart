import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/lobba_tokens.dart';
import '../../../core/widgets/lobba_widgets.dart';

class BookCoachScreen extends ConsumerWidget {
  final String coachId;
  const BookCoachScreen({super.key, required this.coachId});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.t;
    return PushScaffold(
      title: 'Request coach',
      child: Center(child: Text('Leave your number from the Coaches list.', style: TextStyle(color: t.ink3))),
    );
  }
}
