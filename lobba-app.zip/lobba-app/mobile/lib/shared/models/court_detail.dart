import 'package:freezed_annotation/freezed_annotation.dart';

part 'court_detail.freezed.dart';
part 'court_detail.g.dart';

@freezed
class CourtDetail with _$CourtDetail {
  const factory CourtDetail({
    required String id,
    required String venueId,
    required String venueName,
    required String address,
    required double lat,
    required double lng,
    required bool isIndoor,
    @Default(false) bool isPanoramic,
    required double rating,
    required int reviewCount,
    required int courtCount,
    required CourtPricing pricing,
    required VenueContact contact,
    @Default([]) List<String> photoUrls,
    String? videoUrl,
    String? description,
    required VenueSchedule schedule,
  }) = _CourtDetail;

  factory CourtDetail.fromJson(Map<String, dynamic> json) =>
      _$CourtDetailFromJson(json);
}

@freezed
class CourtPricing with _$CourtPricing {
  const factory CourtPricing({
    required int min60,
    required int min90,
    required int min120,
    required int min150,
  }) = _CourtPricing;

  factory CourtPricing.fromJson(Map<String, dynamic> json) =>
      _$CourtPricingFromJson(json);
}

extension CourtPricingX on CourtPricing {
  int priceFor(int minutes) => switch (minutes) {
        60 => min60,
        90 => min90,
        120 => min120,
        150 => min150,
        _ => min60,
      };

  Map<int, int> get allDurations => {
        60: min60,
        90: min90,
        120: min120,
        150: min150,
      };
}

@freezed
class VenueContact with _$VenueContact {
  const factory VenueContact({
    required String phone,
    String? whatsapp,
  }) = _VenueContact;

  factory VenueContact.fromJson(Map<String, dynamic> json) =>
      _$VenueContactFromJson(json);
}

@freezed
class VenueSchedule with _$VenueSchedule {
  const factory VenueSchedule({
    required String openTime,   // "08:00"
    required String closeTime,  // "24:00"
    @Default([]) List<int> closedDays, // 0=Sun, 5=Fri, 6=Sat
  }) = _VenueSchedule;

  factory VenueSchedule.fromJson(Map<String, dynamic> json) =>
      _$VenueScheduleFromJson(json);
}

@freezed
class CourtReview with _$CourtReview {
  const factory CourtReview({
    required String id,
    required String playerName,
    String? playerPhotoUrl,
    required double rating,
    String? comment,
    required DateTime createdAt,
  }) = _CourtReview;

  factory CourtReview.fromJson(Map<String, dynamic> json) =>
      _$CourtReviewFromJson(json);
}

// ── Booking models ────────────────────────────────────────────────────────────

enum PaymentMethod { fawry, instapay, cash }

enum BookingStatus { pending, confirmed, completed, cancelled }

@freezed
class TimeSlot with _$TimeSlot {
  const factory TimeSlot({
    required String id,
    required DateTime startTime,
    required DateTime endTime,
    required bool isAvailable,
  }) = _TimeSlot;

  factory TimeSlot.fromJson(Map<String, dynamic> json) =>
      _$TimeSlotFromJson(json);
}

extension TimeSlotX on TimeSlot {
  String get label {
    final h = startTime.hour.toString().padLeft(2, '0');
    final m = startTime.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }
}

@freezed
class Booking with _$Booking {
  const factory Booking({
    required String id,
    required String courtId,
    required String venueName,
    required DateTime startTime,
    required int durationMinutes,
    required int totalPrice,
    required PaymentMethod paymentMethod,
    required BookingStatus status,
    String? bookingRef,       // e.g. "PD-20240101-A1B2"
    String? fawryReference,
    String? qrData,
  }) = _Booking;

  factory Booking.fromJson(Map<String, dynamic> json) =>
      _$BookingFromJson(json);
}
