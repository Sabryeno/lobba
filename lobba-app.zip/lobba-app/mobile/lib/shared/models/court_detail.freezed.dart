// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'court_detail.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

CourtDetail _$CourtDetailFromJson(Map<String, dynamic> json) {
  return _CourtDetail.fromJson(json);
}

/// @nodoc
mixin _$CourtDetail {
  String get id => throw _privateConstructorUsedError;
  String get venueId => throw _privateConstructorUsedError;
  String get venueName => throw _privateConstructorUsedError;
  String get address => throw _privateConstructorUsedError;
  double get lat => throw _privateConstructorUsedError;
  double get lng => throw _privateConstructorUsedError;
  bool get isIndoor => throw _privateConstructorUsedError;
  bool get isPanoramic => throw _privateConstructorUsedError;
  double get rating => throw _privateConstructorUsedError;
  int get reviewCount => throw _privateConstructorUsedError;
  int get courtCount => throw _privateConstructorUsedError;
  CourtPricing get pricing => throw _privateConstructorUsedError;
  VenueContact get contact => throw _privateConstructorUsedError;
  List<String> get photoUrls => throw _privateConstructorUsedError;
  String? get videoUrl => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  VenueSchedule get schedule => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CourtDetailCopyWith<CourtDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CourtDetailCopyWith<$Res> {
  factory $CourtDetailCopyWith(
          CourtDetail value, $Res Function(CourtDetail) then) =
      _$CourtDetailCopyWithImpl<$Res, CourtDetail>;
  @useResult
  $Res call(
      {String id,
      String venueId,
      String venueName,
      String address,
      double lat,
      double lng,
      bool isIndoor,
      bool isPanoramic,
      double rating,
      int reviewCount,
      int courtCount,
      CourtPricing pricing,
      VenueContact contact,
      List<String> photoUrls,
      String? videoUrl,
      String? description,
      VenueSchedule schedule});

  $CourtPricingCopyWith<$Res> get pricing;
  $VenueContactCopyWith<$Res> get contact;
  $VenueScheduleCopyWith<$Res> get schedule;
}

/// @nodoc
class _$CourtDetailCopyWithImpl<$Res, $Val extends CourtDetail>
    implements $CourtDetailCopyWith<$Res> {
  _$CourtDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? venueId = null,
    Object? venueName = null,
    Object? address = null,
    Object? lat = null,
    Object? lng = null,
    Object? isIndoor = null,
    Object? isPanoramic = null,
    Object? rating = null,
    Object? reviewCount = null,
    Object? courtCount = null,
    Object? pricing = null,
    Object? contact = null,
    Object? photoUrls = null,
    Object? videoUrl = freezed,
    Object? description = freezed,
    Object? schedule = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      venueId: null == venueId
          ? _value.venueId
          : venueId // ignore: cast_nullable_to_non_nullable
              as String,
      venueName: null == venueName
          ? _value.venueName
          : venueName // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      lat: null == lat
          ? _value.lat
          : lat // ignore: cast_nullable_to_non_nullable
              as double,
      lng: null == lng
          ? _value.lng
          : lng // ignore: cast_nullable_to_non_nullable
              as double,
      isIndoor: null == isIndoor
          ? _value.isIndoor
          : isIndoor // ignore: cast_nullable_to_non_nullable
              as bool,
      isPanoramic: null == isPanoramic
          ? _value.isPanoramic
          : isPanoramic // ignore: cast_nullable_to_non_nullable
              as bool,
      rating: null == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as double,
      reviewCount: null == reviewCount
          ? _value.reviewCount
          : reviewCount // ignore: cast_nullable_to_non_nullable
              as int,
      courtCount: null == courtCount
          ? _value.courtCount
          : courtCount // ignore: cast_nullable_to_non_nullable
              as int,
      pricing: null == pricing
          ? _value.pricing
          : pricing // ignore: cast_nullable_to_non_nullable
              as CourtPricing,
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as VenueContact,
      photoUrls: null == photoUrls
          ? _value.photoUrls
          : photoUrls // ignore: cast_nullable_to_non_nullable
              as List<String>,
      videoUrl: freezed == videoUrl
          ? _value.videoUrl
          : videoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      schedule: null == schedule
          ? _value.schedule
          : schedule // ignore: cast_nullable_to_non_nullable
              as VenueSchedule,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $CourtPricingCopyWith<$Res> get pricing {
    return $CourtPricingCopyWith<$Res>(_value.pricing, (value) {
      return _then(_value.copyWith(pricing: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $VenueContactCopyWith<$Res> get contact {
    return $VenueContactCopyWith<$Res>(_value.contact, (value) {
      return _then(_value.copyWith(contact: value) as $Val);
    });
  }

  @override
  @pragma('vm:prefer-inline')
  $VenueScheduleCopyWith<$Res> get schedule {
    return $VenueScheduleCopyWith<$Res>(_value.schedule, (value) {
      return _then(_value.copyWith(schedule: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$CourtDetailImplCopyWith<$Res>
    implements $CourtDetailCopyWith<$Res> {
  factory _$$CourtDetailImplCopyWith(
          _$CourtDetailImpl value, $Res Function(_$CourtDetailImpl) then) =
      __$$CourtDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String venueId,
      String venueName,
      String address,
      double lat,
      double lng,
      bool isIndoor,
      bool isPanoramic,
      double rating,
      int reviewCount,
      int courtCount,
      CourtPricing pricing,
      VenueContact contact,
      List<String> photoUrls,
      String? videoUrl,
      String? description,
      VenueSchedule schedule});

  @override
  $CourtPricingCopyWith<$Res> get pricing;
  @override
  $VenueContactCopyWith<$Res> get contact;
  @override
  $VenueScheduleCopyWith<$Res> get schedule;
}

/// @nodoc
class __$$CourtDetailImplCopyWithImpl<$Res>
    extends _$CourtDetailCopyWithImpl<$Res, _$CourtDetailImpl>
    implements _$$CourtDetailImplCopyWith<$Res> {
  __$$CourtDetailImplCopyWithImpl(
      _$CourtDetailImpl _value, $Res Function(_$CourtDetailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? venueId = null,
    Object? venueName = null,
    Object? address = null,
    Object? lat = null,
    Object? lng = null,
    Object? isIndoor = null,
    Object? isPanoramic = null,
    Object? rating = null,
    Object? reviewCount = null,
    Object? courtCount = null,
    Object? pricing = null,
    Object? contact = null,
    Object? photoUrls = null,
    Object? videoUrl = freezed,
    Object? description = freezed,
    Object? schedule = null,
  }) {
    return _then(_$CourtDetailImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      venueId: null == venueId
          ? _value.venueId
          : venueId // ignore: cast_nullable_to_non_nullable
              as String,
      venueName: null == venueName
          ? _value.venueName
          : venueName // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      lat: null == lat
          ? _value.lat
          : lat // ignore: cast_nullable_to_non_nullable
              as double,
      lng: null == lng
          ? _value.lng
          : lng // ignore: cast_nullable_to_non_nullable
              as double,
      isIndoor: null == isIndoor
          ? _value.isIndoor
          : isIndoor // ignore: cast_nullable_to_non_nullable
              as bool,
      isPanoramic: null == isPanoramic
          ? _value.isPanoramic
          : isPanoramic // ignore: cast_nullable_to_non_nullable
              as bool,
      rating: null == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as double,
      reviewCount: null == reviewCount
          ? _value.reviewCount
          : reviewCount // ignore: cast_nullable_to_non_nullable
              as int,
      courtCount: null == courtCount
          ? _value.courtCount
          : courtCount // ignore: cast_nullable_to_non_nullable
              as int,
      pricing: null == pricing
          ? _value.pricing
          : pricing // ignore: cast_nullable_to_non_nullable
              as CourtPricing,
      contact: null == contact
          ? _value.contact
          : contact // ignore: cast_nullable_to_non_nullable
              as VenueContact,
      photoUrls: null == photoUrls
          ? _value._photoUrls
          : photoUrls // ignore: cast_nullable_to_non_nullable
              as List<String>,
      videoUrl: freezed == videoUrl
          ? _value.videoUrl
          : videoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      schedule: null == schedule
          ? _value.schedule
          : schedule // ignore: cast_nullable_to_non_nullable
              as VenueSchedule,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CourtDetailImpl implements _CourtDetail {
  const _$CourtDetailImpl(
      {required this.id,
      required this.venueId,
      required this.venueName,
      required this.address,
      required this.lat,
      required this.lng,
      required this.isIndoor,
      this.isPanoramic = false,
      required this.rating,
      required this.reviewCount,
      required this.courtCount,
      required this.pricing,
      required this.contact,
      final List<String> photoUrls = const [],
      this.videoUrl,
      this.description,
      required this.schedule})
      : _photoUrls = photoUrls;

  factory _$CourtDetailImpl.fromJson(Map<String, dynamic> json) =>
      _$$CourtDetailImplFromJson(json);

  @override
  final String id;
  @override
  final String venueId;
  @override
  final String venueName;
  @override
  final String address;
  @override
  final double lat;
  @override
  final double lng;
  @override
  final bool isIndoor;
  @override
  @JsonKey()
  final bool isPanoramic;
  @override
  final double rating;
  @override
  final int reviewCount;
  @override
  final int courtCount;
  @override
  final CourtPricing pricing;
  @override
  final VenueContact contact;
  final List<String> _photoUrls;
  @override
  @JsonKey()
  List<String> get photoUrls {
    if (_photoUrls is EqualUnmodifiableListView) return _photoUrls;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_photoUrls);
  }

  @override
  final String? videoUrl;
  @override
  final String? description;
  @override
  final VenueSchedule schedule;

  @override
  String toString() {
    return 'CourtDetail(id: $id, venueId: $venueId, venueName: $venueName, address: $address, lat: $lat, lng: $lng, isIndoor: $isIndoor, isPanoramic: $isPanoramic, rating: $rating, reviewCount: $reviewCount, courtCount: $courtCount, pricing: $pricing, contact: $contact, photoUrls: $photoUrls, videoUrl: $videoUrl, description: $description, schedule: $schedule)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CourtDetailImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.venueId, venueId) || other.venueId == venueId) &&
            (identical(other.venueName, venueName) ||
                other.venueName == venueName) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.lat, lat) || other.lat == lat) &&
            (identical(other.lng, lng) || other.lng == lng) &&
            (identical(other.isIndoor, isIndoor) ||
                other.isIndoor == isIndoor) &&
            (identical(other.isPanoramic, isPanoramic) ||
                other.isPanoramic == isPanoramic) &&
            (identical(other.rating, rating) || other.rating == rating) &&
            (identical(other.reviewCount, reviewCount) ||
                other.reviewCount == reviewCount) &&
            (identical(other.courtCount, courtCount) ||
                other.courtCount == courtCount) &&
            (identical(other.pricing, pricing) || other.pricing == pricing) &&
            (identical(other.contact, contact) || other.contact == contact) &&
            const DeepCollectionEquality()
                .equals(other._photoUrls, _photoUrls) &&
            (identical(other.videoUrl, videoUrl) ||
                other.videoUrl == videoUrl) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.schedule, schedule) ||
                other.schedule == schedule));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      venueId,
      venueName,
      address,
      lat,
      lng,
      isIndoor,
      isPanoramic,
      rating,
      reviewCount,
      courtCount,
      pricing,
      contact,
      const DeepCollectionEquality().hash(_photoUrls),
      videoUrl,
      description,
      schedule);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CourtDetailImplCopyWith<_$CourtDetailImpl> get copyWith =>
      __$$CourtDetailImplCopyWithImpl<_$CourtDetailImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CourtDetailImplToJson(
      this,
    );
  }
}

abstract class _CourtDetail implements CourtDetail {
  const factory _CourtDetail(
      {required final String id,
      required final String venueId,
      required final String venueName,
      required final String address,
      required final double lat,
      required final double lng,
      required final bool isIndoor,
      final bool isPanoramic,
      required final double rating,
      required final int reviewCount,
      required final int courtCount,
      required final CourtPricing pricing,
      required final VenueContact contact,
      final List<String> photoUrls,
      final String? videoUrl,
      final String? description,
      required final VenueSchedule schedule}) = _$CourtDetailImpl;

  factory _CourtDetail.fromJson(Map<String, dynamic> json) =
      _$CourtDetailImpl.fromJson;

  @override
  String get id;
  @override
  String get venueId;
  @override
  String get venueName;
  @override
  String get address;
  @override
  double get lat;
  @override
  double get lng;
  @override
  bool get isIndoor;
  @override
  bool get isPanoramic;
  @override
  double get rating;
  @override
  int get reviewCount;
  @override
  int get courtCount;
  @override
  CourtPricing get pricing;
  @override
  VenueContact get contact;
  @override
  List<String> get photoUrls;
  @override
  String? get videoUrl;
  @override
  String? get description;
  @override
  VenueSchedule get schedule;
  @override
  @JsonKey(ignore: true)
  _$$CourtDetailImplCopyWith<_$CourtDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

CourtPricing _$CourtPricingFromJson(Map<String, dynamic> json) {
  return _CourtPricing.fromJson(json);
}

/// @nodoc
mixin _$CourtPricing {
  int get min60 => throw _privateConstructorUsedError;
  int get min90 => throw _privateConstructorUsedError;
  int get min120 => throw _privateConstructorUsedError;
  int get min150 => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CourtPricingCopyWith<CourtPricing> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CourtPricingCopyWith<$Res> {
  factory $CourtPricingCopyWith(
          CourtPricing value, $Res Function(CourtPricing) then) =
      _$CourtPricingCopyWithImpl<$Res, CourtPricing>;
  @useResult
  $Res call({int min60, int min90, int min120, int min150});
}

/// @nodoc
class _$CourtPricingCopyWithImpl<$Res, $Val extends CourtPricing>
    implements $CourtPricingCopyWith<$Res> {
  _$CourtPricingCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? min60 = null,
    Object? min90 = null,
    Object? min120 = null,
    Object? min150 = null,
  }) {
    return _then(_value.copyWith(
      min60: null == min60
          ? _value.min60
          : min60 // ignore: cast_nullable_to_non_nullable
              as int,
      min90: null == min90
          ? _value.min90
          : min90 // ignore: cast_nullable_to_non_nullable
              as int,
      min120: null == min120
          ? _value.min120
          : min120 // ignore: cast_nullable_to_non_nullable
              as int,
      min150: null == min150
          ? _value.min150
          : min150 // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CourtPricingImplCopyWith<$Res>
    implements $CourtPricingCopyWith<$Res> {
  factory _$$CourtPricingImplCopyWith(
          _$CourtPricingImpl value, $Res Function(_$CourtPricingImpl) then) =
      __$$CourtPricingImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int min60, int min90, int min120, int min150});
}

/// @nodoc
class __$$CourtPricingImplCopyWithImpl<$Res>
    extends _$CourtPricingCopyWithImpl<$Res, _$CourtPricingImpl>
    implements _$$CourtPricingImplCopyWith<$Res> {
  __$$CourtPricingImplCopyWithImpl(
      _$CourtPricingImpl _value, $Res Function(_$CourtPricingImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? min60 = null,
    Object? min90 = null,
    Object? min120 = null,
    Object? min150 = null,
  }) {
    return _then(_$CourtPricingImpl(
      min60: null == min60
          ? _value.min60
          : min60 // ignore: cast_nullable_to_non_nullable
              as int,
      min90: null == min90
          ? _value.min90
          : min90 // ignore: cast_nullable_to_non_nullable
              as int,
      min120: null == min120
          ? _value.min120
          : min120 // ignore: cast_nullable_to_non_nullable
              as int,
      min150: null == min150
          ? _value.min150
          : min150 // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CourtPricingImpl implements _CourtPricing {
  const _$CourtPricingImpl(
      {required this.min60,
      required this.min90,
      required this.min120,
      required this.min150});

  factory _$CourtPricingImpl.fromJson(Map<String, dynamic> json) =>
      _$$CourtPricingImplFromJson(json);

  @override
  final int min60;
  @override
  final int min90;
  @override
  final int min120;
  @override
  final int min150;

  @override
  String toString() {
    return 'CourtPricing(min60: $min60, min90: $min90, min120: $min120, min150: $min150)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CourtPricingImpl &&
            (identical(other.min60, min60) || other.min60 == min60) &&
            (identical(other.min90, min90) || other.min90 == min90) &&
            (identical(other.min120, min120) || other.min120 == min120) &&
            (identical(other.min150, min150) || other.min150 == min150));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, min60, min90, min120, min150);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CourtPricingImplCopyWith<_$CourtPricingImpl> get copyWith =>
      __$$CourtPricingImplCopyWithImpl<_$CourtPricingImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CourtPricingImplToJson(
      this,
    );
  }
}

abstract class _CourtPricing implements CourtPricing {
  const factory _CourtPricing(
      {required final int min60,
      required final int min90,
      required final int min120,
      required final int min150}) = _$CourtPricingImpl;

  factory _CourtPricing.fromJson(Map<String, dynamic> json) =
      _$CourtPricingImpl.fromJson;

  @override
  int get min60;
  @override
  int get min90;
  @override
  int get min120;
  @override
  int get min150;
  @override
  @JsonKey(ignore: true)
  _$$CourtPricingImplCopyWith<_$CourtPricingImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

VenueContact _$VenueContactFromJson(Map<String, dynamic> json) {
  return _VenueContact.fromJson(json);
}

/// @nodoc
mixin _$VenueContact {
  String get phone => throw _privateConstructorUsedError;
  String? get whatsapp => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $VenueContactCopyWith<VenueContact> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $VenueContactCopyWith<$Res> {
  factory $VenueContactCopyWith(
          VenueContact value, $Res Function(VenueContact) then) =
      _$VenueContactCopyWithImpl<$Res, VenueContact>;
  @useResult
  $Res call({String phone, String? whatsapp});
}

/// @nodoc
class _$VenueContactCopyWithImpl<$Res, $Val extends VenueContact>
    implements $VenueContactCopyWith<$Res> {
  _$VenueContactCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phone = null,
    Object? whatsapp = freezed,
  }) {
    return _then(_value.copyWith(
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      whatsapp: freezed == whatsapp
          ? _value.whatsapp
          : whatsapp // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$VenueContactImplCopyWith<$Res>
    implements $VenueContactCopyWith<$Res> {
  factory _$$VenueContactImplCopyWith(
          _$VenueContactImpl value, $Res Function(_$VenueContactImpl) then) =
      __$$VenueContactImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String phone, String? whatsapp});
}

/// @nodoc
class __$$VenueContactImplCopyWithImpl<$Res>
    extends _$VenueContactCopyWithImpl<$Res, _$VenueContactImpl>
    implements _$$VenueContactImplCopyWith<$Res> {
  __$$VenueContactImplCopyWithImpl(
      _$VenueContactImpl _value, $Res Function(_$VenueContactImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phone = null,
    Object? whatsapp = freezed,
  }) {
    return _then(_$VenueContactImpl(
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      whatsapp: freezed == whatsapp
          ? _value.whatsapp
          : whatsapp // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$VenueContactImpl implements _VenueContact {
  const _$VenueContactImpl({required this.phone, this.whatsapp});

  factory _$VenueContactImpl.fromJson(Map<String, dynamic> json) =>
      _$$VenueContactImplFromJson(json);

  @override
  final String phone;
  @override
  final String? whatsapp;

  @override
  String toString() {
    return 'VenueContact(phone: $phone, whatsapp: $whatsapp)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$VenueContactImpl &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.whatsapp, whatsapp) ||
                other.whatsapp == whatsapp));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, phone, whatsapp);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$VenueContactImplCopyWith<_$VenueContactImpl> get copyWith =>
      __$$VenueContactImplCopyWithImpl<_$VenueContactImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$VenueContactImplToJson(
      this,
    );
  }
}

abstract class _VenueContact implements VenueContact {
  const factory _VenueContact(
      {required final String phone,
      final String? whatsapp}) = _$VenueContactImpl;

  factory _VenueContact.fromJson(Map<String, dynamic> json) =
      _$VenueContactImpl.fromJson;

  @override
  String get phone;
  @override
  String? get whatsapp;
  @override
  @JsonKey(ignore: true)
  _$$VenueContactImplCopyWith<_$VenueContactImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

VenueSchedule _$VenueScheduleFromJson(Map<String, dynamic> json) {
  return _VenueSchedule.fromJson(json);
}

/// @nodoc
mixin _$VenueSchedule {
  String get openTime => throw _privateConstructorUsedError; // "08:00"
  String get closeTime => throw _privateConstructorUsedError; // "24:00"
  List<int> get closedDays => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $VenueScheduleCopyWith<VenueSchedule> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $VenueScheduleCopyWith<$Res> {
  factory $VenueScheduleCopyWith(
          VenueSchedule value, $Res Function(VenueSchedule) then) =
      _$VenueScheduleCopyWithImpl<$Res, VenueSchedule>;
  @useResult
  $Res call({String openTime, String closeTime, List<int> closedDays});
}

/// @nodoc
class _$VenueScheduleCopyWithImpl<$Res, $Val extends VenueSchedule>
    implements $VenueScheduleCopyWith<$Res> {
  _$VenueScheduleCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? openTime = null,
    Object? closeTime = null,
    Object? closedDays = null,
  }) {
    return _then(_value.copyWith(
      openTime: null == openTime
          ? _value.openTime
          : openTime // ignore: cast_nullable_to_non_nullable
              as String,
      closeTime: null == closeTime
          ? _value.closeTime
          : closeTime // ignore: cast_nullable_to_non_nullable
              as String,
      closedDays: null == closedDays
          ? _value.closedDays
          : closedDays // ignore: cast_nullable_to_non_nullable
              as List<int>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$VenueScheduleImplCopyWith<$Res>
    implements $VenueScheduleCopyWith<$Res> {
  factory _$$VenueScheduleImplCopyWith(
          _$VenueScheduleImpl value, $Res Function(_$VenueScheduleImpl) then) =
      __$$VenueScheduleImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String openTime, String closeTime, List<int> closedDays});
}

/// @nodoc
class __$$VenueScheduleImplCopyWithImpl<$Res>
    extends _$VenueScheduleCopyWithImpl<$Res, _$VenueScheduleImpl>
    implements _$$VenueScheduleImplCopyWith<$Res> {
  __$$VenueScheduleImplCopyWithImpl(
      _$VenueScheduleImpl _value, $Res Function(_$VenueScheduleImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? openTime = null,
    Object? closeTime = null,
    Object? closedDays = null,
  }) {
    return _then(_$VenueScheduleImpl(
      openTime: null == openTime
          ? _value.openTime
          : openTime // ignore: cast_nullable_to_non_nullable
              as String,
      closeTime: null == closeTime
          ? _value.closeTime
          : closeTime // ignore: cast_nullable_to_non_nullable
              as String,
      closedDays: null == closedDays
          ? _value._closedDays
          : closedDays // ignore: cast_nullable_to_non_nullable
              as List<int>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$VenueScheduleImpl implements _VenueSchedule {
  const _$VenueScheduleImpl(
      {required this.openTime,
      required this.closeTime,
      final List<int> closedDays = const []})
      : _closedDays = closedDays;

  factory _$VenueScheduleImpl.fromJson(Map<String, dynamic> json) =>
      _$$VenueScheduleImplFromJson(json);

  @override
  final String openTime;
// "08:00"
  @override
  final String closeTime;
// "24:00"
  final List<int> _closedDays;
// "24:00"
  @override
  @JsonKey()
  List<int> get closedDays {
    if (_closedDays is EqualUnmodifiableListView) return _closedDays;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_closedDays);
  }

  @override
  String toString() {
    return 'VenueSchedule(openTime: $openTime, closeTime: $closeTime, closedDays: $closedDays)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$VenueScheduleImpl &&
            (identical(other.openTime, openTime) ||
                other.openTime == openTime) &&
            (identical(other.closeTime, closeTime) ||
                other.closeTime == closeTime) &&
            const DeepCollectionEquality()
                .equals(other._closedDays, _closedDays));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, openTime, closeTime,
      const DeepCollectionEquality().hash(_closedDays));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$VenueScheduleImplCopyWith<_$VenueScheduleImpl> get copyWith =>
      __$$VenueScheduleImplCopyWithImpl<_$VenueScheduleImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$VenueScheduleImplToJson(
      this,
    );
  }
}

abstract class _VenueSchedule implements VenueSchedule {
  const factory _VenueSchedule(
      {required final String openTime,
      required final String closeTime,
      final List<int> closedDays}) = _$VenueScheduleImpl;

  factory _VenueSchedule.fromJson(Map<String, dynamic> json) =
      _$VenueScheduleImpl.fromJson;

  @override
  String get openTime;
  @override // "08:00"
  String get closeTime;
  @override // "24:00"
  List<int> get closedDays;
  @override
  @JsonKey(ignore: true)
  _$$VenueScheduleImplCopyWith<_$VenueScheduleImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

CourtReview _$CourtReviewFromJson(Map<String, dynamic> json) {
  return _CourtReview.fromJson(json);
}

/// @nodoc
mixin _$CourtReview {
  String get id => throw _privateConstructorUsedError;
  String get playerName => throw _privateConstructorUsedError;
  String? get playerPhotoUrl => throw _privateConstructorUsedError;
  double get rating => throw _privateConstructorUsedError;
  String? get comment => throw _privateConstructorUsedError;
  DateTime get createdAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CourtReviewCopyWith<CourtReview> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CourtReviewCopyWith<$Res> {
  factory $CourtReviewCopyWith(
          CourtReview value, $Res Function(CourtReview) then) =
      _$CourtReviewCopyWithImpl<$Res, CourtReview>;
  @useResult
  $Res call(
      {String id,
      String playerName,
      String? playerPhotoUrl,
      double rating,
      String? comment,
      DateTime createdAt});
}

/// @nodoc
class _$CourtReviewCopyWithImpl<$Res, $Val extends CourtReview>
    implements $CourtReviewCopyWith<$Res> {
  _$CourtReviewCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? playerName = null,
    Object? playerPhotoUrl = freezed,
    Object? rating = null,
    Object? comment = freezed,
    Object? createdAt = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      playerName: null == playerName
          ? _value.playerName
          : playerName // ignore: cast_nullable_to_non_nullable
              as String,
      playerPhotoUrl: freezed == playerPhotoUrl
          ? _value.playerPhotoUrl
          : playerPhotoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      rating: null == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as double,
      comment: freezed == comment
          ? _value.comment
          : comment // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CourtReviewImplCopyWith<$Res>
    implements $CourtReviewCopyWith<$Res> {
  factory _$$CourtReviewImplCopyWith(
          _$CourtReviewImpl value, $Res Function(_$CourtReviewImpl) then) =
      __$$CourtReviewImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String playerName,
      String? playerPhotoUrl,
      double rating,
      String? comment,
      DateTime createdAt});
}

/// @nodoc
class __$$CourtReviewImplCopyWithImpl<$Res>
    extends _$CourtReviewCopyWithImpl<$Res, _$CourtReviewImpl>
    implements _$$CourtReviewImplCopyWith<$Res> {
  __$$CourtReviewImplCopyWithImpl(
      _$CourtReviewImpl _value, $Res Function(_$CourtReviewImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? playerName = null,
    Object? playerPhotoUrl = freezed,
    Object? rating = null,
    Object? comment = freezed,
    Object? createdAt = null,
  }) {
    return _then(_$CourtReviewImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      playerName: null == playerName
          ? _value.playerName
          : playerName // ignore: cast_nullable_to_non_nullable
              as String,
      playerPhotoUrl: freezed == playerPhotoUrl
          ? _value.playerPhotoUrl
          : playerPhotoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      rating: null == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as double,
      comment: freezed == comment
          ? _value.comment
          : comment // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CourtReviewImpl implements _CourtReview {
  const _$CourtReviewImpl(
      {required this.id,
      required this.playerName,
      this.playerPhotoUrl,
      required this.rating,
      this.comment,
      required this.createdAt});

  factory _$CourtReviewImpl.fromJson(Map<String, dynamic> json) =>
      _$$CourtReviewImplFromJson(json);

  @override
  final String id;
  @override
  final String playerName;
  @override
  final String? playerPhotoUrl;
  @override
  final double rating;
  @override
  final String? comment;
  @override
  final DateTime createdAt;

  @override
  String toString() {
    return 'CourtReview(id: $id, playerName: $playerName, playerPhotoUrl: $playerPhotoUrl, rating: $rating, comment: $comment, createdAt: $createdAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CourtReviewImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.playerName, playerName) ||
                other.playerName == playerName) &&
            (identical(other.playerPhotoUrl, playerPhotoUrl) ||
                other.playerPhotoUrl == playerPhotoUrl) &&
            (identical(other.rating, rating) || other.rating == rating) &&
            (identical(other.comment, comment) || other.comment == comment) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, playerName, playerPhotoUrl, rating, comment, createdAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CourtReviewImplCopyWith<_$CourtReviewImpl> get copyWith =>
      __$$CourtReviewImplCopyWithImpl<_$CourtReviewImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CourtReviewImplToJson(
      this,
    );
  }
}

abstract class _CourtReview implements CourtReview {
  const factory _CourtReview(
      {required final String id,
      required final String playerName,
      final String? playerPhotoUrl,
      required final double rating,
      final String? comment,
      required final DateTime createdAt}) = _$CourtReviewImpl;

  factory _CourtReview.fromJson(Map<String, dynamic> json) =
      _$CourtReviewImpl.fromJson;

  @override
  String get id;
  @override
  String get playerName;
  @override
  String? get playerPhotoUrl;
  @override
  double get rating;
  @override
  String? get comment;
  @override
  DateTime get createdAt;
  @override
  @JsonKey(ignore: true)
  _$$CourtReviewImplCopyWith<_$CourtReviewImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

TimeSlot _$TimeSlotFromJson(Map<String, dynamic> json) {
  return _TimeSlot.fromJson(json);
}

/// @nodoc
mixin _$TimeSlot {
  String get id => throw _privateConstructorUsedError;
  DateTime get startTime => throw _privateConstructorUsedError;
  DateTime get endTime => throw _privateConstructorUsedError;
  bool get isAvailable => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $TimeSlotCopyWith<TimeSlot> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TimeSlotCopyWith<$Res> {
  factory $TimeSlotCopyWith(TimeSlot value, $Res Function(TimeSlot) then) =
      _$TimeSlotCopyWithImpl<$Res, TimeSlot>;
  @useResult
  $Res call(
      {String id, DateTime startTime, DateTime endTime, bool isAvailable});
}

/// @nodoc
class _$TimeSlotCopyWithImpl<$Res, $Val extends TimeSlot>
    implements $TimeSlotCopyWith<$Res> {
  _$TimeSlotCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? startTime = null,
    Object? endTime = null,
    Object? isAvailable = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      startTime: null == startTime
          ? _value.startTime
          : startTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      endTime: null == endTime
          ? _value.endTime
          : endTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isAvailable: null == isAvailable
          ? _value.isAvailable
          : isAvailable // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$TimeSlotImplCopyWith<$Res>
    implements $TimeSlotCopyWith<$Res> {
  factory _$$TimeSlotImplCopyWith(
          _$TimeSlotImpl value, $Res Function(_$TimeSlotImpl) then) =
      __$$TimeSlotImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id, DateTime startTime, DateTime endTime, bool isAvailable});
}

/// @nodoc
class __$$TimeSlotImplCopyWithImpl<$Res>
    extends _$TimeSlotCopyWithImpl<$Res, _$TimeSlotImpl>
    implements _$$TimeSlotImplCopyWith<$Res> {
  __$$TimeSlotImplCopyWithImpl(
      _$TimeSlotImpl _value, $Res Function(_$TimeSlotImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? startTime = null,
    Object? endTime = null,
    Object? isAvailable = null,
  }) {
    return _then(_$TimeSlotImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      startTime: null == startTime
          ? _value.startTime
          : startTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      endTime: null == endTime
          ? _value.endTime
          : endTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isAvailable: null == isAvailable
          ? _value.isAvailable
          : isAvailable // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$TimeSlotImpl implements _TimeSlot {
  const _$TimeSlotImpl(
      {required this.id,
      required this.startTime,
      required this.endTime,
      required this.isAvailable});

  factory _$TimeSlotImpl.fromJson(Map<String, dynamic> json) =>
      _$$TimeSlotImplFromJson(json);

  @override
  final String id;
  @override
  final DateTime startTime;
  @override
  final DateTime endTime;
  @override
  final bool isAvailable;

  @override
  String toString() {
    return 'TimeSlot(id: $id, startTime: $startTime, endTime: $endTime, isAvailable: $isAvailable)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TimeSlotImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.startTime, startTime) ||
                other.startTime == startTime) &&
            (identical(other.endTime, endTime) || other.endTime == endTime) &&
            (identical(other.isAvailable, isAvailable) ||
                other.isAvailable == isAvailable));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, startTime, endTime, isAvailable);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TimeSlotImplCopyWith<_$TimeSlotImpl> get copyWith =>
      __$$TimeSlotImplCopyWithImpl<_$TimeSlotImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$TimeSlotImplToJson(
      this,
    );
  }
}

abstract class _TimeSlot implements TimeSlot {
  const factory _TimeSlot(
      {required final String id,
      required final DateTime startTime,
      required final DateTime endTime,
      required final bool isAvailable}) = _$TimeSlotImpl;

  factory _TimeSlot.fromJson(Map<String, dynamic> json) =
      _$TimeSlotImpl.fromJson;

  @override
  String get id;
  @override
  DateTime get startTime;
  @override
  DateTime get endTime;
  @override
  bool get isAvailable;
  @override
  @JsonKey(ignore: true)
  _$$TimeSlotImplCopyWith<_$TimeSlotImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Booking _$BookingFromJson(Map<String, dynamic> json) {
  return _Booking.fromJson(json);
}

/// @nodoc
mixin _$Booking {
  String get id => throw _privateConstructorUsedError;
  String get courtId => throw _privateConstructorUsedError;
  String get venueName => throw _privateConstructorUsedError;
  DateTime get startTime => throw _privateConstructorUsedError;
  int get durationMinutes => throw _privateConstructorUsedError;
  int get totalPrice => throw _privateConstructorUsedError;
  PaymentMethod get paymentMethod => throw _privateConstructorUsedError;
  BookingStatus get status => throw _privateConstructorUsedError;
  String? get bookingRef =>
      throw _privateConstructorUsedError; // e.g. "PD-20240101-A1B2"
  String? get fawryReference => throw _privateConstructorUsedError;
  String? get qrData => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $BookingCopyWith<Booking> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BookingCopyWith<$Res> {
  factory $BookingCopyWith(Booking value, $Res Function(Booking) then) =
      _$BookingCopyWithImpl<$Res, Booking>;
  @useResult
  $Res call(
      {String id,
      String courtId,
      String venueName,
      DateTime startTime,
      int durationMinutes,
      int totalPrice,
      PaymentMethod paymentMethod,
      BookingStatus status,
      String? bookingRef,
      String? fawryReference,
      String? qrData});
}

/// @nodoc
class _$BookingCopyWithImpl<$Res, $Val extends Booking>
    implements $BookingCopyWith<$Res> {
  _$BookingCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? courtId = null,
    Object? venueName = null,
    Object? startTime = null,
    Object? durationMinutes = null,
    Object? totalPrice = null,
    Object? paymentMethod = null,
    Object? status = null,
    Object? bookingRef = freezed,
    Object? fawryReference = freezed,
    Object? qrData = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      courtId: null == courtId
          ? _value.courtId
          : courtId // ignore: cast_nullable_to_non_nullable
              as String,
      venueName: null == venueName
          ? _value.venueName
          : venueName // ignore: cast_nullable_to_non_nullable
              as String,
      startTime: null == startTime
          ? _value.startTime
          : startTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      durationMinutes: null == durationMinutes
          ? _value.durationMinutes
          : durationMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      totalPrice: null == totalPrice
          ? _value.totalPrice
          : totalPrice // ignore: cast_nullable_to_non_nullable
              as int,
      paymentMethod: null == paymentMethod
          ? _value.paymentMethod
          : paymentMethod // ignore: cast_nullable_to_non_nullable
              as PaymentMethod,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as BookingStatus,
      bookingRef: freezed == bookingRef
          ? _value.bookingRef
          : bookingRef // ignore: cast_nullable_to_non_nullable
              as String?,
      fawryReference: freezed == fawryReference
          ? _value.fawryReference
          : fawryReference // ignore: cast_nullable_to_non_nullable
              as String?,
      qrData: freezed == qrData
          ? _value.qrData
          : qrData // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$BookingImplCopyWith<$Res> implements $BookingCopyWith<$Res> {
  factory _$$BookingImplCopyWith(
          _$BookingImpl value, $Res Function(_$BookingImpl) then) =
      __$$BookingImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String courtId,
      String venueName,
      DateTime startTime,
      int durationMinutes,
      int totalPrice,
      PaymentMethod paymentMethod,
      BookingStatus status,
      String? bookingRef,
      String? fawryReference,
      String? qrData});
}

/// @nodoc
class __$$BookingImplCopyWithImpl<$Res>
    extends _$BookingCopyWithImpl<$Res, _$BookingImpl>
    implements _$$BookingImplCopyWith<$Res> {
  __$$BookingImplCopyWithImpl(
      _$BookingImpl _value, $Res Function(_$BookingImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? courtId = null,
    Object? venueName = null,
    Object? startTime = null,
    Object? durationMinutes = null,
    Object? totalPrice = null,
    Object? paymentMethod = null,
    Object? status = null,
    Object? bookingRef = freezed,
    Object? fawryReference = freezed,
    Object? qrData = freezed,
  }) {
    return _then(_$BookingImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      courtId: null == courtId
          ? _value.courtId
          : courtId // ignore: cast_nullable_to_non_nullable
              as String,
      venueName: null == venueName
          ? _value.venueName
          : venueName // ignore: cast_nullable_to_non_nullable
              as String,
      startTime: null == startTime
          ? _value.startTime
          : startTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      durationMinutes: null == durationMinutes
          ? _value.durationMinutes
          : durationMinutes // ignore: cast_nullable_to_non_nullable
              as int,
      totalPrice: null == totalPrice
          ? _value.totalPrice
          : totalPrice // ignore: cast_nullable_to_non_nullable
              as int,
      paymentMethod: null == paymentMethod
          ? _value.paymentMethod
          : paymentMethod // ignore: cast_nullable_to_non_nullable
              as PaymentMethod,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as BookingStatus,
      bookingRef: freezed == bookingRef
          ? _value.bookingRef
          : bookingRef // ignore: cast_nullable_to_non_nullable
              as String?,
      fawryReference: freezed == fawryReference
          ? _value.fawryReference
          : fawryReference // ignore: cast_nullable_to_non_nullable
              as String?,
      qrData: freezed == qrData
          ? _value.qrData
          : qrData // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$BookingImpl implements _Booking {
  const _$BookingImpl(
      {required this.id,
      required this.courtId,
      required this.venueName,
      required this.startTime,
      required this.durationMinutes,
      required this.totalPrice,
      required this.paymentMethod,
      required this.status,
      this.bookingRef,
      this.fawryReference,
      this.qrData});

  factory _$BookingImpl.fromJson(Map<String, dynamic> json) =>
      _$$BookingImplFromJson(json);

  @override
  final String id;
  @override
  final String courtId;
  @override
  final String venueName;
  @override
  final DateTime startTime;
  @override
  final int durationMinutes;
  @override
  final int totalPrice;
  @override
  final PaymentMethod paymentMethod;
  @override
  final BookingStatus status;
  @override
  final String? bookingRef;
// e.g. "PD-20240101-A1B2"
  @override
  final String? fawryReference;
  @override
  final String? qrData;

  @override
  String toString() {
    return 'Booking(id: $id, courtId: $courtId, venueName: $venueName, startTime: $startTime, durationMinutes: $durationMinutes, totalPrice: $totalPrice, paymentMethod: $paymentMethod, status: $status, bookingRef: $bookingRef, fawryReference: $fawryReference, qrData: $qrData)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BookingImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.courtId, courtId) || other.courtId == courtId) &&
            (identical(other.venueName, venueName) ||
                other.venueName == venueName) &&
            (identical(other.startTime, startTime) ||
                other.startTime == startTime) &&
            (identical(other.durationMinutes, durationMinutes) ||
                other.durationMinutes == durationMinutes) &&
            (identical(other.totalPrice, totalPrice) ||
                other.totalPrice == totalPrice) &&
            (identical(other.paymentMethod, paymentMethod) ||
                other.paymentMethod == paymentMethod) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.bookingRef, bookingRef) ||
                other.bookingRef == bookingRef) &&
            (identical(other.fawryReference, fawryReference) ||
                other.fawryReference == fawryReference) &&
            (identical(other.qrData, qrData) || other.qrData == qrData));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      courtId,
      venueName,
      startTime,
      durationMinutes,
      totalPrice,
      paymentMethod,
      status,
      bookingRef,
      fawryReference,
      qrData);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BookingImplCopyWith<_$BookingImpl> get copyWith =>
      __$$BookingImplCopyWithImpl<_$BookingImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$BookingImplToJson(
      this,
    );
  }
}

abstract class _Booking implements Booking {
  const factory _Booking(
      {required final String id,
      required final String courtId,
      required final String venueName,
      required final DateTime startTime,
      required final int durationMinutes,
      required final int totalPrice,
      required final PaymentMethod paymentMethod,
      required final BookingStatus status,
      final String? bookingRef,
      final String? fawryReference,
      final String? qrData}) = _$BookingImpl;

  factory _Booking.fromJson(Map<String, dynamic> json) = _$BookingImpl.fromJson;

  @override
  String get id;
  @override
  String get courtId;
  @override
  String get venueName;
  @override
  DateTime get startTime;
  @override
  int get durationMinutes;
  @override
  int get totalPrice;
  @override
  PaymentMethod get paymentMethod;
  @override
  BookingStatus get status;
  @override
  String? get bookingRef;
  @override // e.g. "PD-20240101-A1B2"
  String? get fawryReference;
  @override
  String? get qrData;
  @override
  @JsonKey(ignore: true)
  _$$BookingImplCopyWith<_$BookingImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
