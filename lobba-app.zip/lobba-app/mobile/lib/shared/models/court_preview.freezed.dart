// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'court_preview.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

CourtPreview _$CourtPreviewFromJson(Map<String, dynamic> json) {
  return _CourtPreview.fromJson(json);
}

/// @nodoc
mixin _$CourtPreview {
  String get id => throw _privateConstructorUsedError;
  String get venueId => throw _privateConstructorUsedError;
  String get venueName => throw _privateConstructorUsedError;
  bool get isIndoor => throw _privateConstructorUsedError;
  double get rating => throw _privateConstructorUsedError;
  int get reviewCount => throw _privateConstructorUsedError;
  int get pricePerSixtyMin =>
      throw _privateConstructorUsedError; // EGP, always shown prominently
  int get courtCount => throw _privateConstructorUsedError;
  double get distanceKm => throw _privateConstructorUsedError;
  String? get photoUrl => throw _privateConstructorUsedError;
  bool get isFeatured => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CourtPreviewCopyWith<CourtPreview> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CourtPreviewCopyWith<$Res> {
  factory $CourtPreviewCopyWith(
          CourtPreview value, $Res Function(CourtPreview) then) =
      _$CourtPreviewCopyWithImpl<$Res, CourtPreview>;
  @useResult
  $Res call(
      {String id,
      String venueId,
      String venueName,
      bool isIndoor,
      double rating,
      int reviewCount,
      int pricePerSixtyMin,
      int courtCount,
      double distanceKm,
      String? photoUrl,
      bool isFeatured});
}

/// @nodoc
class _$CourtPreviewCopyWithImpl<$Res, $Val extends CourtPreview>
    implements $CourtPreviewCopyWith<$Res> {
  _$CourtPreviewCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? venueId = null,
    Object? venueName = null,
    Object? isIndoor = null,
    Object? rating = null,
    Object? reviewCount = null,
    Object? pricePerSixtyMin = null,
    Object? courtCount = null,
    Object? distanceKm = null,
    Object? photoUrl = freezed,
    Object? isFeatured = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      venueId: null == venueId
          ? _value.venueId
          : venueId // ignore: cast_nullable_to_non_nullable
              as String,
      venueName: null == venueName
          ? _value.venueName
          : venueName // ignore: cast_nullable_to_non_nullable
              as String,
      isIndoor: null == isIndoor
          ? _value.isIndoor
          : isIndoor // ignore: cast_nullable_to_non_nullable
              as bool,
      rating: null == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as double,
      reviewCount: null == reviewCount
          ? _value.reviewCount
          : reviewCount // ignore: cast_nullable_to_non_nullable
              as int,
      pricePerSixtyMin: null == pricePerSixtyMin
          ? _value.pricePerSixtyMin
          : pricePerSixtyMin // ignore: cast_nullable_to_non_nullable
              as int,
      courtCount: null == courtCount
          ? _value.courtCount
          : courtCount // ignore: cast_nullable_to_non_nullable
              as int,
      distanceKm: null == distanceKm
          ? _value.distanceKm
          : distanceKm // ignore: cast_nullable_to_non_nullable
              as double,
      photoUrl: freezed == photoUrl
          ? _value.photoUrl
          : photoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      isFeatured: null == isFeatured
          ? _value.isFeatured
          : isFeatured // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CourtPreviewImplCopyWith<$Res>
    implements $CourtPreviewCopyWith<$Res> {
  factory _$$CourtPreviewImplCopyWith(
          _$CourtPreviewImpl value, $Res Function(_$CourtPreviewImpl) then) =
      __$$CourtPreviewImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String venueId,
      String venueName,
      bool isIndoor,
      double rating,
      int reviewCount,
      int pricePerSixtyMin,
      int courtCount,
      double distanceKm,
      String? photoUrl,
      bool isFeatured});
}

/// @nodoc
class __$$CourtPreviewImplCopyWithImpl<$Res>
    extends _$CourtPreviewCopyWithImpl<$Res, _$CourtPreviewImpl>
    implements _$$CourtPreviewImplCopyWith<$Res> {
  __$$CourtPreviewImplCopyWithImpl(
      _$CourtPreviewImpl _value, $Res Function(_$CourtPreviewImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? venueId = null,
    Object? venueName = null,
    Object? isIndoor = null,
    Object? rating = null,
    Object? reviewCount = null,
    Object? pricePerSixtyMin = null,
    Object? courtCount = null,
    Object? distanceKm = null,
    Object? photoUrl = freezed,
    Object? isFeatured = null,
  }) {
    return _then(_$CourtPreviewImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      venueId: null == venueId
          ? _value.venueId
          : venueId // ignore: cast_nullable_to_non_nullable
              as String,
      venueName: null == venueName
          ? _value.venueName
          : venueName // ignore: cast_nullable_to_non_nullable
              as String,
      isIndoor: null == isIndoor
          ? _value.isIndoor
          : isIndoor // ignore: cast_nullable_to_non_nullable
              as bool,
      rating: null == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as double,
      reviewCount: null == reviewCount
          ? _value.reviewCount
          : reviewCount // ignore: cast_nullable_to_non_nullable
              as int,
      pricePerSixtyMin: null == pricePerSixtyMin
          ? _value.pricePerSixtyMin
          : pricePerSixtyMin // ignore: cast_nullable_to_non_nullable
              as int,
      courtCount: null == courtCount
          ? _value.courtCount
          : courtCount // ignore: cast_nullable_to_non_nullable
              as int,
      distanceKm: null == distanceKm
          ? _value.distanceKm
          : distanceKm // ignore: cast_nullable_to_non_nullable
              as double,
      photoUrl: freezed == photoUrl
          ? _value.photoUrl
          : photoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      isFeatured: null == isFeatured
          ? _value.isFeatured
          : isFeatured // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CourtPreviewImpl implements _CourtPreview {
  const _$CourtPreviewImpl(
      {required this.id,
      required this.venueId,
      required this.venueName,
      required this.isIndoor,
      required this.rating,
      required this.reviewCount,
      required this.pricePerSixtyMin,
      required this.courtCount,
      required this.distanceKm,
      this.photoUrl,
      this.isFeatured = false});

  factory _$CourtPreviewImpl.fromJson(Map<String, dynamic> json) =>
      _$$CourtPreviewImplFromJson(json);

  @override
  final String id;
  @override
  final String venueId;
  @override
  final String venueName;
  @override
  final bool isIndoor;
  @override
  final double rating;
  @override
  final int reviewCount;
  @override
  final int pricePerSixtyMin;
// EGP, always shown prominently
  @override
  final int courtCount;
  @override
  final double distanceKm;
  @override
  final String? photoUrl;
  @override
  @JsonKey()
  final bool isFeatured;

  @override
  String toString() {
    return 'CourtPreview(id: $id, venueId: $venueId, venueName: $venueName, isIndoor: $isIndoor, rating: $rating, reviewCount: $reviewCount, pricePerSixtyMin: $pricePerSixtyMin, courtCount: $courtCount, distanceKm: $distanceKm, photoUrl: $photoUrl, isFeatured: $isFeatured)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CourtPreviewImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.venueId, venueId) || other.venueId == venueId) &&
            (identical(other.venueName, venueName) ||
                other.venueName == venueName) &&
            (identical(other.isIndoor, isIndoor) ||
                other.isIndoor == isIndoor) &&
            (identical(other.rating, rating) || other.rating == rating) &&
            (identical(other.reviewCount, reviewCount) ||
                other.reviewCount == reviewCount) &&
            (identical(other.pricePerSixtyMin, pricePerSixtyMin) ||
                other.pricePerSixtyMin == pricePerSixtyMin) &&
            (identical(other.courtCount, courtCount) ||
                other.courtCount == courtCount) &&
            (identical(other.distanceKm, distanceKm) ||
                other.distanceKm == distanceKm) &&
            (identical(other.photoUrl, photoUrl) ||
                other.photoUrl == photoUrl) &&
            (identical(other.isFeatured, isFeatured) ||
                other.isFeatured == isFeatured));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      venueId,
      venueName,
      isIndoor,
      rating,
      reviewCount,
      pricePerSixtyMin,
      courtCount,
      distanceKm,
      photoUrl,
      isFeatured);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CourtPreviewImplCopyWith<_$CourtPreviewImpl> get copyWith =>
      __$$CourtPreviewImplCopyWithImpl<_$CourtPreviewImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CourtPreviewImplToJson(
      this,
    );
  }
}

abstract class _CourtPreview implements CourtPreview {
  const factory _CourtPreview(
      {required final String id,
      required final String venueId,
      required final String venueName,
      required final bool isIndoor,
      required final double rating,
      required final int reviewCount,
      required final int pricePerSixtyMin,
      required final int courtCount,
      required final double distanceKm,
      final String? photoUrl,
      final bool isFeatured}) = _$CourtPreviewImpl;

  factory _CourtPreview.fromJson(Map<String, dynamic> json) =
      _$CourtPreviewImpl.fromJson;

  @override
  String get id;
  @override
  String get venueId;
  @override
  String get venueName;
  @override
  bool get isIndoor;
  @override
  double get rating;
  @override
  int get reviewCount;
  @override
  int get pricePerSixtyMin;
  @override // EGP, always shown prominently
  int get courtCount;
  @override
  double get distanceKm;
  @override
  String? get photoUrl;
  @override
  bool get isFeatured;
  @override
  @JsonKey(ignore: true)
  _$$CourtPreviewImplCopyWith<_$CourtPreviewImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
