// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'court_detail.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CourtDetailImpl _$$CourtDetailImplFromJson(Map<String, dynamic> json) =>
    _$CourtDetailImpl(
      id: json['id'] as String,
      venueId: json['venueId'] as String,
      venueName: json['venueName'] as String,
      address: json['address'] as String,
      lat: (json['lat'] as num).toDouble(),
      lng: (json['lng'] as num).toDouble(),
      isIndoor: json['isIndoor'] as bool,
      isPanoramic: json['isPanoramic'] as bool? ?? false,
      rating: (json['rating'] as num).toDouble(),
      reviewCount: (json['reviewCount'] as num).toInt(),
      courtCount: (json['courtCount'] as num).toInt(),
      pricing: CourtPricing.fromJson(json['pricing'] as Map<String, dynamic>),
      contact: VenueContact.fromJson(json['contact'] as Map<String, dynamic>),
      photoUrls: (json['photoUrls'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      videoUrl: json['videoUrl'] as String?,
      description: json['description'] as String?,
      schedule:
          VenueSchedule.fromJson(json['schedule'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$CourtDetailImplToJson(_$CourtDetailImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'venueId': instance.venueId,
      'venueName': instance.venueName,
      'address': instance.address,
      'lat': instance.lat,
      'lng': instance.lng,
      'isIndoor': instance.isIndoor,
      'isPanoramic': instance.isPanoramic,
      'rating': instance.rating,
      'reviewCount': instance.reviewCount,
      'courtCount': instance.courtCount,
      'pricing': instance.pricing,
      'contact': instance.contact,
      'photoUrls': instance.photoUrls,
      'videoUrl': instance.videoUrl,
      'description': instance.description,
      'schedule': instance.schedule,
    };

_$CourtPricingImpl _$$CourtPricingImplFromJson(Map<String, dynamic> json) =>
    _$CourtPricingImpl(
      min60: (json['min60'] as num).toInt(),
      min90: (json['min90'] as num).toInt(),
      min120: (json['min120'] as num).toInt(),
      min150: (json['min150'] as num).toInt(),
    );

Map<String, dynamic> _$$CourtPricingImplToJson(_$CourtPricingImpl instance) =>
    <String, dynamic>{
      'min60': instance.min60,
      'min90': instance.min90,
      'min120': instance.min120,
      'min150': instance.min150,
    };

_$VenueContactImpl _$$VenueContactImplFromJson(Map<String, dynamic> json) =>
    _$VenueContactImpl(
      phone: json['phone'] as String,
      whatsapp: json['whatsapp'] as String?,
    );

Map<String, dynamic> _$$VenueContactImplToJson(_$VenueContactImpl instance) =>
    <String, dynamic>{
      'phone': instance.phone,
      'whatsapp': instance.whatsapp,
    };

_$VenueScheduleImpl _$$VenueScheduleImplFromJson(Map<String, dynamic> json) =>
    _$VenueScheduleImpl(
      openTime: json['openTime'] as String,
      closeTime: json['closeTime'] as String,
      closedDays: (json['closedDays'] as List<dynamic>?)
              ?.map((e) => (e as num).toInt())
              .toList() ??
          const [],
    );

Map<String, dynamic> _$$VenueScheduleImplToJson(_$VenueScheduleImpl instance) =>
    <String, dynamic>{
      'openTime': instance.openTime,
      'closeTime': instance.closeTime,
      'closedDays': instance.closedDays,
    };

_$CourtReviewImpl _$$CourtReviewImplFromJson(Map<String, dynamic> json) =>
    _$CourtReviewImpl(
      id: json['id'] as String,
      playerName: json['playerName'] as String,
      playerPhotoUrl: json['playerPhotoUrl'] as String?,
      rating: (json['rating'] as num).toDouble(),
      comment: json['comment'] as String?,
      createdAt: DateTime.parse(json['createdAt'] as String),
    );

Map<String, dynamic> _$$CourtReviewImplToJson(_$CourtReviewImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'playerName': instance.playerName,
      'playerPhotoUrl': instance.playerPhotoUrl,
      'rating': instance.rating,
      'comment': instance.comment,
      'createdAt': instance.createdAt.toIso8601String(),
    };

_$TimeSlotImpl _$$TimeSlotImplFromJson(Map<String, dynamic> json) =>
    _$TimeSlotImpl(
      id: json['id'] as String,
      startTime: DateTime.parse(json['startTime'] as String),
      endTime: DateTime.parse(json['endTime'] as String),
      isAvailable: json['isAvailable'] as bool,
    );

Map<String, dynamic> _$$TimeSlotImplToJson(_$TimeSlotImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'startTime': instance.startTime.toIso8601String(),
      'endTime': instance.endTime.toIso8601String(),
      'isAvailable': instance.isAvailable,
    };

_$BookingImpl _$$BookingImplFromJson(Map<String, dynamic> json) =>
    _$BookingImpl(
      id: json['id'] as String,
      courtId: json['courtId'] as String,
      venueName: json['venueName'] as String,
      startTime: DateTime.parse(json['startTime'] as String),
      durationMinutes: (json['durationMinutes'] as num).toInt(),
      totalPrice: (json['totalPrice'] as num).toInt(),
      paymentMethod: $enumDecode(_$PaymentMethodEnumMap, json['paymentMethod']),
      status: $enumDecode(_$BookingStatusEnumMap, json['status']),
      bookingRef: json['bookingRef'] as String?,
      fawryReference: json['fawryReference'] as String?,
      qrData: json['qrData'] as String?,
    );

Map<String, dynamic> _$$BookingImplToJson(_$BookingImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'courtId': instance.courtId,
      'venueName': instance.venueName,
      'startTime': instance.startTime.toIso8601String(),
      'durationMinutes': instance.durationMinutes,
      'totalPrice': instance.totalPrice,
      'paymentMethod': _$PaymentMethodEnumMap[instance.paymentMethod]!,
      'status': _$BookingStatusEnumMap[instance.status]!,
      'bookingRef': instance.bookingRef,
      'fawryReference': instance.fawryReference,
      'qrData': instance.qrData,
    };

const _$PaymentMethodEnumMap = {
  PaymentMethod.fawry: 'fawry',
  PaymentMethod.instapay: 'instapay',
  PaymentMethod.cash: 'cash',
};

const _$BookingStatusEnumMap = {
  BookingStatus.pending: 'pending',
  BookingStatus.confirmed: 'confirmed',
  BookingStatus.completed: 'completed',
  BookingStatus.cancelled: 'cancelled',
};
