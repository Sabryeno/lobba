import 'package:freezed_annotation/freezed_annotation.dart';

part 'court_preview.freezed.dart';
part 'court_preview.g.dart';

/// Lightweight model for rendering court cards in the carousel + list.
/// The full court detail (gallery, reviews, schedule) lives in CourtDetail.
@freezed
class CourtPreview with _$CourtPreview {
  const factory CourtPreview({
    required String id,
    required String venueId,
    required String venueName,
    required bool isIndoor,
    required double rating,
    required int reviewCount,
    required int pricePerSixtyMin,  // EGP, always shown prominently
    required int courtCount,
    required double distanceKm,
    String? photoUrl,
    @Default(false) bool isFeatured,
  }) = _CourtPreview;

  factory CourtPreview.fromJson(Map<String, dynamic> json) =>
      _$CourtPreviewFromJson(json);
}

extension CourtPreviewX on CourtPreview {
  /// Human-readable distance string
  String get distanceLabel {
    if (distanceKm < 1) {
      return '${(distanceKm * 1000).round()} m';
    }
    return '${distanceKm.toStringAsFixed(1)} km';
  }
}
