/// Lightweight model used by the organizer's court management screens.
/// Maps directly to what [GET /courts/my] returns — a Court entity with its
/// Venue eagerly joined.
///
/// Deliberately hand-written (no freezed) so it compiles without build_runner.

class PricingTierOrg {
  final int durationMin; // 60 | 90 | 120 | 150
  final int priceEgp;

  const PricingTierOrg({required this.durationMin, required this.priceEgp});

  factory PricingTierOrg.fromJson(Map<String, dynamic> j) => PricingTierOrg(
        durationMin: (j['durationMin'] as num).toInt(),
        priceEgp: (j['priceEgp'] as num).toInt(),
      );
}

class OrganizerCourt {
  final String id;
  final String venueId;
  final String venueName;
  final String venueCity;
  final String name;

  /// 'indoor' | 'outdoor' | 'panoramic'
  final String courtType;

  /// 'artificial_grass' | 'glass' | 'concrete'
  final String surface;

  final List<PricingTierOrg> pricing;
  final List<String> amenities;
  final List<String> imageUrls;
  final bool isActive;
  final double avgRating;
  final int reviewCount;

  const OrganizerCourt({
    required this.id,
    required this.venueId,
    required this.venueName,
    required this.venueCity,
    required this.name,
    required this.courtType,
    required this.surface,
    required this.pricing,
    required this.amenities,
    required this.imageUrls,
    required this.isActive,
    required this.avgRating,
    required this.reviewCount,
  });

  factory OrganizerCourt.fromJson(Map<String, dynamic> j) {
    final venue = j['venue'] as Map<String, dynamic>? ?? {};
    return OrganizerCourt(
      id: j['id'] as String,
      venueId: j['venueId'] as String? ?? '',
      venueName: venue['name'] as String? ?? '',
      venueCity: venue['city'] as String? ?? '',
      name: j['name'] as String,
      courtType: j['courtType'] as String? ?? 'indoor',
      surface: j['surface'] as String? ?? 'artificial_grass',
      pricing: (j['pricing'] as List<dynamic>? ?? [])
          .map((e) => PricingTierOrg.fromJson(e as Map<String, dynamic>))
          .toList(),
      amenities: (j['amenities'] as List<dynamic>? ?? [])
          .map((e) => e.toString())
          .toList(),
      imageUrls: (j['imageUrls'] as List<dynamic>? ?? [])
          .map((e) => e.toString())
          .toList(),
      isActive: j['isActive'] as bool? ?? true,
      avgRating: (j['avgRating'] as num? ?? 0).toDouble(),
      reviewCount: (j['reviewCount'] as num? ?? 0).toInt(),
    );
  }

  OrganizerCourt copyWith({bool? isActive}) => OrganizerCourt(
        id: id,
        venueId: venueId,
        venueName: venueName,
        venueCity: venueCity,
        name: name,
        courtType: courtType,
        surface: surface,
        pricing: pricing,
        amenities: amenities,
        imageUrls: imageUrls,
        isActive: isActive ?? this.isActive,
        avgRating: avgRating,
        reviewCount: reviewCount,
      );

  // ── Helpers ────────────────────────────────────────────────────────────────

  /// Cheapest pricing tier price in EGP (shown as "From EGP X/hr").
  int get minPriceEgp {
    if (pricing.isEmpty) return 0;
    return pricing.map((p) => p.priceEgp).reduce((a, b) => a < b ? a : b);
  }

  /// Human-readable court type label.
  String get courtTypeLabel => switch (courtType) {
        'outdoor' => 'Outdoor',
        'panoramic' => 'Panoramic',
        _ => 'Indoor',
      };

  /// Human-readable surface label.
  String get surfaceLabel => switch (surface) {
        'glass' => 'Glass',
        'concrete' => 'Concrete',
        _ => 'Artificial Grass',
      };

  /// First image URL, or null if none.
  String? get coverImageUrl => imageUrls.isNotEmpty ? imageUrls.first : null;
}
