// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'court_preview.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CourtPreviewImpl _$$CourtPreviewImplFromJson(Map<String, dynamic> json) =>
    _$CourtPreviewImpl(
      id: json['id'] as String,
      venueId: json['venueId'] as String,
      venueName: json['venueName'] as String,
      isIndoor: json['isIndoor'] as bool,
      rating: (json['rating'] as num).toDouble(),
      reviewCount: (json['reviewCount'] as num).toInt(),
      pricePerSixtyMin: (json['pricePerSixtyMin'] as num).toInt(),
      courtCount: (json['courtCount'] as num).toInt(),
      distanceKm: (json['distanceKm'] as num).toDouble(),
      photoUrl: json['photoUrl'] as String?,
      isFeatured: json['isFeatured'] as bool? ?? false,
    );

Map<String, dynamic> _$$CourtPreviewImplToJson(_$CourtPreviewImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'venueId': instance.venueId,
      'venueName': instance.venueName,
      'isIndoor': instance.isIndoor,
      'rating': instance.rating,
      'reviewCount': instance.reviewCount,
      'pricePerSixtyMin': instance.pricePerSixtyMin,
      'courtCount': instance.courtCount,
      'distanceKm': instance.distanceKm,
      'photoUrl': instance.photoUrl,
      'isFeatured': instance.isFeatured,
    };
