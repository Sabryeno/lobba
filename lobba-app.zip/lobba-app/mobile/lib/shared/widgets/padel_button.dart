import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

enum PadelButtonVariant { filled, outlined, ghost }

class PadelButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final PadelButtonVariant variant;
  final bool loading;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final IconData? prefixIcon;
  final double? width;
  final double height;

  const PadelButton({
    super.key,
    required this.label,
    this.onPressed,
    this.variant = PadelButtonVariant.filled,
    this.loading = false,
    this.backgroundColor,
    this.foregroundColor,
    this.prefixIcon,
    this.width,
    this.height = 56,
  });

  @override
  Widget build(BuildContext context) {
    final effectiveBg = backgroundColor ??
        (variant == PadelButtonVariant.filled ? AppColors.primary : Colors.transparent);
    final effectiveFg = foregroundColor ??
        (variant == PadelButtonVariant.filled ? Colors.white : AppColors.primary);

    final child = loading
        ? SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              color: effectiveFg,
            ),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (prefixIcon != null) ...[
                Icon(prefixIcon, size: 20, color: effectiveFg),
                const SizedBox(width: 8),
              ],
              Text(label),
            ],
          );

    final style = switch (variant) {
      PadelButtonVariant.filled => ElevatedButton.styleFrom(
          backgroundColor: effectiveBg,
          foregroundColor: effectiveFg,
          minimumSize: Size(width ?? double.infinity, height),
          disabledBackgroundColor: AppColors.border,
          disabledForegroundColor: AppColors.textTertiary,
        ),
      PadelButtonVariant.outlined => OutlinedButton.styleFrom(
          foregroundColor: effectiveFg,
          minimumSize: Size(width ?? double.infinity, height),
          side: BorderSide(color: effectiveFg, width: 1.5),
        ),
      PadelButtonVariant.ghost => TextButton.styleFrom(
          foregroundColor: effectiveFg,
          minimumSize: Size(width ?? double.infinity, height),
        ),
    };

    return switch (variant) {
      PadelButtonVariant.filled => ElevatedButton(
          style: style,
          onPressed: loading ? null : onPressed,
          child: child,
        ),
      PadelButtonVariant.outlined => OutlinedButton(
          style: style,
          onPressed: loading ? null : onPressed,
          child: child,
        ),
      PadelButtonVariant.ghost => TextButton(
          style: style,
          onPressed: loading ? null : onPressed,
          child: child,
        ),
    };
  }
}
