import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

class LobbaAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;
  final bool showBack;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final Widget? bottom;
  final double bottomHeight;

  const LobbaAppBar({
    super.key,
    required this.title,
    this.actions,
    this.showBack = true,
    this.backgroundColor,
    this.foregroundColor,
    this.bottom,
    this.bottomHeight = 0,
  });

  @override
  Size get preferredSize =>
      Size.fromHeight(kToolbarHeight + bottomHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: backgroundColor ?? AppColors.primary,
      foregroundColor: foregroundColor ?? AppColors.white,
      elevation: 0,
      automaticallyImplyLeading: showBack,
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      actions: actions,
    );
  }
}
