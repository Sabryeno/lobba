import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../models/court_preview.dart';
import 'court_price_badge.dart';
import 'shimmer_box.dart';

/// Auto-advancing full-width carousel for featured courts.
/// Pauses on user drag, resumes after [_resumeDelay].
/// Each card taps through to the court detail via Hero transition.
class FeaturedCourtsCarousel extends StatefulWidget {
  final List<CourtPreview> courts;
  final Duration autoAdvance;
  final ValueChanged<CourtPreview>? onTap;

  const FeaturedCourtsCarousel({
    super.key,
    required this.courts,
    this.autoAdvance = const Duration(seconds: 4),
    this.onTap,
  });

  /// Loading skeleton — shown while courts are fetched.
  const FeaturedCourtsCarousel.loading({super.key})
      : courts = const [],
        autoAdvance = const Duration(seconds: 4),
        onTap = null;

  bool get _isLoading => courts.isEmpty && onTap == null;

  @override
  State<FeaturedCourtsCarousel> createState() => _FeaturedCourtsCarouselState();
}

class _FeaturedCourtsCarouselState extends State<FeaturedCourtsCarousel> {
  late final PageController _pageCtrl;
  Timer? _timer;

  static const _resumeDelay = Duration(seconds: 6);
  static const _cardHeight = 176.0;
  static const _horizontalPadding = 20.0;
  static const _cardRadius = 22.0;

  @override
  void initState() {
    super.initState();
    _pageCtrl = PageController(viewportFraction: 1.0);
    if (!widget._isLoading) _startTimer();
  }

  @override
  void didUpdateWidget(FeaturedCourtsCarousel old) {
    super.didUpdateWidget(old);
    if (widget._isLoading != old._isLoading && !widget._isLoading) {
      _startTimer();
    }
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(widget.autoAdvance, (_) => _advance());
  }

  void _advance() {
    if (!_pageCtrl.hasClients || widget.courts.isEmpty) return;
    final next = (_pageCtrl.page!.round() + 1) % widget.courts.length;
    _pageCtrl.animateToPage(
      next,
      duration: const Duration(milliseconds: 520),
      curve: Curves.easeInOut,
    );
  }

  void _onUserInteraction() {
    _timer?.cancel();
    // Resume after a pause so user has time to read
    Future.delayed(_resumeDelay, () {
      if (mounted) _startTimer();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget._isLoading) return _buildSkeleton();

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          height: _cardHeight,
          child: NotificationListener<ScrollNotification>(
            onNotification: (n) {
              if (n is ScrollStartNotification) _onUserInteraction();
              return false;
            },
            child: PageView.builder(
              controller: _pageCtrl,
              itemCount: widget.courts.length,
              padEnds: false,
              physics: const BouncingScrollPhysics(
                decelerationRate: ScrollDecelerationRate.fast,
              ),
              itemBuilder: (ctx, i) => _CourtSlide(
                court: widget.courts[i],
                onTap: () => widget.onTap?.call(widget.courts[i]),
                horizontalPadding: _horizontalPadding,
                cardRadius: _cardRadius,
                cardHeight: _cardHeight,
              ),
            ),
          ),
        )
            .animate()
            .fadeIn(duration: 500.ms)
            .slideY(begin: 0.06, end: 0, duration: 500.ms, curve: Curves.easeOut),

        const SizedBox(height: 12),

        // Animated pill-dot indicator
        SmoothPageIndicator(
          controller: _pageCtrl,
          count: widget.courts.length,
          effect: ExpandingDotsEffect(
            dotHeight: 6,
            dotWidth: 6,
            expansionFactor: 3,
            spacing: 5,
            activeDotColor: AppColors.primary,
            dotColor: AppColors.border,
          ),
        ),
      ],
    );
  }

  Widget _buildSkeleton() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: _horizontalPadding),
          child: ShimmerBox(
            height: _cardHeight,
            borderRadius: _cardRadius,
          ),
        ),
        const SizedBox(height: 12),
        // Skeleton dots
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            4,
            (i) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: ShimmerBox(
                height: 6,
                width: i == 0 ? 18 : 6,
                borderRadius: 3,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ── Individual slide card ─────────────────────────────────────────────────────

class _CourtSlide extends StatelessWidget {
  final CourtPreview court;
  final VoidCallback onTap;
  final double horizontalPadding;
  final double cardRadius;
  final double cardHeight;

  const _CourtSlide({
    required this.court,
    required this.onTap,
    required this.horizontalPadding,
    required this.cardRadius,
    required this.cardHeight,
  });

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
      child: GestureDetector(
        onTap: onTap,
        child: Hero(
          tag: 'court-hero-${court.id}',
          child: ClipRRect(
            borderRadius: BorderRadius.circular(cardRadius),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // ── Background image / gradient ──────────────────────────
                _CourtBackground(court: court),

                // ── Subtle court-line overlay ────────────────────────────
                const _CourtLineOverlay(),

                // ── Top badges ───────────────────────────────────────────
                Positioned(
                  top: 12,
                  left: 12,
                  child: _TypeBadge(
                    label: '${court.isIndoor ? '🏠' : '☀️'}  '
                        '${court.isIndoor ? 'Indoor' : 'Outdoor'}'
                        ' · ⭐ ${court.rating.toStringAsFixed(1)}',
                  ),
                ),

                // ── Price — always amber, always visible ─────────────────
                Positioned(
                  top: 12,
                  right: 12,
                  child: CourtPriceBadge(
                    pricePerSixty: court.pricePerSixtyMin,
                    locale: locale,
                  ),
                ),

                // ── Bottom info gradient ─────────────────────────────────
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: _BottomInfo(court: court, locale: locale),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CourtBackground extends StatelessWidget {
  final CourtPreview court;
  const _CourtBackground({required this.court});

  static const _gradients = [
    [Color(0xFF0D2E22), Color(0xFF1A4D3C)],
    [Color(0xFF1A3A4D), Color(0xFF1B6978)],
    [Color(0xFF2E1A0D), Color(0xFF7A3D1A)],
    [Color(0xFF1A1A2E), Color(0xFF3B2F7A)],
  ];

  @override
  Widget build(BuildContext context) {
    if (court.photoUrl != null) {
      return Image.network(
        court.photoUrl!,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _fallback(court.id),
      );
    }
    return _fallback(court.id);
  }

  Widget _fallback(String id) {
    final colors = _gradients[id.hashCode.abs() % _gradients.length];
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: colors,
        ),
      ),
    );
  }
}

class _CourtLineOverlay extends StatelessWidget {
  const _CourtLineOverlay();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _CourtLinePainter());
  }
}

class _CourtLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.06)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    // Horizontal mid line
    canvas.drawLine(
      Offset(size.width * 0.08, size.height * 0.5),
      Offset(size.width * 0.92, size.height * 0.5),
      paint,
    );
    // Vertical mid line
    canvas.drawLine(
      Offset(size.width * 0.5, size.height * 0.08),
      Offset(size.width * 0.5, size.height * 0.92),
      paint,
    );
    // Service box
    canvas.drawRect(
      Rect.fromLTWH(
        size.width * 0.25,
        size.height * 0.25,
        size.width * 0.5,
        size.height * 0.5,
      ),
      paint,
    );
  }

  @override
  bool shouldRepaint(_) => false;
}

class _TypeBadge extends StatelessWidget {
  final String label;
  const _TypeBadge({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.25)),
        // Frosted glass on supported platforms
        backgroundBlendMode: BlendMode.overlay,
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 10,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.3,
        ),
      ),
    );
  }
}

class _BottomInfo extends StatelessWidget {
  final CourtPreview court;
  final Locale locale;
  const _BottomInfo({required this.court, required this.locale});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.transparent, Color(0x99000000)],
        ),
      ),
      padding: const EdgeInsets.fromLTRB(14, 24, 14, 14),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            court.venueName,
            style: AppTypography.titleMedium(locale).copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              _MetaChip(
                '${court.isIndoor ? '🏠' : '☀️'} '
                '${court.isIndoor ? 'Indoor' : 'Outdoor'}',
              ),
              const SizedBox(width: 8),
              _MetaChip('📍 ${court.distanceLabel}'),
              const SizedBox(width: 8),
              _MetaChip('🎾 ${court.courtCount} courts'),
            ],
          ),
        ],
      ),
    );
  }
}

class _MetaChip extends StatelessWidget {
  final String text;
  const _MetaChip(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        color: Color(0xCCFFFFFF),
        fontSize: 10,
        fontWeight: FontWeight.w500,
      ),
    );
  }
}
