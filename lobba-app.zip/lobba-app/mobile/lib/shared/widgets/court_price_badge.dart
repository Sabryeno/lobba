import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

/// Amber price tag — the most prominent element on every court card.
/// Always shows EGP, respects Arabic-Indic numeral preference.
class CourtPriceBadge extends StatelessWidget {
  final int pricePerSixty;
  final Locale locale;
  final bool large;

  const CourtPriceBadge({
    super.key,
    required this.pricePerSixty,
    required this.locale,
    this.large = false,
  });

  @override
  Widget build(BuildContext context) {
    final label = '${_formatPrice(pricePerSixty)} EGP';

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: large ? 14 : 10,
        vertical: large ? 7 : 5,
      ),
      decoration: BoxDecoration(
        color: AppColors.accent,
        borderRadius: BorderRadius.circular(large ? 14 : 20),
        boxShadow: [
          BoxShadow(
            color: AppColors.accent.withOpacity(0.35),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Text(
        label,
        style: TextStyle(
          color: Colors.white,
          fontSize: large ? 15 : 11,
          fontWeight: FontWeight.w800,
          letterSpacing: -0.2,
          height: 1,
        ),
      ),
    );
  }

  String _formatPrice(int price) {
    // Arabic-Indic numerals if Arabic locale is active
    if (locale.languageCode == 'ar') {
      return price.toString().split('').map(_toArabicIndic).join();
    }
    return price.toString();
  }

  String _toArabicIndic(String digit) {
    const map = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    final i = int.tryParse(digit);
    return i != null ? map[i] : digit;
  }
}
