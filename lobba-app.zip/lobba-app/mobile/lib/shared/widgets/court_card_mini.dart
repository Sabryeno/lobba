import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../features/auth/providers/locale_provider.dart';
import '../models/court_preview.dart';
import 'court_price_badge.dart';

/// Compact court card for the "Near you" horizontal scroll row.
/// Width: 120 px. Height: 156 px.
class CourtCardMini extends ConsumerWidget {
  final CourtPreview court;
  final VoidCallback onTap;

  const CourtCardMini({
    super.key,
    required this.court,
    required this.onTap,
  });

  static const _width = 120.0;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(localeProvider);

    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: _width,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surfaceElevated,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border, width: 0.5),
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Image / gradient
              _Thumbnail(court: court),

              // Info
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(9, 7, 9, 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        court.venueName,
                        style: AppTypography.labelLarge(locale).copyWith(
                          fontSize: 11,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      // Type badge
                      Row(
                        children: [
                          _TypeDot(isIndoor: court.isIndoor),
                          const SizedBox(width: 4),
                          Text(
                            court.isIndoor ? 'Indoor' : 'Outdoor',
                            style: const TextStyle(
                              fontSize: 9,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      // Price — always amber
                      CourtPriceBadge(
                        pricePerSixty: court.pricePerSixtyMin,
                        locale: locale,
                      ),
                      const SizedBox(height: 3),
                      // Distance
                      Text(
                        court.distanceLabel,
                        style: const TextStyle(
                          fontSize: 9,
                          color: AppColors.textTertiary,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Thumbnail extends StatelessWidget {
  final CourtPreview court;
  const _Thumbnail({required this.court});

  static const _gradients = [
    [Color(0xFFC8E6D8), Color(0xFFA8D4BC)],
    [Color(0xFFC8DCE6), Color(0xFFA8C4D4)],
    [Color(0xFFE6D8C8), Color(0xFFD4B8A8)],
    [Color(0xFFDCC8E6), Color(0xFFC4A8D4)],
  ];

  @override
  Widget build(BuildContext context) {
    if (court.photoUrl != null) {
      return Image.network(
        court.photoUrl!,
        height: 80,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _fallback(),
      );
    }
    return _fallback();
  }

  Widget _fallback() {
    final pair = _gradients[court.id.hashCode.abs() % _gradients.length];
    return Container(
      height: 80,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: pair,
        ),
      ),
      child: const Center(child: Text('🎾', style: TextStyle(fontSize: 26))),
    );
  }
}

class _TypeDot extends StatelessWidget {
  final bool isIndoor;
  const _TypeDot({required this.isIndoor});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 6,
      height: 6,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isIndoor ? AppColors.primary : AppColors.accent,
      ),
    );
  }
}
