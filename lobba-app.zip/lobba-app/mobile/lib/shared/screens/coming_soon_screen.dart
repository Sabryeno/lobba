import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../core/localization/app_localizations.dart';
import '../../features/auth/providers/locale_provider.dart';
import '../widgets/padel_button.dart';

/// Phase 6: "Store & Merch — Coming Soon"
/// Navigation route exists; no backend functionality yet.
class ComingSoonScreen extends ConsumerWidget {
  const ComingSoonScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final locale = ref.watch(localeProvider);

    return Scaffold(
      backgroundColor: AppColors.primary,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Icon / illustration
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Center(
                  child: Text('🛍️', style: TextStyle(fontSize: 52)),
                ),
              )
                  .animate()
                  .scale(
                    begin: const Offset(0.7, 0.7),
                    end: const Offset(1, 1),
                    duration: 700.ms,
                    curve: Curves.elasticOut,
                  ),
              const SizedBox(height: 32),

              // "Coming soon" badge
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  l10n.tr('store.coming_soon_badge').toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 11,
                    letterSpacing: 1.5,
                  ),
                ),
              )
                  .animate(delay: 200.ms)
                  .fadeIn(duration: 400.ms),
              const SizedBox(height: 16),

              Text(
                l10n.tr('store.coming_soon_title'),
                textAlign: TextAlign.center,
                style: AppTypography.headlineMedium(locale).copyWith(
                  color: Colors.white,
                ),
              )
                  .animate(delay: 300.ms)
                  .fadeIn(duration: 400.ms),
              const SizedBox(height: 12),
              Text(
                l10n.tr('store.coming_soon_subtitle'),
                textAlign: TextAlign.center,
                style: AppTypography.bodyLarge(locale).copyWith(
                  color: Colors.white70,
                ),
              )
                  .animate(delay: 400.ms)
                  .fadeIn(duration: 400.ms),
              const SizedBox(height: 48),

              PadelButton(
                label: l10n.tr('store.notify_me'),
                backgroundColor: AppColors.accent,
                foregroundColor: Colors.white,
                onPressed: () {
                  // Phase 6: wire up notification signup
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("We'll notify you at launch!")),
                  );
                },
              )
                  .animate(delay: 500.ms)
                  .fadeIn(duration: 400.ms),
            ],
          ),
        ),
      ),
    );
  }
}
