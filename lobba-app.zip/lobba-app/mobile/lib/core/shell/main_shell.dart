import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../theme/lobba_tokens.dart';
import '../navigation/app_routes.dart';
import '../i18n/lobba_i18n.dart';

/// Player shell with the agreed floating nav:
/// • On Home — a translucent pill (Home · Match · Deals) + a separate green
///   profile circle beside it.
/// • On any other screen — it rolls up into a single Home button (bottom-left).
class MainShell extends ConsumerStatefulWidget {
  final Widget child;
  const MainShell({super.key, required this.child});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  DateTime? _lastBack;

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    final loc = GoRouterState.of(context).matchedLocation;
    final onHome = loc.startsWith(AppRoutes.home);

    return PopScope(
      // Back never drops out of a screen unexpectedly:
      // • On a non-home tab → jump to Home.
      // • On Home → first press shows a hint, a second within 2s exits.
      canPop: false,
      onPopInvoked: (didPop) {
        if (didPop) return;
        if (!onHome) {
          context.go(AppRoutes.home);
          return;
        }
        final now = DateTime.now();
        if (_lastBack == null || now.difference(_lastBack!) > const Duration(seconds: 2)) {
          _lastBack = now;
          ScaffoldMessenger.of(context)
            ..clearSnackBars()
            ..showSnackBar(SnackBar(content: Text('Press back again to exit'.tr(context)), duration: const Duration(seconds: 2)));
        } else {
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        backgroundColor: t.bg,
        body: Stack(
          children: [
            Positioned.fill(child: widget.child),
            if (onHome)
              _FullNav(loc: loc)
            else
              Positioned(left: 16, bottom: 16, child: _HomeButton()),
          ],
        ),
      ),
    );
  }
}

const _pillBg = Color(0xCC1A1E1B); // translucent dark, both themes (per mockup)

class _FullNav extends StatelessWidget {
  final String loc;
  const _FullNav({required this.loc});

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Positioned(
      left: 16, right: 16, bottom: 16,
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            // Translucent floating pill: Home · Match · Deals (left).
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(99),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 10),
                    decoration: BoxDecoration(
                      color: _pillBg,
                      borderRadius: BorderRadius.circular(99),
                      border: Border.all(color: Colors.white.withOpacity(.08)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _NavIcon(Icons.home_rounded, active: true, onTap: () => context.go(AppRoutes.home)),
                        _NavIcon(Icons.sports_tennis_rounded, onTap: () => context.go(AppRoutes.matches)),
                        _NavIcon(Icons.local_offer_rounded, onTap: () => context.push(AppRoutes.deals)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 9),
            // Separate green profile circle — on the RIGHT.
            GestureDetector(
              onTap: () => context.go(AppRoutes.profile),
              child: Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  color: t.accent, shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 16, offset: const Offset(0, 8))],
                ),
                child: Icon(Icons.person_outline_rounded, color: t.onAccent, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavIcon extends StatelessWidget {
  final IconData icon;
  final bool active;
  final VoidCallback onTap;
  const _NavIcon(this.icon, {this.active = false, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Icon(icon, size: 21, color: active ? t.gold : const Color(0x80ECE7DC)),
      ),
    );
  }
}

class _HomeButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: GestureDetector(
        onTap: () => context.go(AppRoutes.home),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: const Color(0xD11A1E1B),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withOpacity(.1)),
              ),
              child: const Icon(Icons.home_rounded, size: 18, color: Color(0xFFECE7DC)),
            ),
          ),
        ),
      ),
    );
  }
}
