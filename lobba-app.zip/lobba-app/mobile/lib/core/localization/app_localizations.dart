import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AppLocalizations {
  final Locale locale;
  late Map<String, dynamic> _strings;

  AppLocalizations(this.locale);

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const delegate = _AppLocalizationsDelegate();

  static const supportedLocales = [
    Locale('en'),
    Locale('ar'),
  ];

  Future<bool> load() async {
    final jsonString = await rootBundle.loadString(
      'assets/translations/${locale.languageCode}.json',
    );
    _strings = json.decode(jsonString) as Map<String, dynamic>;
    return true;
  }

  /// Retrieves a translation by dot-separated key, e.g. `tr('auth.login')`.
  /// Supports named interpolation: `tr('otp.subtitle', args: {'phone': '+201...'})`.
  String tr(String key, {Map<String, String>? args}) {
    final parts = key.split('.');
    dynamic value = _strings;
    for (final part in parts) {
      if (value is Map<String, dynamic>) {
        value = value[part];
      } else {
        return key; // key not found — return raw key so it's visible in QA
      }
    }
    if (value == null) return key;
    var result = value.toString();
    args?.forEach((k, v) {
      result = result.replaceAll('{$k}', v);
    });
    return result;
  }

  bool get isArabic => locale.languageCode == 'ar';
  TextDirection get textDirection =>
      isArabic ? TextDirection.rtl : TextDirection.ltr;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      AppLocalizations.supportedLocales
          .any((l) => l.languageCode == locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    final localizations = AppLocalizations(locale);
    await localizations.load();
    return localizations;
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
