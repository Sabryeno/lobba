import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Local file path of the user's chosen profile photo (null = use initial).
final profilePhotoProvider = StateProvider<String?>((ref) => null);
