import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

const apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://10.0.2.2:3000/api/v1', // Android emulator → localhost
);

final apiClientProvider = Provider<Dio>((ref) {
  final dio = Dio(
    BaseOptions(
      baseUrl: apiBaseUrl,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 30),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Accept-Language': 'ar,en',
      },
    ),
  );

  dio.interceptors.add(_AuthInterceptor());
  dio.interceptors.add(_LoggingInterceptor());

  return dio;
});

class _AuthInterceptor extends Interceptor {
  // Read tokens directly from secure storage — avoids a circular import
  // with auth_provider.dart (which imports api_client.dart).
  static const _storage = FlutterSecureStorage();
  static const _kAccess = 'access_token';
  static const _kRefresh = 'refresh_token';

  @override
  Future<void> onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    try {
      final token = await _storage.read(key: _kAccess);
      if (token != null) {
        options.headers['Authorization'] = 'Bearer $token';
      }
    } catch (_) {}
    handler.next(options);
  }

  @override
  Future<void> onError(
    DioException err,
    ErrorInterceptorHandler handler,
  ) async {
    if (err.response?.statusCode == 401) {
      try {
        final refreshToken = await _storage.read(key: _kRefresh);
        if (refreshToken != null) {
          // Use a bare Dio instance to avoid triggering this interceptor again
          final refreshDio = Dio(BaseOptions(baseUrl: apiBaseUrl));
          final resp = await refreshDio.post(
            '/auth/token/refresh',
            data: {'refreshToken': refreshToken},
          );
          final data = resp.data as Map<String, dynamic>;
          final newAccess = data['accessToken'] as String;
          final newRefresh = data['refreshToken'] as String?;
          await _storage.write(key: _kAccess, value: newAccess);
          if (newRefresh != null) {
            await _storage.write(key: _kRefresh, value: newRefresh);
          }
          // Retry the original request with the new token
          final opts = err.requestOptions;
          opts.headers['Authorization'] = 'Bearer $newAccess';
          final retryResp = await Dio().fetch(opts);
          return handler.resolve(retryResp);
        }
      } catch (_) {
        // Refresh failed — clear all stored credentials so the user is
        // redirected to login on the next session restore.
        await const FlutterSecureStorage().deleteAll();
      }
    }
    handler.next(err);
  }
}

class _LoggingInterceptor extends Interceptor {
  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    assert(() {
      // Only log in debug mode
      // ignore: avoid_print
      print('[API] ${options.method} ${options.path}');
      return true;
    }());
    handler.next(options);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    assert(() {
      // ignore: avoid_print
      print('[API ERROR] ${err.response?.statusCode} ${err.message}');
      return true;
    }());
    handler.next(err);
  }
}

// ── Standardised API error ────────────────────────────────────────────────
class ApiException implements Exception {
  final int? statusCode;
  final String message;
  final String? code;

  const ApiException({this.statusCode, required this.message, this.code});

  @override
  String toString() => 'ApiException($statusCode): $message';
}
