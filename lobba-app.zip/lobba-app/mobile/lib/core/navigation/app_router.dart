import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/auth/screens/splash_screen.dart';
import '../../features/auth/screens/welcome_screen.dart';
import '../../features/auth/screens/player_signup_screen.dart';
import '../../features/auth/screens/email_auth_screen.dart';
import '../../features/auth/screens/role_select_screen.dart';
import '../../features/auth/models/user_model.dart';
import '../../features/social/screens/social_screens.dart';
import '../../features/profile/screens/settings_screen.dart';
import '../../features/matches/screens/match_result_screens.dart';
import '../../features/discovery/screens/map_search_screen.dart';
import '../../features/matches/screens/join_pending_screen.dart';
import '../../features/auth/screens/coach_validate_screen.dart';
import '../../features/auth/screens/organizer_signup_screen.dart';
import '../../features/auth/screens/otp_verification_screen.dart';
import '../../features/auth/screens/player_profile_setup_screen.dart';
import '../../features/auth/screens/assessment_screen.dart';
import '../../features/auth/screens/organizer_pending_screen.dart';
import '../../features/auth/screens/organizer_kyc_screen.dart';
import '../../features/auth/providers/auth_provider.dart';
import '../../features/auth/models/user_model.dart';
import '../shell/main_shell.dart';
import '../../features/home/screens/home_screen.dart';
import '../../features/discovery/screens/discovery_screen.dart';
import '../../features/booking/screens/booking_flow_screen.dart';
import '../../features/booking/screens/court_detail_screen.dart';
import '../../features/booking/screens/my_bookings_screen.dart';
import '../../features/booking/screens/booking_confirmed_screen.dart';
import '../../features/booking/screens/qr_ticket_screen.dart';
import '../../features/social/screens/clubs_screen.dart';
import '../../features/social/screens/club_detail_screen.dart';
import '../../features/profile/screens/profile_screen.dart';
import '../../features/profile/screens/edit_profile_screen.dart';
import '../../features/profile/screens/player_detail_screen.dart';
import '../../features/matches/screens/matches_screen.dart';
import '../../features/matches/screens/create_match_screen.dart';
import '../../features/matches/screens/match_detail_screen.dart';
import '../../features/tournaments/screens/tournaments_screen.dart';
import '../../features/tournaments/screens/tournament_detail_screen.dart';
import '../../features/coaches/screens/coaches_screen.dart';
import '../../features/coaches/screens/coach_detail_screen.dart';
import '../../features/coaches/screens/book_coach_screen.dart';
import '../../features/academies/screens/academies_screen.dart';
import '../../features/academies/screens/academy_detail_screen.dart';
import '../../features/leaderboard/screens/leaderboard_screen.dart';
import '../../features/chat/screens/chats_screen.dart';
import '../../features/chat/screens/chat_detail_screen.dart';
import '../../features/notifications/screens/notifications_screen.dart';
import '../../features/deals/screens/deals_screen.dart';
import '../../features/teams/screens/teams_screen.dart';
import '../../features/teams/screens/team_detail_screen.dart';
import '../../features/organizer/screens/organizer_shell.dart';
import '../../features/organizer/screens/organizer_dashboard_screen.dart';
import '../../features/organizer/screens/organizer_courts_screen.dart';
import '../../features/organizer/screens/organizer_bookings_screen.dart';
import '../../features/organizer/screens/organizer_analytics_screen.dart';
import '../../features/organizer/screens/organizer_deals_screen.dart';
import '../../shared/screens/coming_soon_screen.dart';
import 'app_routes.dart';

export 'app_routes.dart';

/// Notifies go_router to re-run its redirect when auth state changes, WITHOUT
/// recreating the whole router (recreating reset the navigator and looked like
/// the login page endlessly "refreshing").
class GoRouterAuthRefresh extends ChangeNotifier {
  GoRouterAuthRefresh(Ref ref) {
    _sub = ref.listen(authStateProvider, (_, __) => notifyListeners());
  }
  late final ProviderSubscription _sub;
  @override
  void dispose() {
    _sub.close();
    super.dispose();
  }
}

final routerProvider = Provider<GoRouter>((ref) {
  final refresh = GoRouterAuthRefresh(ref);
  ref.onDispose(refresh.dispose);

  return GoRouter(
    initialLocation: AppRoutes.splash,
    debugLogDiagnostics: false,
    refreshListenable: refresh,
    // Automatic Firebase Analytics screen_view tracking (skipped if Firebase
    // failed to initialise, e.g. missing google-services.json).
    observers: [
      if (Firebase.apps.isNotEmpty)
        FirebaseAnalyticsObserver(analytics: FirebaseAnalytics.instance),
    ],
    redirect: (context, state) {
      final authState = ref.read(authStateProvider);
      final isLoggedIn = authState.value != null;
      final loc = state.matchedLocation;
      final isOnAuth = loc.startsWith('/welcome') ||
          loc.startsWith('/auth') ||
          loc.startsWith('/signup') ||
          loc.startsWith('/otp') ||
          loc == AppRoutes.splash;

      if (isLoggedIn && isOnAuth) {
        final user = authState.value!;
        return user.role == UserRole.organizer
            ? AppRoutes.organizerDashboard
            : AppRoutes.home;
      }
      if (!isLoggedIn && !isOnAuth) return AppRoutes.welcome;
      return null;
    },
    routes: [
      // ── Auth ──────────────────────────────────────────────
      GoRoute(path: AppRoutes.splash, builder: (c, s) => const SplashScreen()),
      GoRoute(path: AppRoutes.welcome, builder: (c, s) => const RoleSelectScreen()),
      GoRoute(
        path: '/auth/:role',
        builder: (c, s) => EmailAuthScreen(
          role: s.pathParameters['role'] == 'owner' ? UserRole.organizer : UserRole.player,
        ),
      ),
      GoRoute(path: AppRoutes.playerSignup, builder: (c, s) => const PlayerSignupScreen()),
      GoRoute(path: AppRoutes.organizerSignup, builder: (c, s) => const OrganizerSignupScreen()),
      GoRoute(
        path: AppRoutes.otp,
        builder: (c, s) => OtpVerificationScreen(
          phone: s.uri.queryParameters['phone'] ?? '',
          flow: s.uri.queryParameters['flow'] ?? 'player',
        ),
      ),
      GoRoute(path: AppRoutes.playerSetup, builder: (c, s) => const PlayerProfileSetupScreen()),
      GoRoute(path: AppRoutes.assessment, builder: (c, s) => const AssessmentScreen()),
      GoRoute(path: AppRoutes.organizerKyc, builder: (c, s) => const OrganizerKycScreen()),
      GoRoute(path: AppRoutes.organizerPending, builder: (c, s) => const OrganizerPendingScreen()),

      // ── Player Shell (bottom nav) ──────────────────────────
      ShellRoute(
        builder: (c, s, child) => MainShell(child: child),
        routes: [
          GoRoute(path: AppRoutes.home, builder: (c, s) => const HomeScreen()),
          GoRoute(path: AppRoutes.discovery, builder: (c, s) => const DiscoveryScreen()),
          GoRoute(path: AppRoutes.matches, builder: (c, s) => const MatchesScreen()),
          GoRoute(path: AppRoutes.leaderboard, builder: (c, s) => const LeaderboardScreen()),
          GoRoute(path: AppRoutes.profile, builder: (c, s) => const ProfileScreen()),
        ],
      ),

      // ── Full-screen Player routes ──────────────────────────
      GoRoute(
        path: AppRoutes.courtDetail,
        builder: (c, s) => CourtDetailScreen(
          courtId: s.pathParameters['courtId']!,
          dealPercent: int.tryParse(s.uri.queryParameters['deal'] ?? ''),
        ),
      ),
      GoRoute(
        path: AppRoutes.booking,
        builder: (c, s) => BookingFlowScreen(
          courtId: s.pathParameters['courtId']!,
          dealPercent: int.tryParse(s.uri.queryParameters['deal'] ?? ''),
          initialDur: int.tryParse(s.uri.queryParameters['dur'] ?? ''),
        ),
      ),
      GoRoute(
        path: AppRoutes.bookingConfirmed,
        builder: (c, s) => BookingConfirmedScreen(
          reference: s.pathParameters['reference']!,
          courtId: s.uri.queryParameters['court'],
          subCourt: int.tryParse(s.uri.queryParameters['sub'] ?? '') ?? 1,
          day: int.tryParse(s.uri.queryParameters['day'] ?? '') ?? 1,
          slot: int.tryParse(s.uri.queryParameters['slot'] ?? '') ?? 1,
          dur: int.tryParse(s.uri.queryParameters['durIdx'] ?? '') ?? 1,
          price: int.tryParse(s.uri.queryParameters['price'] ?? ''),
          players: int.tryParse(s.uri.queryParameters['players'] ?? '') ?? 4,
        ),
      ),
      GoRoute(
        path: AppRoutes.qrTicket,
        builder: (c, s) => QrTicketScreen(
          reference: s.pathParameters['reference']!,
          courtId: s.uri.queryParameters['court'],
          subCourt: int.tryParse(s.uri.queryParameters['sub'] ?? '') ?? 1,
          day: int.tryParse(s.uri.queryParameters['day'] ?? '') ?? 1,
          slot: int.tryParse(s.uri.queryParameters['slot'] ?? '') ?? 1,
          dur: int.tryParse(s.uri.queryParameters['durIdx'] ?? '') ?? 1,
          players: int.tryParse(s.uri.queryParameters['players'] ?? '') ?? 4,
        ),
      ),
      GoRoute(path: AppRoutes.myBookings, builder: (c, s) => const MyBookingsScreen()),
      GoRoute(path: AppRoutes.deals, builder: (c, s) => const DealsScreen()),
      GoRoute(path: AppRoutes.notifications, builder: (c, s) => const NotificationsScreen()),
      GoRoute(path: AppRoutes.friends, builder: (c, s) => const FriendsScreen()),
      GoRoute(path: AppRoutes.addFriends, builder: (c, s) => const AddFriendsScreen()),
      GoRoute(path: AppRoutes.tribes, builder: (c, s) => const FriendsScreen()),
      GoRoute(path: AppRoutes.tribeDetail, builder: (c, s) => const TribeDetailScreen()),
      GoRoute(path: AppRoutes.createTribe, builder: (c, s) => const CreateTribeScreen()),
      GoRoute(path: AppRoutes.inviteTribe, builder: (c, s) => const InviteToTribeScreen()),
      GoRoute(path: AppRoutes.captainReview, builder: (c, s) => const CaptainReviewScreen()),
      GoRoute(path: AppRoutes.settings, builder: (c, s) => const SettingsScreen()),
      GoRoute(path: AppRoutes.deleteAccount, builder: (c, s) => const DeleteAccountScreen()),
      GoRoute(path: AppRoutes.recordScore, builder: (c, s) => const RecordScoreScreen()),
      GoRoute(path: AppRoutes.confirmScore, builder: (c, s) => const ScoreConfirmScreen()),
      GoRoute(path: AppRoutes.rateMatch, builder: (c, s) => const RateMatchScreen()),
      GoRoute(path: AppRoutes.discoverMap, builder: (c, s) => const MapSearchScreen()),
      GoRoute(path: AppRoutes.joinPending, builder: (c, s) => const JoinPendingScreen()),
      GoRoute(path: AppRoutes.coachValidate, builder: (c, s) => const CoachValidateScreen()),
      GoRoute(path: AppRoutes.editProfile, builder: (c, s) => const EditProfileScreen()),

      // ── Matches ──────────────────────────────────────────
      GoRoute(path: AppRoutes.createMatch, builder: (c, s) => const CreateMatchScreen()),
      GoRoute(
        path: AppRoutes.matchDetail,
        builder: (c, s) => MatchDetailScreen(
          matchId: s.pathParameters['matchId']!,
          name: s.uri.queryParameters['name'],
          area: s.uri.queryParameters['area'],
          court: int.tryParse(s.uri.queryParameters['court'] ?? '') ?? 0,
          date: s.uri.queryParameters['date'],
          time: s.uri.queryParameters['time'],
          dur: s.uri.queryParameters['dur'],
          skill: s.uri.queryParameters['skill'],
          spots: s.uri.queryParameters['spots'],
        ),
      ),

      // ── Tournaments ───────────────────────────────────────
      GoRoute(path: AppRoutes.tournaments, builder: (c, s) => const TournamentsScreen()),
      GoRoute(
        path: AppRoutes.tournamentDetail,
        builder: (c, s) => TournamentDetailScreen(id: s.pathParameters['id']!),
      ),

      // ── Coaches ────────────────────────────────────────────
      GoRoute(path: AppRoutes.coaches, builder: (c, s) => const CoachesScreen()),
      GoRoute(
        path: AppRoutes.coachDetail,
        builder: (c, s) => CoachDetailScreen(id: s.pathParameters['id']!),
      ),
      GoRoute(
        path: AppRoutes.bookCoach,
        builder: (c, s) => BookCoachScreen(coachId: s.pathParameters['id']!),
      ),

      // ── Academies ──────────────────────────────────────────
      GoRoute(path: AppRoutes.academies, builder: (c, s) => const AcademiesScreen()),
      GoRoute(
        path: AppRoutes.academyDetail,
        builder: (c, s) => AcademyDetailScreen(id: s.pathParameters['id']!),
      ),

      // ── Teams ──────────────────────────────────────────────
      GoRoute(path: AppRoutes.teams, builder: (c, s) => const TeamsScreen()),
      GoRoute(
        path: AppRoutes.teamDetail,
        builder: (c, s) => TeamDetailScreen(id: s.pathParameters['id']!),
      ),

      // ── Chat ───────────────────────────────────────────────
      GoRoute(path: AppRoutes.chats, builder: (c, s) => const ChatsScreen()),
      GoRoute(
        path: AppRoutes.chatDetail,
        builder: (c, s) => ChatDetailScreen(chatId: s.pathParameters['chatId']!),
      ),

      // ── Social ─────────────────────────────────────────────
      GoRoute(path: AppRoutes.clubs, builder: (c, s) => const ClubsScreen()),
      GoRoute(
        path: AppRoutes.clubDetail,
        builder: (c, s) => ClubDetailScreen(clubId: s.pathParameters['clubId']!),
      ),
      GoRoute(
        path: AppRoutes.playerDetail,
        builder: (c, s) => PlayerDetailScreen(playerId: s.pathParameters['playerId']!),
      ),

      // ── Store ──────────────────────────────────────────────
      GoRoute(path: AppRoutes.store, builder: (c, s) => const ComingSoonScreen()),

      // ── Organizer Shell ────────────────────────────────────
      ShellRoute(
        builder: (c, s, child) => OrganizerShell(child: child),
        routes: [
          GoRoute(path: AppRoutes.organizerDashboard, builder: (c, s) => const OrganizerDashboardScreen()),
          GoRoute(path: AppRoutes.organizerVenues, builder: (c, s) => const OrganizerCourtsScreen()),
          GoRoute(path: AppRoutes.organizerBookings, builder: (c, s) => const OrganizerBookingsScreen()),
          GoRoute(path: AppRoutes.organizerAnalytics, builder: (c, s) => const OrganizerAnalyticsScreen()),
          GoRoute(path: AppRoutes.organizerDeals, builder: (c, s) => const OrganizerDealsScreen()),
        ],
      ),
    ],
  );
});
