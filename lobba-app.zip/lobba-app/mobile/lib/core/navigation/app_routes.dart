/// Route path constants — kept in their own file (no Firebase/router imports) so
/// screens and previews can reference them without pulling in the whole router.
class AppRoutes {
  // ── Auth ────────────────────────────────────────────────
  static const splash = '/';
  static const welcome = '/welcome';
  static const playerSignup = '/signup/player';
  static const organizerSignup = '/signup/organizer';
  static const otp = '/otp';
  static const playerSetup = '/setup/player';
  static const assessment = '/setup/assessment';
  static const organizerKyc = '/kyc/organizer';
  static const organizerPending = '/pending/organizer';

  // ── Player Shell ─────────────────────────────────────────
  static const home = '/home';
  static const discovery = '/discovery';
  static const matches = '/matches';
  static const leaderboard = '/leaderboard';
  static const profile = '/profile';

  // ── Full-screen Player ────────────────────────────────────
  static const courtDetail = '/court/:courtId';
  static const booking = '/booking/:courtId';
  static const bookingConfirmed = '/booking/confirmed/:reference';
  static const qrTicket = '/ticket/:reference';
  static const myBookings = '/bookings/me';
  static const deals = '/deals';
  static const notifications = '/notifications';

  // ── Matches ───────────────────────────────────────────────
  static const createMatch = '/matches/create';
  static const matchDetail = '/matches/:matchId';

  // ── Tournaments ───────────────────────────────────────────
  static const tournaments = '/tournaments';
  static const tournamentDetail = '/tournaments/:id';

  // ── Coaches ───────────────────────────────────────────────
  static const coaches = '/coaches';
  static const coachDetail = '/coaches/:id';
  static const bookCoach = '/coaches/:id/book';

  // ── Academies ─────────────────────────────────────────────
  static const academies = '/academies';
  static const academyDetail = '/academies/:id';

  // ── Teams ─────────────────────────────────────────────────
  static const teams = '/teams';
  static const teamDetail = '/teams/:id';

  // ── Chat ──────────────────────────────────────────────────
  static const chats = '/chats';
  static const chatDetail = '/chats/:chatId';

  // ── Social ────────────────────────────────────────────────
  static const clubs = '/clubs';
  static const clubDetail = '/clubs/:clubId';
  static const playerDetail = '/players/:playerId';

  // ── Profile ───────────────────────────────────────────────
  static const editProfile = '/profile/edit';
  static const store = '/store';

  // ── Social / bookings / flow (rebuilt screens) ────────────
  static const friends = '/friends';
  static const addFriends = '/friends/add';
  static const tribes = '/tribes';
  static const tribeDetail = '/tribes/detail';
  static const settings = '/settings';
  static const deleteAccount = '/settings/delete';
  static const recordScore = '/score';
  static const confirmScore = '/score/confirm';
  static const rateMatch = '/rate';
  static const bookingConfirmedS = '/booking/done';
  static const qrTicketS = '/ticket';
  static const discoverMap = '/discover/map';
  static const createTribe = '/tribes/create';
  static const inviteTribe = '/tribes/invite';
  static const captainReview = '/tribes/review';
  static const joinPending = '/matches/joined';
  static const coachValidate = '/assessment/validate';

  // ── Organizer Shell ───────────────────────────────────────
  static const organizerDashboard = '/organizer/dashboard';
  static const organizerVenues = '/organizer/venues';
  static const organizerCourts = '/organizer/venues';
  static const addCourt = '/organizer/venues';
  static const organizerBookings = '/organizer/bookings';
  static const organizerAnalytics = '/organizer/analytics';
  static const organizerDeals = '/organizer/deals';
}
