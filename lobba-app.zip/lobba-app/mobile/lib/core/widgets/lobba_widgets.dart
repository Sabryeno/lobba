import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../theme/lobba_tokens.dart';

/// A pushed screen with a circular back arrow header + optional trailing action.
class PushScaffold extends StatelessWidget {
  const PushScaffold({super.key, required this.title, required this.child, this.trailing, this.subtitle, this.bottomBar});
  final String title;
  final String? subtitle;
  final Widget child;
  final Widget? trailing;
  final Widget? bottomBar;

  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Scaffold(
      backgroundColor: t.bg,
      body: SafeArea(
        bottom: false,
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 8, 18, 4),
            child: Row(children: [
              GestureDetector(
                onTap: () => context.canPop() ? context.pop() : null,
                child: Container(width: 34, height: 34, decoration: BoxDecoration(color: t.surface, shape: BoxShape.circle, border: Border.all(color: t.line)), child: Icon(Icons.chevron_left_rounded, size: 20, color: t.ink2)),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text(title, style: TextStyle(fontFamily: kSerif, fontSize: 18, fontWeight: FontWeight.w500, color: t.ink)),
                if (subtitle != null) Text(subtitle!, style: TextStyle(fontSize: 10.5, color: t.ink3)),
              ])),
              if (trailing != null) trailing!,
            ]),
          ),
          Expanded(child: child),
        ]),
      ),
      bottomNavigationBar: bottomBar,
    );
  }
}

/// A rounded pill chip.
class LPill extends StatelessWidget {
  const LPill(this.text, {super.key, required this.bg, required this.fg, this.icon});
  final String text; final Color bg, fg; final IconData? icon;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(99)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[Icon(icon, size: 12, color: fg), const SizedBox(width: 4)],
          Text(text, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: fg)),
        ]),
      );
}

/// A circular initial avatar.
class LAvatar extends StatelessWidget {
  const LAvatar(this.ch, {super.key, this.size = 38, this.bg, this.fg});
  final String ch; final double size; final Color? bg, fg;
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Container(width: size, height: size, alignment: Alignment.center,
      decoration: BoxDecoration(color: bg ?? t.surface2, shape: BoxShape.circle),
      child: Text(ch, style: TextStyle(fontFamily: kSerif, fontSize: size * .42, fontWeight: FontWeight.w600, color: fg ?? t.ink2)));
  }
}

/// Uppercase micro-label with wide tracking (the design's "eyebrow").
class Eyebrow extends StatelessWidget {
  const Eyebrow(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) {
    final t = context.t;
    return Text(
      text.toUpperCase(),
      style: TextStyle(
        fontSize: 10.5, fontWeight: FontWeight.w600, letterSpacing: 1.6,
        color: t.ink3, fontFamily: kSans,
      ),
    );
  }
}

/// Serif display number/heading helper.
class Display extends StatelessWidget {
  const Display(this.text, {super.key, this.size = 22, this.color});
  final String text;
  final double size;
  final Color? color;
  @override
  Widget build(BuildContext context) => Text(text,
      style: TextStyle(fontFamily: kSerif, fontSize: size, fontWeight: FontWeight.w500, color: color ?? context.t.ink));
}
