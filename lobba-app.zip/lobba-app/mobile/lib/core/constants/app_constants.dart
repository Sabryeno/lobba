/// Global constants for the Lobba app.
class AppConstants {
  AppConstants._();

  // ── Branding ─────────────────────────────────────────────
  static const String appName = 'Lobba';
  static const String appTagline = 'Your Court. Your Game.';

  // ── API ───────────────────────────────────────────────────
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:3000/api/v1', // Android emulator → host
  );
  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration receiveTimeout = Duration(seconds: 30);
  static const int maxRetries = 3;

  // ── Storage Keys ──────────────────────────────────────────
  static const String keyAccessToken = 'access_token';
  static const String keyRefreshToken = 'refresh_token';
  static const String keyUserId = 'user_id';
  static const String keyUserRole = 'user_role';
  static const String keyLocale = 'locale';
  static const String keyOnboardingDone = 'onboarding_done';
  static const String keyAssessmentDone = 'assessment_done';

  // ── Booking ───────────────────────────────────────────────
  static const List<int> bookingDurations = [60, 90, 120];
  static const int bookingExpiryMinutes = 10;
  static const int maxPlayersPerBooking = 4;

  // ── ELO ───────────────────────────────────────────────────
  static const int defaultEloRating = 1200;
  static const Map<String, String> skillLevelLabels = {
    'BEGINNER': 'Beginner',
    'BEGINNER_PLUS': 'Beginner+',
    'INTERMEDIATE': 'Intermediate',
    'ADVANCED': 'Advanced',
    'EXPERT': 'Expert',
    'ELITE': 'Elite',
  };

  // ── Egypt ─────────────────────────────────────────────────
  static const String countryCode = '+20';
  static const String currency = 'EGP';
  static const List<String> egyptianCities = [
    'Cairo', 'Alexandria', 'Giza', '6th of October', 'New Cairo',
    'Hurghada', 'Sharm El Sheikh', 'Luxor', 'Aswan', 'Mansoura',
    'Tanta', 'Zagazig', 'Ismailia', 'Port Said', 'Suez',
  ];

  // ── Padel Amenities ───────────────────────────────────────
  static const Map<String, String> amenityIcons = {
    'parking': '🅿️',
    'cafe': '☕',
    'showers': '🚿',
    'lockers': '🔒',
    'pro_shop': '🛒',
    'wifi': '📶',
    'ac': '❄️',
    'lighting': '💡',
  };

  // ── Pagination ────────────────────────────────────────────
  static const int defaultPageSize = 20;
  static const int homePageSize = 10;
}
