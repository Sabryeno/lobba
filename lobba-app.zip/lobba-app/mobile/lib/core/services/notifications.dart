import 'dart:async';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Local notifications for court owners — new-booking alerts, with a repeating
/// reminder for unpaid cash bookings.
///
/// Note: the 5-minute repeat runs via an in-app timer, so it fires while the
/// app is alive. A true background repeat (app killed) needs FCM / WorkManager.
class LobbaNotifications {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static Timer? _cashTimer;
  static bool _inited = false;

  static const _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'bookings', 'Bookings',
      channelDescription: 'New booking alerts for court owners',
      importance: Importance.high, priority: Priority.high,
    ),
  );

  static Future<void> init() async {
    if (_inited) return;
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: android));
    try {
      await _plugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    } catch (_) {}
    _inited = true;
  }

  static Future<void> show(String title, String body, {int id = 1}) async {
    await init();
    await _plugin.show(id, title, body, _details);
  }

  /// A confirmed booking arrived — notify the owner once.
  static Future<void> notifyBooking(String who) => show('New booking', '$who just booked a court', id: 10);

  /// Cash booking → notify now and repeat every 5 minutes until [stopCashReminder].
  static Future<void> startCashReminder(String who) async {
    await init();
    await _plugin.show(100, 'New cash booking', '$who booked — collect the deposit', _details);
    _cashTimer?.cancel();
    _cashTimer = Timer.periodic(const Duration(minutes: 5), (_) {
      _plugin.show(100, 'Cash payment reminder', '$who — deposit still pending', _details);
    });
  }

  static void stopCashReminder() {
    _cashTimer?.cancel();
    _cashTimer = null;
    _plugin.cancel(100);
  }
}
