import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;

import '../network/api_client.dart';
import '../../features/booking/providers/booking_provider.dart';
import '../../features/booking/providers/my_bookings_provider.dart';
import '../../features/booking/providers/bookings_provider.dart';

final realtimeProvider = Provider<RealtimeConnection>((ref) {
  final connection = RealtimeConnection(ref);
  connection.connect();
  ref.onDispose(connection.dispose);
  return connection;
});

class RealtimeConnection {
  RealtimeConnection(this.ref);

  final Ref ref;
  static const _storage = FlutterSecureStorage();
  io.Socket? _socket;

  Future<void> connect() async {
    final token = await _storage.read(key: 'access_token');
    if (token == null || token.isEmpty || _socket != null) return;

    final origin = apiBaseUrl.replaceFirst(RegExp(r'/api/v1/?$'), '');
    final socket = io.io(
      '$origin/realtime',
      io.OptionBuilder()
          .setTransports(['websocket'])
          .setAuth({'token': token})
          .enableReconnection()
          .disableAutoConnect()
          .build(),
    );
    _socket = socket;

    for (final event in const [
      'booking.created',
      'booking.updated',
      'booking.cancelled',
      'booking.expired',
      'booking.checked_in',
    ]) {
      socket.on(event, (_) {
        ref.invalidate(myBookingsProvider);
        ref.invalidate(availableSlotsProvider);
        ref.invalidate(bookingsProvider);
      });
    }
    socket.connect();
  }

  void dispose() {
    _socket?.dispose();
    _socket = null;
  }
}
