import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants/app_constants.dart';

// ── Dio instance ─────────────────────────────────────────────────────────────
final dioProvider = Provider<Dio>((ref) {
  final storage = ref.read(secureStorageProvider);
  final dio = Dio(
    BaseOptions(
      baseUrl: AppConstants.apiBaseUrl,
      connectTimeout: AppConstants.connectTimeout,
      receiveTimeout: AppConstants.receiveTimeout,
      headers: {'Content-Type': 'application/json'},
    ),
  );

  // Auth interceptor — attach token + refresh on 401
  dio.interceptors.add(
    InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await storage.read(key: AppConstants.keyAccessToken);
        if (token != null) options.headers['Authorization'] = 'Bearer $token';
        return handler.next(options);
      },
      onError: (error, handler) async {
        if (error.response?.statusCode == 401) {
          try {
            final refreshToken = await storage.read(key: AppConstants.keyRefreshToken);
            if (refreshToken == null) return handler.next(error);

            final resp = await Dio().post(
              '${AppConstants.apiBaseUrl}/auth/token/refresh',
              data: {'refreshToken': refreshToken},
            );
            final newAccess = resp.data['accessToken'];
            final newRefresh = resp.data['refreshToken'];
            await storage.write(key: AppConstants.keyAccessToken, value: newAccess);
            await storage.write(key: AppConstants.keyRefreshToken, value: newRefresh);

            final opts = error.requestOptions;
            opts.headers['Authorization'] = 'Bearer $newAccess';
            final retryResp = await dio.fetch(opts);
            return handler.resolve(retryResp);
          } catch (_) {
            return handler.next(error);
          }
        }
        return handler.next(error);
      },
    ),
  );

  return dio;
});

final secureStorageProvider = Provider<FlutterSecureStorage>((ref) {
  return const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
});

// ── Generic API helpers ───────────────────────────────────────────────────────
extension DioExtensions on Dio {
  Future<T> getJson<T>(
    String path, {
    Map<String, dynamic>? queryParameters,
    T Function(dynamic)? fromJson,
  }) async {
    final resp = await get<Map<String, dynamic>>(path, queryParameters: queryParameters);
    final data = resp.data;
    return fromJson != null ? fromJson(data) : data as T;
  }

  Future<T> postJson<T>(
    String path, {
    dynamic data,
    T Function(dynamic)? fromJson,
  }) async {
    final resp = await post<Map<String, dynamic>>(path, data: data);
    final body = resp.data;
    return fromJson != null ? fromJson(body) : body as T;
  }

  Future<T> patchJson<T>(
    String path, {
    dynamic data,
    T Function(dynamic)? fromJson,
  }) async {
    final resp = await patch<Map<String, dynamic>>(path, data: data);
    final body = resp.data;
    return fromJson != null ? fromJson(body) : body as T;
  }

  Future<void> deleteJson(String path) async {
    await delete(path);
  }
}

// ── Pagination ────────────────────────────────────────────────────────────────
class PaginatedResult<T> {
  final List<T> items;
  final int total;
  final int page;
  final int limit;
  final bool hasMore;

  const PaginatedResult({
    required this.items,
    required this.total,
    required this.page,
    required this.limit,
    required this.hasMore,
  });
}
