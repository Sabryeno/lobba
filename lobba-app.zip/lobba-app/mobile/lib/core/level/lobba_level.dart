import 'package:flutter/widgets.dart';
import '../i18n/lobba_i18n.dart';

/// Lobba levelling — a Playtomic-style 0–7 numeric level with named bands,
/// replacing the old ELO number. A player's level is a double (e.g. 3.0).
class LevelBand {
  final int index;
  final double min, max;
  final String name; // English key — translate with .tr(context)
  final String desc;
  const LevelBand(this.index, this.min, this.max, this.name, this.desc);
  String get range => '${min.toStringAsFixed(0)}–${max.toStringAsFixed(0)}';
}

const kLevelBands = <LevelBand>[
  LevelBand(0, 0, 1, 'Initiation', 'Little or no experience in racket sports and little aptitude to play.'),
  LevelBand(1, 1, 2, 'Initiation Intermediate', 'Just started padel — a learning phase. No tactics or positioning yet; slow returns and difficulty with walls.'),
  LevelBand(2, 2, 3, 'Intermediate', 'You know the most important shots but need court experience; improving control, power and rallies.'),
  LevelBand(3, 3, 4, 'Intermediate Advanced', 'Consistent with medium-speed shots and better positioning, but you still make unforced errors.'),
  LevelBand(4, 4, 5, 'Advanced', 'You anticipate trajectories, control depth and adjust your game plan; forehand & volley have improved.'),
  LevelBand(5, 5, 6, 'Advanced High', 'You dominate your forehand, build points, transition to the net and exploit opponents’ weaknesses.'),
  LevelBand(6, 6, 7, 'Elite', 'You compete at a professional level.'),
];

LevelBand bandFor(double level) => kLevelBands[level.floor().clamp(0, 6)];

/// "Level 3.0" (localised).
String levelText(BuildContext c, double level) => '${'Level'.tr(c)} ${level.toStringAsFixed(1)}';

/// Localised band name for a level.
String bandName(BuildContext c, double level) => bandFor(level).name.tr(c);
