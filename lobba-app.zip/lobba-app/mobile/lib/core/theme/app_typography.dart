import 'package:flutter/material.dart';
import 'app_colors.dart';

/// Typography scale. Arabic uses Tajawal, Latin uses Inter (body) +
/// PlayfairDisplay (display headings). The TextTheme is built once and applied
/// to both LTR and RTL MaterialApp instances.

class AppTypography {
  AppTypography._();

  // ── Font families ─────────────────────────────────────────────────────────
  static const String _arabic = 'Tajawal';
  static const String _latinBody = 'HankenGrotesk';
  static const String _latinDisplay = 'Spectral';

  // ── Base styles (locale-agnostic size/weight, no family) ─────────────────
  static const _base = TextStyle(
    color: AppColors.textPrimary,
    letterSpacing: 0,
    height: 1.4,
  );

  // ── Scale ─────────────────────────────────────────────────────────────────

  /// Large hero heading — court name, onboarding title
  static TextStyle displayLarge(Locale locale) => _base.copyWith(
        fontFamily: _isArabic(locale) ? _arabic : _latinDisplay,
        fontSize: 32,
        fontWeight: FontWeight.w700,
        height: 1.2,
        letterSpacing: _isArabic(locale) ? 0 : -0.5,
      );

  /// Section headings
  static TextStyle headlineMedium(Locale locale) => _base.copyWith(
        fontFamily: _isArabic(locale) ? _arabic : _latinDisplay,
        fontSize: 22,
        fontWeight: FontWeight.w600,
        height: 1.3,
      );

  /// Card titles, screen titles
  static TextStyle titleLarge(Locale locale) => _base.copyWith(
        fontFamily: _isArabic(locale) ? _arabic : _latinBody,
        fontSize: 18,
        fontWeight: FontWeight.w600,
      );

  static TextStyle titleMedium(Locale locale) => _base.copyWith(
        fontFamily: _isArabic(locale) ? _arabic : _latinBody,
        fontSize: 16,
        fontWeight: FontWeight.w600,
      );

  /// Body copy
  static TextStyle bodyLarge(Locale locale) => _base.copyWith(
        fontFamily: _isArabic(locale) ? _arabic : _latinBody,
        fontSize: 16,
        fontWeight: FontWeight.w400,
      );

  static TextStyle bodyMedium(Locale locale) => _base.copyWith(
        fontFamily: _isArabic(locale) ? _arabic : _latinBody,
        fontSize: 14,
        fontWeight: FontWeight.w400,
      );

  static TextStyle bodySmall(Locale locale) => _base.copyWith(
        fontFamily: _isArabic(locale) ? _arabic : _latinBody,
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: AppColors.textSecondary,
      );

  /// Captions, labels
  static TextStyle labelLarge(Locale locale) => _base.copyWith(
        fontFamily: _isArabic(locale) ? _arabic : _latinBody,
        fontSize: 14,
        fontWeight: FontWeight.w500,
      );

  static TextStyle labelSmall(Locale locale) => _base.copyWith(
        fontFamily: _isArabic(locale) ? _arabic : _latinBody,
        fontSize: 11,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.5,
        color: AppColors.textSecondary,
      );

  /// Price display — always prominent
  static TextStyle priceDisplay(Locale locale) => _base.copyWith(
        fontFamily: _isArabic(locale) ? _arabic : _latinBody,
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: AppColors.accent,
      );

  // ── ThemeData TextTheme (uses the active locale) ──────────────────────────
  static TextTheme buildTextTheme(Locale locale) => TextTheme(
        displayLarge: displayLarge(locale),
        headlineMedium: headlineMedium(locale),
        titleLarge: titleLarge(locale),
        titleMedium: titleMedium(locale),
        bodyLarge: bodyLarge(locale),
        bodyMedium: bodyMedium(locale),
        labelLarge: labelLarge(locale),
        labelSmall: labelSmall(locale),
      );

  static bool _isArabic(Locale locale) => locale.languageCode == 'ar';
}
