import 'package:flutter/material.dart';

/// Design token definitions for all 3 palette options.
/// Active palette is [AppColors] — swap the mixin to change theme.
///
/// Palette A: Forest Sanctuary (default — matches user's preference)
/// Palette B: Midnight Oasis
/// Palette C: Royal Garden

// ─── Palette A: Forest Sanctuary ────────────────────────────────────────────
abstract class _PaletteA {
  // Greens
  static const Color primary = Color(0xFF1A4D3C);       // Deep Emerald
  static const Color primaryLight = Color(0xFF2D7A5F);  // Forest Green
  static const Color primarySurface = Color(0xFFE8F4EF); // Mint mist

  // Backgrounds
  static const Color background = Color(0xFFFAF7F2);    // Warm Cream
  static const Color surface = Color(0xFFF5F2ED);       // Off-White
  static const Color surfaceElevated = Color(0xFFFFFFFF);

  // Accent
  static const Color accent = Color(0xFFC9933A);        // Amber Gold
  static const Color accentLight = Color(0xFFEDD9A3);   // Pale Gold

  // Text
  static const Color textPrimary = Color(0xFF1C1C1E);   // Rich Charcoal
  static const Color textSecondary = Color(0xFF6B6B70); // Warm Gray
  static const Color textTertiary = Color(0xFFAEAEB2);  // Muted

  // Semantic
  static const Color success = Color(0xFF34C759);
  static const Color error = Color(0xFFFF3B30);
  static const Color warning = Color(0xFFFF9500);
  static const Color info = Color(0xFF007AFF);

  // Borders & dividers
  static const Color border = Color(0xFFE5E0D8);
  static const Color divider = Color(0xFFF0EDE8);

  // Court type badges
  static const Color indoorBadge = Color(0xFF1A4D3C);
  static const Color outdoorBadge = Color(0xFFC9933A);
}

// ─── Palette B: Midnight Oasis ───────────────────────────────────────────────
abstract class _PaletteB {
  static const Color primary = Color(0xFF0D3D4A);
  static const Color primaryLight = Color(0xFF1B6978);
  static const Color primarySurface = Color(0xFFE5F3F7);
  static const Color background = Color(0xFFF8F6F1);
  static const Color surface = Color(0xFFF3F0E9);
  static const Color surfaceElevated = Color(0xFFFFFFFF);
  static const Color accent = Color(0xFFB87333);
  static const Color accentLight = Color(0xFFE8CEAD);
  static const Color textPrimary = Color(0xFF1A1A2E);
  static const Color textSecondary = Color(0xFF5C6370);
  static const Color textTertiary = Color(0xFFADB5BD);
  static const Color success = Color(0xFF34C759);
  static const Color error = Color(0xFFFF3B30);
  static const Color warning = Color(0xFFFF9500);
  static const Color info = Color(0xFF007AFF);
  static const Color border = Color(0xFFE2DDD4);
  static const Color divider = Color(0xFFEDE9E0);
  static const Color indoorBadge = Color(0xFF0D3D4A);
  static const Color outdoorBadge = Color(0xFFB87333);
}

// ─── Palette C: Royal Garden ─────────────────────────────────────────────────
abstract class _PaletteC {
  static const Color primary = Color(0xFF1E3A2F);
  static const Color primaryLight = Color(0xFF4A7C59);
  static const Color primarySurface = Color(0xFFEBF3EE);
  static const Color background = Color(0xFFFAFAF7);
  static const Color surface = Color(0xFFF7F7F4);
  static const Color surfaceElevated = Color(0xFFFFFFFF);
  static const Color accent = Color(0xFFD4AF37);
  static const Color accentLight = Color(0xFFF2E4A3);
  static const Color textPrimary = Color(0xFF1F2937);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textTertiary = Color(0xFF9CA3AF);
  static const Color success = Color(0xFF10B981);
  static const Color error = Color(0xFFEF4444);
  static const Color warning = Color(0xFFF59E0B);
  static const Color info = Color(0xFF3B82F6);
  static const Color border = Color(0xFFE5E7EB);
  static const Color divider = Color(0xFFF3F4F6);
  static const Color indoorBadge = Color(0xFF1E3A2F);
  static const Color outdoorBadge = Color(0xFFD4AF37);
}

// ─── Active Palette (change this line to switch themes) ──────────────────────
class AppColors extends _PaletteA {
  AppColors._();

  // ── Active palette tokens ──────────────────────────────────────────────────
  // NOTE: Dart does NOT inherit `static` members through `extends`, so the base
  // palette must be re-exposed here. To swap themes, point these at _PaletteB /
  // _PaletteC instead of _PaletteA.
  // ── Sage Atelier tokens (the agreed design system) ───────────────────────
  static const Color primary        = Color(0xFF2F5446); // accent green
  static const Color primaryLight   = Color(0xFF3E6B58);
  static const Color primarySurface = Color(0xFFE2ECE5); // accent-soft
  static const Color background      = Color(0xFFE9EDE7); // page bg
  static const Color surface         = Color(0xFFFFFFFF);
  static const Color surfaceElevated = Color(0xFFFFFFFF);
  static const Color accent      = Color(0xFFC49A52); // muted gold (used sparingly)
  static const Color accentLight = Color(0xFFE7D8B5);
  static const Color textPrimary   = Color(0xFF1F2A24); // ink
  static const Color textSecondary = Color(0xFF5E6B62); // ink-2
  static const Color textTertiary  = Color(0xFF9AA89F); // ink-3
  static const Color success = Color(0xFF5E9B7A); // sage
  static const Color error   = Color(0xFFC2705A); // clay
  static const Color warning = Color(0xFFC49A52); // gold
  static const Color info    = Color(0xFF5E83A8); // slate
  static const Color border  = Color(0xFFDCE4DA); // line
  static const Color divider = Color(0xFFE6ECE2);
  static const Color indoorBadge  = Color(0xFF2F5446);
  static const Color outdoorBadge = Color(0xFFC49A52);

  // ── Extended Primary ──────────────────────────────────────────────────────
  static const Color primaryDark = Color(0xFF223F34);    // frame/dark green
  static const Color textMuted   = Color(0xFF9AA89F);    // alias for textTertiary

  // ── Organizer / Owner Theme (same Sage green as the owner mockups) ─────────
  static const Color organizer = Color(0xFF2F5446);
  static const Color organizerLight = Color(0xFF3E6B58);
  static const Color organizerSurface = Color(0xFFE2ECE5);

  // ── Extended Neutrals ──────────────────────────────────────────────────────
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);
  static const Color grey50  = Color(0xFFFAFAFA);
  static const Color grey100 = Color(0xFFF5F5F5);
  static const Color grey200 = Color(0xFFEEEEEE);
  static const Color grey300 = Color(0xFFE0E0E0);
  static const Color grey400 = Color(0xFFBDBDBD);
  static const Color grey500 = Color(0xFF9E9E9E);
  static const Color grey600 = Color(0xFF757575);
  static const Color grey700 = Color(0xFF616161);
  static const Color grey800 = Color(0xFF424242);
  static const Color grey900 = Color(0xFF212121);

  // ── Booking Status ────────────────────────────────────────────────────────
  static const Color statusConfirmed  = Color(0xFF5E9B7A);
  static const Color statusPending    = Color(0xFFC49A52);
  static const Color statusCancelled  = Color(0xFFC2705A);
  static const Color statusCompleted  = Color(0xFF9AA89F);
  static const Color slotAvailable    = Color(0xFFE2ECE5);
  static const Color slotBooked       = Color(0xFFF3E4DF);
  static const Color slotSelected     = Color(0xFF2F5446);

  // ── ELO / Skill Level ─────────────────────────────────────────────────────
  static const Color eloBeginner    = Color(0xFF95A5A6);
  static const Color eloIntermediate = Color(0xFF3498DB);
  static const Color eloAdvanced    = Color(0xFF9B59B6);
  static const Color eloExpert      = Color(0xFFE67E22);
  static const Color eloElite       = Color(0xFFE74C3C);

  // ── Gradients ────────────────────────────────────────────────────────────
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF3E6B58), Color(0xFF223F34)],
  );
  static const LinearGradient heroGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Colors.transparent, Color(0xCC000000)],
  );
  static const LinearGradient organizerGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [organizer, organizerLight],
  );

  // ── Helpers ───────────────────────────────────────────────────────────────
  static Color forSkillLevel(String level) {
    switch (level.toUpperCase()) {
      case 'BEGINNER':
      case 'BEGINNER_PLUS':
        return eloBeginner;
      case 'INTERMEDIATE':
        return eloIntermediate;
      case 'ADVANCED':
        return eloAdvanced;
      case 'EXPERT':
        return eloExpert;
      case 'ELITE':
        return eloElite;
      default:
        return eloBeginner;
    }
  }

  static Color forBookingStatus(String status) {
    switch (status.toUpperCase()) {
      case 'CONFIRMED':       return statusConfirmed;
      case 'PENDING_PAYMENT': return statusPending;
      case 'CANCELLED':       return statusCancelled;
      case 'COMPLETED':       return statusCompleted;
      default:                return grey400;
    }
  }
}
