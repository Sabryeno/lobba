import 'package:flutter/material.dart';
import 'lobba_tokens.dart';

/// Builds the Sage Atelier (light) and Ink & Brass (dark) Material themes from
/// the LobbaTokens. Screens use `context.t` for exact token colours; this theme
/// just sets sensible Material defaults (fonts, scaffold, inputs, buttons).
class LobbaTheme {
  LobbaTheme._();

  static ThemeData light() => _build(LobbaTokens.light, Brightness.light);
  static ThemeData dark() => _build(LobbaTokens.dark, Brightness.dark);

  static ThemeData _build(LobbaTokens t, Brightness b) {
    final base = ThemeData(brightness: b, useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: t.bg,
      extensions: [t],
      colorScheme: ColorScheme(
        brightness: b,
        primary: t.accent, onPrimary: t.onAccent,
        primaryContainer: t.accentSoft, onPrimaryContainer: t.accent,
        secondary: t.gold, onSecondary: t.onAccent,
        surface: t.surface, onSurface: t.ink,
        error: t.clay, onError: Colors.white,
        outline: t.line,
      ),
      textTheme: base.textTheme.apply(
        fontFamily: kSans,
        bodyColor: t.ink,
        displayColor: t.ink,
      ),
      dividerColor: t.line,
      iconTheme: IconThemeData(color: t.ink, size: 22),
      appBarTheme: AppBarTheme(
        backgroundColor: t.bg, foregroundColor: t.ink, elevation: 0,
        scrolledUnderElevation: 0, centerTitle: false,
        titleTextStyle: TextStyle(fontFamily: kSerif, fontSize: 20, fontWeight: FontWeight.w500, color: t.ink),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: t.surface,
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
        hintStyle: TextStyle(color: t.ink3, fontFamily: kSans),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.line)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.accent, width: 1.5)),
        errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: t.clay)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: t.accent, foregroundColor: t.onAccent, elevation: 0,
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontFamily: kSans, fontSize: 15, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}
