import 'package:flutter/material.dart';

/// The exact Sage Atelier (light) / Ink & Brass (dark) design tokens, exposed as
/// a ThemeExtension so every screen reads the right value for the active theme
/// via `context.t`. These mirror the agreed redesign 1:1.
@immutable
class LobbaTokens extends ThemeExtension<LobbaTokens> {
  final Color bg, surface, surface2, ink, ink2, ink3, line;
  final Color accent, accentSoft, onAccent, frame;
  final Color gold, clay, sage, slate;
  final Color headBg, headFg, headCard, headChipBg, headChipBd;

  const LobbaTokens({
    required this.bg, required this.surface, required this.surface2,
    required this.ink, required this.ink2, required this.ink3, required this.line,
    required this.accent, required this.accentSoft, required this.onAccent, required this.frame,
    required this.gold, required this.clay, required this.sage, required this.slate,
    required this.headBg, required this.headFg, required this.headCard,
    required this.headChipBg, required this.headChipBd,
  });

  static const light = LobbaTokens(
    bg: Color(0xFFE9EDE7), surface: Color(0xFFFFFFFF), surface2: Color(0xFFEEF2EC),
    ink: Color(0xFF1F2A24), ink2: Color(0xFF5E6B62), ink3: Color(0xFF9AA89F), line: Color(0xFFDCE4DA),
    accent: Color(0xFF2F5446), accentSoft: Color(0xFFE2ECE5), onAccent: Color(0xFFFFFFFF), frame: Color(0xFF16201B),
    gold: Color(0xFFC49A52), clay: Color(0xFFC2705A), sage: Color(0xFF5E9B7A), slate: Color(0xFF5E83A8),
    headBg: Color(0xFF2F5446), headFg: Color(0xFFFFFFFF), headCard: Color(0x24FFFFFF),
    headChipBg: Color(0x29FFFFFF), headChipBd: Color(0x4DFFFFFF),
  );

  static const dark = LobbaTokens(
    bg: Color(0xFF1A1E1B), surface: Color(0xFF242A26), surface2: Color(0xFF2D332E),
    ink: Color(0xFFECE7DC), ink2: Color(0xFFA8A89D), ink3: Color(0xFF73776E), line: Color(0xFF343B35),
    accent: Color(0xFFC9A36B), accentSoft: Color(0xFF2C2E25), onAccent: Color(0xFF1A1E1B), frame: Color(0xFF0B0D0C),
    gold: Color(0xFFC49A52), clay: Color(0xFFC2705A), sage: Color(0xFF5E9B7A), slate: Color(0xFF5E83A8),
    headBg: Color(0xFF222824), headFg: Color(0xFFC9A36B), headCard: Color(0xFF2D332E),
    headChipBg: Color(0xFF2D332E), headChipBd: Color(0xFF343B35),
  );

  @override
  LobbaTokens copyWith() => this;

  @override
  LobbaTokens lerp(ThemeExtension<LobbaTokens>? other, double t) {
    if (other is! LobbaTokens) return this;
    Color c(Color a, Color b) => Color.lerp(a, b, t)!;
    return LobbaTokens(
      bg: c(bg, other.bg), surface: c(surface, other.surface), surface2: c(surface2, other.surface2),
      ink: c(ink, other.ink), ink2: c(ink2, other.ink2), ink3: c(ink3, other.ink3), line: c(line, other.line),
      accent: c(accent, other.accent), accentSoft: c(accentSoft, other.accentSoft),
      onAccent: c(onAccent, other.onAccent), frame: c(frame, other.frame),
      gold: c(gold, other.gold), clay: c(clay, other.clay), sage: c(sage, other.sage), slate: c(slate, other.slate),
      headBg: c(headBg, other.headBg), headFg: c(headFg, other.headFg), headCard: c(headCard, other.headCard),
      headChipBg: c(headChipBg, other.headChipBg), headChipBd: c(headChipBd, other.headChipBd),
    );
  }
}

/// Font families (bundled in pubspec).
const kSerif = 'Spectral';      // display / headings / numbers
const kSans = 'HankenGrotesk';  // body / UI

extension LobbaContext on BuildContext {
  LobbaTokens get t => Theme.of(this).extension<LobbaTokens>() ?? LobbaTokens.light;
}
