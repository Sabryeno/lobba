import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'core/theme/lobba_theme.dart';
import 'core/providers/theme_mode_provider.dart';
import 'core/localization/app_localizations.dart';
import 'core/navigation/app_router.dart';
import 'core/network/api_client.dart';
import 'core/services/notifications.dart';
import 'core/services/realtime_service.dart';
import 'features/auth/providers/auth_provider.dart';
import 'features/auth/providers/locale_provider.dart';

/// Background message handler — must be top-level function.
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Firebase is already initialised — nothing more needed here.
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock to portrait on phones; allow landscape on tablets
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );

  // Firebase — gracefully skip if google-services.json / GoogleService-Info.plist
  // is not yet configured (avoids crashes in CI / development without Firebase).
  try {
    await Firebase.initializeApp();
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  } catch (_) {
    // Firebase not configured — push notifications disabled.
  }

  // Local notifications (owner booking alerts).
  try {
    await LobbaNotifications.init();
  } catch (_) {}

  runApp(const ProviderScope(child: Lobba()));
}

class Lobba extends ConsumerWidget {
  const Lobba({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(localeProvider);
    final router = ref.watch(routerProvider);
    ref.watch(realtimeProvider);

    // Register FCM token whenever a user is logged in.
    ref.listen<AsyncValue<dynamic>>(authStateProvider, (_, next) {
      next.whenData((user) {
        if (user != null) _registerFcmToken(ref);
      });
    });

    return MaterialApp.router(
      title: 'Lobba',
      debugShowCheckedModeBanner: false,
      theme: LobbaTheme.light(),
      darkTheme: LobbaTheme.dark(),
      themeMode: ref.watch(themeModeProvider),
      locale: locale,
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      routerConfig: router,
    );
  }
}

/// Request permission + upload FCM token to backend. Fire-and-forget.
Future<void> _registerFcmToken(WidgetRef ref) async {
  try {
    final messaging = FirebaseMessaging.instance;
    final settings = await messaging.requestPermission(
      alert: true, badge: true, sound: true,
    );
    if (settings.authorizationStatus == AuthorizationStatus.denied) return;

    final token = await messaging.getToken();
    if (token == null) return;

    final api = ref.read(apiClientProvider);
    await api.patch('/users/me/fcm-token', data: {'fcmToken': token});

    // Refresh token whenever it rotates.
    FirebaseMessaging.instance.onTokenRefresh.listen((newToken) {
      ref.read(apiClientProvider).patch(
        '/users/me/fcm-token',
        data: {'fcmToken': newToken},
      ).catchError((_) {});
    });
  } catch (_) {
    // Firebase not configured or permission denied — silently skip.
  }
}
