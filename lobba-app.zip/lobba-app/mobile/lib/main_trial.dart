// Lobba — TRIAL build entrypoint.
// Wraps the bundled interactive prototype (assets/trial/index.html) in a WebView
// so testers can tap through the full player flow before the native screens are
// ported. Build:  flutter build apk --release --target=lib/main_trial.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const LobbaTrialApp());
}

class LobbaTrialApp extends StatelessWidget {
  const LobbaTrialApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Lobba (Trial)',
      debugShowCheckedModeBanner: false,
      home: TrialWebView(),
    );
  }
}

class TrialWebView extends StatefulWidget {
  const TrialWebView({super.key});
  @override
  State<TrialWebView> createState() => _TrialWebViewState();
}

class _TrialWebViewState extends State<TrialWebView> {
  late final WebViewController _c;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFE9EDE7))
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) => setState(() => _loading = false),
      ))
      ..loadFlutterAsset('assets/trial/index.html');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF16201B),
      body: SafeArea(
        child: Stack(
          children: [
            WebViewWidget(controller: _c),
            if (_loading)
              const Center(
                child: CircularProgressIndicator(color: Color(0xFF2F5446)),
              ),
          ],
        ),
      ),
    );
  }
}
