// Design-preview entry: renders the new Sage Atelier / Ink & Brass screens in a
// phone frame with a light/dark toggle — NO Firebase/maps/router — so the UI can
// be verified on Flutter web against the mockups.
//   flutter run -d chrome --target=lib/main_preview.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/theme/lobba_theme.dart';
import 'core/theme/lobba_tokens.dart';
import 'features/home/screens/home_screen.dart';
import 'features/profile/screens/player_detail_screen.dart';

void main() => runApp(const ProviderScope(child: _PreviewApp()));

class _PreviewApp extends StatefulWidget {
  const _PreviewApp();
  @override
  State<_PreviewApp> createState() => _PreviewAppState();
}

class _PreviewAppState extends State<_PreviewApp> {
  ThemeMode mode = ThemeMode.light;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: LobbaTheme.light(),
      darkTheme: LobbaTheme.dark(),
      themeMode: mode,
      home: Builder(builder: (context) {
        final t = context.t;
        return Scaffold(
          backgroundColor: const Color(0xFFD9D6CE),
          body: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(vertical: 28),
              child: Column(children: [
                // theme toggle
                ElevatedButton(
                  onPressed: () => setState(() => mode = mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark),
                  child: Text(mode == ThemeMode.dark ? '☾ Ink & Brass' : '☀ Sage Atelier'),
                ),
                const SizedBox(height: 18),
                // phone frame
                Container(
                  width: 320,
                  height: 680,
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(color: t.frame, borderRadius: BorderRadius.circular(42)),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(34),
                    child: const PlayerDetailScreen(playerId: 'Sara Mostafa'),
                  ),
                ),
              ]),
            ),
          ),
        );
      }),
    );
  }
}
